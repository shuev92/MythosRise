package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.engine.SkillTree
import com.mythosrise.game.models.HeroClass

class SkillTreeActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private var skillPoints = 0
    private lateinit var tvSkillPoints: TextView
    private lateinit var llSkillNodes: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skill_tree)
        engine = GameEngine(this)
        engine.loadGame()

        // Skill points = level / 2 (rounded down)
        skillPoints = engine.character.level / 2 - SkillTree.getUnlockedNodes().size.coerceAtMost(engine.character.level / 2)

        tvSkillPoints = findViewById(R.id.tvSkillPoints)
        llSkillNodes = findViewById(R.id.llSkillNodes)

        setupFilterButtons()
        renderTree("Всички")
        updateHeader()
    }

    private fun updateHeader() {
        val c = engine.character
        tvSkillPoints.text = "⭐ Точки Умения: $skillPoints | Ниво ${c.level} | ✨${c.divinity}"
    }

    private fun setupFilterButtons() {
        val categories = listOf("Всички", classLabel(), "Митология", "Универсален")
        val ll = findViewById<LinearLayout>(R.id.llSkillFilters)
        ll.removeAllViews()
        categories.forEach { cat ->
            val btn = Button(this).apply {
                text = cat; textSize = 12f
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C2C2C"))
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(4, 0, 4, 0)
                layoutParams = lp
                setOnClickListener { renderTree(cat) }
            }
            ll.addView(btn)
        }
    }

    private fun classLabel() = when (engine.character.heroClass) {
        HeroClass.WARRIOR -> "Воин"
        HeroClass.MAGE -> "Маг"
        HeroClass.ARCHER -> "Ловец"
        HeroClass.MONK -> "Монах"
    }

    private fun renderTree(filter: String) {
        llSkillNodes.removeAllViews()
        val c = engine.character
        val nodes = SkillTree.ALL_NODES.filter { node ->
            when (filter) {
                "Всички" -> node.heroClass == null || node.heroClass == c.heroClass
                classLabel() -> node.heroClass == c.heroClass
                "Митология" -> node.category == "Митология"
                "Универсален" -> node.heroClass == null
                else -> true
            }
        }

        // Group by tier
        (1..5).forEach { tier ->
            val tierNodes = nodes.filter { it.tier == tier }
            if (tierNodes.isEmpty()) return@forEach

            val tierHeader = TextView(this).apply {
                val tierName = when (tier) { 1 -> "ОСНОВНИ"; 2 -> "НАПРЕДНАЛИ"; 3 -> "МАЙСТОРСКИ"; 4 -> "БОЖЕСТВЕНИ"; else -> "ВСЕБОГ" }
                text = "── ТИР $tier: $tierName ──"
                setTextColor(Color.parseColor(SkillTree.getTierColor(tier)))
                textSize = 14f; isFakeBoldText = true
                setPadding(8, 16, 8, 8)
            }
            llSkillNodes.addView(tierHeader)

            tierNodes.forEach { node -> addNodeView(node) }
        }
    }

    private fun addNodeView(node: com.mythosrise.game.engine.SkillNode) {
        val canUnlock = SkillTree.canUnlock(node, engine.character, skillPoints)
        val tierColor = SkillTree.getTierColor(node.tier)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(
                when {
                    node.unlocked -> Color.parseColor("#0A2A0A")
                    canUnlock -> Color.parseColor("#1A0A2E")
                    else -> Color.parseColor("#0A0A0A")
                }
            )
            alpha = if (node.unlocked || canUnlock) 1.0f else 0.4f
            setPadding(12, 10, 12, 10)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 4, 0, 4)
            layoutParams = lp
        }

        val emojiTv = TextView(this).apply {
            text = if (node.unlocked) "✅" else node.emoji
            textSize = 26f; setPadding(0, 0, 12, 0)
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        TextView(this).apply {
            text = node.name
            setTextColor(Color.parseColor(tierColor)); textSize = 14f; isFakeBoldText = true
        }.also { info.addView(it) }

        TextView(this).apply {
            text = node.description
            setTextColor(Color.LTGRAY); textSize = 12f
        }.also { info.addView(it) }

        // Bonuses
        val bonuses = buildString {
            if (node.attackBonus != 0) append("⚔️+${node.attackBonus} ")
            if (node.defenseBonus != 0) append("🛡️+${node.defenseBonus} ")
            if (node.healthBonus != 0) append("❤️+${node.healthBonus} ")
            if (node.manaBonus != 0) append("💙+${node.manaBonus} ")
            if (node.critChanceBonus != 0f) append("🎯+${(node.critChanceBonus * 100).toInt()}% крит ")
            if (node.divinityGainBonus != 0f) append("✨+${(node.divinityGainBonus * 100).toInt()}% дивинити ")
            if (node.abilityGranted != null) append("🔮 Ново умение!")
        }
        if (bonuses.isNotBlank()) {
            TextView(this).apply {
                text = bonuses; setTextColor(Color.parseColor("#88FF88")); textSize = 11f
            }.also { info.addView(it) }
        }

        // Requirements
        val reqs = buildString {
            append("⭐ ${node.cost} точки")
            if (node.requiredLevel > 1) append(" | Ниво ${node.requiredLevel}")
            if (node.requiredDivinity > 0) append(" | ✨${node.requiredDivinity}")
        }
        TextView(this).apply {
            text = reqs; setTextColor(Color.GRAY); textSize = 10f
        }.also { info.addView(it) }

        val btn = Button(this).apply {
            text = when {
                node.unlocked -> "✅ ОТКЛЮЧЕН"
                canUnlock -> "🔓 ОТКЛЮЧИ"
                else -> "🔒 ЗАКЛЮЧЕН"
            }
            textSize = 10f; setTextColor(Color.WHITE)
            isEnabled = canUnlock
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                when {
                    node.unlocked -> Color.parseColor("#006600")
                    canUnlock -> Color.parseColor("#6A0DAD")
                    else -> Color.parseColor("#333333")
                }
            )
            setOnClickListener {
                AlertDialog.Builder(this@SkillTreeActivity)
                    .setTitle("Отключи: ${node.name}?")
                    .setMessage("Ще похарчиш ${node.cost} точки умения.\n\n${node.description}\n\n$bonuses")
                    .setPositiveButton("Отключи!") { _, _ ->
                        if (SkillTree.unlockNode(node, engine.character)) {
                            skillPoints -= node.cost
                            engine.saveGame()
                            updateHeader()
                            renderTree("Всички")
                            Toast.makeText(this@SkillTreeActivity, "✅ ${node.name} е отключен!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Назад", null)
                    .show()
            }
        }

        row.addView(emojiTv)
        row.addView(info)
        row.addView(btn)
        llSkillNodes.addView(row)
    }
}
