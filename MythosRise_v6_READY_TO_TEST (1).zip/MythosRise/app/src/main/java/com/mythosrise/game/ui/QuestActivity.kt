package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.engine.QuestManager
import com.mythosrise.game.engine.QuestStatus
import com.mythosrise.game.engine.QuestRarity

class QuestActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llQuests: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentFilter = "Активни"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quests)
        engine = GameEngine(this)
        engine.loadGame()

        llQuests = findViewById(R.id.llQuestList)
        tvHeader = findViewById(R.id.tvQuestHeader)

        // Unlock available quests
        QuestManager.unlockAvailableQuests(engine.character)

        setupFilters()
        renderQuests()
    }

    private fun setupFilters() {
        val filters = listOf("Активни", "Налични", "Завършени", "Главни", "Странични")
        val ll = findViewById<LinearLayout>(R.id.llQuestFilters)
        filters.forEach { f ->
            val btn = Button(this).apply {
                text = f; textSize = 12f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (f == currentFilter) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0)
                layoutParams = lp
                setOnClickListener { currentFilter = f; setupFilters(); renderQuests() }
            }
            ll.addView(btn)
        }
    }

    private fun renderQuests() {
        llQuests.removeAllViews()
        val c = engine.character
        val active = QuestManager.getActiveQuests().size
        val completed = QuestManager.getCompletedQuests().size
        val total = QuestManager.ALL_QUESTS.size
        tvHeader.text = "📜 Куестове: $active активни | $completed/$total завършени"

        val quests = when (currentFilter) {
            "Активни" -> QuestManager.getActiveQuests()
            "Налични" -> QuestManager.ALL_QUESTS.filter { it.status == QuestStatus.AVAILABLE }
            "Завършени" -> QuestManager.getCompletedQuests()
            "Главни" -> QuestManager.getMainQuests()
            "Странични" -> QuestManager.ALL_QUESTS.filter { !it.isMainQuest && it.status != QuestStatus.LOCKED }
            else -> QuestManager.ALL_QUESTS
        }

        if (quests.isEmpty()) {
            val tv = TextView(this).apply {
                text = when (currentFilter) {
                    "Активни" -> "Нямаш активни куестове. Приеми такива от 'Налични'!"
                    "Налични" -> "Нямаш налични куестове. Повиши нивото!"
                    "Завършени" -> "Все още не си завършил куест."
                    else -> "Няма куестове."
                }
                setTextColor(Color.GRAY); textSize = 14f; setPadding(16, 24, 16, 16)
            }
            llQuests.addView(tv)
            return
        }

        quests.forEach { quest ->
            val rarityColor = when (quest.rarity) {
                QuestRarity.COMMON -> "#AAAAAA"
                QuestRarity.UNCOMMON -> "#00CC00"
                QuestRarity.RARE -> "#4444FF"
                QuestRarity.EPIC -> "#AA00FF"
                QuestRarity.LEGENDARY -> "#FF8800"
                QuestRarity.DIVINE -> "#FFD700"
            }
            val bgColor = when (quest.status) {
                QuestStatus.ACTIVE -> "#0A1A2A"
                QuestStatus.COMPLETED -> "#0A1A0A"
                QuestStatus.AVAILABLE -> "#1A0A1A"
                else -> "#0A0A0A"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor(bgColor))
                setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 6, 0, 6)
                layoutParams = lp
            }

            // Title row
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply {
                text = "${quest.emoji} "
                textSize = 22f
            }.also { titleRow.addView(it) }
            val titleInfo = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = buildString {
                    if (quest.isMainQuest) append("🌟 ")
                    append(quest.title)
                }
                setTextColor(Color.parseColor(rarityColor)); textSize = 15f; isFakeBoldText = true
            }.also { titleInfo.addView(it) }
            TextView(this).apply {
                text = "📖 ${quest.giver} | ${quest.rarity.name.lowercase().replaceFirstChar { it.uppercase() }}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { titleInfo.addView(it) }
            titleRow.addView(titleInfo)

            val statusEmoji = when (quest.status) {
                QuestStatus.ACTIVE -> "🔵"
                QuestStatus.COMPLETED -> "✅"
                QuestStatus.AVAILABLE -> "🟡"
                else -> "🔒"
            }
            TextView(this).apply { text = statusEmoji; textSize = 20f }.also { titleRow.addView(it) }
            card.addView(titleRow)

            // Description
            TextView(this).apply {
                text = quest.description
                setTextColor(Color.LTGRAY); textSize = 12f
                setPadding(0, 6, 0, 6)
            }.also { card.addView(it) }

            // Objectives
            quest.objectives.forEach { obj ->
                val objRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 2, 0, 2) }
                val doneColor = if (obj.isComplete) "#00CC00" else "#AAAAAA"
                TextView(this).apply {
                    text = if (obj.isComplete) "✅ " else "⬜ "
                    textSize = 14f
                }.also { objRow.addView(it) }
                val objInfo = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                TextView(this).apply {
                    text = "${obj.description}: ${obj.progress}"
                    setTextColor(Color.parseColor(doneColor)); textSize = 12f
                }.also { objInfo.addView(it) }
                if (obj.progressTarget > 1) {
                    val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                        max = obj.progressTarget; progress = obj.currentCount
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12)
                        progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(doneColor))
                    }
                    objInfo.addView(pb)
                }
                objRow.addView(objInfo)
                card.addView(objRow)
            }

            // Rewards
            val r = quest.reward
            val rewardText = buildString {
                if (r.gold > 0) append("💰${r.gold} ")
                if (r.exp > 0) append("⭐${r.exp} ")
                if (r.divinity > 0) append("✨${r.divinity} ")
                if (r.itemId != null) append("🎁Предмет ")
                if (r.skillPoints > 0) append("🌟${r.skillPoints} точки умения ")
                if (r.title != null) append("👑${r.title}")
            }
            TextView(this).apply {
                text = "🏆 Награди: $rewardText"
                setTextColor(Color.parseColor("#FFD700")); textSize = 11f; setPadding(0, 4, 0, 4)
            }.also { card.addView(it) }

            // Button
            when (quest.status) {
                QuestStatus.AVAILABLE -> {
                    Button(this).apply {
                        text = "✅ ПРИЕМИ КУЕСТ"
                        setTextColor(Color.WHITE)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0DAD"))
                        setOnClickListener {
                            QuestManager.acceptQuest(quest)
                            engine.saveGame()
                            Toast.makeText(this@QuestActivity, "📜 Куест приет: ${quest.title}", Toast.LENGTH_SHORT).show()
                            renderQuests()
                        }
                    }.also { card.addView(it) }
                }
                QuestStatus.ACTIVE -> {
                    TextView(this).apply {
                        text = "🔵 В прогрес — бий врагове за да напредваш!"
                        setTextColor(Color.parseColor("#4488FF")); textSize = 12f
                    }.also { card.addView(it) }
                }
                QuestStatus.COMPLETED -> {
                    TextView(this).apply {
                        text = "✅ ЗАВЪРШЕН! Наградата е получена."
                        setTextColor(Color.parseColor("#00CC00")); textSize = 12f
                    }.also { card.addView(it) }
                }
                else -> {}
            }

            // Tap for lore
            card.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("${quest.emoji} ${quest.title}")
                    .setMessage("📖 Лор:\n${quest.lore}\n\n🎯 Даден от: ${quest.giver}\n\n📋 Изисквания: Ниво ${quest.requiredLevel}${if (quest.requiredDivinity > 0) ", ✨${quest.requiredDivinity} Дивинити" else ""}")
                    .setPositiveButton("Затвори", null)
                    .show()
            }

            llQuests.addView(card)
        }
    }
}
