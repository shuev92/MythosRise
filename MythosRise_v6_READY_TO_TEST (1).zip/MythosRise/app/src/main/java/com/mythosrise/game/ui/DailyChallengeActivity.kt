package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*
import com.mythosrise.game.models.Character
import java.util.Calendar

class DailyChallengeActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llChallenges: LinearLayout
    private lateinit var tvHeader: TextView
    private lateinit var tvEvent: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvCompletion: TextView
    private var countdownTimer: CountDownTimer? = null
    private val todayChallenges = mutableListOf<DailyChallenge>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_challenge)
        engine = GameEngine(this)
        engine.loadGame()

        llChallenges = findViewById(R.id.llDailyChallenges)
        tvHeader = findViewById(R.id.tvDailyHeader)
        tvEvent = findViewById(R.id.tvDailyEvent)
        tvTimer = findViewById(R.id.tvDailyTimer)
        tvCompletion = findViewById(R.id.tvDailyCompletion)

        loadChallenges()
        showSpecialEvent()
        startCountdown()
        renderChallenges()
    }

    private fun loadChallenges() {
        todayChallenges.clear()
        todayChallenges.addAll(DailyChallengeManager.getTodaysChallenges(engine.character))
    }

    private fun showSpecialEvent() {
        val event = DailyChallengeManager.getTodaysEvent()
        if (event != null) {
            tvEvent.visibility = android.view.View.VISIBLE
            tvEvent.text = buildString {
                append("🎉 СПЕЦИАЛНО СЪБИТИЕ: ${event.title}\n")
                append("${event.description}\n")
                append("⏱ Продължава ${event.durationDays} ден(а)")
            }
            tvEvent.setTextColor(Color.parseColor("#FFD700"))
            tvEvent.setBackgroundColor(Color.parseColor("#1A0A00"))
        } else {
            tvEvent.visibility = android.view.View.GONE
        }
    }

    private fun startCountdown() {
        val cal = Calendar.getInstance()
        val millisUntilMidnight = run {
            val midnight = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            midnight.timeInMillis - cal.timeInMillis
        }

        countdownTimer = object : CountDownTimer(millisUntilMidnight, 1000) {
            override fun onTick(ms: Long) {
                val h = ms / 3600000
                val m = (ms % 3600000) / 60000
                val s = (ms % 60000) / 1000
                tvTimer.text = "⏰ Нови предизвикателства след: %02d:%02d:%02d".format(h, m, s)
            }
            override fun onFinish() { tvTimer.text = "⏰ Нови предизвикателства са налични!" }
        }.start()
    }

    private fun renderChallenges() {
        llChallenges.removeAllViews()
        val completed = todayChallenges.count { it.completed }
        tvHeader.text = "📅 ДНЕВНИ ПРЕДИЗВИКАТЕЛСТВА"
        tvCompletion.text = "✅ Изпълнени: ${DailyChallengeManager.getCompletionRate(todayChallenges)}"

        if (completed == todayChallenges.size) {
            val bonusTv = TextView(this).apply {
                text = "🏆 ВСИЧКИ ИЗПЪЛНЕНИ! Елитен бонус отключен!"
                setTextColor(Color.parseColor("#FFD700"))
                textSize = 16f; isFakeBoldText = true
                gravity = android.view.Gravity.CENTER
                setPadding(8, 16, 8, 8)
            }
            llChallenges.addView(bonusTv)
        }

        todayChallenges.forEach { ch ->
            val diffColor = when (ch.difficulty) {
                "Лесна" -> "#00CC00"; "Средна" -> "#FFAA00"; "Трудна" -> "#FF4444"
                else -> "#AAAAAA"
            }
            val bgColor = when {
                ch.claimed -> "#0A0A0A"
                ch.completed -> "#0A1A0A"
                else -> "#0A0A1A"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor(bgColor))
                setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 6, 0, 6)
                layoutParams = lp
                alpha = if (ch.claimed) 0.5f else 1.0f
            }

            val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply { text = ch.emoji; textSize = 26f; setPadding(0, 0, 10, 0) }.also { row1.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = ch.title; setTextColor(Color.WHITE); textSize = 15f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "[${ch.difficulty}] ${ch.description}"
                setTextColor(Color.parseColor(diffColor)); textSize = 12f
            }.also { info.addView(it) }
            row1.addView(info)
            val statusTv = TextView(this).apply {
                text = when { ch.claimed -> "✅"; ch.completed -> "🎁"; else -> "" }
                textSize = 22f
            }
            row1.addView(statusTv)
            card.addView(row1)

            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = ch.targetValue; progress = ch.currentValue
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 16).apply { setMargins(0, 6, 0, 2) }
                progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(diffColor))
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#222222"))
            }
            card.addView(pb)
            TextView(this).apply {
                text = "${ch.currentValue}/${ch.targetValue}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { card.addView(it) }

            val rewardText = buildString {
                if (ch.goldReward > 0) append("💰+${ch.goldReward} ")
                if (ch.divinityReward > 0) append("✨+${ch.divinityReward} ")
                if (ch.expReward > 0) append("⭐+${ch.expReward} ")
                if (ch.skillPointReward > 0) append("🌟+${ch.skillPointReward} точки")
            }
            TextView(this).apply {
                text = "🏆 $rewardText"; setTextColor(Color.parseColor("#FFD700")); textSize = 12f
            }.also { card.addView(it) }

            if (ch.completed && !ch.claimed) {
                Button(this).apply {
                    text = "🎁 ВЗЕМИ НАГРАДА!"; setTextColor(Color.WHITE)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#006600"))
                    setOnClickListener {
                        val msg = DailyChallengeManager.claimReward(ch, engine.character)
                        engine.saveGame()
                        AlertDialog.Builder(this@DailyChallengeActivity)
                            .setTitle("🎁 Награда взета!")
                            .setMessage(msg)
                            .setPositiveButton("🎉 Супер!", null)
                            .show()
                        renderChallenges()
                    }
                }.also { card.addView(it) }
            }

            llChallenges.addView(card)
        }

        // All completed bonus
        if (completed == todayChallenges.size && todayChallenges.all { it.claimed }) {
            val allDone = Button(this).apply {
                text = "🏆 ВЗЕМИ ЕЛИТЕН БОНУС (+1000✨ +5000💰)"
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0DAD"))
            }
            llChallenges.addView(allDone)
        }
    }

    override fun onDestroy() { super.onDestroy(); countdownTimer?.cancel() }
}
