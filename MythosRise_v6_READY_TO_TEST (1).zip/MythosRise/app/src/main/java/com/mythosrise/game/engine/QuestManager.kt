package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.World

// ─────────────────────────────────────────────
//  QUEST TYPES & STATUS
// ─────────────────────────────────────────────

enum class QuestType { KILL, COLLECT, EXPLORE, ABSORB, SURVIVE, CRAFT, BOSS }
enum class QuestStatus { LOCKED, AVAILABLE, ACTIVE, COMPLETED, FAILED }
enum class QuestRarity(val color: String) {
    COMMON("#AAAAAA"), UNCOMMON("#00CC00"), RARE("#4444FF"),
    EPIC("#AA00FF"), LEGENDARY("#FF8800"), DIVINE("#FFD700")
}

// ─────────────────────────────────────────────
//  QUEST OBJECTIVE
// ─────────────────────────────────────────────

data class QuestObjective(
    val description: String,
    val type: QuestType,
    val targetId: String,       // enemy id, item id, world name, etc.
    val targetCount: Int,
    var currentCount: Int = 0
) {
    val isComplete get() = currentCount >= targetCount
    val progress get() = "$currentCount/$targetCount"
}

// ─────────────────────────────────────────────
//  QUEST REWARD
// ─────────────────────────────────────────────

data class QuestReward(
    val gold: Int = 0,
    val exp: Long = 0,
    val divinity: Int = 0,
    val itemId: String? = null,
    val abilityId: String? = null,
    val skillPoints: Int = 0,
    val title: String? = null
)

// ─────────────────────────────────────────────
//  QUEST
// ─────────────────────────────────────────────

data class Quest(
    val id: String,
    val title: String,
    val description: String,
    val lore: String,
    val emoji: String,
    val rarity: QuestRarity,
    val objectives: List<QuestObjective>,
    val reward: QuestReward,
    val requiredLevel: Int = 1,
    val requiredDivinity: Int = 0,
    val requiredWorld: World? = null,
    val prerequisites: List<String> = emptyList(),
    var status: QuestStatus = QuestStatus.LOCKED,
    val isMainQuest: Boolean = false,
    val chapter: Int = 0,
    val giver: String = "Мистериозен старец"
)

// ─────────────────────────────────────────────
//  QUEST DATABASE
// ─────────────────────────────────────────────

object QuestManager {

    val ALL_QUESTS = mutableListOf(

        // ════════════════════════════════
        //  ГЛАВА 1: ПРОБУЖДАНЕ (Main Quest)
        // ════════════════════════════════
        Quest(
            id = "mq_01_awakening",
            title = "Пробуждането",
            description = "Убий 5 бандита и докажи, че си достоен за нещо повече.",
            lore = "Всяка легенда започва с първата стъпка. Твоята е тук, в праха на смъртното кралство.",
            emoji = "⚔️", rarity = QuestRarity.COMMON,
            objectives = listOf(QuestObjective("Убий 5 бандита", QuestType.KILL, "bandit", 5)),
            reward = QuestReward(gold = 200, exp = 300, divinity = 10),
            requiredLevel = 1, isMainQuest = true, chapter = 1,
            giver = "Старецът Теос", status = QuestStatus.AVAILABLE
        ),
        Quest(
            id = "mq_02_first_power",
            title = "Първата Сила",
            description = "Погълни силите на 3 врага. Научи какво означава да поглъщаш.",
            lore = "Способността ти да поглъщаш е уникална в историята. Никой бог не е имал такава сила.",
            emoji = "🌀", rarity = QuestRarity.UNCOMMON,
            objectives = listOf(QuestObjective("Погълни силите на 3 врага", QuestType.ABSORB, "any", 3)),
            reward = QuestReward(gold = 500, exp = 800, divinity = 50, skillPoints = 1),
            requiredLevel = 2, isMainQuest = true, chapter = 1,
            prerequisites = listOf("mq_01_awakening"), giver = "Старецът Теос"
        ),
        Quest(
            id = "mq_03_dragon_blood",
            title = "Кръвта на Дракона",
            description = "Убий Огнен Дракон и погълни силата му.",
            lore = "Драконите са по-стари от боговете. Тяхната кръв тече в жилите на вечността.",
            emoji = "🐉", rarity = QuestRarity.RARE,
            objectives = listOf(
                QuestObjective("Убий Огнен Дракон", QuestType.KILL, "fire_dragon", 1),
                QuestObjective("Погълни дракон сила", QuestType.ABSORB, "dragon", 1)
            ),
            reward = QuestReward(gold = 2000, exp = 3000, divinity = 200, itemId = "fire_dragon_fang"),
            requiredLevel = 16, isMainQuest = true, chapter = 2,
            prerequisites = listOf("mq_02_first_power"), giver = "Дракон Мъдрецът"
        ),
        Quest(
            id = "mq_04_olympus",
            title = "Пред Портите на Олимп",
            description = "Победи трима Гръцки богове и заяви правата си.",
            lore = "Олимп не приема смъртни. Но ти вече не си смъртен, нали?",
            emoji = "🏛️", rarity = QuestRarity.EPIC,
            objectives = listOf(
                QuestObjective("Убий Циклоп", QuestType.KILL, "cyclops", 1),
                QuestObjective("Убий Медуза", QuestType.KILL, "medusa", 1),
                QuestObjective("Убий Минотавър", QuestType.KILL, "minotaur", 1)
            ),
            reward = QuestReward(gold = 5000, exp = 8000, divinity = 500, abilityId = "thunder_god", skillPoints = 2),
            requiredLevel = 8, isMainQuest = true, chapter = 2,
            prerequisites = listOf("mq_03_dragon_blood"), giver = "Хермес"
        ),
        Quest(
            id = "mq_05_zeus",
            title = "Цареубийство",
            description = "Изправи се срещу Зевс. Само един може да управлява небесата.",
            lore = "Зевс вярва, че е непобедим. Докажи му обратното.",
            emoji = "⚡", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(QuestObjective("Победи Зевс", QuestType.BOSS, "zeus", 1)),
            reward = QuestReward(gold = 15000, exp = 20000, divinity = 1500,
                itemId = "zeus_lightning", skillPoints = 3, title = "Цареубиец"),
            requiredLevel = 12, isMainQuest = true, chapter = 2,
            prerequisites = listOf("mq_04_olympus"), giver = "Прометей"
        ),
        Quest(
            id = "mq_06_allgod",
            title = "ПЪТЯТ КЪМ ВСЕБОГА",
            description = "Победи Хаос и стани абсолютният Всебог.",
            lore = "В началото беше Хаос. В края — ти. Всичко трябваше да стигне до тук.",
            emoji = "🌌", rarity = QuestRarity.DIVINE,
            objectives = listOf(
                QuestObjective("Победи Хаос", QuestType.BOSS, "primordial", 1),
                QuestObjective("Достигни 50000 Дивинити", QuestType.ABSORB, "divinity", 50000)
            ),
            reward = QuestReward(gold = 999999, exp = 1000000, divinity = 10000,
                itemId = "omnigod_crown", title = "ВСЕБОГ", skillPoints = 10),
            requiredLevel = 45, isMainQuest = true, chapter = 5,
            prerequisites = listOf("mq_05_zeus"), giver = "Самото Съдбоносие"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — ГЪРЦИЯ
        // ════════════════════════════════
        Quest(
            id = "sq_hercules_labor",
            title = "12-те Подвига на Херакъл",
            description = "Убий Лернейската Хидра, Цербер и Медуза.",
            lore = "Херакъл ги е правил. Можеш ли ти?",
            emoji = "💪", rarity = QuestRarity.EPIC,
            objectives = listOf(
                QuestObjective("Убий Хидрата", QuestType.KILL, "hydra", 1),
                QuestObjective("Убий Цербер", QuestType.KILL, "cerberus", 1),
                QuestObjective("Убий Медуза", QuestType.KILL, "medusa", 1)
            ),
            reward = QuestReward(gold = 8000, exp = 10000, divinity = 600,
                itemId = "golden_fleece", skillPoints = 2),
            requiredLevel = 10, giver = "Духът на Херакъл"
        ),
        Quest(
            id = "sq_poseidon_wrath",
            title = "Гневът на Посейдон",
            description = "Морето е разбушувало се. Успокой го.",
            lore = "Посейдон е ядосан. Някой е откраднал трезъбеца му.",
            emoji = "🌊", rarity = QuestRarity.RARE,
            objectives = listOf(QuestObjective("Намери Трезъбеца", QuestType.COLLECT, "poseidon_trident", 1)),
            reward = QuestReward(gold = 4000, exp = 5000, divinity = 300, itemId = "poseidon_trident"),
            requiredLevel = 7, giver = "Нереида"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — ЕГИПЕТ
        // ════════════════════════════════
        Quest(
            id = "sq_pyramid_secret",
            title = "Тайната на Пирамидата",
            description = "Открий какво се крие вътре. Убий 10 мумии.",
            lore = "Пирамидите крият тайни от 3000 години. Ти ще ги разкриеш.",
            emoji = "🏺", rarity = QuestRarity.UNCOMMON,
            objectives = listOf(QuestObjective("Убий 10 мумии", QuestType.KILL, "mummy", 10)),
            reward = QuestReward(gold = 1500, exp = 2000, divinity = 80, itemId = "scarab_amulet"),
            requiredLevel = 13, giver = "Египетски Жрец"
        ),
        Quest(
            id = "sq_ra_blessing",
            title = "Благословията на Ра",
            description = "Докажи се пред слънчевия бог.",
            lore = "Ра не благославя лесно. Трябва да победиш тъмнината.",
            emoji = "☀️", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(
                QuestObjective("Убий Апеп", QuestType.BOSS, "apep", 1),
                QuestObjective("Убий Сет", QuestType.BOSS, "set_god", 1)
            ),
            reward = QuestReward(gold = 12000, exp = 15000, divinity = 1000, itemId = "ra_staff", skillPoints = 2),
            requiredLevel = 17, giver = "Жрецът на Ра"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — ДРАКОНИ
        // ════════════════════════════════
        Quest(
            id = "sq_dragon_hunter",
            title = "Дракон Ловец",
            description = "Убий 5 дракони от различни видове.",
            lore = "Само истински герой може да убие 5 дракона.",
            emoji = "🐉", rarity = QuestRarity.EPIC,
            objectives = listOf(
                QuestObjective("Убий Огнен Дракон", QuestType.KILL, "fire_dragon", 1),
                QuestObjective("Убий Ледена Дракониха", QuestType.KILL, "ice_dragon", 1),
                QuestObjective("Убий Сенчест Дракон", QuestType.KILL, "shadow_dragon", 1),
                QuestObjective("Убий Нидхог", QuestType.KILL, "nidhogg", 1),
                QuestObjective("Убий Уиверн", QuestType.KILL, "wyvern", 2)
            ),
            reward = QuestReward(gold = 10000, exp = 12000, divinity = 800,
                itemId = "dragon_scale_armor", skillPoints = 2),
            requiredLevel = 18, giver = "Дракон Ловецът Вортан"
        ),
        Quest(
            id = "sq_tiamat_revenge",
            title = "Отмъщението на Тиамат",
            description = "Тиамат е майката на всички дракони. Тя идва за теб.",
            lore = "Убил си децата й. Сега тя лично ще те накаже.",
            emoji = "🌊", rarity = QuestRarity.DIVINE,
            objectives = listOf(QuestObjective("Победи Тиамат", QuestType.BOSS, "tiamat", 1)),
            reward = QuestReward(gold = 30000, exp = 40000, divinity = 3000,
                itemId = "tiamat_scale", skillPoints = 4),
            requiredLevel = 24, prerequisites = listOf("sq_dragon_hunter"),
            giver = "Вавилонски Жрец"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — ЯПОНИЯ
        // ════════════════════════════════
        Quest(
            id = "sq_samurai_honor",
            title = "Самурайска Чест",
            description = "Победи 20 Они демони с чест.",
            lore = "Самураят не се бие за слава. Той се бие защото това е правилно.",
            emoji = "⛩️", rarity = QuestRarity.RARE,
            objectives = listOf(QuestObjective("Убий 20 Они", QuestType.KILL, "oni", 20)),
            reward = QuestReward(gold = 5000, exp = 6000, divinity = 350, itemId = "katana_of_storms"),
            requiredLevel = 24, giver = "Самурайски Дух"
        ),
        Quest(
            id = "sq_orochi_blade",
            title = "Мечът от Орочи",
            description = "В опашката на Ямата-но-Орочи се крие легендарен меч.",
            lore = "Сусаноо го е направил веднъж. Сега ти трябва да го повториш.",
            emoji = "🗡️", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(QuestObjective("Убий Орочи", QuestType.BOSS, "yamata_no_orochi", 1)),
            reward = QuestReward(gold = 20000, exp = 25000, divinity = 2000, itemId = "kusanagi", skillPoints = 3),
            requiredLevel = 26, giver = "Духът на Сусаноо"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — КИТАЙ
        // ════════════════════════════════
        Quest(
            id = "sq_monkey_king",
            title = "По-Велик от Маймунския Крал",
            description = "Ву Конг предизвиква всеки. Прие ли предизвикателството?",
            lore = "Ву Конг е победил небесните армии. Но не е срещнал теб.",
            emoji = "🐒", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(QuestObjective("Победи Сун Ву Конг", QuestType.BOSS, "sun_wukong", 1)),
            reward = QuestReward(gold = 25000, exp = 30000, divinity = 2500,
                itemId = "ruyi_jingu_bang", skillPoints = 3),
            requiredLevel = 30, giver = "Нефритеният Цар"
        ),
        Quest(
            id = "sq_dragon_pearl",
            title = "Перлата на Дракона",
            description = "Намери Перлата на Дракон Краля.",
            lore = "Перлата носи безкрайна мъдрост. Ако можеш да я вземеш.",
            emoji = "🐲", rarity = QuestRarity.EPIC,
            objectives = listOf(QuestObjective("Победи Дракон Краля", QuestType.BOSS, "dragon_king", 1)),
            reward = QuestReward(gold = 15000, exp = 18000, divinity = 1200, itemId = "dragon_pearl"),
            requiredLevel = 28, giver = "Небесен Вестител"
        ),

        // ════════════════════════════════
        //  СТРАНИЧНИ КУЕСТОВЕ — СКАНДИНАВИЯ
        // ════════════════════════════════
        Quest(
            id = "sq_ragnarok_prep",
            title = "Подготовка за Рагнарок",
            description = "Убий Фенрир, Нидхог и Тор преди Рагнарок.",
            lore = "Рагнарок идва. Ако го спреш — историята ще се промени завинаги.",
            emoji = "⚡", rarity = QuestRarity.DIVINE,
            objectives = listOf(
                QuestObjective("Убий Фенрир", QuestType.KILL, "fenrir", 1),
                QuestObjective("Убий Нидхог", QuestType.KILL, "nidhogg", 1),
                QuestObjective("Убий Тор", QuestType.BOSS, "thor", 1)
            ),
            reward = QuestReward(gold = 20000, exp = 25000, divinity = 2000,
                itemId = "mjolnir", skillPoints = 3),
            requiredLevel = 32, giver = "Один"
        ),

        // ════════════════════════════════
        //  АРЕНА КУЕСТОВЕ
        // ════════════════════════════════
        Quest(
            id = "sq_arena_rookie",
            title = "Арена Новак",
            description = "Оцелей до вълна 3 в Арената.",
            lore = "Арената не прощава слабост.",
            emoji = "🏟️", rarity = QuestRarity.COMMON,
            objectives = listOf(QuestObjective("Оцелей до вълна 3", QuestType.SURVIVE, "arena_wave_3", 1)),
            reward = QuestReward(gold = 500, exp = 600, divinity = 30),
            requiredLevel = 25, giver = "Арена Организатор"
        ),
        Quest(
            id = "sq_arena_master",
            title = "Арена Майстор",
            description = "Завърши всички 10 вълни в Арената.",
            lore = "Никой не е завършвал всички 10 вълни. Докато сега.",
            emoji = "🏆", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(QuestObjective("Завърши вълна 10", QuestType.SURVIVE, "arena_wave_10", 1)),
            reward = QuestReward(gold = 20000, exp = 25000, divinity = 1500,
                itemId = "war_banner", skillPoints = 3),
            requiredLevel = 25, prerequisites = listOf("sq_arena_rookie"),
            giver = "Арена Легенда"
        ),

        // ════════════════════════════════
        //  СПЕЦИАЛНИ КУЕСТОВЕ
        // ════════════════════════════════
        Quest(
            id = "sq_power_absorber",
            title = "Колекционер на Сили",
            description = "Погълни силите на 20 различни врага.",
            lore = "Всяка поглъщане те прави по-силен. До кога?",
            emoji = "🌀", rarity = QuestRarity.EPIC,
            objectives = listOf(QuestObjective("Погълни 20 различни сили", QuestType.ABSORB, "unique", 20)),
            reward = QuestReward(gold = 8000, exp = 10000, divinity = 700, skillPoints = 2),
            requiredLevel = 15, giver = "Мистериозен Старец"
        ),
        Quest(
            id = "sq_god_slayer",
            title = "Убиецът на Богове",
            description = "Убий 5 различни богове от различни митологии.",
            lore = "Боговете вярват, че са вечни. Докажи им обратното.",
            emoji = "⚡", rarity = QuestRarity.DIVINE,
            objectives = listOf(QuestObjective("Убий 5 богове", QuestType.KILL, "god", 5)),
            reward = QuestReward(gold = 50000, exp = 60000, divinity = 5000,
                skillPoints = 5, title = "Богоубиец Легендарен"),
            requiredLevel = 20, giver = "Антибог"
        ),
        Quest(
            id = "sq_world_traveler",
            title = "Пътешественик на Световете",
            description = "Посети всички 12 свята.",
            lore = "Малцина са виждали всички свята. Ти ще бъдеш от тях.",
            emoji = "🌍", rarity = QuestRarity.LEGENDARY,
            objectives = listOf(QuestObjective("Посети 12 свята", QuestType.EXPLORE, "world", 12)),
            reward = QuestReward(gold = 30000, exp = 40000, divinity = 3000, skillPoints = 4),
            requiredLevel = 35, giver = "Хермес"
        )
    )

    // ─────────────────────────────────────────────
    //  QUEST LOGIC
    // ─────────────────────────────────────────────

    fun getActiveQuests() = ALL_QUESTS.filter { it.status == QuestStatus.ACTIVE }
    fun getAvailableQuests(character: Character) = ALL_QUESTS.filter { quest ->
        quest.status == QuestStatus.LOCKED &&
        character.level >= quest.requiredLevel &&
        character.divinity >= quest.requiredDivinity &&
        quest.prerequisites.all { prereqId ->
            ALL_QUESTS.find { it.id == prereqId }?.status == QuestStatus.COMPLETED
        }
    }
    fun getCompletedQuests() = ALL_QUESTS.filter { it.status == QuestStatus.COMPLETED }
    fun getMainQuests() = ALL_QUESTS.filter { it.isMainQuest }

    fun acceptQuest(quest: Quest) {
        quest.status = QuestStatus.ACTIVE
    }

    fun updateQuestProgress(eventType: QuestType, targetId: String, count: Int = 1): List<Quest> {
        val completedNow = mutableListOf<Quest>()
        getActiveQuests().forEach { quest ->
            quest.objectives.filter { obj ->
                obj.type == eventType && (obj.targetId == targetId || obj.targetId == "any")
                && !obj.isComplete
            }.forEach { obj ->
                obj.currentCount = minOf(obj.currentCount + count, obj.targetCount)
            }
            if (quest.objectives.all { it.isComplete } && quest.status == QuestStatus.ACTIVE) {
                quest.status = QuestStatus.COMPLETED
                completedNow.add(quest)
            }
        }
        return completedNow
    }

    fun unlockAvailableQuests(character: Character) {
        getAvailableQuests(character).forEach { it.status = QuestStatus.AVAILABLE }
    }

    fun applyReward(quest: Quest, character: Character) {
        val r = quest.reward
        character.gold += r.gold
        character.gainExperience(r.exp)
        character.divinity += r.divinity
        r.itemId?.let { itemId ->
            GameDatabase.ALL_ITEMS[itemId]?.let { character.inventory.add(it.copy()) }
        }
        r.abilityId?.let { abilityId ->
            GameDatabase.getAbilityById(abilityId)?.let { ability ->
                if (character.abilities.none { it.id == ability.id }) {
                    character.abilities.add(ability.copy())
                }
            }
        }
        character.updateDivinityTitle()
    }

    fun getQuestsByChapter(chapter: Int) = ALL_QUESTS.filter { it.chapter == chapter && it.isMainQuest }
    fun getCompletionPercent(): Int {
        val total = ALL_QUESTS.size
        val done = getCompletedQuests().size
        return if (total == 0) 0 else (done * 100) / total
    }
}

// ─────────────────────────────────────────────
//  QUEST DIALOGUE DATABASE
// ─────────────────────────────────────────────

object QuestDialogueDB {
    val QUEST_GIVER_INTROS = mapOf(
        "Старецът Теос" to listOf(
            "Млади пришълец... Чакал съм те дълго.",
            "Вижда ми се, ти не си обикновен смъртен.",
            "Силата, която носиш в себе си — тя е рядка. Опасна. Но необходима.",
            "Боговете спят. Ти трябва да ги събудиш — или да ги замениш."
        ),
        "Хермес" to listOf(
            "О! Нов кандидат за Олимп! Интересно.",
            "Татко Зевс не знае, че съм тук. Бързо!",
            "Имам задача. Неофициална. Добре платена.",
            "Бягам от Арес. Той е разгневен. Помогни ми и ти помагам."
        ),
        "Прометей" to listOf(
            "Три хиляди години верижен. Знаеш ли колко часа е това?",
            "Орелът ще дойде скоро. Но преди него — имам задача.",
            "Аз открих огъня на хората. Ти трябва да открадне нещо от боговете.",
            "Всичко, което боговете пазят, трябва да стане свободно."
        ),
        "Один" to listOf(
            "Гарваните ми вече ти наблюдават от часове.",
            "Виждам Рагнарок в очите ти. Ти ще преживееш ли го?",
            "Жертвах окото си за мъдрост. Ти ще жертвашли нещо?",
            "Вреемто е кратко. Рагнарок идва. Действай."
        ),
        "Дракон Мъдрецът" to listOf(
            "Дракони сме по-стари от боговете. Помни това.",
            "Тиамат е недоволна. Убил си нейни деца.",
            "Искаш мощта на дракон? Тогава трябва да спечелиш правото.",
            "Огънят в теб — той е роден от дракон. Аз го чувствам."
        )
    )
    
    val QUEST_COMPLETE_PHRASES = listOf(
        "✅ Легендата расте!",
        "✅ Митовете те помнят!",
        "✅ Боговете трепват!",
        "✅ Поглъщаш история!",
        "✅ Всебогът се приближава!",
        "✅ Митологията се промени завинаги!",
        "✅ Герой? Не. Нещо повече!",
        "✅ Дивинитито ти расте!"
    )
    
    val QUEST_FAIL_PHRASES = listOf(
        "❌ Провалил се... за сега.",
        "❌ Боговете се смеят. Засега.",
        "❌ Опитай отново. По-силен.",
        "❌ Митът не приема слабост.",
        "❌ Хаосът взима победата... засега."
    )
    
    fun getRandomComplete() = QUEST_COMPLETE_PHRASES.random()
    fun getRandomFail() = QUEST_FAIL_PHRASES.random()
    fun getIntro(giverName: String) = QUEST_GIVER_INTROS[giverName]?.random() ?: "Имам задача за теб."
}
