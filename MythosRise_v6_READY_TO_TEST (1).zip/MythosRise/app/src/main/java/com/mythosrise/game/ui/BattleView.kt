package com.mythosrise.game.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.mythosrise.game.engine.ParticleSystem
import com.mythosrise.game.models.*
import kotlin.math.*
import kotlin.random.Random

class BattleView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // ─────────────────────────────────────────────
    //  STATE
    // ─────────────────────────────────────────────

    var character: Character? = null
    var enemy: Enemy? = null

    private val particleSystem = ParticleSystem()
    private var lastFrameTime = System.nanoTime()

    // Shake effect
    private var shakeX = 0f
    private var shakeY = 0f
    private var shakePower = 0f

    // Flash effect
    private var flashAlpha = 0f
    private var flashColor = Color.WHITE

    // Floating damage numbers
    private val floatingTexts = mutableListOf<FloatingText>()

    // Hero/Enemy positions & animation
    private var heroX = 0f
    private var heroY = 0f
    private var enemyX = 0f
    private var enemyY = 0f
    private var heroOffsetX = 0f
    private var heroOffsetY = 0f
    private var enemyOffsetX = 0f
    private var enemyOffsetY = 0f
    private var heroScale = 1f
    private var enemyScale = 1f
    private var enemyDeathAlpha = 1f

    // Background parallax layers
    private var bgOffset = 0f
    private var bgOffset2 = 0f

    // Paints
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val hpBarBgPaint = Paint().apply { color = Color.parseColor("#330000") }
    private val hpBarPaint = Paint().apply { color = Color.parseColor("#CC0000") }
    private val playerHpPaint = Paint().apply { color = Color.parseColor("#00CC00") }
    private val manaBarPaint = Paint().apply { color = Color.parseColor("#0066FF") }
    private val manaBarBgPaint = Paint().apply { color = Color.parseColor("#000033") }
    private val overlayPaint = Paint()
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        alpha = 120
        maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL)
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
    }
    private val divineRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#FFD700")
        maskFilter = BlurMaskFilter(15f, BlurMaskFilter.Blur.NORMAL)
    }

    // ─────────────────────────────────────────────
    //  DATA CLASSES
    // ─────────────────────────────────────────────

    data class FloatingText(
        var x: Float, var y: Float,
        val text: String, val color: Int,
        var life: Float = 1f,
        var size: Float = 36f,
        var vx: Float = 0f,
        var vy: Float = -3f
    )

    // ─────────────────────────────────────────────
    //  PUBLIC TRIGGERS
    // ─────────────────────────────────────────────

    fun triggerPlayerAttack(dmg: Int, isCrit: Boolean = false) {
        val color = if (isCrit) Color.parseColor("#FFD700") else Color.WHITE
        val size = if (isCrit) 52f else 38f
        addFloatingText(enemyX, enemyY - 80f, if (isCrit) "💥 $dmg!" else "-$dmg", color, size)
        particleSystem.emitBlood(enemyX, enemyY)
        shakeScreen(if (isCrit) 18f else 8f)
        flashScreen(Color.WHITE, if (isCrit) 0.4f else 0.2f)
        animateHeroAttack()
    }

    fun triggerEnemyAttack(dmg: Int) {
        addFloatingText(heroX, heroY - 60f, "-$dmg", Color.RED, 40f)
        shakeScreen(12f)
        flashScreen(Color.RED, 0.25f)
        animateEnemyAttack()
    }

    fun triggerAbility(abilityName: String, dmg: Int, isCrit: Boolean = false) {
        particleSystem.emitForAbility(abilityName, enemyX, enemyY)
        addFloatingText(enemyX, enemyY - 100f, "✨ $dmg!", Color.parseColor("#FFD700"), 46f, vx = Random.nextFloat() * 2f - 1f)
        shakeScreen(15f)
        flashScreen(Color.parseColor("#FFD700"), 0.3f)
        animateHeroAttack()
    }

    fun triggerHeal(amount: Int) {
        particleSystem.emitHeal(heroX, heroY)
        addFloatingText(heroX, heroY - 70f, "+$amount ❤️", Color.GREEN, 42f)
    }

    fun triggerEnemyDeath() {
        particleSystem.emitExplosion(enemyX, enemyY, 80)
        particleSystem.emitGold(enemyX, enemyY + 50f, 30)
        particleSystem.emitDivine(enemyX, enemyY, 40)
        shakeScreen(25f)
        flashScreen(Color.WHITE, 0.6f)
        animateEnemyDeath()
    }

    fun triggerDivinityGain(amount: Int) {
        particleSystem.emitDivine(width / 2f, height / 2f, 60)
        addFloatingText(heroX, heroY - 120f, "✨ +$amount Дивинити!", Color.parseColor("#FFD700"), 34f)
    }

    fun triggerPlayerDeath() {
        particleSystem.emitBlood(heroX, heroY, 50)
        particleSystem.emitShadow(heroX, heroY, 40)
        shakeScreen(30f)
        flashScreen(Color.RED, 0.8f)
    }

    fun triggerBossEntrance() {
        particleSystem.emitChaos(enemyX, enemyY, 80)
        shakeScreen(35f)
        flashScreen(Color.parseColor("#6600CC"), 0.7f)
    }

    fun triggerLevelUp() {
        particleSystem.emitHoly(heroX, heroY, 60)
        particleSystem.emitGold(heroX, heroY, 40)
        addFloatingText(heroX, heroY - 130f, "⭐ LEVEL UP!", Color.parseColor("#FFD700"), 50f)
        shakeScreen(10f)
    }

    // ─────────────────────────────────────────────
    //  ANIMATIONS
    // ─────────────────────────────────────────────

    private fun animateHeroAttack() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                heroOffsetX = if (t < 0.5f) t * 2f * 60f else (1f - t) * 2f * 60f
                invalidate()
            }
            start()
        }
    }

    private fun animateEnemyAttack() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            addUpdateListener {
                val t = it.animatedValue as Float
                enemyOffsetX = if (t < 0.5f) -(t * 2f * 60f) else -((1f - t) * 2f * 60f)
                invalidate()
            }
            start()
        }
    }

    private fun animateEnemyDeath() {
        enemyDeathAlpha = 1f
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 800
            addUpdateListener {
                enemyDeathAlpha = it.animatedValue as Float
                enemyScale = 1f + (1f - enemyDeathAlpha) * 0.5f
                invalidate()
            }
            start()
        }
    }

    private fun shakeScreen(power: Float) {
        shakePower = power
    }

    private fun flashScreen(color: Int, alpha: Float) {
        flashColor = color
        flashAlpha = alpha
    }

    private fun addFloatingText(x: Float, y: Float, text: String, color: Int, size: Float = 36f, vx: Float = 0f) {
        floatingTexts += FloatingText(x, y, text, color, size = size, vx = vx)
    }

    // ─────────────────────────────────────────────
    //  LAYOUT
    // ─────────────────────────────────────────────

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        enemyX = w * 0.65f
        enemyY = h * 0.35f
        heroX = w * 0.25f
        heroY = h * 0.70f
    }

    // ─────────────────────────────────────────────
    //  MAIN DRAW
    // ─────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = ((now - lastFrameTime) / 1_000_000_000f).coerceAtMost(0.05f)
        lastFrameTime = now

        update(dt)

        val cx = width / 2f
        val cy = height / 2f

        // Apply screen shake
        canvas.save()
        if (shakePower > 0.5f) {
            canvas.translate(
                (Random.nextFloat() - 0.5f) * shakePower,
                (Random.nextFloat() - 0.5f) * shakePower
            )
        }

        // ── Background ──
        drawBackground(canvas)

        // ── Enemy ──
        drawEnemy(canvas)

        // ── Hero ──
        drawHero(canvas)

        // ── Health Bars ──
        drawBars(canvas)

        // ── Particles ──
        particleSystem.draw(canvas)

        // ── Floating texts ──
        drawFloatingTexts(canvas)

        canvas.restore()

        // ── Screen flash ──
        if (flashAlpha > 0.01f) {
            overlayPaint.color = flashColor
            overlayPaint.alpha = (flashAlpha * 255).toInt()
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)
        }

        // Animate continuously
        invalidate()
    }

    // ─────────────────────────────────────────────
    //  UPDATE LOGIC
    // ─────────────────────────────────────────────

    private fun update(dt: Float) {
        particleSystem.update(dt)
        shakePower *= 0.85f
        flashAlpha *= 0.88f
        bgOffset += dt * 20f
        bgOffset2 += dt * 8f

        val iter = floatingTexts.iterator()
        while (iter.hasNext()) {
            val ft = iter.next()
            ft.life -= dt * 0.8f
            ft.y += ft.vy
            ft.x += ft.vx
            if (ft.life <= 0f) iter.remove()
        }

        // Idle bob animations
        heroOffsetY = sin(System.currentTimeMillis() / 500.0).toFloat() * 4f
        enemyOffsetY = sin(System.currentTimeMillis() / 400.0 + 1.0).toFloat() * 5f
    }

    // ─────────────────────────────────────────────
    //  DRAW COMPONENTS
    // ─────────────────────────────────────────────

    private fun drawBackground(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // Sky gradient
        val skyGradient = LinearGradient(0f, 0f, 0f, h * 0.6f,
            intArrayOf(Color.parseColor("#0A0015"), Color.parseColor("#1A0A3E"), Color.parseColor("#0D1A3A")),
            null, Shader.TileMode.CLAMP)
        bgPaint.shader = skyGradient
        canvas.drawRect(0f, 0f, w, h * 0.65f, bgPaint)
        bgPaint.shader = null

        // Ground gradient
        val groundGradient = LinearGradient(0f, h * 0.65f, 0f, h,
            Color.parseColor("#0A1A0A"), Color.parseColor("#050A05"), Shader.TileMode.CLAMP)
        bgPaint.shader = groundGradient
        canvas.drawRect(0f, h * 0.65f, w, h, bgPaint)
        bgPaint.shader = null

        // Stars (static pattern)
        bgPaint.color = Color.WHITE
        val starSeed = 42L
        val rng = java.util.Random(starSeed)
        repeat(60) {
            val sx = rng.nextFloat() * w
            val sy = rng.nextFloat() * h * 0.6f
            val sr = 0.5f + rng.nextFloat() * 2f
            val sa = (0.4f + sin((System.currentTimeMillis() / 1000.0 + it).toFloat()) * 0.3f).coerceIn(0f, 1f)
            bgPaint.alpha = (sa * 255).toInt()
            canvas.drawCircle(sx, sy, sr, bgPaint)
        }
        bgPaint.alpha = 255

        // Scrolling nebula/mist
        bgPaint.color = Color.parseColor("#11003322")
        bgPaint.alpha = 40
        val offset = (bgOffset % w)
        canvas.drawOval(offset - 200f, h * 0.3f, offset + 200f, h * 0.6f, bgPaint)
        canvas.drawOval(offset + w / 2 - 150f, h * 0.2f, offset + w / 2 + 150f, h * 0.5f, bgPaint)
        bgPaint.alpha = 255

        // Distant mountains silhouette
        bgPaint.color = Color.parseColor("#0D0D22")
        val mPath = Path()
        mPath.moveTo(0f, h * 0.65f)
        mPath.lineTo(w * 0.1f, h * 0.4f)
        mPath.lineTo(w * 0.25f, h * 0.55f)
        mPath.lineTo(w * 0.4f, h * 0.35f)
        mPath.lineTo(w * 0.55f, h * 0.48f)
        mPath.lineTo(w * 0.7f, h * 0.3f)
        mPath.lineTo(w * 0.85f, h * 0.45f)
        mPath.lineTo(w, h * 0.38f)
        mPath.lineTo(w, h * 0.65f)
        mPath.close()
        canvas.drawPath(mPath, bgPaint)

        // Horizon glow
        val horizonGlow = RadialGradient(w / 2, h * 0.65f, w * 0.6f,
            Color.parseColor("#22004488"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        bgPaint.shader = horizonGlow
        canvas.drawRect(0f, h * 0.5f, w, h * 0.75f, bgPaint)
        bgPaint.shader = null
    }

    private fun drawEnemy(canvas: Canvas) {
        val e = enemy ?: return
        val x = enemyX + enemyOffsetX
        val y = enemyY + enemyOffsetY

        canvas.save()
        canvas.translate(x, y)
        canvas.scale(enemyScale, enemyScale)
        canvas.alpha = (enemyDeathAlpha * 255).toInt()

        // Shadow under enemy
        shadowPaint.alpha = (80 * enemyDeathAlpha).toInt()
        canvas.drawOval(-55f, 60f, 55f, 80f, shadowPaint)

        // Glow for bosses
        if (e.isBoss) {
            glowPaint.color = Color.parseColor("#AA0000")
            glowPaint.alpha = 120
            canvas.drawCircle(0f, 0f, 90f, glowPaint)

            // Rotating divine rings for high-level bosses
            if (e.divinityReward > 500) {
                canvas.save()
                canvas.rotate((System.currentTimeMillis() / 20f) % 360f)
                divineRingPaint.color = Color.parseColor("#FF4400")
                canvas.drawCircle(0f, 0f, 80f, divineRingPaint)
                canvas.restore()
                canvas.save()
                canvas.rotate(-(System.currentTimeMillis() / 30f) % 360f)
                divineRingPaint.color = Color.parseColor("#FF8800")
                canvas.drawCircle(0f, 0f, 95f, divineRingPaint)
                canvas.restore()
            }
        }

        // Enemy emoji (large)
        textPaint.textSize = if (e.isBoss) 96f else 72f
        textPaint.alpha = 255
        canvas.drawText(e.emoji, 0f, 30f, textPaint)

        // HP bar above enemy
        val barW = 120f
        val barH = 12f
        val hpFrac = (e.currentHealth.toFloat() / e.maxHealth).coerceIn(0f, 1f)
        val hpColor = when {
            hpFrac > 0.6f -> Color.parseColor("#00CC00")
            hpFrac > 0.3f -> Color.parseColor("#FFAA00")
            else -> Color.parseColor("#CC0000")
        }
        canvas.drawRoundRect(-barW / 2, -90f, barW / 2, -90f + barH, 6f, 6f, hpBarBgPaint)
        hpBarPaint.color = hpColor
        canvas.drawRoundRect(-barW / 2, -90f, -barW / 2 + barW * hpFrac, -90f + barH, 6f, 6f, hpBarPaint)

        // Enemy name
        textPaint.textSize = 18f
        textPaint.color = if (e.isBoss) Color.parseColor("#FFD700") else Color.parseColor("#FF8888")
        canvas.drawText(e.name.take(20), 0f, -100f, textPaint)
        textPaint.color = Color.WHITE

        canvas.alpha = 255
        canvas.restore()
    }

    private fun drawHero(canvas: Canvas) {
        val c = character ?: return
        val x = heroX + heroOffsetX
        val y = heroY + heroOffsetY

        canvas.save()
        canvas.translate(x, y)
        canvas.scale(heroScale, heroScale)

        // Shadow
        shadowPaint.alpha = 80
        canvas.drawOval(-40f, 50f, 40f, 65f, shadowPaint)

        // Divine aura for high divinity
        if (c.divinity > 500) {
            val auraAlpha = min(180, c.divinity / 10)
            val auraColor = when {
                c.divinity > 25000 -> Color.parseColor("#FF00FF")
                c.divinity > 10000 -> Color.parseColor("#3498DB")
                c.divinity > 5000 -> Color.parseColor("#9B59B6")
                c.divinity > 1500 -> Color.parseColor("#FF6600")
                else -> Color.parseColor("#FFD700")
            }
            glowPaint.color = auraColor
            glowPaint.alpha = auraAlpha
            canvas.drawCircle(0f, 0f, 70f + c.divinity / 500f, glowPaint)

            // Rotating rings for gods
            if (c.divinity > 4000) {
                canvas.save()
                canvas.rotate((System.currentTimeMillis() / 15f) % 360f)
                divineRingPaint.color = auraColor
                canvas.drawCircle(0f, 0f, 75f, divineRingPaint)
                canvas.restore()
            }
        }

        // Hero emoji
        val heroEmoji = when (c.heroClass) {
            HeroClass.WARRIOR -> "🤺"
            HeroClass.MAGE -> "🧙"
            HeroClass.ARCHER -> "🏹"
            HeroClass.MONK -> "🥋"
        }
        textPaint.textSize = 64f
        textPaint.color = Color.WHITE
        canvas.drawText(heroEmoji, 0f, 25f, textPaint)

        // Divinity title floating above hero
        if (c.divinityTitle.ordinal >= 2) {
            textPaint.textSize = 14f
            textPaint.color = Color.parseColor(c.divinityTitle.color)
            canvas.drawText(c.divinityTitle.title, 0f, -75f, textPaint)
        }

        // HP bar below hero
        val barW = 100f
        val barH = 10f
        val hpFrac = (c.health.toFloat() / c.getTotalMaxHealth()).coerceIn(0f, 1f)
        val manaFrac = (c.mana.toFloat() / c.maxMana).coerceIn(0f, 1f)

        canvas.drawRoundRect(-barW / 2, 50f, barW / 2, 50f + barH, 5f, 5f, hpBarBgPaint)
        playerHpPaint.color = if (hpFrac > 0.3f) Color.parseColor("#00CC00") else Color.parseColor("#CC0000")
        canvas.drawRoundRect(-barW / 2, 50f, -barW / 2 + barW * hpFrac, 50f + barH, 5f, 5f, playerHpPaint)

        canvas.drawRoundRect(-barW / 2, 64f, barW / 2, 64f + 8f, 4f, 4f, manaBarBgPaint)
        canvas.drawRoundRect(-barW / 2, 64f, -barW / 2 + barW * manaFrac, 64f + 8f, 4f, 4f, manaBarPaint)

        textPaint.color = Color.WHITE
        canvas.restore()
    }

    private fun drawBars(canvas: Canvas) {
        val c = character ?: return
        val e = enemy ?: return
        val w = width.toFloat()

        // Top info bar
        val barPaint = Paint().apply { color = Color.parseColor("#99000011"); }
        canvas.drawRect(0f, 0f, w, 60f, barPaint)

        textPaint.textSize = 14f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.parseColor("#66FF66")
        canvas.drawText("${c.name} — ${c.divinityTitle.title}", 12f, 22f, textPaint)
        textPaint.color = Color.parseColor("#FF6666")
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("${e.name.take(18)}", w - 12f, 22f, textPaint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.WHITE
    }

    private fun drawFloatingTexts(canvas: Canvas) {
        floatingTexts.forEach { ft ->
            textPaint.textSize = ft.size
            textPaint.color = ft.color
            textPaint.alpha = (ft.life * 255).toInt().coerceIn(0, 255)
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(ft.text, ft.x, ft.y, textPaint)
        }
        textPaint.alpha = 255
        textPaint.color = Color.WHITE
    }
}
