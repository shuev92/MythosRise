package com.mythosrise.game.engine

import com.mythosrise.game.models.*

object GameDatabase {

    // ─────────────────────────────────────────────
    //  ABILITIES
    // ─────────────────────────────────────────────

    val ALL_ABILITIES = mapOf(
        "slash" to Ability("slash", "Вихрен Удар", "Мощен удар с оръжие", 10, 1, 1.8f, emoji = "⚔️"),
        "fireball" to Ability("fireball", "Огнена топка", "Магически огнен взрив", 25, 2, 3.0f, emoji = "🔥"),
        "arrow_rain" to Ability("arrow_rain", "Дъжд от стрели", "Стотици стрели от небето", 20, 3, 2.5f, emoji = "🏹"),
        "holy_strike" to Ability("holy_strike", "Свят удар", "Енергия от боговете", 30, 2, 2.8f, emoji = "✨"),
        "thunder_god" to Ability("thunder_god", "Гръм на Зевс", "Мълния от Олимп", 50, 4, 5.0f, stunChance = 0.4f, emoji = "⚡", requiredDivinity = 500),
        "poseidon_wave" to Ability("poseidon_wave", "Вълна на Посейдон", "Гигантско цунами", 60, 5, 4.5f, aoeRadius = 1.0f, emoji = "🌊", requiredDivinity = 800),
        "shiva_dance" to Ability("shiva_dance", "Танцът на Шива", "Разрушителен вихър", 70, 5, 6.0f, aoeRadius = 1.5f, emoji = "💫", requiredDivinity = 1200),
        "brahma_create" to Ability("brahma_create", "Творение на Брахма", "Създава дубликат", 80, 6, 3.0f, healPercent = 0.3f, emoji = "🕉️", requiredDivinity = 1500),
        "thor_hammer" to Ability("thor_hammer", "Мьолнир", "Чукът на Тор смазва всичко", 65, 4, 5.5f, stunChance = 0.6f, emoji = "⚡", requiredDivinity = 1000),
        "odin_spear" to Ability("odin_spear", "Копието на Один", "Гунгнир никога не пропуска", 90, 6, 7.0f, emoji = "🔱", requiredDivinity = 2000),
        "kronos_time" to Ability("kronos_time", "Спиране на Времето", "Замразява врага", 100, 8, 4.0f, stunChance = 1.0f, emoji = "⏳", requiredDivinity = 3000),
        "omnigod_strike" to Ability("omnigod_strike", "Удар на Всебога", "Чистата сила на Вселената", 150, 10, 12.0f, aoeRadius = 3.0f, emoji = "🌌", requiredDivinity = 50000),
        "heal_self" to Ability("heal_self", "Лечебна аура", "Възстановява живота", 30, 3, 0f, healPercent = 0.4f, emoji = "💚"),
        "berserker" to Ability("berserker", "Берсерк", "Удвоена атака за 1 ход", 15, 4, 2.0f, emoji = "😤"),
        "shadow_step" to Ability("shadow_step", "Сенчест скок", "Избягва следващия удар + атака", 20, 3, 2.2f, emoji = "🌑"),

        // === DRAGON ABILITIES ===
        "dragon_fire" to Ability("dragon_fire", "Дракон Огън", "Изгаря всичко пред теб", 40, 2, 4.0f, aoeRadius = 1.0f, emoji = "🔥", requiredDivinity = 200),
        "dragon_ice" to Ability("dragon_ice", "Ледено Дихание", "Замразява и пронизва", 45, 3, 3.5f, stunChance = 0.5f, emoji = "🧊", requiredDivinity = 400),
        "dragon_shadow" to Ability("dragon_shadow", "Сянка на Дракона", "Потапя врага в мрак", 55, 4, 4.5f, stunChance = 0.3f, emoji = "🌑", requiredDivinity = 600),
        "dragon_roar" to Ability("dragon_roar", "Рев на Дракона", "Парализира всички врагове", 60, 5, 2.0f, stunChance = 0.8f, aoeRadius = 2.0f, emoji = "🐉", requiredDivinity = 700),
        "tiamat_chaos" to Ability("tiamat_chaos", "Хаос на Тиамат", "Петоглавото чудовище атакува", 120, 8, 9.0f, aoeRadius = 3.0f, emoji = "🌊", requiredDivinity = 5000),

        // === EGYPTIAN ABILITIES ===
        "ra_sunbeam" to Ability("ra_sunbeam", "Слънчев Лъч на Ра", "Директна слънчева енергия", 55, 3, 5.0f, emoji = "☀️", requiredDivinity = 600),
        "anubis_judgment" to Ability("anubis_judgment", "Съдът на Анубис", "Претегля сърцето на врага", 70, 5, 6.0f, emoji = "⚖️", requiredDivinity = 1000),
        "osiris_revival" to Ability("osiris_revival", "Прераждане на Озирис", "Умираш и се прераждаш по-силен", 80, 6, 0f, healPercent = 0.6f, emoji = "🌿", requiredDivinity = 1200),
        "horus_eye" to Ability("horus_eye", "Окото на Хор", "Вижда слабото място на всеки враг", 65, 4, 5.5f, emoji = "👁️", requiredDivinity = 900),
        "set_storm" to Ability("set_storm", "Пясъчна Буря на Сет", "Опустошителна пясъчна буря", 75, 5, 5.8f, aoeRadius = 2.0f, emoji = "🌪️", requiredDivinity = 1100),

        // === JAPANESE ABILITIES ===
        "susanoo_storm" to Ability("susanoo_storm", "Буря на Сусаноо", "Бог на бурите атакува", 70, 4, 5.5f, aoeRadius = 1.5f, emoji = "⛈️", requiredDivinity = 900),
        "amaterasu_light" to Ability("amaterasu_light", "Светлина на Аматерасу", "Слънчевата богиня изгаря мрака", 80, 5, 6.5f, emoji = "🌅", requiredDivinity = 1300),
        "raijin_thunder" to Ability("raijin_thunder", "Гром на Райджин", "Японски бог на гръмотевицата", 60, 3, 5.0f, stunChance = 0.5f, emoji = "🥁", requiredDivinity = 800),
        "samurai_slash" to Ability("samurai_slash", "Самурайски Удар", "Светкавичен смъртоносен удар", 25, 2, 3.5f, emoji = "🗡️"),
        "oni_rage" to Ability("oni_rage", "Ярост на Они", "Демоничен разрушителен удар", 35, 3, 3.8f, emoji = "👹"),

        // === CHINESE ABILITIES ===
        "wukong_staff" to Ability("wukong_staff", "Пръчката на Ву Конг", "72 трансформации!", 60, 3, 5.2f, emoji = "🐒", requiredDivinity = 800),
        "dragon_king_water" to Ability("dragon_king_water", "Водата на Дракон Краля", "Вълни от дракон", 75, 5, 5.5f, aoeRadius = 2.0f, emoji = "🌊", requiredDivinity = 1100),
        "jade_emperor" to Ability("jade_emperor", "Повеля на Нефритения Цар", "Всички небесни войски атакуват", 100, 7, 8.0f, aoeRadius = 3.0f, emoji = "👑", requiredDivinity = 2000),
        "nezha_fire" to Ability("nezha_fire", "Огненото колело на Нежа", "Огнени колела от всички посоки", 65, 4, 5.8f, aoeRadius = 1.5f, emoji = "🔥", requiredDivinity = 1000),

        // === MASS BATTLE ABILITIES ===
        "army_strike" to Ability("army_strike", "Армеен Удар", "Атакуваш ВСИЧКИ врагове наведнъж", 80, 3, 3.0f, aoeRadius = 99f, emoji = "⚔️", requiredDivinity = 500),
        "divine_meteor" to Ability("divine_meteor", "Божествен Метеор", "Метеор от небето върху всички", 110, 5, 5.0f, aoeRadius = 99f, emoji = "☄️", requiredDivinity = 2000),
        "apocalypse" to Ability("apocalypse", "АПОКАЛИПСИС", "Краят на всичко живо около теб", 200, 10, 8.0f, aoeRadius = 99f, emoji = "💥", requiredDivinity = 10000)
    )

    // ─────────────────────────────────────────────
    //  ITEMS DATABASE
    // ─────────────────────────────────────────────

    val ALL_ITEMS = mapOf(

        // === MORTAL REALM ITEMS ===
        "iron_sword" to Item("iron_sword", "Железен меч", "Прост, но верен.", ItemType.WEAPON, Rarity.COMMON, attackBonus = 5, mythology = "Mortal", emoji = "🗡️", value = 50),
        "leather_armor" to Item("leather_armor", "Кожена броня", "Лека защита.", ItemType.ARMOR, Rarity.COMMON, defenseBonus = 4, mythology = "Mortal", emoji = "🧥", value = 40),
        "steel_sword" to Item("steel_sword", "Стоманен меч", "Острата стомана.", ItemType.WEAPON, Rarity.UNCOMMON, attackBonus = 12, mythology = "Mortal", emoji = "⚔️", value = 150),
        "knights_plate" to Item("knights_plate", "Рицарска плоча", "Защита на рицарите.", ItemType.ARMOR, Rarity.RARE, defenseBonus = 18, mythology = "Mortal", emoji = "🛡️", value = 400),
        "health_potion" to Item("health_potion", "Еликсир на живота", "Възстановява 50% живот.", ItemType.POTION, Rarity.COMMON, healthBonus = 50, mythology = "Mortal", emoji = "🧪", value = 80),
        "mana_potion" to Item("mana_potion", "Еликсир на маната", "Зарежда 80 мана.", ItemType.POTION, Rarity.COMMON, manaBonus = 80, mythology = "Mortal", emoji = "💙", value = 80),

        // === GREEK MYTHOLOGY ITEMS ===
        "zeus_lightning" to Item("zeus_lightning", "Мълниите на Зевс", "Самите мълнии на царя на боговете.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 120, divinityBonus = 500, mythology = "Greek", emoji = "⚡", specialEffect = "Шанс за зашеметяване 50%", value = 99999),
        "poseidon_trident" to Item("poseidon_trident", "Тризъбецът на Посейдон", "Владее океаните и земетресенията.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 95, divinityBonus = 400, mythology = "Greek", emoji = "🔱", specialEffect = "AOE вълна удар", value = 50000),
        "hephaestus_armor" to Item("hephaestus_armor", "Броня на Хефест", "Wykuta в огъня на вулкан.", ItemType.ARMOR, Rarity.LEGENDARY, defenseBonus = 75, healthBonus = 200, mythology = "Greek", emoji = "🔥", value = 20000),
        "athena_shield" to Item("athena_shield", "Щитът на Атина", "Aegis - отразява магии.", ItemType.ARMOR, Rarity.MYTHIC, defenseBonus = 60, manaBonus = 100, mythology = "Greek", emoji = "🛡️", specialEffect = "20% шанс отразяване на магия", value = 35000),
        "hermes_boots" to Item("hermes_boots", "Сандалите на Хермес", "Крилати сандали с невероятна скорост.", ItemType.BOOTS, Rarity.LEGENDARY, speedBonus = 0.8f, defenseBonus = 15, mythology = "Greek", emoji = "👟", specialEffect = "Двойна скорост", value = 18000),
        "apollo_bow" to Item("apollo_bow", "Лъкът на Аполон", "Никога не пропуска целта.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 85, mythology = "Greek", emoji = "🏹", specialEffect = "100% точност", value = 40000),
        "golden_fleece" to Item("golden_fleece", "Златното руно", "Регенерира 5% живот всеки ход.", ItemType.AMULET, Rarity.LEGENDARY, healthBonus = 300, mythology = "Greek", emoji = "✨", specialEffect = "5% регенерация на ход", value = 25000),
        "hades_helm" to Item("hades_helm", "Шлемът на Хадес", "Прави носителя невидим.", ItemType.HELMET, Rarity.MYTHIC, defenseBonus = 45, mythology = "Greek", emoji = "⚫", specialEffect = "30% шанс за избягване на удар", value = 45000),

        // === INDIAN MYTHOLOGY ITEMS ===
        "vishnu_chakra" to Item("vishnu_chakra", "Чакрата на Вишну", "Сударшана Чакра - всесилното оръжие.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 110, divinityBonus = 600, mythology = "Indian", emoji = "☸️", specialEffect = "Прорязва всяка защита", value = 99999),
        "shiva_trishul" to Item("shiva_trishul", "Тришулът на Шива", "Тризъбец на разрушението.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 100, divinityBonus = 450, mythology = "Indian", emoji = "🔱", specialEffect = "Изгаря карма на врага", value = 60000),
        "indra_vajra" to Item("indra_vajra", "Ваджрата на Индра", "Гръмотевичното оръжие на небесния цар.", ItemType.WEAPON, Rarity.LEGENDARY, attackBonus = 80, mythology = "Indian", emoji = "⚡", value = 22000),
        "kali_sword" to Item("kali_sword", "Меч на Кали", "Напоен с кръвта на демони.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 90, attackBonus2 = 0, mythology = "Indian", emoji = "🗡️", specialEffect = "15% шанс за мигновена смърт", value = 55000),
        "brahma_lotus" to Item("brahma_lotus", "Лотосът на Брахма", "Съдържа мъдростта на Вселената.", ItemType.AMULET, Rarity.DIVINE, manaBonus = 500, divinityBonus = 300, mythology = "Indian", emoji = "🪷", specialEffect = "-30% цена на умения", value = 80000),

        // === NORSE MYTHOLOGY ITEMS ===
        "mjolnir" to Item("mjolnir", "Мьолнир", "Чукът на Тор. Легендарен.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 105, divinityBonus = 400, mythology = "Norse", emoji = "🔨", specialEffect = "Зашеметяване при всяко попадение", value = 55000),
        "gungnir" to Item("gungnir", "Гунгнир", "Копието на Один. Никога не пропуска.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 115, divinityBonus = 550, mythology = "Norse", emoji = "🗡️", specialEffect = "100% точност + Игнорира защита", value = 90000),
        "valhalla_armor" to Item("valhalla_armor", "Броня на Валхала", "Нося от павшите воини.", ItemType.ARMOR, Rarity.LEGENDARY, defenseBonus = 80, healthBonus = 250, mythology = "Norse", emoji = "🛡️", value = 28000),
        "yggdrasil_ring" to Item("yggdrasil_ring", "Пръстен на Игдрасил", "Силата на Световното дърво.", ItemType.RING, Rarity.MYTHIC, healthBonus = 400, manaBonus = 200, divinityBonus = 200, mythology = "Norse", emoji = "💍", value = 65000),

        // === TITAN ITEMS ===
        "kronos_scythe" to Item("kronos_scythe", "Косата на Кронос", "Коси времето само.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 130, divinityBonus = 700, mythology = "Titan", emoji = "⚔️", specialEffect = "Замразява врага за 1 ход", value = 120000),
        "atlas_gauntlets" to Item("atlas_gauntlets", "Ръкавиците на Атлас", "Носеше небесния свод.", ItemType.ARMOR, Rarity.MYTHIC, defenseBonus = 90, healthBonus = 500, mythology = "Titan", emoji = "💪", value = 70000),

        // === DRAGON ITEMS ===
        "dragon_scale_armor" to Item("dragon_scale_armor", "Броня от Дракон Люспи", "Ескалирана от легендарен дракон.", ItemType.ARMOR, Rarity.LEGENDARY, defenseBonus = 65, healthBonus = 180, mythology = "Dragon", emoji = "🐉", specialEffect = "50% резистентност към огън", value = 30000),
        "fire_dragon_fang" to Item("fire_dragon_fang", "Зъб на Огнен Дракон", "Пронизва всякаква броня.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 88, divinityBonus = 300, mythology = "Dragon", emoji = "🔥", specialEffect = "Изгаря за 3 хода", value = 48000),
        "ice_dragon_horn" to Item("ice_dragon_horn", "Рог на Ледения Дракон", "Студен като самата смърт.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 82, mythology = "Dragon", emoji = "🧊", specialEffect = "Замразява за 2 хода", value = 42000),
        "hydra_blood_vial" to Item("hydra_blood_vial", "Кръвта на Хидрата", "Регенерира 2 глави за всяка изгубена.", ItemType.AMULET, Rarity.LEGENDARY, healthBonus = 600, mythology = "Dragon", emoji = "🐍", specialEffect = "Регенерира 10% HP всеки ход", value = 35000),
        "tiamat_scale" to Item("tiamat_scale", "Люспа на Тиамат", "От петоглавото чудовище.", ItemType.ARMOR, Rarity.DIVINE, defenseBonus = 110, healthBonus = 700, divinityBonus = 500, mythology = "Dragon", emoji = "🌊", specialEffect = "Имунитет към магически атаки", value = 95000),
        "nidhogg_venom" to Item("nidhogg_venom", "Отрова на Нидхог", "Гризе Игдрасил вечно.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 95, mythology = "Norse Dragon", emoji = "🌑", specialEffect = "Отравя врага за 5 хода", value = 52000),

        // === EGYPTIAN ITEMS ===
        "ra_staff" to Item("ra_staff", "Жезълът на Ра", "Слънчевата енергия в чист вид.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 105, divinityBonus = 480, mythology = "Egyptian", emoji = "☀️", specialEffect = "Изгаря нежни твари", value = 85000),
        "anubis_scale" to Item("anubis_scale", "Везните на Анубис", "Претегля живота и смъртта.", ItemType.AMULET, Rarity.MYTHIC, healthBonus = 350, manaBonus = 150, divinityBonus = 300, mythology = "Egyptian", emoji = "⚖️", specialEffect = "Шанс за мигновено убиване", value = 60000),
        "osiris_crook" to Item("osiris_crook", "Жезълът на Озирис", "Символ на прераждането.", ItemType.WEAPON, Rarity.LEGENDARY, attackBonus = 70, healthBonus = 200, mythology = "Egyptian", emoji = "🌿", specialEffect = "Лекува при убиване", value = 28000),
        "horus_wings" to Item("horus_wings", "Крилете на Хор", "Вижда всичко. Удря всичко.", ItemType.ARMOR, Rarity.MYTHIC, defenseBonus = 55, attackBonus = 40, mythology = "Egyptian", emoji = "🦅", specialEffect = "100% точност", value = 50000),
        "pharaoh_crown" to Item("pharaoh_crown", "Короната на Фараона", "Владетел на живите и мъртвите.", ItemType.HELMET, Rarity.LEGENDARY, defenseBonus = 40, divinityBonus = 200, mythology = "Egyptian", emoji = "👑", value = 25000),
        "khopesh" to Item("khopesh", "Хопеш на Сет", "Свещен египетски меч.", ItemType.WEAPON, Rarity.EPIC, attackBonus = 55, mythology = "Egyptian", emoji = "⚔️", value = 12000),
        "scarab_amulet" to Item("scarab_amulet", "Амулет на Скарабея", "Защита от злото.", ItemType.AMULET, Rarity.RARE, defenseBonus = 25, healthBonus = 100, mythology = "Egyptian", emoji = "🪲", value = 5000),

        // === JAPANESE ITEMS ===
        "katana_of_storms" to Item("katana_of_storms", "Катаната на Бурите", "Скована от Сусаноо.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 92, divinityBonus = 350, mythology = "Japanese", emoji = "⛈️", specialEffect = "Удря с мълния", value = 50000),
        "amaterasu_mirror" to Item("amaterasu_mirror", "Огледалото на Аматерасу", "Свещено огледало — едно от трите съкровища.", ItemType.AMULET, Rarity.DIVINE, manaBonus = 400, divinityBonus = 450, mythology = "Japanese", emoji = "🌅", specialEffect = "Отразява 30% магии", value = 88000),
        "kusanagi" to Item("kusanagi", "Кусанаги-но-Цуруги", "Мечът намерен в опашката на осемглавия змей.", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 118, divinityBonus = 520, mythology = "Japanese", emoji = "⚔️", specialEffect = "Може да реже вятъра", value = 92000),
        "oni_club" to Item("oni_club", "Тоя на Они", "Желязна бухалка на демон.", ItemType.WEAPON, Rarity.EPIC, attackBonus = 48, mythology = "Japanese", emoji = "👹", value = 10000),
        "tengu_mask" to Item("tengu_mask", "Маската на Тенгу", "Носи мъдростта на планинския демон.", ItemType.HELMET, Rarity.LEGENDARY, defenseBonus = 35, manaBonus = 200, mythology = "Japanese", emoji = "🎭", specialEffect = "Удвоена мана регенерация", value = 20000),
        "samurai_armor" to Item("samurai_armor", "Самурайска Броня О-Йорой", "Непроницаема традиционна броня.", ItemType.ARMOR, Rarity.RARE, defenseBonus = 45, mythology = "Japanese", emoji = "🥷", value = 8000),

        // === CHINESE ITEMS ===
        "ruyi_jingu_bang" to Item("ruyi_jingu_bang", "Пръчката Жуйи Цзингу Банг", "Оръжието на Ву Конг. Промени теглото!", ItemType.WEAPON, Rarity.DIVINE, attackBonus = 125, divinityBonus = 600, mythology = "Chinese", emoji = "🐒", specialEffect = "Може да е с всякакъв размер", value = 99000),
        "dragon_pearl" to Item("dragon_pearl", "Перлата на Дракона", "Свещената перла на китайския дракон.", ItemType.AMULET, Rarity.MYTHIC, healthBonus = 450, manaBonus = 300, divinityBonus = 400, mythology = "Chinese", emoji = "🐲", specialEffect = "Регенерира мана", value = 70000),
        "jade_armor" to Item("jade_armor", "Нефритена Броня", "От нефритения дворец.", ItemType.ARMOR, Rarity.LEGENDARY, defenseBonus = 70, healthBonus = 220, mythology = "Chinese", emoji = "💚", value = 22000),
        "guan_yu_halberd" to Item("guan_yu_halberd", "Алебардата на Гуан Ю", "Оръжието на бога на войната.", ItemType.WEAPON, Rarity.MYTHIC, attackBonus = 98, divinityBonus = 380, mythology = "Chinese", emoji = "🪓", specialEffect = "Страх при всяко попадение", value = 55000),
        "nezha_armillary" to Item("nezha_armillary", "Огнените гривни на Нежа", "Хвърчи с огнени колела.", ItemType.BOOTS, Rarity.LEGENDARY, speedBonus = 1.0f, attackBonus = 30, mythology = "Chinese", emoji = "🔥", specialEffect = "Тройна скорост", value = 30000),

        // === MASS BATTLE ITEMS ===
        "war_banner" to Item("war_banner", "Бойно Знаме", "Вдъхновява за масов бой.", ItemType.SPECIAL, Rarity.EPIC, attackBonus = 30, defenseBonus = 20, mythology = "Mortal", emoji = "🚩", specialEffect = "AOE атаки +50% урон", value = 15000),
        "berserker_potion" to Item("berserker_potion", "Еликсир на Берсерка", "Тройна атака за 3 хода!", ItemType.POTION, Rarity.RARE, attackBonus = 0, mythology = "Mortal", emoji = "😤", specialEffect = "x3 атака", value = 2000),
        "mass_heal_scroll" to Item("mass_heal_scroll", "Свитък на Масово Лечение", "Лекува 80% от живота.", ItemType.POTION, Rarity.EPIC, healthBonus = 999, mythology = "Divine", emoji = "📜", value = 8000),

        // === DIVINE TIER (final boss drops) ===
        "omnigod_crown" to Item("omnigod_crown", "Короната на Всебога", "Символ на абсолютна власт.", ItemType.HELMET, Rarity.DIVINE, defenseBonus = 100, divinityBonus = 10000, healthBonus = 1000, manaBonus = 1000, mythology = "Divine", emoji = "👑", specialEffect = "Отключва формата ВСЕБОГ", value = 999999)
    )

    // Kotlin doesn't allow duplicate named params, fix the kali_sword
    private val Item.attackBonus2 get() = 0

    // ─────────────────────────────────────────────
    //  ENEMY DATABASE
    // ─────────────────────────────────────────────

    val ALL_ENEMIES = listOf(

        // === MORTAL REALM ===
        Enemy("bandit", "Разбойник", "Прост крадец по пътищата.", "Mortal", World.MORTAL_REALM, 1,
            health = 40, attack = 8, defense = 3, divinityReward = 2, expReward = 20, goldReward = 15,
            emoji = "🗡️", loreText = "Много попадат по пътя на греха."),
        Enemy("orc", "Орк", "Груб орк от планините.", "Mortal", World.MORTAL_REALM, 2,
            health = 80, attack = 14, defense = 6, divinityReward = 5, expReward = 45, goldReward = 30,
            emoji = "👹", loreText = "Орките живеят в племена и служат на мрака."),
        Enemy("troll", "Планински тролл", "Огромен тролл с каменна кожа.", "Mortal", World.MORTAL_REALM, 3,
            health = 150, attack = 18, defense = 12, divinityReward = 10, expReward = 80, goldReward = 60,
            emoji = "🧌", isBoss = false),
        Enemy("dark_knight", "Тъмен рицар", "Рицар погълнат от мрака.", "Mortal", World.MORTAL_REALM, 4,
            health = 220, attack = 25, defense = 18, divinityReward = 20, expReward = 120, goldReward = 90,
            abilities = listOf(EnemyAbility("Тъмен удар", 2.0f, 0.3f, "Удар с тъмна енергия")),
            emoji = "⚫", possibleDrops = listOf("steel_sword", "knights_plate"),
            loreText = "Някога беше герой. Сега служи на злото."),
        Enemy("dragon_whelp", "Дракончe", "Малък дракон, но огнен.", "Mortal", World.MORTAL_REALM, 5,
            health = 350, attack = 35, defense = 20, divinityReward = 35, expReward = 200, goldReward = 150,
            abilities = listOf(EnemyAbility("Огнена струя", 2.5f, 0.4f, "Изгаря с огън")),
            emoji = "🐉", isBoss = true, possibleDrops = listOf("steel_sword"),
            loreText = "Пазач на кралската хазна."),

        // === GREEK OLYMPUS ===
        Enemy("cyclops", "Циклоп", "Едноок великан от Гърция.", "Greek", World.GREEK_OLYMPUS, 6,
            health = 400, attack = 40, defense = 15, divinityReward = 50, expReward = 300, goldReward = 200,
            emoji = "👁️", loreText = "Полифем и неговите братя пазят тези земи."),
        Enemy("medusa", "Медуза", "Поглед, превръщащ в камък.", "Greek", World.GREEK_OLYMPUS, 7,
            health = 320, attack = 50, defense = 10, divinityReward = 70, expReward = 400, goldReward = 280,
            abilities = listOf(EnemyAbility("Каменен поглед", 0.5f, 0.35f, "Зашеметява")),
            emoji = "🐍", possibleDrops = listOf("hephaestus_armor"),
            loreText = "Беше красавица, сега е чудовище на Атина."),
        Enemy("minotaur", "Минотавър", "Бик-човек от лабиринта.", "Greek", World.GREEK_OLYMPUS, 8,
            health = 600, attack = 55, defense = 25, divinityReward = 100, expReward = 500, goldReward = 350,
            abilities = listOf(EnemyAbility("Безумна атака", 2.2f, 0.45f, "Тройно удряне")),
            emoji = "🐂", isBoss = true, possibleDrops = listOf("athena_shield"),
            loreText = "Пазач на лабиринта на Крит."),
        Enemy("cerberus", "Цербер", "Тройноглав пазач на Хадес.", "Greek", World.GREEK_OLYMPUS, 10,
            health = 900, attack = 65, defense = 30, divinityReward = 150, expReward = 700, goldReward = 500,
            abilities = listOf(
                EnemyAbility("Тройна захапка", 3.0f, 0.4f, "Трите глави хапят наведнъж"),
                EnemyAbility("Адски вой", 1.5f, 0.3f, "Зашеметява с ужас")
            ),
            emoji = "🐕", isBoss = true, possibleDrops = listOf("hades_helm"),
            loreText = "Единственото изход от Хадес минава край него."),
        Enemy("ares", "Арес - Бог на Войната", "Олимпийски бог. Жажда за кръв.", "Greek", World.GREEK_OLYMPUS, 12,
            health = 1500, attack = 90, defense = 50, divinityReward = 400, expReward = 1500, goldReward = 2000,
            abilities = listOf(
                EnemyAbility("Берсерк на Арес", 3.5f, 0.5f, "Безумна ярост"),
                EnemyAbility("Военна тактика", 2.0f, 0.4f, "Удар в слабото място")
            ),
            emoji = "⚔️", isBoss = true, specialPower = "Всяка убивка го лекува",
            possibleDrops = listOf("zeus_lightning", "poseidon_trident"),
            loreText = "Арес е безмилостен. Войната е неговото дете."),
        Enemy("zeus", "Зевс - Цар на Боговете", "Владетелят на Олимп. Мълнии!", "Greek", World.GREEK_OLYMPUS, 15,
            health = 5000, attack = 150, defense = 80, divinityReward = 1000, expReward = 5000, goldReward = 10000,
            abilities = listOf(
                EnemyAbility("Олимпийска мълния", 5.0f, 0.6f, "Мощна мълния от Зевс"),
                EnemyAbility("Гняв на Зевс", 4.0f, 0.4f, "Цялата сила на небето"),
                EnemyAbility("Бури", 3.0f, 0.3f, "Вятър и буря")
            ),
            emoji = "⚡", isBoss = true, specialPower = "Имунитет към мълния",
            possibleDrops = listOf("zeus_lightning", "golden_fleece"),
            loreText = "Зевс не прощава. Никога. Никому."),

        // === TARTARUS ===
        Enemy("hades", "Хадес - Бог на Мъртвите", "Властелинът на подземното царство.", "Greek", World.TARTARUS, 14,
            health = 4000, attack = 130, defense = 70, divinityReward = 900, expReward = 4500, goldReward = 8000,
            abilities = listOf(
                EnemyAbility("Смъртно докосване", 4.5f, 0.5f, "Директен контакт с душата"),
                EnemyAbility("Призоваване на мъртви", 2.0f, 0.6f, "Лекува се от мъртвите"),
                EnemyAbility("Ада", 6.0f, 0.3f, "Открива портал към ада")
            ),
            emoji = "💀", isBoss = true, specialPower = "Регенерира 200 HP на ход",
            possibleDrops = listOf("hades_helm", "kronos_scythe"),
            loreText = "Хадес не е зло. Но смъртта не спира за никого."),

        // === INDIAN MYTHOLOGY ===
        Enemy("rakshasa", "Ракшас", "Демон от индийската митология.", "Indian", World.INDIAN_REALM, 16,
            health = 700, attack = 70, defense = 35, divinityReward = 120, expReward = 600, goldReward = 400,
            emoji = "😈", loreText = "Ракшасите се хранят с плътта на героите."),
        Enemy("naga", "Нага", "Свещен змей с човешко лице.", "Indian", World.INDIAN_REALM, 17,
            health = 850, attack = 75, defense = 40, divinityReward = 150, expReward = 700, goldReward = 500,
            abilities = listOf(EnemyAbility("Отрова", 2.0f, 0.5f, "Отравя за 3 хода")),
            emoji = "🐍", possibleDrops = listOf("vishnu_chakra")),
        Enemy("ravana", "Равана - Цар на Демоните", "Десетглав демон-цар.", "Indian", World.INDIAN_REALM, 20,
            health = 3000, attack = 110, defense = 60, divinityReward = 700, expReward = 3000, goldReward = 6000,
            abilities = listOf(
                EnemyAbility("Десет глави - Десет удара", 4.0f, 0.5f, "Всяка глава удря"),
                EnemyAbility("Огнен дъх", 3.0f, 0.4f, "Демоничен огън"),
                EnemyAbility("Тъмна магия", 3.5f, 0.35f, "Проклятие")
            ),
            emoji = "👹", isBoss = true, specialPower = "10 живота (глави)",
            possibleDrops = listOf("shiva_trishul"), loreText = "Равана уграбил Сита. Рама го победил."),
        Enemy("shiva", "Шива - Разрушителят", "Богът на разрушението и прераждането.", "Indian", World.INDIAN_REALM, 22,
            health = 6000, attack = 170, defense = 90, divinityReward = 1200, expReward = 6000, goldReward = 12000,
            abilities = listOf(
                EnemyAbility("Танц на Разрушението", 6.0f, 0.6f, "Натараджа разрушава всичко"),
                EnemyAbility("Трето Oko", 8.0f, 0.3f, "Изгаря всичко"),
                EnemyAbility("Тришул", 4.5f, 0.5f, "Митичният тризъбец")
            ),
            emoji = "🔱", isBoss = true, specialPower = "Имунитет към огън",
            possibleDrops = listOf("shiva_trishul", "brahma_lotus"),
            loreText = "Шива е разрушителят. Без разрушение - няма прераждане."),

        // === NORSE ASGARD ===
        Enemy("frost_giant", "Ледоустин", "Великан от Йотунхайм.", "Norse", World.NORSE_ASGARD, 21,
            health = 900, attack = 85, defense = 45, divinityReward = 160, expReward = 800, goldReward = 600,
            emoji = "🧊", loreText = "Jötnar - великаните от ледените пустини."),
        Enemy("fenrir", "Фенрир - Вълкът", "Огромен вълк, дете на Локи.", "Norse", World.NORSE_ASGARD, 23,
            health = 2500, attack = 100, defense = 55, divinityReward = 500, expReward = 2500, goldReward = 4000,
            abilities = listOf(
                EnemyAbility("Захапка на Глетнир", 3.5f, 0.5f, "Бесни хапане"),
                EnemyAbility("Вой на Рагнарок", 2.0f, 0.4f, "Зашеметява всички")
            ),
            emoji = "🐺", isBoss = true, possibleDrops = listOf("mjolnir"),
            loreText = "Фенрир ще погълне Один при Рагнарок."),
        Enemy("thor", "Тор - Богът на Гръмотевицата", "Защитникът на Асгард.", "Norse", World.NORSE_ASGARD, 25,
            health = 5500, attack = 160, defense = 85, divinityReward = 1100, expReward = 5500, goldReward = 11000,
            abilities = listOf(
                EnemyAbility("Мьолнир Удар", 5.0f, 0.6f, "Чукът носи гръм"),
                EnemyAbility("Гръмотевична Буря", 4.0f, 0.5f, "Небето гърми"),
                EnemyAbility("Берсерк", 3.0f, 0.4f, "Войнски ярост")
            ),
            emoji = "⚡", isBoss = true, specialPower = "Имунитет към мълния",
            possibleDrops = listOf("mjolnir", "valhalla_armor"),
            loreText = "Тор пие бира и убива Йотуни. В тази последователност."),
        Enemy("odin", "Один - Всебащата", "Върховният бог на Асгард.", "Norse", World.NORSE_ASGARD, 28,
            health = 8000, attack = 190, defense = 100, divinityReward = 1800, expReward = 8000, goldReward = 18000,
            abilities = listOf(
                EnemyAbility("Гунгнир", 7.0f, 0.6f, "Копието Гунгнир"),
                EnemyAbility("Мъдростта на Мимир", 5.0f, 0.5f, "Знае слабото ти място"),
                EnemyAbility("Вороните - Хугин и Мунин", 4.0f, 0.4f, "Ударите от всяка посока")
            ),
            emoji = "🦅", isBoss = true, specialPower = "Чете ума ти - знае следващия ти ход",
            possibleDrops = listOf("gungnir", "yggdrasil_ring"),
            loreText = "Един окото за мъдростта. Един жертва себе си на Игдрасил."),

        // === TITAN REALM ===
        Enemy("atlas", "Атлас", "Носи небесния свод.", "Titan", World.TITAN_REALM, 38,
            health = 10000, attack = 200, defense = 120, divinityReward = 2000, expReward = 10000, goldReward = 20000,
            abilities = listOf(
                EnemyAbility("Хвърляне на планини", 6.0f, 0.5f, "Буквално хвърля планини"),
                EnemyAbility("Небесен удар", 5.0f, 0.4f, "Свалява небето")
            ),
            emoji = "🏔️", isBoss = true, possibleDrops = listOf("atlas_gauntlets"),
            loreText = "Прометей му е брат. Наказан от Зевс."),
        Enemy("kronos", "Кронос - Титанът на Времето", "Баща на Зевс. Господар на времето.", "Titan", World.TITAN_REALM, 42,
            health = 15000, attack = 250, defense = 150, divinityReward = 3000, expReward = 15000, goldReward = 30000,
            abilities = listOf(
                EnemyAbility("Спиране на Времето", 0f, 0.7f, "Замразява играча за 2 хода"),
                EnemyAbility("Коса на Хаоса", 8.0f, 0.6f, "Реже самото Битие"),
                EnemyAbility("Отмъщение от миналото", 10.0f, 0.3f, "Атакува от миналото")
            ),
            emoji = "⏳", isBoss = true, specialPower = "Понякога обръща времето назад",
            possibleDrops = listOf("kronos_scythe"),
            loreText = "Кронос поглъщал децата си от страх. Зевс го победил."),

        // ═══════════════════════════════════════════
        //  DRAGON REALM ENEMIES
        // ═══════════════════════════════════════════
        Enemy("wyvern", "Уиверн", "Двукрил дракон с опашна жилка.", "Dragon", World.DRAGON_REALM, 17,
            health = 800, attack = 75, defense = 35, divinityReward = 130, expReward = 700, goldReward = 500,
            abilities = listOf(EnemyAbility("Отрова", 2.5f, 0.45f, "Смъртоносна жилка")),
            emoji = "🐲", loreText = "По-малък от дракон, но не по-малко смъртоносен."),
        Enemy("fire_dragon", "Огнен Дракон", "Класически дракон с огнено дихание.", "Dragon", World.DRAGON_REALM, 18,
            health = 1200, attack = 95, defense = 45, divinityReward = 180, expReward = 1000, goldReward = 800,
            abilities = listOf(
                EnemyAbility("Огнено Дихание", 3.5f, 0.5f, "Плътна стена от огън"),
                EnemyAbility("Опашен Удар", 2.0f, 0.4f, "Смазващ удар с опашката")
            ),
            emoji = "🔥", possibleDrops = listOf("fire_dragon_fang", "dragon_scale_armor"),
            loreText = "Живее в вулкани. Хвърля злато."),
        Enemy("ice_dragon", "Ледена Дракониха", "Кралицата на ледените планини.", "Dragon", World.DRAGON_REALM, 19,
            health = 1100, attack = 88, defense = 50, divinityReward = 165, expReward = 950, goldReward = 750,
            abilities = listOf(
                EnemyAbility("Ледено Дихание", 3.0f, 0.5f, "Замразява в блок лед"),
                EnemyAbility("Ледена Буря", 2.5f, 0.4f, "Буря от ледени кристали")
            ),
            emoji = "🧊", possibleDrops = listOf("ice_dragon_horn"),
            loreText = "Кралицата пази яйцата си с живота си."),
        Enemy("shadow_dragon", "Сенчест Дракон", "Дракон от чистия мрак.", "Dragon", World.DRAGON_REALM, 20,
            health = 1300, attack = 100, defense = 40, divinityReward = 200, expReward = 1100, goldReward = 900,
            abilities = listOf(
                EnemyAbility("Сенчесто Дихание", 3.8f, 0.5f, "Тъмна материя"),
                EnemyAbility("Изчезване", 0f, 0.4f, "Избягва удара")
            ),
            emoji = "🌑", loreText = "Никой не е видял истинската му форма."),
        Enemy("hydra", "Лернейска Хидра", "9 глави. Отрежеш една — израстват две.", "Dragon", World.DRAGON_REALM, 21,
            health = 2500, attack = 110, defense = 55, divinityReward = 350, expReward = 2000, goldReward = 1800,
            abilities = listOf(
                EnemyAbility("Деветорна Захапка", 4.5f, 0.5f, "Всичките 9 глави хапят"),
                EnemyAbility("Регенерация на Глава", 0f, 0.6f, "Лекува се с 500 HP"),
                EnemyAbility("Отрова от всички глави", 3.0f, 0.4f, "Масово отравяне")
            ),
            emoji = "🐍", isBoss = true, possibleDrops = listOf("hydra_blood_vial"),
            loreText = "Херакъл я победил с помощта на Йолай.", specialPower = "Регенерира 500 HP всеки ход"),
        Enemy("nidhogg", "Нидхог", "Гризе корените на Игдрасил.", "Norse Dragon", World.DRAGON_REALM, 22,
            health = 2000, attack = 105, defense = 48, divinityReward = 300, expReward = 1700, goldReward = 1500,
            abilities = listOf(
                EnemyAbility("Вселенска Отрова", 4.0f, 0.5f, "Отрова от световния змей"),
                EnemyAbility("Корени на Игдрасил", 3.0f, 0.4f, "Обвива в корени")
            ),
            emoji = "🐉", possibleDrops = listOf("nidhogg_venom"),
            loreText = "Гризе Игдрасил от зората на времето."),
        Enemy("tiamat", "Тиамат - Майката на Дракони", "Вавилонското петоглаво чудовище. Майката на всички дракони.", "Dragon", World.DRAGON_REALM, 25,
            health = 20000, attack = 280, defense = 160, divinityReward = 4000, expReward = 20000, goldReward = 40000,
            abilities = listOf(
                EnemyAbility("Петоглав Хаос", 7.0f, 0.6f, "5 глави атакуват едновременно"),
                EnemyAbility("Примордиална Магия", 6.0f, 0.5f, "Магия от зората на времето"),
                EnemyAbility("Морски Хаос", 8.0f, 0.4f, "Цунами от хаотична енергия"),
                EnemyAbility("Раждане на Дракони", 3.0f, 0.5f, "Призовава малки дракони")
            ),
            emoji = "🌊", isBoss = true, specialPower = "Петте глави имат отделни HP",
            possibleDrops = listOf("tiamat_scale", "fire_dragon_fang"),
            loreText = "Тиамат е самия Хаос в дракон форма. Победена от Мардук."),

        // ═══════════════════════════════════════════
        //  EGYPTIAN REALM ENEMIES
        // ═══════════════════════════════════════════
        Enemy("mummy", "Мумия", "Прокълнат фараон от древността.", "Egyptian", World.EGYPTIAN_REALM, 14,
            health = 500, attack = 50, defense = 22, divinityReward = 80, expReward = 450, goldReward = 320,
            abilities = listOf(EnemyAbility("Проклятие", 1.5f, 0.4f, "Намалява атаката")),
            emoji = "🧟", loreText = "Пазачи на пирамидите. Никога не спят."),
        Enemy("sphinx", "Сфинкс", "Лице на жена, тяло на лъв. Задава гатанки.", "Egyptian", World.EGYPTIAN_REALM, 14,
            health = 650, attack = 60, defense = 30, divinityReward = 100, expReward = 500, goldReward = 400,
            abilities = listOf(
                EnemyAbility("Мистична Захапка", 2.5f, 0.4f, "Лъвска захапка"),
                EnemyAbility("Гатанката на Смъртта", 5.0f, 0.2f, "Не можеш да отговориш")
            ),
            emoji = "🦁", loreText = "Убивала пътници, невъзможни да решат гатанките."),
        Enemy("ammit", "Амит - Пожирателят", "Поглъща сърцата на недостойните.", "Egyptian", World.EGYPTIAN_REALM, 15,
            health = 800, attack = 70, defense = 35, divinityReward = 120, expReward = 600, goldReward = 480,
            abilities = listOf(EnemyAbility("Поглъщане на Душа", 4.0f, 0.35f, "Краде от живота ти")),
            emoji = "🐊", loreText = "Тялото на крокодил, глава на хипопотам, грива на лъв."),
        Enemy("apep", "Апеп - Змеят на Хаоса", "Вечен враг на Ра. Змей на мрака.", "Egyptian", World.EGYPTIAN_REALM, 16,
            health = 3000, attack = 120, defense = 65, divinityReward = 600, expReward = 2800, goldReward = 4000,
            abilities = listOf(
                EnemyAbility("Поглъщане на Слънцето", 5.0f, 0.5f, "Опит да погълне Ра"),
                EnemyAbility("Хаотична Отрова", 4.0f, 0.4f, "Отрова от Хаоса"),
                EnemyAbility("Тъмнина", 3.0f, 0.5f, "Гаси светлината")
            ),
            emoji = "🐍", isBoss = true, possibleDrops = listOf("ra_staff"),
            loreText = "Всяка нощ атакува слънчевата ладия. Всяка нощ губи."),
        Enemy("set_god", "Сет - Богът на Хаоса", "Бог на пустинята, бурите и злото.", "Egyptian", World.EGYPTIAN_REALM, 17,
            health = 4500, attack = 140, defense = 75, divinityReward = 900, expReward = 4000, goldReward = 7000,
            abilities = listOf(
                EnemyAbility("Пясъчна Буря", 4.5f, 0.5f, "Опустошителна буря"),
                EnemyAbility("Хаотична Сила", 5.0f, 0.4f, "Чиста сила на хаоса"),
                EnemyAbility("Убийство на Озирис", 7.0f, 0.3f, "Удар с мощта на предателство")
            ),
            emoji = "🌪️", isBoss = true, possibleDrops = listOf("khopesh", "anubis_scale"),
            loreText = "Уби брат си Озирис. Осъден от Хор."),
        Enemy("ra", "Ра - Слънчевият Бог", "Върховният бог на Египет. Слънцето е негово тяло.", "Egyptian", World.EGYPTIAN_REALM, 18,
            health = 8000, attack = 180, defense = 95, divinityReward = 1600, expReward = 7500, goldReward = 15000,
            abilities = listOf(
                EnemyAbility("Слънчев Взрив", 6.0f, 0.6f, "Цялата мощ на слънцето"),
                EnemyAbility("Лъчите на Ра", 5.0f, 0.5f, "Неудържими слънчеви лъчи"),
                EnemyAbility("Трансформация в Слънце", 8.0f, 0.3f, "Ра се превръща в чиста светлина")
            ),
            emoji = "☀️", isBoss = true, specialPower = "Имунитет към тъмнина",
            possibleDrops = listOf("ra_staff", "horus_wings"),
            loreText = "Ра пътува по небето всеки ден. Всяка нощ се бие с Апеп."),

        // ═══════════════════════════════════════════
        //  JAPANESE REALM ENEMIES
        // ═══════════════════════════════════════════
        Enemy("oni", "Они - Японски Демон", "Рогат демон с желязна бухалка.", "Japanese", World.JAPANESE_REALM, 25,
            health = 900, attack = 85, defense = 40, divinityReward = 160, expReward = 800, goldReward = 600,
            abilities = listOf(EnemyAbility("Тоя Удар", 2.5f, 0.5f, "Смазващ удар с желязна бухалка")),
            emoji = "👹", loreText = "Они живеят в Ад. Мъчат грешните."),
        Enemy("tengu", "Тенгу - Планинска Птица", "Полуптица полудемон. Майстор на меча.", "Japanese", World.JAPANESE_REALM, 25,
            health = 750, attack = 90, defense = 35, divinityReward = 150, expReward = 750, goldReward = 550,
            abilities = listOf(
                EnemyAbility("Вятърен Удар", 2.8f, 0.5f, "Скоростен удар"),
                EnemyAbility("Крило Атака", 2.0f, 0.4f, "Удар с крило")
            ),
            emoji = "🦅", loreText = "Тенгу учили самурайте на бойни изкуства."),
        Enemy("yamata_no_orochi", "Ямата-но-Орочи", "Осемглавия японски дракон змей.", "Japanese", World.JAPANESE_REALM, 27,
            health = 5000, attack = 155, defense = 80, divinityReward = 1000, expReward = 4500, goldReward = 8000,
            abilities = listOf(
                EnemyAbility("Осем глави - Осем удара", 4.5f, 0.5f, "Всяка глава хапе"),
                EnemyAbility("Отровно дихание", 3.5f, 0.4f, "Масова отрова"),
                EnemyAbility("Замитане с опашката", 5.0f, 0.35f, "Смазва с огромната опашка")
            ),
            emoji = "🐍", isBoss = true, possibleDrops = listOf("kusanagi"),
            loreText = "В опашката му беше скрит мечът Кусанаги. Убит от Сусаноо."),
        Enemy("susanoo", "Сусаноо - Бог на Бурите", "Брат на Аматерасу. Повелява бурите.", "Japanese", World.JAPANESE_REALM, 28,
            health = 6000, attack = 165, defense = 85, divinityReward = 1200, expReward = 5500, goldReward = 10000,
            abilities = listOf(
                EnemyAbility("Буря на Сусаноо", 5.5f, 0.5f, "Разрушителна буря"),
                EnemyAbility("Мълния и Гром", 4.5f, 0.45f, "Японска гръмотевица"),
                EnemyAbility("Морски Вал", 6.0f, 0.35f, "Вал от бурното море")
            ),
            emoji = "⛈️", isBoss = true, possibleDrops = listOf("katana_of_storms"),
            loreText = "Изгонен от Аматерасу. Убил Орочи. Намерил Кусанаги."),
        Enemy("amaterasu_god", "Аматерасу - Богиня на Слънцето", "Върховната богиня на Япония. Слънцето.", "Japanese", World.JAPANESE_REALM, 30,
            health = 9000, attack = 195, defense = 105, divinityReward = 1900, expReward = 9000, goldReward = 18000,
            abilities = listOf(
                EnemyAbility("Слънчева Стрела", 6.5f, 0.5f, "Стрела от чиста светлина"),
                EnemyAbility("Изгаряща Светлина", 7.0f, 0.4f, "Невидимо изгаряне"),
                EnemyAbility("Небесната Скала", 8.0f, 0.3f, "Скала от небесата")
            ),
            emoji = "🌅", isBoss = true, specialPower = "Имунитет към тъмнина",
            possibleDrops = listOf("amaterasu_mirror", "kusanagi"),
            loreText = "Когато се скрила в пещера, светлината изчезнала от света."),

        // ═══════════════════════════════════════════
        //  CHINESE REALM ENEMIES
        // ═══════════════════════════════════════════
        Enemy("jiangshi", "Дзянши - Китайски Вампир", "Скача и смуче жизнена сила.", "Chinese", World.CHINESE_REALM, 29,
            health = 700, attack = 80, defense = 30, divinityReward = 140, expReward = 650, goldReward = 480,
            abilities = listOf(EnemyAbility("Смучене на ци", 2.5f, 0.5f, "Краде живот")),
            emoji = "🧟", loreText = "Ако закриеш ноздрите си — не те вижда."),
        Enemy("dragon_king", "Дракон Кралят на Морето", "Властелин на подводния дворец.", "Chinese", World.CHINESE_REALM, 30,
            health = 5500, attack = 150, defense = 78, divinityReward = 1100, expReward = 5000, goldReward = 9000,
            abilities = listOf(
                EnemyAbility("Водна Армия", 4.0f, 0.5f, "Призовава подводни войници"),
                EnemyAbility("Дракон Вълна", 5.5f, 0.45f, "Гигантска вълна"),
                EnemyAbility("Тайфун", 6.0f, 0.35f, "Унищожителен тайфун")
            ),
            emoji = "🐲", isBoss = true, possibleDrops = listOf("dragon_pearl", "dragon_king_water"),
            loreText = "Ву Конг му открадна магическата пръчка."),
        Enemy("sun_wukong", "Сун Ву Конг - Маймунският Крал", "Крал на маймуните. 72 трансформации. Безсмъртен.", "Chinese", World.CHINESE_REALM, 32,
            health = 12000, attack = 220, defense = 130, divinityReward = 2500, expReward = 12000, goldReward = 25000,
            abilities = listOf(
                EnemyAbility("72 Трансформации", 5.0f, 0.6f, "Копира силата на врага"),
                EnemyAbility("Пръчката Жуйи", 7.0f, 0.5f, "Огромна пръчка"),
                EnemyAbility("Облак Скок", 4.0f, 0.4f, "Скок от небесния облак"),
                EnemyAbility("Армия от клонинги", 3.0f, 0.5f, "Косъм → армия от маймуни")
            ),
            emoji = "🐒", isBoss = true, specialPower = "Безсмъртен — трябва 3 пъти да го убиеш",
            possibleDrops = listOf("ruyi_jingu_bang"),
            loreText = "Роден от камък. Победи смъртта. Победи ада. Победи небесата."),
        Enemy("jade_emperor_god", "Нефритеният Цар", "Правителят на небесата.", "Chinese", World.CHINESE_REALM, 35,
            health = 18000, attack = 270, defense = 155, divinityReward = 3500, expReward = 18000, goldReward = 35000,
            abilities = listOf(
                EnemyAbility("Небесна Армия", 5.0f, 0.6f, "100 000 небесни войници"),
                EnemyAbility("Нефритен Гръм", 7.0f, 0.5f, "Смазващ небесен гръм"),
                EnemyAbility("Повеля на Небесата", 9.0f, 0.4f, "Абсолютна власт"),
                EnemyAbility("Отлъчване", 6.0f, 0.35f, "Отнема силите на врага")
            ),
            emoji = "👑", isBoss = true, specialPower = "Призовава армия при 50% HP",
            possibleDrops = listOf("jade_armor", "dragon_pearl"),
            loreText = "Управлява 33-те небеса. Дори Ву Конг не може да излезе от дланта му."),

        // ═══════════════════════════════════════════
        //  MASS BATTLE ARENA ENEMIES (weaker but in waves)
        // ═══════════════════════════════════════════
        Enemy("arena_soldier", "Арена Войник", "Обикновен гладиатор.", "Arena", World.MASS_BATTLE_ARENA, 1,
            health = 60, attack = 12, defense = 5, divinityReward = 3, expReward = 15, goldReward = 10,
            emoji = "⚔️", loreText = "Пушечно месо в арената."),
        Enemy("arena_archer", "Арена Стрелец", "Стреля от разстояние.", "Arena", World.MASS_BATTLE_ARENA, 1,
            health = 45, attack = 15, defense = 3, divinityReward = 3, expReward = 15, goldReward = 10,
            emoji = "🏹"),
        Enemy("arena_mage", "Арена Магьосник", "Хвърля огнени топки.", "Arena", World.MASS_BATTLE_ARENA, 1,
            health = 35, attack = 20, defense = 2, divinityReward = 4, expReward = 20, goldReward = 15,
            abilities = listOf(EnemyAbility("Огнена топка", 2.0f, 0.5f, "Магически удар")),
            emoji = "🔮"),
        Enemy("arena_beast", "Арена Звяр", "Дива немируема бестия.", "Arena", World.MASS_BATTLE_ARENA, 1,
            health = 100, attack = 18, defense = 8, divinityReward = 5, expReward = 25, goldReward = 20,
            emoji = "🐗"),
        Enemy("arena_champion", "Арена Шампион", "Непобеден до днес.", "Arena", World.MASS_BATTLE_ARENA, 5,
            health = 500, attack = 60, defense = 30, divinityReward = 80, expReward = 300, goldReward = 250,
            abilities = listOf(EnemyAbility("Шампионски удар", 3.0f, 0.5f, "Мощен удар")),
            emoji = "🏆", isBoss = true,
            possibleDrops = listOf("steel_sword", "knights_plate")),

        // ═══════════════════════════════════════════
        //  DIVINE PANTHEON (Final)
        // ═══════════════════════════════════════════
        Enemy("primordial", "Хаос - Първичността", "Преди боговете имаше само Хаос.", "Divine", World.DIVINE_PANTHEON, 48,
            health = 100000, attack = 500, defense = 300, divinityReward = 50000, expReward = 100000, goldReward = 200000,
            abilities = listOf(
                EnemyAbility("Хаос Взрив", 10.0f, 0.7f, "Силата на Хаоса"),
                EnemyAbility("Отмяна на Реалността", 15.0f, 0.4f, "Всичко престава да съществува"),
                EnemyAbility("Вечна Нощ", 8.0f, 0.5f, "Поглъща светлината"),
                EnemyAbility("Призоваване на всички богове", 12.0f, 0.4f, "Всички богове атакуват"),
                EnemyAbility("Началото на Края", 20.0f, 0.25f, "Апокалиптичен удар")
            ),
            emoji = "🌌", isBoss = true, specialPower = "Имунитет към всичко до 25000 дивинити",
            possibleDrops = listOf("omnigod_crown"),
            loreText = "В началото беше Хаос. В края — ти.")
    )

    // ─────────────────────────────────────────────
    //  DIALOGUES
    // ─────────────────────────────────────────────

    val ALL_DIALOGUES = listOf(
        Dialogue("intro", listOf(
            DialogueLine("Мъдрецът", "Пътниче... Боговете те наблюдават.", emoji = "🧙"),
            DialogueLine("Мъдрецът", "Смъртните не могат да надвишат боговете... или поне тъй вярваха.", emoji = "🧙"),
            DialogueLine("Мъдрецът", "Ти ще докажеш обратното. Поеми силата на враговете си. Стани повече от бог.", emoji = "🧙"),
            DialogueLine("${"%s"}", "Аз приемам съдбата си.", emoji = "⚔️",
                choices = listOf(
                    DialogueChoice("\"Ще победя всеки бог!\"", effect = DialogueEffect(expChange = 50)),
                    DialogueChoice("\"Търся само мир.\"", effect = DialogueEffect(goldChange = 100)),
                    DialogueChoice("\"Силата е всичко.\"", effect = DialogueEffect(divinityChange = 10))
                ))
        )),
        Dialogue("zeus_pre_battle", listOf(
            DialogueLine("Зевс ⚡", "СМЪРТНИ! Как смееш да стъпиш на Олимп?!", emoji = "⚡"),
            DialogueLine("Зевс ⚡", "Аз съм Зевс! Царят на боговете! Ще те обърна на пепел!", emoji = "⚡"),
            DialogueLine("${"%s"}", "Аз не се страхувам от богове.", emoji = "⚔️",
                choices = listOf(
                    DialogueChoice("\"Мълниите ти са нищо!\"", effect = DialogueEffect(divinityChange = 20)),
                    DialogueChoice("\"Научи ме нещо преди да умреш.\"")
                ))
        )),
        Dialogue("shiva_pre_battle", listOf(
            DialogueLine("Шива 🔱", "Аз съм Натараджа. Танцът на разрушението е безкраен.", emoji = "🔱"),
            DialogueLine("Шива 🔱", "Дори и да ме победиш, аз ще се прераждам. Вечно.", emoji = "🔱"),
            DialogueLine("${"%s"}", "Тогава ще те побеждавам вечно.", emoji = "⚔️")
        )),
        Dialogue("kronos_pre_battle", listOf(
            DialogueLine("Кронос ⏳", "Аз съм Времето. Всичко е моята крепост.", emoji = "⏳"),
            DialogueLine("Кронос ⏳", "Ти си само момент. Аз съм Вечността.", emoji = "⏳"),
            DialogueLine("${"%s"}", "Ще открадна вечността от теб.", emoji = "⚔️")
        )),
        Dialogue("final_boss", listOf(
            DialogueLine("Хаос 🌌", "Ти... смъртен... стигна до тук?", emoji = "🌌"),
            DialogueLine("Хаос 🌌", "Поглъщаш сили... как и аз. Може би ти... си достоен.", emoji = "🌌"),
            DialogueLine("Хаос 🌌", "Победи ме... и стани... ВСЕБОГ.", emoji = "🌌"),
            DialogueLine("${"%s"}", "Дойдох за твоята сила.", emoji = "⚔️")
        ))
    )

    fun getEnemiesForWorld(world: World): List<Enemy> = ALL_ENEMIES.filter { it.world == world }
    fun getItemById(id: String): Item? = ALL_ITEMS[id]
    fun getAbilityById(id: String): Ability? = ALL_ABILITIES[id]
    fun getDialogueById(id: String): Dialogue? = ALL_DIALOGUES.find { it.id == id }

    fun getStarterAbilities(heroClass: HeroClass): List<Ability> {
        return when (heroClass) {
            HeroClass.WARRIOR -> listOf(ALL_ABILITIES["slash"]!!, ALL_ABILITIES["berserker"]!!)
            HeroClass.MAGE -> listOf(ALL_ABILITIES["fireball"]!!, ALL_ABILITIES["heal_self"]!!)
            HeroClass.ARCHER -> listOf(ALL_ABILITIES["arrow_rain"]!!, ALL_ABILITIES["shadow_step"]!!)
            HeroClass.MONK -> listOf(ALL_ABILITIES["holy_strike"]!!, ALL_ABILITIES["heal_self"]!!)
        }
    }

    fun getRandomEnemyForLevel(level: Int): Enemy {
        val suitable = ALL_ENEMIES.filter { Math.abs(it.level - level) <= 3 }
        return if (suitable.isNotEmpty()) suitable.random() else ALL_ENEMIES.first()
    }
}

// ─────────────────────────────────────────────
//  EXTENDED ENEMY LORE DATABASE
// ─────────────────────────────────────────────

object EnemyLoreDatabase {
    val LORE = mapOf(
        "zeus" to "Зевс е цар на Олимп от победата над Кронос. Никой смъртен не го е победил... досега.",
        "odin" to "Един пожертвал окото си в кладенеца на Мимир за абсолютна мъдрост. Знае кога ще умре при Рагнарок.",
        "ra" to "Ра се ражда всяка сутрин като скарабей, пътува до залез, умира и се ражда пак. Безкраен цикъл.",
        "shiva" to "Шива танцува Тандава — Танца на Разрушението. Когато спре, светът приключва.",
        "sun_wukong" to "Ву Конг победил 100 000 небесни войника сам. Единственото нещо, спряло го, е самия Буда.",
        "thor" to "Тор убива Йормунганд при Рагнарок, но умира от отровата му. Знае го. Все пак се бие.",
        "amaterasu_god" to "Аматерасу е самото слънце. Когато се скрила, тъмнина обвила света. Само смях я извел.",
        "anubis" to "Анубис е справедлив, не зъл. Претегля всяка душа с математическа точност.",
        "kronos" to "Кронос изял 5 от децата си от страх. Шестото — Зевс — го победило. Историята се повтаря.",
        "tiamat" to "От тялото на Тиамат е направен светът. Всяка капка вода в морето е нейна кръв.",
        "fenrir" to "Фенрир е по-мощен от всички богове взети заедно. Само магическата верига Глейпнир го удържа.",
        "medusa" to "Медуза не винаги е чудовище. Тя е жертва на несправедливостта на боговете.",
        "hydra" to "Отровата на Хидрата е толкова силна, че нанесена на стрели, убива векове по-късно.",
        "cerberus" to "Цербер не е зъл — само не пуска никого да напусне. Орфей го приспал с музика.",
        "atlas" to "Атлас носи небесата на раменете си. Не защото трябва — а защото Зевс го е наказал.",
        "prometheus_enemy" to "Прометей открал огъня на хората. Зевс го наказал: орел яде черния му дроб всеки ден.",
        "dragon_king" to "Дракон Кралят управлява Източното море. Ву Конг му е откраднал магическата пръчка.",
        "nidhogg" to "Нидхог гризе корените на Игдрасил. Денят, в който завърши, е денят на Рагнарок.",
        "yamata_no_orochi" to "Орочи иска по едно момиче всяка година. Сусаноо го спира с ориз ракия и меч.",
        "apep" to "Апеп е вечен. Унищожен хиляди пъти, ражда се отново всяка нощ. Хаосът не умира."
    )

    val BOSS_BATTLE_QUOTES = mapOf(
        "zeus" to listOf(
            "Смея ли да се яви смъртен пред Царя на Боговете?",
            "Мълниите ми са ковани от Циклопите. Опитай се да ги избегнеш.",
            "Олимп не е за смъртни!",
            "Ти ще станеш спомен. Нищо повече.",
            "МЪЛНИЯ НА БОГОВЕТЕ!"
        ),
        "odin" to listOf(
            "Виждам съдбата ти. Тя не е добра.",
            "Гарваните ми вече ми казаха за теб.",
            "Гунгнир никога не пропуска.",
            "Ти знаеш ли какво жертвах за знанието?",
            "Рагнарок ще дойде. Но преди него — ти."
        ),
        "shiva" to listOf(
            "Тандава започва. Радвай се на последния си танц.",
            "Разрушавам, за да творя. Ти ще бъдеш суровина.",
            "Трето oko се отваря!",
            "Ом Намах Шивая!",
            "Ти си прах. Аз съм вечността."
        ),
        "sun_wukong" to listOf(
            "Ха! Да видим дали си по-добър от 100 000 небесни войника!",
            "72 трансформации! Коя ще избереш?",
            "Моята пръчка може да е голяма колкото планини!",
            "Не съм победен от богове. Ти мислиш, че ще успееш?",
            "МАЙМУНСКИ КРАЛ АТАКУВА!"
        )
    )

    fun getQuote(enemyId: String): String {
        val quotes = BOSS_BATTLE_QUOTES[enemyId] ?: return "..."
        return quotes.random()
    }

    fun getLore(enemyId: String): String {
        return LORE[enemyId] ?: "Легендарен враг от митологичните времена."
    }
}

// ─────────────────────────────────────────────
//  EXTENDED ENEMY DIALOGUE DATABASE
// ─────────────────────────────────────────────

object ExtendedEnemyDialogueDB {

    val PRE_BATTLE_TAUNTS = mapOf(
        "zeus" to listOf(
            "СМЪРТЕН на Олимп?! Последният, дошъл тук, е пепел!",
            "Мълниите ми не пропускат. Никога не са пропускали.",
            "Знаеш ли колко са пробвали? Всичките са мъртви.",
            "Атина ми е казала. Мислех, че лъже. Сега не съм сигурен."
        ),
        "odin" to listOf(
            "Гарваните ми те наблюдаваха. Впечатляващ. За смъртен.",
            "Видях твоето бъдеще в руните. Любопитно.",
            "Гунгнирът никога не пропуска. Ще го проверим.",
            "Рагнарок идва. Ти ли ще го спреш? Амбициозно."
        ),
        "ra" to listOf(
            "Аз се раждам всяка сутрин. Умирам всяка вечер. Ти?",
            "Слънчевата ми аура изгаря всичко. Включително дивинитито ти.",
            "3000 години без предизвикателство. Интересно.",
            "Апоп се опитва всяка нощ. Дори той не успява."
        ),
        "thor" to listOf(
            "AHAHAHA! Смъртен! Харесвам дързостта ти!",
            "Мьолнир е жаден! Последно е пил Великанска кръв!",
            "Баща ми казва да те тествам. С удоволствие!",
            "Ако оцелееш — ще те почерпя! Ако не — Валхала е хубаво!"
        ),
        "shiva" to listOf(
            "Тандава започва. Вселената трепери. Ти?",
            "Третото ми oko те вижда. Всичко за теб. Слабостите ти.",
            "Разрушавам. После сътворявам. Ти ще бъдеш материала.",
            "Многото ти животи са капани. Всичките ще поглъщам."
        ),
        "chaos" to listOf(
            "Ти дойде. Знаех, че ще дойдеш.",
            "Аз съм преди всичко. Ти ще бъдеш след всичко.",
            "Всеки ред е Хаос, чакащ освобождение.",
            "Победи ме. Ако можеш. Ако искаш. Ако разбираш последствията."
        ),
        "tiamat" to listOf(
            "Седем глави. Седем елемента. Нула шанса.",
            "Аз съм майката на всички дракони. Ти убиваш децата ми.",
            "Преди боговете беше Тиамат. Ще остана и след тях.",
            "Огън, Лед, Мълния, Отрова, Сянка, Земя, Вятър. Коя глава първо?"
        ),
        "kronos" to listOf(
            "Поглъщах децата си. Заслужено ли? Може би.",
            "Зевс ме хвърли тук. Syn против баща. Срамно.",
            "Чакам хиляди години. Реваншът е сладък.",
            "Времето е мое. Беше. Ще бъде отново."
        )
    )

    val POST_BATTLE_DEFEAT_LINES = mapOf(
        "zeus" to "Невъзможно... Мълниите... Силата ми тече към теб...",
        "odin" to "Видях го в руните... Не вярвах... Бъди достоен с нея...",
        "ra" to "Слънцето... за пръв път... не изгрява самò...",
        "thor" to "AHAHAHA! Победен! За пръв път! Приятел! Ела да пием!",
        "shiva" to "Разрушен... но не унищожен... Тандава продължава в теб...",
        "chaos" to "Поглъщаш ме... Ставаш... всичко... Добре дошъл...",
        "tiamat" to "Седем глави паднаха... Силата на дракона е твоя...",
        "kronos" to "Времето... спря... за мен... Сега е твое..."
    )

    val WORLD_AMBIENT_DIALOGUES = mapOf(
        "Олимп" to listOf(
            "Хермес: Псст! Давам ти подсказка — Атина е настрани Зевс!",
            "Незнаен Глас: Не всички богове са враждебни. Слушай внимателно.",
            "Ехо: Мълниите тук имат своя воля. Внимавай."
        ),
        "Асгард" to listOf(
            "Валкирия: Храбрите мъртви идват тук. Ти си храбър — ще се върнеш ли?",
            "Йотун Глас: Великаните чакат. Рагнарок е близо.",
            "Иггдрасил Шепот: Дървото говори на тези, умеещи да слушат."
        ),
        "Египет" to listOf(
            "Жрец: Маат гледа. Всяко действие — претеглено.",
            "Мумия Глас: Не всички мъртви спят. Не всички буднали са живи.",
            "Пясъкът Говори: Пирамидите пазят тайни. Ако намериш — не казвай."
        ),
        "Дракон Царство" to listOf(
            "Дракон Малък: Не убивай майка ми. Тя е добра когато не те яде.",
            "Древен Глас: Тиамат е по-стара от боговете. Уважавай.",
            "Огън Пращи: Дракон Люспите падат само от честна битка."
        )
    )

    val ALLY_DIALOGUE_LINES = mapOf(
        "Companion_Ares" to listOf(
            "Убий ги! Всичките! После убий и тях!",
            "Кръвта е единственият валиден аргумент.",
            "Войната е поезия. Аз съм поет."
        ),
        "Companion_Artemis" to listOf(
            "Точност. Фокус. Една стрела, един враг.",
            "Луната ме пази. И теб — засега.",
            "Дивите животни са по-честни от боговете."
        ),
        "Companion_Loki" to listOf(
            "Доверяваш ли ми се? Умно ли е това?",
            "Имам план. Може да работи. Вероятно.",
            "Предателят е полезен — докато не те предаде."
        ),
        "Companion_Freya" to listOf(
            "Любовта и войната са едно и също. Питай Арес.",
            "Брисингамен ме пази. Тебе — талантът ти.",
            "Половината от убитите са мои. Другата — на Один."
        )
    )

    fun getPreBattleTaunt(enemyId: String): String {
        val taunts = PRE_BATTLE_TAUNTS[enemyId] ?: listOf("Подготви се за битка!")
        return taunts.random()
    }

    fun getPostBattleDefeatLine(enemyId: String): String =
        POST_BATTLE_DEFEAT_LINES[enemyId] ?: "Победен... Силата ми е твоя..."

    fun getAmbientDialogue(worldName: String): String? {
        val lines = WORLD_AMBIENT_DIALOGUES[worldName] ?: return null
        return lines.random()
    }

    fun getCompanionLine(companionId: String): String {
        val lines = ALLY_DIALOGUE_LINES[companionId] ?: listOf("...")
        return lines.random()
    }
}

// ─────────────────────────────────────────────
//  ITEM DESCRIPTION EXTENDED DATABASE
// ─────────────────────────────────────────────

object ItemDescriptionExtendedDB {

    val LEGENDARY_ITEM_LORE = mapOf(
        "zeus_thunderbolt" to "Изкована от Хефест по поръчка на Зевс след Титаномахията. Нито един друг бог не може да я носи без последствия.",
        "odin_gungnir" to "Гунгнирът никога не пропуска. Сакрифициран от самия Един в началото на Рагнарок. Намерен в пепелта след края.",
        "thor_mjolnir" to "Мьолнир е по-кратък от планираното заради Локи (дърпал ковача за косата). Тор го ползва с ръкавица — иначе изгаря.",
        "ra_solar_disc" to "Слънчевият диск на Ра. Загасва само когато Ра умира всяка вечер. Светва отново с изгрева. Взет след победа над Апоп.",
        "anubis_scales" to "Везните на Анубис претеглят не тежестта — а честността. Лека душа преминава. Тежка душа — Амут чака.",
        "athena_shield" to "Щитът Егида на Атина. Украсен с главата на Медуза. Погледнеш ли в него — окамениш се.",
        "shiva_trident" to "Тришулата на Шива. Три зъба за три функции: сътворение, опазване, разрушение. Едновременно.",
        "excalibur_mythos" to "Митичната Екскалибур в светът на Митос. Само истинският Всебог може да я вдигне. Дори и тогава е тежка."
    )

    val SET_BONUS_DESCRIPTIONS = mapOf(
        "zeus_set" to mapOf(
            "2" to "Мълниите ти ускоряват — атакуваш двойно по-бързо в 5 секунди след крит.",
            "4" to "Зевс ти изпраща допълнителна мълния на всяка 5-та атака твоя (+200 урон).",
            "6" to "ЗЕВСОВ БЛАГОСЛОВ: При HP под 30% се телепортираш и атакуваш x3. Cooldown: 60s."
        ),
        "ragnarok_set" to mapOf(
            "2" to "Ледено Оплетение: Враговете губят 10% скорост на атака при всеки твой удар.",
            "4" to "Берсерк Активиран: При HP под 50% — ATK x2 автоматично до края на битката.",
            "6" to "РАГНАРОК РЕЖИМ: Под 30% HP? ATK x4, DEF x0.5. Атакуваш или умираш."
        ),
        "pharaoh_set" to mapOf(
            "2" to "Фараонска Аура: +25% злато и дивинити. Всеки убит враг дава малко повече.",
            "4" to "Анубис Защита: 1 път на битка — блокираш смъртоносен удар изцяло.",
            "6" to "РА БЛАГОСЛОВ: Изгаряща аура — враговете губят 3% HP/ход при влизане."
        ),
        "omnigod_set" to mapOf(
            "2" to "+800 ATK, +500 DEF. Ти вече не си нормален.",
            "4" to "+1500 ATK, +1000 DEF, +50% всичко. Боговете се страхуват.",
            "6" to "ВСЕБОГ МОЩ: x2 всичко. При враг под 10% HP — МИГНОВЕНА СМЪРТ."
        )
    )

    fun getItemLore(itemId: String): String =
        LEGENDARY_ITEM_LORE[itemId] ?: "Произходът на този предмет е загадка — дори за боговете."

    fun getSetBonusDescription(setId: String, pieces: Int): String {
        val bonuses = SET_BONUS_DESCRIPTIONS[setId] ?: return "Без сет бонус."
        return when {
            pieces >= 6 -> bonuses["6"] ?: "—"
            pieces >= 4 -> bonuses["4"] ?: "—"
            pieces >= 2 -> bonuses["2"] ?: "—"
            else -> "Нужни поне 2 части за сет бонус."
        }
    }

    val ITEM_FLAVOR_TEXTS = listOf(
        "\"Оръжията не убиват. Хората убиват. Оръжията помагат.\" — Арес",
        "\"Най-доброто оръжие е това, което нямаш нужда да използваш.\" — Атина",
        "\"Занаятчийството е молитва в метал.\" — Хефест",
        "\"Злато е универсален език. Дори боговете го говорят.\" — Хермес",
        "\"Предметите пазят истории. Слушай ги.\" — Теос",
        "\"Легендарните предмети намират своите носители. Не обратното.\" — Съдбата"
    )

    fun getRandomFlavorText() = ITEM_FLAVOR_TEXTS.random()
}
