package com.mythosrise.game.engine

// ─────────────────────────────────────────────
//  ELEMENTS
// ─────────────────────────────────────────────

enum class Element(val displayName: String, val emoji: String, val color: String) {
    FIRE("Огън", "🔥", "#FF4400"),
    ICE("Лед", "❄️", "#44AAFF"),
    LIGHTNING("Мълния", "⚡", "#FFFF00"),
    HOLY("Свят", "✨", "#FFFFFF"),
    SHADOW("Сянка", "🌑", "#440088"),
    POISON("Отрова", "🐍", "#00CC44"),
    WATER("Вода", "🌊", "#0088FF"),
    EARTH("Земя", "🌍", "#886622"),
    WIND("Вятър", "💨", "#88FFAA"),
    CHAOS("Хаос", "🌀", "#FF00FF"),
    DIVINE("Дивин", "🌟", "#FFD700"),
    PHYSICAL("Физически", "⚔️", "#AAAAAA")
}

// ─────────────────────────────────────────────
//  ELEMENT MATCHUP
// ─────────────────────────────────────────────

object ElementSystem {

    // element -> list of elements it's STRONG against (2.0x damage)
    private val strongAgainst = mapOf(
        Element.FIRE    to listOf(Element.ICE, Element.WIND, Element.EARTH),
        Element.ICE     to listOf(Element.FIRE, Element.EARTH, Element.WIND),
        Element.LIGHTNING to listOf(Element.WATER, Element.ICE, Element.WIND),
        Element.HOLY    to listOf(Element.SHADOW, Element.CHAOS),
        Element.SHADOW  to listOf(Element.HOLY, Element.DIVINE),
        Element.POISON  to listOf(Element.EARTH, Element.WATER, Element.PHYSICAL),
        Element.WATER   to listOf(Element.FIRE, Element.EARTH),
        Element.EARTH   to listOf(Element.LIGHTNING, Element.POISON, Element.PHYSICAL),
        Element.WIND    to listOf(Element.EARTH, Element.POISON),
        Element.CHAOS   to listOf(Element.DIVINE, Element.HOLY, Element.PHYSICAL),
        Element.DIVINE  to listOf(Element.CHAOS, Element.SHADOW),
        Element.PHYSICAL to listOf(Element.ICE, Element.WIND)
    )

    // element -> list of elements it's WEAK to (0.5x damage)
    private val weakAgainst = mapOf(
        Element.FIRE    to listOf(Element.WATER, Element.ICE),
        Element.ICE     to listOf(Element.FIRE, Element.LIGHTNING),
        Element.LIGHTNING to listOf(Element.EARTH, Element.SHADOW),
        Element.HOLY    to listOf(Element.CHAOS, Element.SHADOW),
        Element.SHADOW  to listOf(Element.HOLY, Element.DIVINE),
        Element.POISON  to listOf(Element.HOLY, Element.WIND),
        Element.WATER   to listOf(Element.LIGHTNING, Element.ICE),
        Element.EARTH   to listOf(Element.WATER, Element.WIND),
        Element.WIND    to listOf(Element.LIGHTNING, Element.FIRE),
        Element.CHAOS   to listOf(Element.DIVINE),
        Element.DIVINE  to listOf(Element.CHAOS),
        Element.PHYSICAL to listOf(Element.EARTH, Element.HOLY)
    )

    // element -> list of elements that deal NORMAL damage (1.0x, immune to resist)
    private val immuneTo = mapOf(
        Element.SHADOW  to listOf(Element.POISON),
        Element.DIVINE  to listOf(Element.POISON, Element.FIRE),
        Element.CHAOS   to listOf(Element.ICE, Element.WATER)
    )

    // ─────────────────────────────────────────────
    //  DAMAGE CALCULATION
    // ─────────────────────────────────────────────

    fun getMultiplier(attackElement: Element, defenderElement: Element): Float {
        return when {
            immuneTo[defenderElement]?.contains(attackElement) == true -> 0.0f
            strongAgainst[attackElement]?.contains(defenderElement) == true -> 2.0f
            weakAgainst[attackElement]?.contains(defenderElement) == true -> 0.5f
            else -> 1.0f
        }
    }

    fun getEffectivenessText(mult: Float): String = when {
        mult == 0.0f -> "🚫 ИММУНЕН!"
        mult >= 2.0f -> "💥 СУПЕР ЕФЕКТИВНО!"
        mult <= 0.5f -> "⬇️ Не е ефективно..."
        else -> ""
    }

    fun getBestElementAgainst(defenderElement: Element): Element? {
        return strongAgainst.entries
            .filter { (_, targets) -> targets.contains(defenderElement) }
            .map { it.key }
            .firstOrNull()
    }

    fun getEnemyElementFromName(enemyId: String): Element = when {
        enemyId.contains("fire") || enemyId.contains("ares") || enemyId.contains("ra") -> Element.FIRE
        enemyId.contains("ice") || enemyId.contains("frost") || enemyId.contains("boreas") -> Element.ICE
        enemyId.contains("thor") || enemyId.contains("zeus") || enemyId.contains("raijin") -> Element.LIGHTNING
        enemyId.contains("anubis") || enemyId.contains("hades") || enemyId.contains("shadow") -> Element.SHADOW
        enemyId.contains("vishnu") || enemyId.contains("amaterasu") || enemyId.contains("ra") -> Element.HOLY
        enemyId.contains("hydra") || enemyId.contains("nidhogg") || enemyId.contains("poison") -> Element.POISON
        enemyId.contains("poseidon") || enemyId.contains("dragon_king") || enemyId.contains("water") -> Element.WATER
        enemyId.contains("titan") || enemyId.contains("atlas") || enemyId.contains("earth") -> Element.EARTH
        enemyId.contains("chaos") || enemyId.contains("primordial") || enemyId.contains("tiamat") -> Element.CHAOS
        enemyId.contains("zeus") || enemyId.contains("odin") || enemyId.contains("god") -> Element.DIVINE
        else -> Element.PHYSICAL
    }

    fun getAbilityElement(abilityId: String): Element = when {
        abilityId.contains("fire") || abilityId.contains("flame") -> Element.FIRE
        abilityId.contains("ice") || abilityId.contains("frost") || abilityId.contains("blizzard") -> Element.ICE
        abilityId.contains("thunder") || abilityId.contains("lightning") || abilityId.contains("bolt") -> Element.LIGHTNING
        abilityId.contains("holy") || abilityId.contains("light") || abilityId.contains("divine") -> Element.HOLY
        abilityId.contains("shadow") || abilityId.contains("dark") -> Element.SHADOW
        abilityId.contains("poison") || abilityId.contains("venom") -> Element.POISON
        abilityId.contains("water") || abilityId.contains("tsunami") -> Element.WATER
        abilityId.contains("earth") || abilityId.contains("quake") -> Element.EARTH
        abilityId.contains("chaos") || abilityId.contains("apocalypse") -> Element.CHAOS
        else -> Element.PHYSICAL
    }

    fun describeMatchup(attElem: Element, defElem: Element): String {
        val mult = getMultiplier(attElem, defElem)
        return buildString {
            append("${attElem.emoji} vs ${defElem.emoji}: ")
            append(when {
                mult == 0.0f -> "🚫 Имунен (0x)"
                mult >= 2.0f -> "💥 Супер ефективно (2x)"
                mult <= 0.5f -> "⬇️ Неефективно (0.5x)"
                else -> "Normal (1x)"
            })
        }
    }

    fun getAllMatchupsForElement(elem: Element): List<String> = buildList {
        Element.values().forEach { other ->
            val desc = describeMatchup(elem, other)
            if (!desc.contains("Normal")) add(desc)
        }
    }

    fun getElementChart(): String = buildString {
        appendLine("═══ ЕЛЕМЕНТАРНА ТАБЛИЦА ═══")
        Element.values().forEach { atk ->
            val strong = strongAgainst[atk]?.joinToString(", ") { it.emoji } ?: "—"
            val weak = weakAgainst[atk]?.joinToString(", ") { it.emoji } ?: "—"
            appendLine("${atk.emoji} ${atk.displayName}:")
            appendLine("  💥 Силно срещу: $strong")
            appendLine("  ⬇️ Слабо срещу: $weak")
        }
    }
}
