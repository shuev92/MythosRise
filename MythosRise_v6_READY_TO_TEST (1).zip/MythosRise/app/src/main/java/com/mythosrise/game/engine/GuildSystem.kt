package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.HeroClass

// ─────────────────────────────────────────────
//  GUILD RANK
// ─────────────────────────────────────────────

enum class GuildRank(val displayName: String, val emoji: String, val permissions: List<String>) {
    RECRUIT("Новак", "🔰", listOf("view", "donate")),
    MEMBER("Член", "⚔️", listOf("view", "donate", "quest", "raid")),
    VETERAN("Ветеран", "🏅", listOf("view", "donate", "quest", "raid", "invite")),
    OFFICER("Офицер", "🎖️", listOf("view", "donate", "quest", "raid", "invite", "kick_recruit", "manage_quests")),
    DEPUTY("Заместник", "👑", listOf("view", "donate", "quest", "raid", "invite", "kick", "manage_quests", "manage_events")),
    LEADER("Лидер", "🏆", listOf("all"))
}

// ─────────────────────────────────────────────
//  GUILD MEMBER
// ─────────────────────────────────────────────

data class GuildMember(
    val name: String,
    val heroClass: HeroClass,
    val level: Int,
    val divinity: Int,
    val rank: GuildRank,
    val weeklyContribution: Int = 0,
    val totalContribution: Int = 0,
    val joinDate: String = "01/01/2025",
    val lastOnline: String = "Днес",
    val isOnline: Boolean = false
)

// ─────────────────────────────────────────────
//  GUILD QUEST
// ─────────────────────────────────────────────

data class GuildQuest(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val targetType: String,
    val targetCount: Int,
    var currentCount: Int = 0,
    val goldReward: Int,
    val divinityReward: Int,
    val expReward: Long,
    val guildExpReward: Int,
    val difficulty: String,
    val expiresInHours: Int = 48
) {
    val isComplete get() = currentCount >= targetCount
    val progress get() = "$currentCount/$targetCount"
    val progressPercent get() = if (targetCount == 0) 100 else (currentCount * 100) / targetCount
}

// ─────────────────────────────────────────────
//  GUILD BUFF
// ─────────────────────────────────────────────

data class GuildBuff(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val attackBonus: Float = 0f,
    val defenseBonus: Float = 0f,
    val goldBonus: Float = 0f,
    val divinityBonus: Float = 0f,
    val expBonus: Float = 0f,
    val durationHours: Int = 24,
    val guildExpCost: Int,
    val requiredGuildLevel: Int = 1
)

// ─────────────────────────────────────────────
//  GUILD
// ─────────────────────────────────────────────

data class Guild(
    val id: String,
    var name: String,
    var tag: String,                // e.g. [MYT]
    var description: String,
    var emblem: String,             // emoji
    var level: Int = 1,
    var experience: Long = 0,
    var totalGold: Long = 0,
    var members: MutableList<GuildMember> = mutableListOf(),
    var activeBuffs: MutableList<GuildBuff> = mutableListOf(),
    var activeQuests: MutableList<GuildQuest> = mutableListOf(),
    var completedQuests: Int = 0,
    var warWins: Int = 0,
    var warLosses: Int = 0,
    var mythology: String = "Mixed",
    var minLevel: Int = 1,
    var isPublic: Boolean = true,
    var announcement: String = "",
    val foundedDate: String = "01/01/2025"
) {
    val memberCount get() = members.size
    val maxMembers get() = 10 + level * 5
    val isFull get() = memberCount >= maxMembers
    val averageLevel get() = if (members.isEmpty()) 0 else members.sumOf { it.level } / members.size
    val totalDivinity get() = members.sumOf { it.divinity.toLong() }
    val nextLevelExp get() = level * 10000L
    val levelProgress get() = if (nextLevelExp == 0L) 100 else ((experience % nextLevelExp) * 100 / nextLevelExp).toInt()
}

// ─────────────────────────────────────────────
//  GUILD SYSTEM
// ─────────────────────────────────────────────

object GuildSystem {

    // Sample guilds for demonstration
    val SAMPLE_GUILDS = mutableListOf(
        Guild(
            id = "guild_olympians",
            name = "Олимпийците",
            tag = "[OLY]",
            description = "Най-мощната гилдия. Само Ниво 20+. Убиваме богове.",
            emblem = "⚡",
            level = 8,
            experience = 75000,
            totalGold = 500000,
            mythology = "Greek",
            minLevel = 20,
            warWins = 15,
            announcement = "Война с [DRAG] утре! Всички онлайн в 20:00!"
        ).apply {
            members.addAll(listOf(
                GuildMember("ΖευςSlayer99", HeroClass.WARRIOR, 45, 35000, GuildRank.LEADER, 5000, 50000, isOnline = true),
                GuildMember("Медуза_Убиец", HeroClass.ARCHER, 38, 22000, GuildRank.DEPUTY, 3200, 38000, isOnline = true),
                GuildMember("ОлимпОфицер", HeroClass.MAGE, 35, 18000, GuildRank.OFFICER, 2800, 30000, isOnline = false),
                GuildMember("АтинаФолоуър", HeroClass.MONK, 32, 15000, GuildRank.VETERAN, 2100, 25000, isOnline = true),
                GuildMember("ПосейдонФен", HeroClass.WARRIOR, 28, 10000, GuildRank.MEMBER, 1500, 18000, isOnline = false)
            ))
        },
        Guild(
            id = "guild_dragons",
            name = "Дракон Орден",
            tag = "[DRAG]",
            description = "Дракони са нашата религия. Тиамат е нашата богиня.",
            emblem = "🐉",
            level = 6,
            experience = 52000,
            totalGold = 320000,
            mythology = "Dragon",
            minLevel = 15,
            warWins = 10,
            warLosses = 3,
            announcement = "Тиамат Hunt тази събота! 5x Дракон Люспи на победител!"
        ).apply {
            members.addAll(listOf(
                GuildMember("TiamatFan", HeroClass.WARRIOR, 42, 28000, GuildRank.LEADER, 4500, 42000, isOnline = true),
                GuildMember("DragonBlood", HeroClass.MAGE, 36, 20000, GuildRank.DEPUTY, 3000, 35000, isOnline = false),
                GuildMember("WyvernKing", HeroClass.ARCHER, 30, 14000, GuildRank.OFFICER, 2200, 22000, isOnline = true)
            ))
        },
        Guild(
            id = "guild_valhalla",
            name = "Валхала",
            tag = "[VAL]",
            description = "Скандинавска гилдия. Рагнарок е близо. Ние сме готови.",
            emblem = "🏔️",
            level = 5,
            experience = 41000,
            totalGold = 280000,
            mythology = "Norse",
            minLevel = 10,
            warWins = 8,
            warLosses = 5
        ).apply {
            members.addAll(listOf(
                GuildMember("OdinsFavored", HeroClass.WARRIOR, 40, 25000, GuildRank.LEADER, 4000, 40000, isOnline = false),
                GuildMember("ThorHammer", HeroClass.WARRIOR, 35, 18000, GuildRank.DEPUTY, 3500, 35000, isOnline = true),
                GuildMember("FreyjaLover", HeroClass.MONK, 28, 12000, GuildRank.VETERAN, 2000, 20000, isOnline = false),
                GuildMember("LokiTrickster", HeroClass.MAGE, 25, 8000, GuildRank.MEMBER, 1200, 12000, isOnline = true)
            ))
        },
        Guild(
            id = "guild_pharaohs",
            name = "Фараони",
            tag = "[PHA]",
            description = "Египетска гилдия. Ра е нашето слънце. Анубис ни пази.",
            emblem = "🏺",
            level = 4,
            experience = 32000,
            totalGold = 220000,
            mythology = "Egyptian",
            minLevel = 8
        ).apply {
            members.addAll(listOf(
                GuildMember("RaFollower", HeroClass.MAGE, 38, 22000, GuildRank.LEADER, 3800, 38000, isOnline = true),
                GuildMember("AnubisGuard", HeroClass.WARRIOR, 32, 16000, GuildRank.OFFICER, 2500, 28000, isOnline = false),
                GuildMember("PyramidKing", HeroClass.ARCHER, 26, 10000, GuildRank.MEMBER, 1800, 18000, isOnline = true)
            ))
        },
        Guild(
            id = "guild_beginners",
            name = "Нови Герои",
            tag = "[NEW]",
            description = "Гилдия за нови играчи! Всички са добре дошли! Помагаме си!",
            emblem = "🌱",
            level = 1,
            experience = 2000,
            totalGold = 10000,
            mythology = "Mixed",
            minLevel = 1
        ).apply {
            members.addAll(listOf(
                GuildMember("FriendlyLeader", HeroClass.MONK, 15, 1000, GuildRank.LEADER, 500, 5000, isOnline = true),
                GuildMember("NewPlayer1", HeroClass.WARRIOR, 5, 100, GuildRank.RECRUIT, 100, 500, isOnline = false),
                GuildMember("NewPlayer2", HeroClass.MAGE, 3, 50, GuildRank.RECRUIT, 50, 200, isOnline = true)
            ))
        }
    )

    val GUILD_BUFFS = listOf(
        GuildBuff("buff_attack", "Боен Дух", "+10% атака за всички членове", "⚔️",
            attackBonus = 0.10f, durationHours = 24, guildExpCost = 500, requiredGuildLevel = 1),
        GuildBuff("buff_defense", "Желязна Стена", "+15% защита за всички членове", "🛡️",
            defenseBonus = 0.15f, durationHours = 24, guildExpCost = 500, requiredGuildLevel = 1),
        GuildBuff("buff_gold", "Жетва", "+25% злато от всички врагове", "💰",
            goldBonus = 0.25f, durationHours = 12, guildExpCost = 800, requiredGuildLevel = 2),
        GuildBuff("buff_divinity", "Дивинити Прилив", "+20% дивинити от всичко", "✨",
            divinityBonus = 0.20f, durationHours = 12, guildExpCost = 1000, requiredGuildLevel = 3),
        GuildBuff("buff_exp", "Знание на Гилдията", "+30% опит от всичко", "⭐",
            expBonus = 0.30f, durationHours = 8, guildExpCost = 700, requiredGuildLevel = 2),
        GuildBuff("buff_berserker", "Колективна Ярост", "+25% атака и -10% защита", "😤",
            attackBonus = 0.25f, defenseBonus = -0.10f, durationHours = 6, guildExpCost = 1200, requiredGuildLevel = 4),
        GuildBuff("buff_omnigod_presence", "Присъствие на Всебога", "+50% от всичко за 2ч", "🌌",
            attackBonus = 0.50f, defenseBonus = 0.50f, goldBonus = 0.50f, divinityBonus = 0.50f,
            durationHours = 2, guildExpCost = 5000, requiredGuildLevel = 8)
    )

    val GUILD_QUESTS = listOf(
        GuildQuest("gq_kill_100", "Клане", "Гилдията убива 100 врагове.", "⚔️",
            "kill", 100, goldReward = 5000, divinityReward = 200, expReward = 3000, guildExpReward = 500, difficulty = "Лесна"),
        GuildQuest("gq_kill_gods_5", "Богоубийци", "Убийте 5 бога заедно.", "⚡",
            "kill_god", 5, goldReward = 20000, divinityReward = 1000, expReward = 15000, guildExpReward = 2000, difficulty = "Трудна"),
        GuildQuest("gq_arena_waves", "Арена Чест", "Завършете 50 вълни в Арената.", "🏟️",
            "arena_wave", 50, goldReward = 10000, divinityReward = 500, expReward = 8000, guildExpReward = 1000, difficulty = "Средна"),
        GuildQuest("gq_craft_10", "Занаятчийство", "Занаятете 10 предмета заедно.", "🔨",
            "craft", 10, goldReward = 8000, divinityReward = 300, expReward = 5000, guildExpReward = 800, difficulty = "Средна"),
        GuildQuest("gq_explore_worlds", "Изследователи", "Посетете всичките 11 свята.", "🌍",
            "explore", 11, goldReward = 15000, divinityReward = 750, expReward = 10000, guildExpReward = 1500, difficulty = "Трудна"),
        GuildQuest("gq_boss_rush", "Гилдиен Boss Rush", "Завършете Boss Rush в нормален режим.", "👑",
            "boss_rush", 1, goldReward = 25000, divinityReward = 1500, expReward = 20000, guildExpReward = 3000, difficulty = "Екстремна"),
        GuildQuest("gq_divinity_50k", "Дивинити Скок", "Гилдията събира 50 000 дивинити.", "✨",
            "divinity", 50000, goldReward = 30000, divinityReward = 5000, expReward = 25000, guildExpReward = 5000, difficulty = "Легендарна")
    )

    // ─────────────────────────────────────────────
    //  GUILD WAR SYSTEM
    // ─────────────────────────────────────────────

    data class GuildWar(
        val attackerGuild: Guild,
        val defenderGuild: Guild,
        var attackerScore: Int = 0,
        var defenderScore: Int = 0,
        val durationHours: Int = 24,
        var isActive: Boolean = true,
        val goldStake: Int = 10000,
        val warLog: MutableList<String> = mutableListOf()
    ) {
        val winner get() = when {
            !isActive && attackerScore > defenderScore -> attackerGuild
            !isActive && defenderScore > attackerScore -> defenderGuild
            else -> null
        }
    }

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun createGuild(name: String, tag: String, emblem: String, description: String, leader: Character): Guild {
        return Guild(
            id = "guild_${System.currentTimeMillis()}",
            name = name, tag = tag, emblem = emblem, description = description
        ).apply {
            members.add(GuildMember(
                name = leader.name, heroClass = leader.heroClass,
                level = leader.level, divinity = leader.divinity,
                rank = GuildRank.LEADER, isOnline = true
            ))
        }
    }

    fun getGuildRanking(): List<Pair<Int, Guild>> {
        return SAMPLE_GUILDS
            .sortedByDescending { it.level * 1000 + it.totalDivinity / 1000 + it.warWins * 500 }
            .mapIndexed { i, g -> (i + 1) to g }
    }

    fun getGuildScore(guild: Guild): Long {
        return guild.level * 10000L + guild.totalDivinity / 10 + guild.warWins * 5000L + guild.completedQuests * 1000L
    }

    fun addGuildExperience(guild: Guild, exp: Int) {
        guild.experience += exp
        while (guild.experience >= guild.level * 10000L) {
            guild.experience -= guild.level * 10000L
            guild.level++
        }
    }

    fun getAvailableBuffs(guild: Guild): List<GuildBuff> {
        return GUILD_BUFFS.filter { it.requiredGuildLevel <= guild.level }
    }

    fun activateBuff(buff: GuildBuff, guild: Guild): Boolean {
        if (guild.experience < buff.guildExpCost) return false
        guild.experience -= buff.guildExpCost
        guild.activeBuffs.add(buff)
        return true
    }

    fun getGuildDescription(guild: Guild): String = buildString {
        appendLine("${guild.emblem} ${guild.name} ${guild.tag}")
        appendLine("📊 Ниво: ${guild.level} (${guild.levelProgress}% до ${guild.level + 1})")
        appendLine("👥 Членове: ${guild.memberCount}/${guild.maxMembers}")
        appendLine("⚔️ Войни: ${guild.warWins}В/${guild.warLosses}П")
        appendLine("📚 Митология: ${guild.mythology}")
        appendLine("⭐ Мин. ниво: ${guild.minLevel}")
        appendLine()
        appendLine(guild.description)
        if (guild.announcement.isNotBlank()) {
            appendLine()
            appendLine("📢 ${guild.announcement}")
        }
    }
}

// ─────────────────────────────────────────────
//  GUILD WAR MECHANICS
// ─────────────────────────────────────────────

object GuildWarSystem {
    data class WarBattle(
        val attackerName: String,
        val defenderName: String,
        val attackerClass: String,
        val result: String,
        val pointsEarned: Int,
        val timestamp: String
    )

    val WAR_BATTLE_LOG = mutableListOf<WarBattle>()

    val WAR_REWARDS = mapOf(
        "win" to mapOf("gold" to 20000, "divinity" to 1000, "guildExp" to 5000),
        "loss" to mapOf("gold" to 5000, "divinity" to 200, "guildExp" to 1000),
        "draw" to mapOf("gold" to 10000, "divinity" to 500, "guildExp" to 2500)
    )

    val WAR_STRATEGIES = listOf(
        "🛡️ Отбранителна: Постави по-силни играчи в отбрана",
        "⚔️ Агресивна: Атакувай непрекъснато — лидера им е слаб",
        "🎯 Целенасочена: Концентрирай се върху 1-2 ключови цели",
        "🌀 Хаотична: Рандом атаки объркват врага",
        "⭐ Бос Стратегия: Само силните играчи атакуват"
    )

    val WAR_TIPS = listOf(
        "💡 Атакувай в часовете, когато врагът е офлайн!",
        "💡 Координирай с офицерите кой кога атакува",
        "💡 Тихите гилдии с малко членове може да са много силни",
        "💡 Проверявай WR (Win Rate) на противниковите играчи",
        "💡 Гилдийните Бафове преди война = масивно предимство",
        "💡 Boss Rush завърши? +500 War Points!",
        "💡 Залогът е злато — победата = удвоено злато!"
    )

    fun simulateWarBattle(attacker: GuildMember, defender: GuildMember): Pair<Boolean, Int> {
        val attackScore = attacker.level * 100 + attacker.divinity / 100 + (0..500).random()
        val defenseScore = defender.level * 100 + defender.divinity / 100 + (0..300).random()
        val won = attackScore > defenseScore
        val points = if (won) 50 + (attacker.level * 2) else 15
        return won to points
    }

    fun getWarStatus(attackerScore: Int, defenderScore: Int): String {
        val diff = attackerScore - defenderScore
        return when {
            diff > 500 -> "🟢 Доминираме! Продължавай!"
            diff > 0 -> "🟡 Водим — пази позицията!"
            diff == 0 -> "⚪ Равенство — следващата битка решава!"
            diff > -500 -> "🟠 Изоставаме — нужни са повече атаки!"
            else -> "🔴 Критично! Всички онлайн!"
        }
    }

    fun calculateWarScore(guild: Guild, battles: Int, wins: Int, bossKills: Int): Int {
        return wins * 50 + (battles - wins) * 10 + bossKills * 200 + guild.level * 100
    }
}

// ─────────────────────────────────────────────
//  GUILD ACHIEVEMENTS
// ─────────────────────────────────────────────

object GuildAchievements {
    data class GuildAchievement(
        val id: String,
        val name: String,
        val emoji: String,
        val description: String,
        val requirement: String,
        val goldReward: Int,
        val guildExpReward: Int,
        var isUnlocked: Boolean = false
    )

    val ALL_ACHIEVEMENTS = listOf(
        GuildAchievement("ga_first_war", "Първа Война", "⚔️", "Участвай в гилдийна война", "war_participated = 1", 5000, 1000),
        GuildAchievement("ga_war_win", "Военна Победа", "🏆", "Победи в гилдийна война", "wars_won >= 1", 10000, 2000),
        GuildAchievement("ga_quest_10", "Куест Гилдия", "📜", "Завърши 10 гилдийни куеста", "quests_completed >= 10", 15000, 3000),
        GuildAchievement("ga_level_5", "Гилдия Ниво 5", "⭐", "Достигни Гилдия Ниво 5", "guild.level >= 5", 20000, 5000),
        GuildAchievement("ga_full_guild", "Пълна Гилдия", "👥", "Максимален брой членове", "members == max", 25000, 5000),
        GuildAchievement("ga_war_10", "Ветерани на Войната", "🎖️", "Спечели 10 гилдийни войни", "wars_won >= 10", 50000, 15000),
        GuildAchievement("ga_level_10", "Легендарна Гилдия", "🌟", "Гилдия Ниво 10", "guild.level >= 10", 100000, 30000),
        GuildAchievement("ga_omnigod_guild", "ВСЕБОГ ГИЛДИЯ", "🌌", "Средно Дивинити > 10000", "avg_divinity >= 10000", 200000, 100000)
    )

    fun checkAchievements(guild: Guild): List<GuildAchievement> {
        val unlocked = mutableListOf<GuildAchievement>()
        ALL_ACHIEVEMENTS.filter { !it.isUnlocked }.forEach { ach ->
            val shouldUnlock = when (ach.id) {
                "ga_level_5" -> guild.level >= 5
                "ga_level_10" -> guild.level >= 10
                "ga_full_guild" -> guild.memberCount >= guild.maxMembers
                "ga_quest_10" -> guild.completedQuests >= 10
                "ga_war_win" -> guild.warWins >= 1
                "ga_war_10" -> guild.warWins >= 10
                "ga_omnigod_guild" -> guild.members.isNotEmpty() && guild.members.sumOf { it.divinity } / guild.members.size >= 10000
                else -> false
            }
            if (shouldUnlock) { ach.isUnlocked = true; unlocked.add(ach) }
        }
        return unlocked
    }
}

// ─────────────────────────────────────────────
//  GUILD HALL OF FAME
// ─────────────────────────────────────────────

object GuildHallOfFame {
    data class HallEntry(val guildName: String, val emoji: String, val achievement: String, val date: String, val score: Long)

    val ENTRIES = listOf(
        HallEntry("Олимпийците", "⚡", "Първа Гилдия Ниво 10", "01/02/2025", 500000L),
        HallEntry("Дракон Орден", "🐉", "10 Войни Спечелени", "15/02/2025", 350000L),
        HallEntry("Валхала", "🏔️", "Пълна Гилдия (110 члена)", "28/02/2025", 280000L),
        HallEntry("Фараони", "🏺", "100 Гилдийни Куеста", "10/03/2025", 200000L)
    )

    fun getTopEntry() = ENTRIES.maxByOrNull { it.score }
    fun getFormattedHallText() = buildString {
        appendLine("🏛️ ГИЛДИЙНА ЗАЛА НА СЛАВАТА")
        ENTRIES.forEachIndexed { i, e -> appendLine("${i+1}. ${e.emoji} ${e.guildName} — ${e.achievement}") }
    }
}
