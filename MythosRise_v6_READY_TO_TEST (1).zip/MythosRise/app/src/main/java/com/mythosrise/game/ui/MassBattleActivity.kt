package com.mythosrise.game.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MassBattleActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private val handler = Handler(Looper.getMainLooper())

    // Active enemies in current wave
    private val waveEnemies = mutableListOf<Enemy>()
    private var waveNumber = 0
    private var maxWaves = 10
    private var totalGoldEarned = 0
    private var totalDivinityEarned = 0
    private var totalExpEarned = 0L
    private var isAnimating = false

    // UI
    private lateinit var tvWaveTitle: TextView
    private lateinit var tvWaveProgress: TextView
    private lateinit var tvPlayerHp: TextView
    private lateinit var pbPlayerHp: ProgressBar
    private lateinit var tvPlayerMana: TextView
    private lateinit var tvEnemyCount: TextView
    private lateinit var tvBattleLog: TextView
    private lateinit var svLog: ScrollView
    private lateinit var llEnemyGrid: LinearLayout
    private lateinit var btnMassAttack: Button
    private lateinit var btnAoeAbility: Button
    private lateinit var btnPotion: Button
    private lateinit var btnFlee: Button
    private lateinit var tvRewards: TextView
    private lateinit var tvDivinityTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mass_battle)
        engine = GameEngine(this)
        engine.loadGame()

        bindViews()
        startNextWave()
    }

    private fun bindViews() {
        tvWaveTitle = findViewById(R.id.tvMassWaveTitle)
        tvWaveProgress = findViewById(R.id.tvMassWaveProgress)
        tvPlayerHp = findViewById(R.id.tvMassPlayerHp)
        pbPlayerHp = findViewById(R.id.pbMassPlayerHp)
        tvPlayerMana = findViewById(R.id.tvMassPlayerMana)
        tvEnemyCount = findViewById(R.id.tvMassEnemyCount)
        tvBattleLog = findViewById(R.id.tvMassBattleLog)
        svLog = findViewById(R.id.svMassLog)
        llEnemyGrid = findViewById(R.id.llMassEnemyGrid)
        btnMassAttack = findViewById(R.id.btnMassAttack)
        btnAoeAbility = findViewById(R.id.btnMassAoe)
        btnPotion = findViewById(R.id.btnMassPotion)
        btnFlee = findViewById(R.id.btnMassFlee)
        tvRewards = findViewById(R.id.tvMassRewards)
        tvDivinityTitle = findViewById(R.id.tvMassDivinityTitle)

        btnMassAttack.setOnClickListener {
            if (!isAnimating) doMassAttack()
        }
        btnAoeAbility.setOnClickListener {
            if (!isAnimating) showAoeAbilities()
        }
        btnPotion.setOnClickListener { showPotions() }
        btnFlee.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Бягство от Арената")
                .setMessage("Ще загубиш текущата вълна, но ще запазиш спечеленото до момента.\n\n💰 Злато: +$totalGoldEarned\n✨ Дивинити: +$totalDivinityEarned")
                .setPositiveButton("Бягай!") { _, _ -> finishBattle(survived = true) }
                .setNegativeButton("Продължи!", null)
                .show()
        }
    }

    // ─────────────────────────────────────────────
    //  WAVE SYSTEM
    // ─────────────────────────────────────────────

    private fun startNextWave() {
        waveNumber++
        waveEnemies.clear()

        val enemyCount = when {
            waveNumber <= 3 -> Random.nextInt(3, 6)
            waveNumber <= 6 -> Random.nextInt(5, 10)
            waveNumber <= 9 -> Random.nextInt(8, 15)
            else -> Random.nextInt(15, 25)
        }

        val arenaEnemies = GameDatabase.ALL_ENEMIES.filter { it.world == World.MASS_BATTLE_ARENA && !it.isBoss }
        val bossEnemies = GameDatabase.ALL_ENEMIES.filter { it.world == World.MASS_BATTLE_ARENA && it.isBoss }

        // Add regular enemies
        repeat(enemyCount) {
            val baseEnemy = arenaEnemies.random()
            val scaledEnemy = baseEnemy.copy(
                id = "${baseEnemy.id}_${it}",
                maxHealth = (baseEnemy.maxHealth * (1 + waveNumber * 0.3f)).toInt(),
                currentHealth = (baseEnemy.maxHealth * (1 + waveNumber * 0.3f)).toInt(),
                attack = (baseEnemy.attack * (1 + waveNumber * 0.2f)).toInt(),
                divinityReward = baseEnemy.divinityReward + waveNumber * 2,
                expReward = baseEnemy.expReward + waveNumber * 10,
                goldReward = baseEnemy.goldReward + waveNumber * 5
            )
            waveEnemies.add(scaledEnemy)
        }

        // Every 5th wave — add a boss
        if (waveNumber % 5 == 0 && bossEnemies.isNotEmpty()) {
            waveEnemies.add(bossEnemies.first().copy(currentHealth = bossEnemies.first().maxHealth))
        }

        tvWaveTitle.text = "⚔️ ВЪЛНА $waveNumber / $maxWaves"
        tvWaveProgress.text = "🏆 Вълна $waveNumber — ${waveEnemies.size} врага!"

        addLog("═══ ВЪЛНА $waveNumber ЗАПОЧВА! ══")
        addLog("${waveEnemies.size} врагове нахлуват в арената!")

        updateUI()
        renderEnemyGrid()
    }

    // ─────────────────────────────────────────────
    //  COMBAT
    // ─────────────────────────────────────────────

    private fun doMassAttack() {
        if (waveEnemies.isEmpty()) return
        isAnimating = true
        setButtonsEnabled(false)

        // Attack random enemy
        val target = waveEnemies.filter { it.currentHealth > 0 }.randomOrNull() ?: return
        val dmg = max(1, engine.character.getTotalAttack() - target.defense / 3)
        target.currentHealth -= dmg

        addLog("⚔️ ${engine.character.name} удари ${target.emoji}${target.name} за $dmg урон!")

        if (target.currentHealth <= 0) {
            onEnemyKilled(target)
        }

        // All alive enemies attack back
        handler.postDelayed({
            doEnemyCounterAttack()
        }, 400)
    }

    private fun doAoeAttack(ability: Ability) {
        if (engine.character.mana < ability.manaCost) {
            Toast.makeText(this, "❌ Недостатъчно мана!", Toast.LENGTH_SHORT).show()
            return
        }
        isAnimating = true
        setButtonsEnabled(false)
        engine.character.mana -= ability.manaCost

        val targets = waveEnemies.filter { it.currentHealth > 0 }
        var totalKills = 0
        var totalDmg = 0

        targets.forEach { enemy ->
            val dmg = max(1, (engine.character.getTotalAttack() * ability.damageMultiplier).toInt() - enemy.defense / 3)
            enemy.currentHealth -= dmg
            totalDmg += dmg
            if (enemy.currentHealth <= 0) {
                onEnemyKilled(enemy)
                totalKills++
            }
        }

        addLog("✨ ${ability.emoji} ${ability.name}: Уби $totalKills врагове! ($totalDmg общ урон)")

        handler.postDelayed({
            if (waveEnemies.any { it.currentHealth > 0 }) {
                doEnemyCounterAttack()
            } else {
                updateUI()
                renderEnemyGrid()
                isAnimating = false
                setButtonsEnabled(true)
                checkWaveEnd()
            }
        }, 400)
    }

    private fun doEnemyCounterAttack() {
        val livingEnemies = waveEnemies.filter { it.currentHealth > 0 }
        var totalDmg = 0

        livingEnemies.forEach { enemy ->
            val dmg = max(1, (enemy.attack / livingEnemies.size.coerceAtLeast(1)) - engine.character.getTotalDefense() / 3)
            engine.character.health -= dmg
            totalDmg += dmg
        }

        addLog("💥 ${livingEnemies.size} врагове контраатакуват за $totalDmg общ урон!")

        updateUI()
        renderEnemyGrid()

        if (engine.character.health <= 0) {
            engine.character.health = 1
            addLog("💀 Паднал си! Арената е немилостива!")
            handler.postDelayed({ finishBattle(survived = false) }, 1000)
        } else {
            isAnimating = false
            setButtonsEnabled(true)
            checkWaveEnd()
        }
    }

    private fun onEnemyKilled(enemy: Enemy) {
        totalDivinityEarned += enemy.divinityReward
        totalGoldEarned += enemy.goldReward
        totalExpEarned += enemy.expReward

        engine.character.divinity += enemy.divinityReward
        engine.character.gold += enemy.goldReward
        engine.character.enemiesDefeated++
        engine.character.updateDivinityTitle()
        engine.character.gainExperience(enemy.expReward.toLong())

        addLog("💀 ${enemy.emoji} ${enemy.name} е убит! +${enemy.divinityReward}✨ +${enemy.goldReward}💰")

        updateRewards()
    }

    private fun checkWaveEnd() {
        val allDead = waveEnemies.all { it.currentHealth <= 0 }
        if (!allDead) return

        addLog("🏆 ВЪЛНА $waveNumber ЗАВЪРШЕНА!")
        engine.saveGame()

        if (waveNumber >= maxWaves) {
            handler.postDelayed({ finishBattle(survived = true, allWaves = true) }, 800)
        } else {
            handler.postDelayed({
                AlertDialog.Builder(this)
                    .setTitle("🏆 Вълна $waveNumber завършена!")
                    .setMessage("💰 Злато: +$totalGoldEarned\n✨ Дивинити: +$totalDivinityEarned\n${engine.character.divinityTitle.title}\n\nСледваща вълна: ${waveNumber + 1}/$maxWaves\nЖивот: ${engine.character.health}/${engine.character.getTotalMaxHealth()}")
                    .setCancelable(false)
                    .setPositiveButton("СЛЕДВАЩА ВЪЛНА ⚔️") { _, _ -> startNextWave() }
                    .setNegativeButton("Оттегли се") { _, _ -> finishBattle(survived = true) }
                    .show()
            }, 500)
        }
    }

    // ─────────────────────────────────────────────
    //  UI
    // ─────────────────────────────────────────────

    private fun updateUI() {
        val c = engine.character
        tvPlayerHp.text = "❤️ ${c.health}/${c.getTotalMaxHealth()}"
        pbPlayerHp.max = c.getTotalMaxHealth()
        pbPlayerHp.progress = c.health
        tvPlayerMana.text = "💙 ${c.mana}/${c.maxMana}"
        tvEnemyCount.text = "👹 ${waveEnemies.count { it.currentHealth > 0 }} врагове живи"
        tvDivinityTitle.text = "${c.divinityTitle.title} | ✨${c.divinity}"
        updateRewards()
    }

    private fun updateRewards() {
        tvRewards.text = "💰 +$totalGoldEarned  ✨ +$totalDivinityEarned  ⭐ +$totalExpEarned"
    }

    private fun renderEnemyGrid() {
        llEnemyGrid.removeAllViews()
        val living = waveEnemies.filter { it.currentHealth > 0 }
        val dead = waveEnemies.count { it.currentHealth <= 0 }

        living.take(20).forEach { enemy ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(4, 2, 4, 2)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            val emojiTv = TextView(this).apply {
                text = enemy.emoji
                textSize = 18f
                setPadding(0, 0, 8, 0)
            }
            val nameTv = TextView(this).apply {
                text = enemy.name
                textSize = 11f
                setTextColor(if (enemy.isBoss) Color.parseColor("#FFD700") else Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val hpTv = TextView(this).apply {
                text = "❤️${enemy.currentHealth}"
                textSize = 11f
                setTextColor(Color.parseColor("#FF6666"))
            }
            row.addView(emojiTv)
            row.addView(nameTv)
            row.addView(hpTv)
            llEnemyGrid.addView(row)
        }

        if (living.size > 20) {
            val moreTv = TextView(this).apply {
                text = "...и още ${living.size - 20} врагове"
                textSize = 11f
                setTextColor(Color.GRAY)
                setPadding(4, 4, 4, 4)
            }
            llEnemyGrid.addView(moreTv)
        }

        if (dead > 0) {
            val deadTv = TextView(this).apply {
                text = "💀 Убити: $dead"
                textSize = 11f
                setTextColor(Color.parseColor("#555555"))
                setPadding(4, 4, 4, 4)
            }
            llEnemyGrid.addView(deadTv)
        }
    }

    private fun addLog(text: String) {
        engine.battleLog.add(text)
        val logs = engine.battleLog.takeLast(10).joinToString("\n")
        tvBattleLog.text = logs
        svLog.post { svLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        btnMassAttack.isEnabled = enabled
        btnAoeAbility.isEnabled = enabled
        btnPotion.isEnabled = enabled
    }

    private fun showAoeAbilities() {
        val aoeAbilities = engine.character.abilities.filter { it.aoeRadius > 0 || it.name.contains("Армия") || it.name.contains("Метеор") || it.name.contains("АПОКАЛИПСИС") }
        if (aoeAbilities.isEmpty()) {
            Toast.makeText(this, "Нямаш AOE умения! Нужни са за масов бой.", Toast.LENGTH_SHORT).show()
            return
        }
        val items = aoeAbilities.map {
            "${it.emoji} ${it.name} — 💙${it.manaCost} мана\n${it.description}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("⚡ AOE Умения (удрят ВСИЧКИ врагове)")
            .setItems(items) { _, which -> doAoeAttack(aoeAbilities[which]) }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun showPotions() {
        val potions = engine.character.inventory.filter { it.type == ItemType.POTION }
        if (potions.isEmpty()) { Toast.makeText(this, "Нямаш еликсири!", Toast.LENGTH_SHORT).show(); return }
        val items = potions.map { "${it.emoji} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("🧪 Еликсири")
            .setItems(items) { _, which ->
                val msg = engine.usePotion(potions[which])
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                updateUI()
            }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun finishBattle(survived: Boolean, allWaves: Boolean = false) {
        engine.saveGame()
        val title = if (allWaves) "🏆 АРЕНАТА Е ПОБЕДЕНА!" else if (survived) "✅ Оттеглил си се" else "💀 Паднал в Арената"
        val msg = buildString {
            if (allWaves) appendLine("Завърши всички $maxWaves вълни!\n")
            appendLine("💰 Спечелено злато: $totalGoldEarned")
            appendLine("✨ Спечелена дивинити: $totalDivinityEarned")
            appendLine("⭐ Спечелен опит: $totalExpEarned")
            appendLine("👹 Убити врагове: ${engine.character.enemiesDefeated}")
            appendLine("\n${engine.character.divinityTitle.title}")
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("Карта на световете") { _, _ ->
                startActivity(Intent(this, WorldMapActivity::class.java))
                finish()
            }
            .show()
    }
}
