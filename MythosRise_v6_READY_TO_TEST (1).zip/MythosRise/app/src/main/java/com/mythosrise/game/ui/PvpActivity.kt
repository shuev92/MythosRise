package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

class PvpActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentTab = "Битка"
    private var isSearching = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pvp)
        engine = GameEngine(this)
        engine.loadGame()
        llContent = findViewById(R.id.llPvpContent)
        tvHeader = findViewById(R.id.tvPvpHeader)
        setupTabs()
        showBattleTab()
    }

    private fun setupTabs() {
        val tabs = listOf("Битка", "Класация", "История", "Ранг")
        val ll = findViewById<LinearLayout>(R.id.llPvpTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            Button(this).apply {
                text = tab; textSize = 11f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (tab == currentTab) Color.parseColor("#8B0000") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0); layoutParams = lp
                setOnClickListener {
                    currentTab = tab; setupTabs()
                    when (tab) {
                        "Битка" -> showBattleTab()
                        "Класация" -> showLeaderboardTab()
                        "История" -> showHistoryTab()
                        "Ранг" -> showRankTab()
                    }
                }
            }.also { ll.addView(it) }
        }
    }

    private fun showBattleTab() {
        llContent.removeAllViews()
        val c = engine.character
        val rank = PvpSystem.getPvpRank(c.pvpRating)
        tvHeader.text = "⚔️ PvP АРЕНА — ${rank.emoji} ${rank.displayName}"

        // Player info
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0015"))
            setPadding(14, 12, 14, 12)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 12); layoutParams = lp
        }
        TextView(this).apply {
            text = "👤 ${c.heroClass.emoji} ${c.name}"
            setTextColor(Color.WHITE); textSize = 15f; isFakeBoldText = true
        }.also { playerCard.addView(it) }
        TextView(this).apply {
            text = "${rank.emoji} Рейтинг: ${c.pvpRating} | ${rank.displayName}"
            setTextColor(Color.parseColor(rank.color)); textSize = 13f
        }.also { playerCard.addView(it) }
        TextView(this).apply {
            text = "⚔️${c.getTotalAttack()} 🛡️${c.getTotalDefense()} ❤️${c.getTotalMaxHealth()}"
            setTextColor(Color.GRAY); textSize = 12f
        }.also { playerCard.addView(it) }
        llContent.addView(playerCard)

        // Find opponent section
        addSectionTitle("🔍 НАМЕРИ ПРОТИВНИК")

        val opponents = PvpSystem.findOpponentsByRating(c.pvpRating)
        opponents.forEach { opp ->
            val oppRank = PvpSystem.getPvpRank(opp.rating)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.parseColor("#0A0A1A"))
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 4, 0, 4); layoutParams = lp
            }
            TextView(this).apply { text = opp.heroClass.emoji; textSize = 26f; setPadding(0, 0, 10, 0) }.also { card.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "${opp.country} ${opp.name}"
                setTextColor(Color.WHITE); textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "${oppRank.emoji} ${oppRank.displayName} | Ниво ${opp.level} | ✨${opp.divinity}"
                setTextColor(Color.parseColor(oppRank.color)); textSize = 11f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "⚔️${opp.attack} 🛡️${opp.defense} | WR: ${(opp.winRate * 100).toInt()}% | ${opp.pvpStyle}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            card.addView(info)

            val ratingDiff = opp.rating - c.pvpRating
            val diffColor = if (ratingDiff > 0) "#FF4444" else "#44FF44"
            val diffText = if (ratingDiff >= 0) "+$ratingDiff" else "$ratingDiff"
            val diffView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER }
            TextView(this).apply {
                text = diffText; setTextColor(Color.parseColor(diffColor)); textSize = 13f; isFakeBoldText = true
            }.also { diffView.addView(it) }
            Button(this).apply {
                text = "⚔️"; textSize = 14f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0000"))
                val lp = LinearLayout.LayoutParams(64, 48); layoutParams = lp
                setOnClickListener { startPvpBattle(opp) }
            }.also { diffView.addView(it) }
            card.addView(diffView)
            llContent.addView(card)
        }

        // Quick match
        Button(this).apply {
            text = "⚡ БЪРЗА БИТКА — Случаен противник"
            setTextColor(Color.WHITE); textSize = 14f; isFakeBoldText = true
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0000"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dpToPx())
            lp.setMargins(0, 16, 0, 0); layoutParams = lp
            setOnClickListener {
                val opp = PvpSystem.findOpponent(c.pvpRating, c.level)
                startPvpBattle(opp)
            }
        }.also { llContent.addView(it) }
    }

    private fun startPvpBattle(opponent: PvpOpponent) {
        AlertDialog.Builder(this)
            .setTitle("⚔️ PvP БИТКА")
            .setMessage(buildString {
                appendLine("${opponent.country} ${opponent.heroClass.emoji} ${opponent.name}")
                appendLine("${PvpSystem.getPvpRank(opponent.rating).emoji} Рейтинг: ${opponent.rating}")
                appendLine("Ниво: ${opponent.level} | ✨${opponent.divinity}")
                appendLine("⚔️ ${opponent.attack} | 🛡️ ${opponent.defense} | ❤️${opponent.maxHealth}")
                appendLine("Стил: ${opponent.pvpStyle}")
                appendLine()
                appendLine("Любими умения: ${opponent.abilities.joinToString(", ")}")
                appendLine()
                appendLine("💰 При победа: ~${500 + opponent.rating / 10} злато")
            })
            .setPositiveButton("⚔️ БИТКА!") { _, _ -> executeBattle(opponent) }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun executeBattle(opponent: PvpOpponent) {
        val result = PvpSystem.simulatePvpBattle(engine.character, opponent)

        if (result.won) {
            engine.character.gold += result.goldReward
            engine.character.divinity += result.divinityReward
            engine.character.updateDivinityTitle()
        }
        engine.saveGame()

        AlertDialog.Builder(this)
            .setTitle(if (result.won) "🏆 ПОБЕДА!" else "💀 ПОРАЖЕНИЕ")
            .setMessage(buildString {
                appendLine("VS ${opponent.name}")
                appendLine()
                appendLine("📊 РЕЗУЛТАТ:")
                appendLine("⚔️ Нанесен урон: ${result.playerDamageDealt}")
                appendLine("🛡️ Получен урон: ${result.opponentDamageDealt}")
                appendLine("🔄 Ходове: ${result.turnsPlayed}")
                appendLine()
                appendLine("✨ ${result.mvpMoment}")
                appendLine()
                if (result.won) {
                    appendLine("🏆 Награди:")
                    appendLine("💰 +${result.goldReward} злато")
                    appendLine("✨ +${result.divinityReward} дивинити")
                }
                appendLine()
                val change = result.ratingChange
                appendLine("📈 Рейтинг: ${if (change >= 0) "+$change" else "$change"} → ${engine.character.pvpRating + change}")
            })
            .setPositiveButton("📋 Подробен лог") { _, _ ->
                showBattleLog(result)
            }
            .setNegativeButton("OK") { _, _ -> showBattleTab() }
            .show()
    }

    private fun showBattleLog(result: PvpMatchResult) {
        val logText = result.matchLog.joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle("📋 Боен Лог")
            .setMessage(logText)
            .setPositiveButton("OK") { _, _ -> showBattleTab() }
            .show()
    }

    private fun showLeaderboardTab() {
        llContent.removeAllViews()
        tvHeader.text = "🏆 PvP КЛАСАЦИЯ"
        addSectionTitle("🌍 СВЕТОВНА КЛАСАЦИЯ")

        val board = PvpSystem.getSeasonLeaderboard()
        board.forEach { (rank, name, rating) ->
            val rankEmoji = when (rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "#$rank" }
            val pvpRank = PvpSystem.getPvpRank(rating)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (rank <= 3) Color.parseColor("#1A0000") else Color.parseColor("#080808"))
                setPadding(12, 8, 12, 8)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            TextView(this).apply { text = "$rankEmoji"; textSize = 20f; setPadding(0, 0, 8, 0) }.also { row.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 13f }.also { info.addView(it) }
            TextView(this).apply { text = "${pvpRank.emoji} ${pvpRank.displayName}"; setTextColor(Color.parseColor(pvpRank.color)); textSize = 11f }.also { info.addView(it) }
            row.addView(info)
            TextView(this).apply { text = "$rating"; setTextColor(Color.parseColor("#FFD700")); textSize = 14f; isFakeBoldText = true }.also { row.addView(it) }
            llContent.addView(row)
        }

        addSectionTitle("👤 ТВОЯТА ПОЗИЦИЯ")
        val c = engine.character
        val myRank = PvpSystem.getPvpRank(c.pvpRating)
        addInfoText("${myRank.emoji} ${c.name} — Рейтинг: ${c.pvpRating}")
        addInfoText("Ранг: ${myRank.displayName}")
    }

    private fun showHistoryTab() {
        llContent.removeAllViews()
        tvHeader.text = "📜 PvP ИСТОРИЯ"
        addInfoText("Последни битки ще се показват тук.")
        addInfoText("Играй повече PvP битки за история!")
        addSectionTitle("🏆 PvP ПОСТИЖЕНИЯ")
        PvpSystem.PVP_ACHIEVEMENTS.forEach { achievement ->
            addInfoText(achievement)
        }
    }

    private fun showRankTab() {
        llContent.removeAllViews()
        val c = engine.character
        val rank = PvpSystem.getPvpRank(c.pvpRating)
        tvHeader.text = "${rank.emoji} PvP РАНГ"

        addInfoBanner("${rank.emoji} ${rank.displayName} | Рейтинг: ${c.pvpRating}")

        addSectionTitle("🏆 ВСИЧКИ РАНГОВЕ")
        PvpRank.values().forEach { r ->
            val isCurrentRank = r == rank
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (isCurrentRank) Color.parseColor("#1A0000") else Color.parseColor("#080808"))
                setPadding(12, 8, 12, 8)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            TextView(this).apply { text = "${r.emoji} ${r.displayName}"; setTextColor(Color.parseColor(r.color)); textSize = 13f; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }.also { row.addView(it) }
            TextView(this).apply { text = "${r.minRating}+"; setTextColor(Color.GRAY); textSize = 12f }.also { row.addView(it) }
            if (isCurrentRank) TextView(this).apply { text = " ← ТИ"; setTextColor(Color.parseColor("#FFD700")); textSize = 11f }.also { row.addView(it) }
            llContent.addView(row)
        }

        addSectionTitle("🎁 СЕЗОННИ НАГРАДИ ПО РАНГ")
        PvpRank.values().forEach { r ->
            addInfoText("${r.emoji} ${r.displayName}: ${PvpSystem.getPvpRewards(r)}")
        }
    }

    private fun addSectionTitle(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#FF4444"))
            textSize = 13f; isFakeBoldText = true; setPadding(4, 14, 4, 6)
        }.also { llContent.addView(it) }
    }

    private fun addInfoText(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(8, 3, 8, 3)
        }.also { llContent.addView(it) }
    }

    private fun addInfoBanner(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.WHITE)
            textSize = 14f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER
            setPadding(12, 10, 12, 10); setBackgroundColor(Color.parseColor("#1A0000"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 8); layoutParams = lp
        }.also { llContent.addView(it) }
    }

    private fun Int.dpToPx() = (this * resources.displayMetrics.density).toInt()
}
