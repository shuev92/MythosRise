package com.mythosrise.game.engine

// ─────────────────────────────────────────────
//  CUTSCENE FRAME
// ─────────────────────────────────────────────

data class CutsceneFrame(
    val speaker: String,
    val speakerEmoji: String,
    val text: String,
    val backgroundEmoji: String,
    val mood: String = "neutral",     // happy, sad, angry, epic, mysterious
    val typingEffect: Boolean = true,
    val pauseAfterMs: Int = 500
)

// ─────────────────────────────────────────────
//  CUTSCENE
// ─────────────────────────────────────────────

data class Cutscene(
    val id: String,
    val title: String,
    val trigger: String,   // "chapter_start", "boss_killed", "level_up", "prestige"
    val frames: List<CutsceneFrame>,
    val skipAllowed: Boolean = true,
    val rewardAfter: Boolean = false
)

// ─────────────────────────────────────────────
//  CUTSCENE DATABASE
// ─────────────────────────────────────────────

object CutsceneDatabase {

    val ALL_CUTSCENES = listOf(

        Cutscene(
            id = "cs_intro",
            title = "Пробуждане",
            trigger = "game_start",
            frames = listOf(
                CutsceneFrame("???", "🌑", "В началото беше само тъмнина.", "🌑", "mysterious"),
                CutsceneFrame("???", "🌑", "После — гласът.", "🌌", "mysterious"),
                CutsceneFrame("???", "✨", "Не чух го. Почувствах го. Директно в съзнанието.", "✨", "epic"),
                CutsceneFrame("Глас", "🌟", "'Събуди се. Светът чака.'", "🌅", "epic"),
                CutsceneFrame("Теос", "🧙", "Отворих очи. Старецът беше там. Усмихнат.", "🏰", "happy"),
                CutsceneFrame("Теос", "🧙", "'Знаех, че ще дойдеш. Исках само да провери дали времето е дошло.'", "🏰", "happy"),
                CutsceneFrame("Теос", "🧙", "'Имаш нещо рядко в теб. Дивинити — силата на боговете в смъртно тяло.'", "⚡", "epic"),
                CutsceneFrame("Теос", "🧙", "'Тя ще расте с всяка победа. Всяко убийство. Всяко поглъщане.'", "🌀", "epic"),
                CutsceneFrame("Теос", "🧙", "'Готов ли си? Митологиите чакат.'", "🌍", "mysterious")
            )
        ),

        Cutscene(
            id = "cs_zeus_killed",
            title = "Падането на Зевс",
            trigger = "zeus_killed",
            frames = listOf(
                CutsceneFrame("Зевс", "⚡", "Как... как е ВЪЗМОЖНО?!", "⚡", "angry"),
                CutsceneFrame("Зевс", "⚡", "Аз съм Зевс. Цар на Олимп. Никой смъртен не може...", "⚡", "angry"),
                CutsceneFrame("Зевс", "⚡", "...чакай. Вече не си смъртен, нали?", "🏛️", "sad"),
                CutsceneFrame("Хермес", "🪶", "Баща! Ти... паднал? Невъзможно!", "🏛️", "shocked"),
                CutsceneFrame("Атина", "🦉", "Видях го. В бъдещето. Знаех, че ще стане.", "🏛️", "neutral"),
                CutsceneFrame("Атина", "🦉", "Затова те пуснах да влезеш.", "🏛️", "mysterious"),
                CutsceneFrame("Зевс", "⚡", "Усещам го. Силата ми тече към теб. Поглъщаш я.", "🌀", "sad"),
                CutsceneFrame("Зевс", "⚡", "Добре. Ако трябва да бъде победен... поне от достоен.", "⚡", "neutral"),
                CutsceneFrame("Зевс", "⚡", "Как се казваш, победителю?", "🌅", "neutral")
            )
        ),

        Cutscene(
            id = "cs_odin_killed",
            title = "Паметта на Един",
            trigger = "odin_killed",
            frames = listOf(
                CutsceneFrame("Един", "🦅", "Виждах това. В рунните. В окото, което пожертвах.", "🌲", "neutral"),
                CutsceneFrame("Един", "🦅", "Знаех, че ще дойде ден, когато ще бъда победен.", "🌲", "sad"),
                CutsceneFrame("Един", "🦅", "Мислех, че ще е Фенрир при Рагнарок.", "🌋", "sad"),
                CutsceneFrame("Един", "🦅", "Но ти... ти не си Фенрир. Ти си нещо ново.", "✨", "epic"),
                CutsceneFrame("Гарван", "🐦", "Хугин и Мунин кацат до мен. Спомен и Мисъл.", "🌲", "mysterious"),
                CutsceneFrame("Един", "🦅", "Вземи ги. Гарваните ми са твои сега.", "🦅", "neutral"),
                CutsceneFrame("Един", "🦅", "Поглъщаш силата ми. Добре. Ще ти трябва.", "⚡", "epic"),
                CutsceneFrame("Един", "🦅", "Рагнарок все пак идва. Но вече е различно.", "🌌", "mysterious"),
                CutsceneFrame("Един", "🦅", "Ти ставаш новия Всебаща. Носи това добре.", "🌅", "epic")
            )
        ),

        Cutscene(
            id = "cs_chaos_killed",
            title = "Краят и Началото",
            trigger = "chaos_killed",
            frames = listOf(
                CutsceneFrame("Хаос", "🌀", "Победи ме.", "🌌", "neutral"),
                CutsceneFrame("Хаос", "🌀", "За пръв път от сътворението — победен.", "🌌", "sad"),
                CutsceneFrame("Хаос", "🌀", "Знаеш ли какво означава? Ако поглъщаш мен...", "🌀", "mysterious"),
                CutsceneFrame("Хаос", "🌀", "...ти ставаш не просто бог. Ти ставаш произхода.", "✨", "epic"),
                CutsceneFrame("???", "🌟", "Всички богове говорят едновременно.", "🌌", "epic"),
                CutsceneFrame("Зевс", "⚡", "Смъртен, станал бог.", "⚡", "epic"),
                CutsceneFrame("Един", "🦅", "Търсещ, намерил.", "🦅", "epic"),
                CutsceneFrame("Ра", "☀️", "Слънцето угаснало и ново изгряло.", "☀️", "epic"),
                CutsceneFrame("Шива", "💫", "Разрушителят, станал Строителят.", "💫", "epic"),
                CutsceneFrame("Теос", "🧙", "В началото беше Хаосът.", "🌌", "mysterious"),
                CutsceneFrame("Теос", "🧙", "В края — ти.", "🌌", "epic"),
                CutsceneFrame("Теос", "🧙", "Добре дошъл. Всебогу.", "✨", "happy")
            )
        ),

        Cutscene(
            id = "cs_first_prestige",
            title = "Прераждане",
            trigger = "first_prestige",
            frames = listOf(
                CutsceneFrame("Теос", "🧙", "Достигна лимита на смъртното.", "⭐", "neutral"),
                CutsceneFrame("Теос", "🧙", "Ниво 50. 50 000 Дивинити. Невероятно.", "⭐", "epic"),
                CutsceneFrame("Теос", "🧙", "Но знаеш ли нещо? Можеш повече.", "🌟", "mysterious"),
                CutsceneFrame("Теос", "🧙", "Прераждането не е смърт. То е еволюция.", "🌀", "epic"),
                CutsceneFrame("Теос", "🧙", "Забравяш силата — но запазваш мъдростта.", "✨", "mysterious"),
                CutsceneFrame("Теос", "🧙", "Следващото прераждане ще е по-силно.", "⭐", "epic"),
                CutsceneFrame("Теос", "🧙", "Добре дошъл. Бронзов Герой.", "🥉", "happy")
            )
        ),

        Cutscene(
            id = "cs_first_dragon",
            title = "Среща с Дракон",
            trigger = "first_dragon_kill",
            frames = listOf(
                CutsceneFrame("Дракон", "🐉", "ГРРРРР!", "🔥", "angry"),
                CutsceneFrame("Дракон", "🐉", "Смъртен дошъл в Дракон Царство?", "🐉", "angry"),
                CutsceneFrame("Дракон", "🐉", "Последният, дошъл тук, стана пепел.", "🔥", "angry"),
                CutsceneFrame("Дракон", "🐉", "Но ти... имаш нещо. Дивинити.", "✨", "curious"),
                CutsceneFrame("Дракон", "🐉", "Може да те изям. Може да те тествам.", "🐉", "neutral"),
                CutsceneFrame("Дракон", "🐉", "ТЕСТ!", "🔥", "angry")
            )
        ),

        Cutscene(
            id = "cs_arena_wave_10",
            title = "Арена Шампион",
            trigger = "arena_wave_10",
            frames = listOf(
                CutsceneFrame("Водещ", "🏟️", "НЕВЕРОЯТНО! ВЪЛНА 10!", "🏟️", "epic"),
                CutsceneFrame("Водещ", "🏟️", "Само един е правил това досега!", "🏟️", "epic"),
                CutsceneFrame("Шампион", "⚔️", "Ти... наистина стигна до тук.", "⚔️", "neutral"),
                CutsceneFrame("Шампион", "⚔️", "Аз пазя тази арена 100 години.", "⚔️", "neutral"),
                CutsceneFrame("Шампион", "⚔️", "Никой не ме победи. Ела. Опитай.", "⚔️", "angry")
            )
        ),

        Cutscene(
            id = "cs_level_50",
            title = "Максимум Ниво",
            trigger = "level_50",
            frames = listOf(
                CutsceneFrame("Теос", "🧙", "Ниво 50. Максимумът.", "⭐", "happy"),
                CutsceneFrame("Теос", "🧙", "Смъртните не стигат дотук.", "⭐", "epic"),
                CutsceneFrame("Теос", "🧙", "Ти вече не си смъртен.", "✨", "epic"),
                CutsceneFrame("Теос", "🧙", "Пред теб е Престиж. Или — продължи и събери повече Дивинити.", "🌟", "neutral"),
                CutsceneFrame("Теос", "🧙", "Изборът е твой. Винаги е бил.", "🌅", "mysterious")
            )
        )
    )

    fun getCutsceneByTrigger(trigger: String): Cutscene? =
        ALL_CUTSCENES.firstOrNull { it.trigger == trigger }

    fun getIntroduction(): Cutscene? = ALL_CUTSCENES.firstOrNull { it.id == "cs_intro" }

    fun formatCutsceneAsText(cutscene: Cutscene): String = buildString {
        appendLine("🎬 ${cutscene.title}")
        appendLine("━━━━━━━━━━━━━━━━")
        cutscene.frames.forEach { frame ->
            appendLine()
            appendLine("${frame.speakerEmoji} ${frame.speaker}:")
            appendLine("\"${frame.text}\"")
        }
    }
}

// ─────────────────────────────────────────────
//  EXTENDED CUTSCENE TRIGGERS
// ─────────────────────────────────────────────

object CutsceneTriggers {
    val ALL_TRIGGERS = mapOf(
        "game_start" to "Въвеждащ кътсцен при стартиране на нова игра",
        "zeus_killed" to "Зевс пада — изненадан от смъртен",
        "odin_killed" to "Един предава гарваните си",
        "ra_killed" to "Слънцето гасне за момент",
        "shiva_killed" to "Тандава спира",
        "chaos_killed" to "Финалната победа — ВСЕБОГ",
        "first_prestige" to "Прераждане — Бронзов Герой",
        "first_dragon" to "Първа среща с дракон",
        "arena_wave_10" to "Арена шампион появява се",
        "level_50" to "Максимум ниво достигнато",
        "first_transformation" to "Първа Божествена Форма",
        "first_guild_war" to "Влизане в гилдийна война",
        "first_pvp_win" to "Първа PvP победа",
        "omnigod_divinity" to "50000 Дивинити — ВСЕБОГ",
        "all_stories_complete" to "Всички глави завършени"
    )

    val TRIGGER_REWARDS = mapOf(
        "game_start" to Pair(0, 0),
        "zeus_killed" to Pair(5000, 200),
        "odin_killed" to Pair(8000, 400),
        "ra_killed" to Pair(6000, 300),
        "chaos_killed" to Pair(50000, 5000),
        "first_prestige" to Pair(10000, 500),
        "level_50" to Pair(15000, 1000),
        "omnigod_divinity" to Pair(100000, 0)
    )

    fun shouldTrigger(trigger: String, character: com.mythosrise.game.models.Character): Boolean = when (trigger) {
        "level_50" -> character.level >= 50
        "omnigod_divinity" -> character.divinity >= 50000
        else -> false
    }

    fun getRewardForTrigger(trigger: String): Pair<Int, Int> = TRIGGER_REWARDS[trigger] ?: Pair(0, 0)
}

// ─────────────────────────────────────────────
//  ANIMATED CUTSCENE EFFECTS
// ─────────────────────────────────────────────

object CutsceneEffects {
    val SCREEN_EFFECTS = mapOf(
        "happy" to listOf("Топла светлина", "Злато блясък", "Меко избледняване"),
        "sad" to listOf("Синкав оттенък", "Бавно тъмнеене", "Дъжд ефект"),
        "angry" to listOf("Червено пулсиране", "Трепване", "Мълния ефект"),
        "epic" to listOf("Дъга избухване", "Частички светлина", "Земетресение"),
        "mysterious" to listOf("Мъгла", "Искрящо тъмно", "Бавен zoom")
    )

    val SOUND_MOODS = mapOf(
        "epic" to "epic_orchestral.mp3",
        "mysterious" to "dark_ambient.mp3",
        "happy" to "triumphant_fanfare.mp3",
        "sad" to "somber_strings.mp3",
        "angry" to "battle_drums.mp3",
        "neutral" to "neutral_ambient.mp3"
    )

    val TRANSITION_TYPES = listOf(
        "fade_black" to "Избледнява в черно",
        "fade_white" to "Избледнява в бяло",
        "slide_left" to "Плъзга наляво",
        "slide_right" to "Плъзга надясно",
        "zoom_in" to "Приближаване",
        "zoom_out" to "Отдалечаване",
        "flash" to "Светкавица",
        "dissolve" to "Разтваряне"
    )

    fun getEffectForMood(mood: String): List<String> = SCREEN_EFFECTS[mood] ?: SCREEN_EFFECTS["neutral"]!!
    fun getSoundForMood(mood: String): String = SOUND_MOODS[mood] ?: SOUND_MOODS["neutral"]!!
}
