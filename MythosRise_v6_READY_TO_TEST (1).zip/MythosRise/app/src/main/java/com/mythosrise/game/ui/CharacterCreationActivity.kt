package com.mythosrise.game.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.*

class CharacterCreationActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine

    private var selectedGender = Gender.MALE
    private var selectedSkin = SkinTone.FAIR
    private var selectedClass = HeroClass.WARRIOR

    // UI references
    private lateinit var etName: EditText
    private lateinit var tvCharacterPreview: TextView
    private lateinit var tvClassDesc: TextView
    private lateinit var tvStats: TextView

    // Gender buttons
    private lateinit var btnMale: Button
    private lateinit var btnFemale: Button
    private lateinit var btnNonbinary: Button

    // Skin buttons
    private lateinit var btnSkinFair: Button
    private lateinit var btnSkinOlive: Button
    private lateinit var btnSkinBrown: Button
    private lateinit var btnSkinDark: Button
    private lateinit var btnSkinGolden: Button

    // Class buttons
    private lateinit var btnWarrior: Button
    private lateinit var btnMage: Button
    private lateinit var btnArcher: Button
    private lateinit var btnMonk: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_character_creation)
        engine = GameEngine(this)

        bindViews()
        setupGenderButtons()
        setupSkinButtons()
        setupClassButtons()
        updatePreview()

        findViewById<Button>(R.id.btnStartAdventure).setOnClickListener {
            val name = etName.text.toString().trim().ifBlank { selectedGender.displayName }
            engine.createCharacter(name, selectedGender, selectedSkin, selectedClass)
            engine.saveGame()
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra("show_intro", true)
            startActivity(intent)
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
            finish()
        }
    }

    private fun bindViews() {
        etName = findViewById(R.id.etHeroName)
        tvCharacterPreview = findViewById(R.id.tvCharacterPreview)
        tvClassDesc = findViewById(R.id.tvClassDescription)
        tvStats = findViewById(R.id.tvClassStats)
        btnMale = findViewById(R.id.btnGenderMale)
        btnFemale = findViewById(R.id.btnGenderFemale)
        btnNonbinary = findViewById(R.id.btnGenderNonbinary)
        btnSkinFair = findViewById(R.id.btnSkinFair)
        btnSkinOlive = findViewById(R.id.btnSkinOlive)
        btnSkinBrown = findViewById(R.id.btnSkinBrown)
        btnSkinDark = findViewById(R.id.btnSkinDark)
        btnSkinGolden = findViewById(R.id.btnSkinGolden)
        btnWarrior = findViewById(R.id.btnClassWarrior)
        btnMage = findViewById(R.id.btnClassMage)
        btnArcher = findViewById(R.id.btnClassArcher)
        btnMonk = findViewById(R.id.btnClassMonk)
    }

    private fun setupGenderButtons() {
        val genderBtns = mapOf(
            btnMale to Gender.MALE,
            btnFemale to Gender.FEMALE,
            btnNonbinary to Gender.NONBINARY
        )
        genderBtns.forEach { (btn, gender) ->
            btn.text = "${gender.emoji} ${gender.displayName}"
            btn.setOnClickListener {
                selectedGender = gender
                updateGenderHighlight(genderBtns)
                updatePreview()
            }
        }
        updateGenderHighlight(genderBtns)
    }

    private fun updateGenderHighlight(map: Map<Button, Gender>) {
        map.forEach { (btn, gender) ->
            btn.alpha = if (gender == selectedGender) 1.0f else 0.4f
        }
    }

    private fun setupSkinButtons() {
        val skinBtns = mapOf(
            btnSkinFair to SkinTone.FAIR,
            btnSkinOlive to SkinTone.OLIVE,
            btnSkinBrown to SkinTone.BROWN,
            btnSkinDark to SkinTone.DARK,
            btnSkinGolden to SkinTone.GOLDEN
        )
        skinBtns.forEach { (btn, skin) ->
            btn.text = skin.displayName
            btn.setOnClickListener {
                selectedSkin = skin
                updateSkinHighlight(skinBtns)
                updatePreview()
            }
        }
        updateSkinHighlight(skinBtns)
    }

    private fun updateSkinHighlight(map: Map<Button, SkinTone>) {
        map.forEach { (btn, skin) ->
            btn.alpha = if (skin == selectedSkin) 1.0f else 0.4f
        }
    }

    private fun setupClassButtons() {
        val classBtns = mapOf(
            btnWarrior to HeroClass.WARRIOR,
            btnMage to HeroClass.MAGE,
            btnArcher to HeroClass.ARCHER,
            btnMonk to HeroClass.MONK
        )
        classBtns.forEach { (btn, cls) ->
            btn.text = "${cls.emoji} ${cls.displayName}"
            btn.setOnClickListener {
                selectedClass = cls
                updateClassHighlight(classBtns)
                updateClassInfo()
                updatePreview()
            }
        }
        updateClassHighlight(classBtns)
        updateClassInfo()
    }

    private fun updateClassHighlight(map: Map<Button, HeroClass>) {
        map.forEach { (btn, cls) ->
            btn.alpha = if (cls == selectedClass) 1.0f else 0.4f
        }
    }

    private fun updateClassInfo() {
        tvClassDesc.text = selectedClass.description
        tvStats.text = """
            ❤️ Живот: ${selectedClass.baseHp}
            ⚔️ Атака: ${selectedClass.baseAtk}
            🛡️ Защита: ${selectedClass.baseDef}
            💙 Мана: ${selectedClass.baseMana}
            
            🔮 Умения: ${GameDatabase.getStarterAbilities(selectedClass).joinToString(", ") { it.name }}
        """.trimIndent()
    }

    private fun updatePreview() {
        val heroEmoji = when (selectedClass) {
            HeroClass.WARRIOR -> "🤺"
            HeroClass.MAGE -> "🧙"
            HeroClass.ARCHER -> "🏹"
            HeroClass.MONK -> "🥋"
        }
        val name = etName.text.toString().ifBlank { selectedGender.displayName }
        tvCharacterPreview.text = """
            $heroEmoji
            
            ${selectedGender.emoji} $name
            ${selectedSkin.displayName}
            ${selectedClass.displayName}
        """.trimIndent()
    }
}
