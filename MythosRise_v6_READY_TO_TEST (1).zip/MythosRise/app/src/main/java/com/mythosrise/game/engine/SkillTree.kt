package com.mythosrise.game.engine

import com.mythosrise.game.models.Ability
import com.mythosrise.game.models.Character
import com.mythosrise.game.models.HeroClass

// ─────────────────────────────────────────────
//  SKILL NODE
// ─────────────────────────────────────────────

enum class SkillNodeType { PASSIVE, ACTIVE, ULTIMATE }

data class SkillNode(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val type: SkillNodeType,
    val tier: Int,               // 1=basic, 2=advanced, 3=master, 4=divine
    val requiredLevel: Int,
    val requiredDivinity: Int,
    val cost: Int,               // skill points
    val prerequisites: List<String> = emptyList(),
    val abilityGranted: String? = null,
    // Passive bonuses
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val healthBonus: Int = 0,
    val manaBonus: Int = 0,
    val speedBonus: Float = 0f,
    val critChanceBonus: Float = 0f,
    val divinityGainBonus: Float = 0f,
    var unlocked: Boolean = false,
    val heroClass: HeroClass? = null,  // null = available to all
    val category: String = "General"
)

// ─────────────────────────────────────────────
//  SKILL TREE
// ─────────────────────────────────────────────

object SkillTree {

    val ALL_NODES = listOf(

        // ══════════════════════════════
        //  WARRIOR TREE
        // ══════════════════════════════
        SkillNode("w_iron_skin", "Желязна Кожа", "+20 защита", "🛡️",
            SkillNodeType.PASSIVE, 1, 1, 0, 1, heroClass = HeroClass.WARRIOR,
            defenseBonus = 20, category = "Воин"),
        SkillNode("w_power_strike", "Силен Удар", "Вихрен удар +50% урон", "⚔️",
            SkillNodeType.ACTIVE, 1, 1, 0, 1, abilityGranted = "slash",
            heroClass = HeroClass.WARRIOR, attackBonus = 10, category = "Воин"),
        SkillNode("w_battle_cry", "Боен Вик", "+30 ATK за 3 хода", "😤",
            SkillNodeType.ACTIVE, 2, 5, 0, 2, prerequisites = listOf("w_iron_skin", "w_power_strike"),
            abilityGranted = "berserker", heroClass = HeroClass.WARRIOR, attackBonus = 15, category = "Воин"),
        SkillNode("w_heavy_armor", "Тежка Броня", "+50 защита +100 живот", "🛡️",
            SkillNodeType.PASSIVE, 2, 8, 100, 2, prerequisites = listOf("w_iron_skin"),
            defenseBonus = 50, healthBonus = 100, heroClass = HeroClass.WARRIOR, category = "Воин"),
        SkillNode("w_berserker_rage", "Ярост на Берсерк", "Критични удари удвоени", "🩸",
            SkillNodeType.PASSIVE, 3, 15, 300, 3, prerequisites = listOf("w_battle_cry"),
            critChanceBonus = 0.15f, attackBonus = 25, heroClass = HeroClass.WARRIOR, category = "Воин"),
        SkillNode("w_divine_warrior", "Божествен Войн", "Поглъщаш +50% повече дивинити", "✨",
            SkillNodeType.PASSIVE, 4, 30, 2000, 4, prerequisites = listOf("w_berserker_rage", "w_heavy_armor"),
            divinityGainBonus = 0.5f, attackBonus = 40, defenseBonus = 40, heroClass = HeroClass.WARRIOR, category = "Воин"),

        // ══════════════════════════════
        //  MAGE TREE
        // ══════════════════════════════
        SkillNode("m_arcane_mind", "Arcane Ум", "+50 мана +5 ATK", "🧠",
            SkillNodeType.PASSIVE, 1, 1, 0, 1, heroClass = HeroClass.MAGE,
            manaBonus = 50, attackBonus = 5, category = "Маг"),
        SkillNode("m_fireball", "Огнена Топка", "Мощна магическа атака", "🔥",
            SkillNodeType.ACTIVE, 1, 1, 0, 1, abilityGranted = "fireball",
            heroClass = HeroClass.MAGE, attackBonus = 8, category = "Маг"),
        SkillNode("m_mana_surge", "Mana Surge", "+100 мана, умения -20% цена", "💙",
            SkillNodeType.PASSIVE, 2, 5, 0, 2, prerequisites = listOf("m_arcane_mind"),
            manaBonus = 100, heroClass = HeroClass.MAGE, category = "Маг"),
        SkillNode("m_elemental_mastery", "Елементарно майсторство", "Всички магии +30% урон", "💫",
            SkillNodeType.PASSIVE, 2, 8, 100, 2, prerequisites = listOf("m_fireball"),
            attackBonus = 20, heroClass = HeroClass.MAGE, category = "Маг"),
        SkillNode("m_arcane_explosion", "Arcane Взрив", "Огромна AOE атака", "💥",
            SkillNodeType.ACTIVE, 3, 15, 400, 3, prerequisites = listOf("m_mana_surge", "m_elemental_mastery"),
            abilityGranted = "fireball", attackBonus = 30, heroClass = HeroClass.MAGE, category = "Маг"),
        SkillNode("m_god_of_magic", "Бог на Магията", "Абсолютно магическо майсторство", "🌌",
            SkillNodeType.PASSIVE, 4, 30, 3000, 4, prerequisites = listOf("m_arcane_explosion"),
            attackBonus = 60, manaBonus = 300, divinityGainBonus = 0.4f, heroClass = HeroClass.MAGE, category = "Маг"),

        // ══════════════════════════════
        //  ARCHER TREE
        // ══════════════════════════════
        SkillNode("a_swift_feet", "Бързи крака", "+0.2 скорост", "👟",
            SkillNodeType.PASSIVE, 1, 1, 0, 1, heroClass = HeroClass.ARCHER,
            speedBonus = 0.2f, category = "Ловец"),
        SkillNode("a_arrow_rain", "Дъжд от стрели", "AOE стрелба", "🏹",
            SkillNodeType.ACTIVE, 1, 1, 0, 1, abilityGranted = "arrow_rain",
            heroClass = HeroClass.ARCHER, attackBonus = 8, category = "Ловец"),
        SkillNode("a_eagle_eye", "Орлово Oko", "+25% криt", "👁️",
            SkillNodeType.PASSIVE, 2, 5, 0, 2, prerequisites = listOf("a_swift_feet"),
            critChanceBonus = 0.25f, heroClass = HeroClass.ARCHER, category = "Ловец"),
        SkillNode("a_shadow_archer", "Сенчест Лучник", "Избягва следващия удар", "🌑",
            SkillNodeType.ACTIVE, 2, 8, 150, 2, prerequisites = listOf("a_arrow_rain"),
            abilityGranted = "shadow_step", heroClass = HeroClass.ARCHER, category = "Ловец"),
        SkillNode("a_divine_arrow", "Стрела на Аполон", "Никога не пропуска", "☀️",
            SkillNodeType.PASSIVE, 3, 18, 500, 3, prerequisites = listOf("a_eagle_eye", "a_shadow_archer"),
            attackBonus = 35, critChanceBonus = 0.1f, heroClass = HeroClass.ARCHER, category = "Ловец"),
        SkillNode("a_god_of_hunt", "Бог на Лова", "Лова ти е легендарен", "🦅",
            SkillNodeType.PASSIVE, 4, 30, 2500, 4, prerequisites = listOf("a_divine_arrow"),
            attackBonus = 50, speedBonus = 0.5f, divinityGainBonus = 0.35f, heroClass = HeroClass.ARCHER, category = "Ловец"),

        // ══════════════════════════════
        //  MONK TREE
        // ══════════════════════════════
        SkillNode("k_inner_peace", "Вътрешен мир", "+80 живот, +30 мана", "🧘",
            SkillNodeType.PASSIVE, 1, 1, 0, 1, heroClass = HeroClass.MONK,
            healthBonus = 80, manaBonus = 30, category = "Монах"),
        SkillNode("k_holy_strike", "Свят Удар", "Свят удар с бонус урон", "✨",
            SkillNodeType.ACTIVE, 1, 1, 0, 1, abilityGranted = "holy_strike",
            heroClass = HeroClass.MONK, attackBonus = 6, category = "Монах"),
        SkillNode("k_meditation", "Медитация", "Регенерация на мана", "🕉️",
            SkillNodeType.PASSIVE, 2, 5, 0, 2, prerequisites = listOf("k_inner_peace"),
            manaBonus = 80, healthBonus = 50, heroClass = HeroClass.MONK, category = "Монах"),
        SkillNode("k_iron_fist", "Желязна Юмрук", "+20 ATK, удрян без оръжие", "👊",
            SkillNodeType.PASSIVE, 2, 8, 100, 2, prerequisites = listOf("k_holy_strike"),
            attackBonus = 20, heroClass = HeroClass.MONK, category = "Монах"),
        SkillNode("k_divine_body", "Божествено Тяло", "Тялото ти е оръжие", "💪",
            SkillNodeType.PASSIVE, 3, 15, 400, 3, prerequisites = listOf("k_meditation", "k_iron_fist"),
            healthBonus = 200, attackBonus = 25, defenseBonus = 25, heroClass = HeroClass.MONK, category = "Монах"),
        SkillNode("k_ascension", "Ascension", "Монахът стана Бог", "☯️",
            SkillNodeType.PASSIVE, 4, 30, 2800, 4, prerequisites = listOf("k_divine_body"),
            healthBonus = 400, manaBonus = 200, divinityGainBonus = 0.45f, heroClass = HeroClass.MONK, category = "Монах"),

        // ══════════════════════════════
        //  UNIVERSAL TREE (all classes)
        // ══════════════════════════════
        SkillNode("u_absorb_master", "Майстор на Поглъщане", "Поглъщаш +25% повече сила", "🌀",
            SkillNodeType.PASSIVE, 2, 10, 200, 2,
            divinityGainBonus = 0.25f, category = "Универсален"),
        SkillNode("u_greek_knowledge", "Гръцко Знание", "Отключва гръцки умения по-рано", "🏛️",
            SkillNodeType.PASSIVE, 2, 8, 100, 2,
            attackBonus = 15, manaBonus = 30, category = "Митология"),
        SkillNode("u_dragon_blood", "Кръв на Дракон", "Частична имунност към огън", "🐉",
            SkillNodeType.PASSIVE, 3, 18, 500, 3, prerequisites = listOf("u_greek_knowledge"),
            healthBonus = 200, defenseBonus = 30, category = "Митология"),
        SkillNode("u_divine_heritage", "Божествено Наследство", "Ускорено придобиване на дивинити", "✨",
            SkillNodeType.PASSIVE, 3, 20, 1000, 3, prerequisites = listOf("u_absorb_master"),
            divinityGainBonus = 0.4f, category = "Универсален"),
        SkillNode("u_zeus_power", "Силата на Зевс", "Отключва Гръм на Зевс", "⚡",
            SkillNodeType.ACTIVE, 3, 22, 1500, 4, prerequisites = listOf("u_greek_knowledge"),
            abilityGranted = "thunder_god", attackBonus = 20, category = "Митология"),
        SkillNode("u_shiva_dance", "Танцът на Шива", "Отключва Танца на Шива", "💫",
            SkillNodeType.ACTIVE, 3, 25, 2000, 4, prerequisites = listOf("u_divine_heritage"),
            abilityGranted = "shiva_dance", attackBonus = 25, category = "Митология"),
        SkillNode("u_omnigod_path", "Пътят на Всебога", "Крайната цел. Стани Всебог.", "🌌",
            SkillNodeType.PASSIVE, 4, 40, 10000, 5,
            prerequisites = listOf("u_zeus_power", "u_shiva_dance", "u_dragon_blood"),
            divinityGainBonus = 1.0f, attackBonus = 100, defenseBonus = 100, healthBonus = 1000, manaBonus = 500,
            abilityGranted = "omnigod_strike", category = "Универсален")
    )

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun canUnlock(node: SkillNode, character: Character, skillPoints: Int): Boolean {
        if (node.unlocked) return false
        if (character.level < node.requiredLevel) return false
        if (character.divinity < node.requiredDivinity) return false
        if (skillPoints < node.cost) return false
        if (node.heroClass != null && node.heroClass != character.heroClass) return false
        return node.prerequisites.all { prereqId ->
            ALL_NODES.find { it.id == prereqId }?.unlocked == true
        }
    }

    fun unlockNode(node: SkillNode, character: Character): Boolean {
        node.unlocked = true
        character.attack += node.attackBonus
        character.defense += node.defenseBonus
        character.maxHealth += node.healthBonus
        character.health = minOf(character.health + node.healthBonus, character.getTotalMaxHealth())
        character.maxMana += node.manaBonus
        character.speed += node.speedBonus
        node.abilityGranted?.let { abilityId ->
            GameDatabase.getAbilityById(abilityId)?.let { ability ->
                if (character.abilities.none { it.id == ability.id }) {
                    character.abilities.add(ability.copy())
                }
            }
        }
        return true
    }

    fun getAvailableNodes(character: Character, skillPoints: Int): List<SkillNode> =
        ALL_NODES.filter { canUnlock(it, character, skillPoints) }

    fun getUnlockedNodes(): List<SkillNode> = ALL_NODES.filter { it.unlocked }

    fun getNodesForClass(heroClass: HeroClass): List<SkillNode> =
        ALL_NODES.filter { it.heroClass == heroClass || it.heroClass == null }

    fun getTierColor(tier: Int): String = when (tier) {
        1 -> "#AAAAAA"
        2 -> "#4444FF"
        3 -> "#FF8800"
        4 -> "#FFD700"
        5 -> "#FF00FF"
        else -> "#FFFFFF"
    }
}

// ─────────────────────────────────────────────
//  SKILL TREE LORE & EXTENDED DESCRIPTIONS
// ─────────────────────────────────────────────

object SkillTreeLore {
    val NODE_LORE = mapOf(
        "iron_skin" to "Кожата ти се втвърдява с всяка битка. Спартанците са го постигнали за 20 години. Ти — с умение.",
        "power_strike" to "Ударът, концентриращ цялата мощ в един момент. Майсторите отнемат десетилетия да го усвоят.",
        "battle_cry" to "Викът на воина, разтърсващ духа на врага. Спартанците са го използвали при Термопилите.",
        "berserker_rage" to "Ярост без граница. Викингите я постигали чрез специални гъби и ритуали. Ти — чрез воля.",
        "divine_warrior" to "Финалното умение на Воина. Арес сам би завидял.",
        "arcane_mind" to "Умът е оръжие. Магьосникът, разбрал това, е по-опасен от всеки меч.",
        "fireball" to "Класическото заклинание. Хекате го е записала в свитъци преди 3000 години.",
        "god_of_magic" to "Ти надминаваш самата Хекате. Магията се подчинява само на теб.",
        "swift_feet" to "Скоростта на Хермес в смъртно тяло. Невъзможно? Вие казахте за летенето също.",
        "divine_arrow" to "Стрелата, намерила дори Парис — Ахил. Твоята е по-добра.",
        "god_of_hunt" to "Артемида би те приела за равен. Ловецът без равен.",
        "inner_peace" to "Будистки Монах достига вътрешен мир след 40 години медитация. Ти имаш умение.",
        "iron_fist" to "Железен Юмрук на Шаолин. Тренира се чрез удряне на дървета 10 000 пъти.",
        "ascension" to "Монахът надхвърля смъртното. Буда го е постигнал. Ти — следващият.",
        "dragon_blood" to "Кръвта на дракон тече в жилите ти. Буквално — или почти.",
        "zeus_power" to "Силата на Зевс без неговата надменност.",
        "omnigod_path" to "Пътят към Всебога е отворен само за малцина. Ти сте тук."
    )
    
    fun getLore(nodeId: String) = NODE_LORE[nodeId] ?: "Умение от митологичните традиции."
    
    fun getNodeFlavorText(tier: Int): String = when (tier) {
        1 -> "📚 Базово — начало на пътя"
        2 -> "📖 Напреднало — воинът расте"
        3 -> "📜 Майсторско — митологическа сила"
        4 -> "✨ Дивинити — богоподобна мощ"
        5 -> "🌌 Всебог — абсолютното"
        else -> "?"
    }
    
    fun getClassPhilosophy(heroClass: String): String = when (heroClass) {
        "WARRIOR" to "WARRIOR" -> buildString {
            appendLine("⚔️ ФИЛОСОФИЯ НА ВОИНА")
            appendLine()
            appendLine("Воинът не мисли — действа.")
            appendLine("Тялото е оръжие. Защитата е атака.")
            appendLine("Арес дава сила. Атина дава стратегия.")
            appendLine("Истинският Воин балансира и двете.")
        }
        else -> buildString {
            appendLine("📚 ФИЛОСОФИЯ НА КЛАСА")
            appendLine("Всеки клас е пълен сам по себе си.")
            appendLine("Открий умения, допълващи стила ти.")
        }
    }
}
