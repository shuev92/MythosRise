package com.mythosrise.game.engine

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.mythosrise.game.ui.WorldMapActivityV6

// ─────────────────────────────────────────────
//  NOTIFICATION TYPES
// ─────────────────────────────────────────────

enum class GameNotification(
    val id: Int,
    val channelId: String,
    val title: String,
    val messages: List<String>,
    val priority: Int = NotificationCompat.PRIORITY_DEFAULT
) {
    DAILY_CHALLENGE(1001, "daily", "📅 Дневни Предизвикателства!",
        listOf(
            "Предизвикателствата те чакат! Злато и Дивинити са твои!",
            "Нов ден, нови предизвикателства! Не ги пропускай!",
            "Боговете те очакват в арената! Дневните са готови!",
            "Ако не завършиш дневните — губиш Battle Pass EXP!",
            "Твоите дневни предизвикателства изтичат! Бързай!"
        ), NotificationCompat.PRIORITY_HIGH),

    GUILD_WAR(1002, "guild", "⚔️ Гилдийна Война!",
        listOf(
            "Твоята гилдия е в битка! Присъедини се!",
            "Войната тече! Точки се губят без теб!",
            "Гилдията те нуждае! Войната е в критична фаза!",
            "Противниковата гилдия води! Действай сега!"
        ), NotificationCompat.PRIORITY_HIGH),

    BOSS_SPAWN(1003, "boss", "👑 Легендарен Бос се появи!",
        listOf(
            "Легендарен бос в Олимп! Убий го за огромни награди!",
            "Тиамат се е появила в Дракон Царство! Поглъщай силата й!",
            "Хаос Бос! Само за напреднали! Дивинити награди x5!",
            "Световен бос! Огромни награди за убийство!"
        ), NotificationCompat.PRIORITY_MAX),

    PVP_CHALLENGE(1004, "pvp", "⚔️ PvP Предизвикателство!",
        listOf(
            "Някой те е предизвикал за PvP! Приеми или загуби рейтинг!",
            "Твоят PvP рейтинг пада! Играй за да го запазиш!",
            "Нов PvP сезон обновен! Виж наградите!",
            "Грандмайстор те е предизвикал! Смел или предпазлив?"
        )),

    RETURN_BONUS(1005, "return", "🎁 Добре дошъл обратно!",
        listOf(
            "Отсъствал си! Тук са твоите бонуси за завръщане!",
            "Боговете те чакаха! Ела — имаш специален подарък!",
            "24 часа без митологии? Тук е компенсацията!",
            "Mythos Rise те пропуска! Вземи бонус злато!"
        )),

    SEASONAL_EVENT(1006, "season", "🎉 Сезонно Събитие!",
        listOf(
            "Ново сезонно събитие е започнало! Уникални врагове и награди!",
            "Олимпийски Игри са тук! Специален контент за ограничено време!",
            "Рагнарок Събитие! Norse награди x3 тази седмица!",
            "Дракон Фестивал! Дракон Drops x200%!"
        ), NotificationCompat.PRIORITY_HIGH),

    STORY_REMINDER(1007, "story", "📖 Историята продължава...",
        listOf(
            "Теос те чака! Следващата глава е готова!",
            "Историята не е завършена! Ела да разкриеш тайните!",
            "Зевс чака реванш! Историята ти зове!",
            "Хаосът се приближава! Продължи историята!"
        )),

    BATTLE_PASS_EXPIRE(1008, "bp", "⭐ Battle Pass изтича!",
        listOf(
            "Battle Pass изтича след 7 дни! Вземи всичките нива!",
            "Само 3 дни до края на сезона! Не губи ексклузивното!",
            "Последен ден! Вземи ексклузивните преди изтичане!",
            "Сезонът приключва утре! Последен шанс!"
        ), NotificationCompat.PRIORITY_MAX)
}

// ─────────────────────────────────────────────
//  NOTIFICATION MANAGER
// ─────────────────────────────────────────────

object GameNotificationManager {

    const val MAIN_CHANNEL_ID = "mythos_rise_main"
    const val MAIN_CHANNEL_NAME = "Mythos Rise Известия"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channels = listOf(
                NotificationChannel("daily", "Дневни Предизвикателства", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Напомняния за дневни предизвикателства"
                },
                NotificationChannel("guild", "Гилдийни Новини", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Гилдийни войни и куестове"
                },
                NotificationChannel("boss", "Легендарни Босове", NotificationManager.IMPORTANCE_MAX).apply {
                    description = "Появяване на легендарни босове"
                },
                NotificationChannel("pvp", "PvP Арена", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "PvP предизвикателства и сезони"
                },
                NotificationChannel("return", "Бонус за Завръщане", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Бонуси при завръщане в играта"
                },
                NotificationChannel("season", "Сезонни Събития", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Специални сезонни събития"
                },
                NotificationChannel("story", "История", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Напомняния за Историята"
                },
                NotificationChannel("bp", "Battle Pass", NotificationManager.IMPORTANCE_MAX).apply {
                    description = "Battle Pass изтичане и нива"
                }
            )
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            channels.forEach { nm.createNotificationChannel(it) }
        }
    }

    fun sendNotification(context: Context, notif: GameNotification) {
        val message = notif.messages.random()
        val intent = Intent(context, WorldMapActivityV6::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pi = PendingIntent.getActivity(context, notif.id, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val builder = NotificationCompat.Builder(context, notif.channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(notif.title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(notif.priority)
            .setContentIntent(pi)
            .setAutoCancel(true)

        NotificationManagerCompat.from(context).notify(notif.id, builder.build())
    }

    fun scheduleDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, 2001, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 10)
            set(java.util.Calendar.MINUTE, 0)
            if (before(java.util.Calendar.getInstance())) add(java.util.Calendar.DAY_OF_MONTH, 1)
        }
        alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY, pi)
    }

    fun cancelAllNotifications(context: Context) {
        NotificationManagerCompat.from(context).cancelAll()
    }

    val MOTIVATIONAL_QUOTES = listOf(
        "\"Всеки бог е бил смъртен веднъж.\" — Теос",
        "\"Дивинитито е реално. Само трябва да го поглъщаш.\" — Теос",
        "\"Зевс е победим. Доказано.\" — Неизвестен Герой",
        "\"Рагнарок е неизбежен. Ти не.\" — Един",
        "\"В началото беше Хаосът. В края — ти.\" — Играта",
        "\"50 000 Дивинити. Един чакан резултат.\" — Всебог Наледник",
        "\"Поглъщаш богове. Те чакат.\" — Арената"
    )

    fun getMotivationalQuote() = MOTIVATIONAL_QUOTES.random()
}

// ─────────────────────────────────────────────
//  BROADCAST RECEIVER
// ─────────────────────────────────────────────

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        GameNotificationManager.sendNotification(context, GameNotification.DAILY_CHALLENGE)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            GameNotificationManager.scheduleDailyReminder(context)
        }
    }
}
