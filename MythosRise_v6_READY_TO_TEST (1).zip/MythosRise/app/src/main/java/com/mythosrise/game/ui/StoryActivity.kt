package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

class StoryActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentChapter: StoryChapter? = null
    private var currentSceneIndex = 0
    private var currentTab = "Глави"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story)
        engine = GameEngine(this)
        engine.loadGame()
        llContent = findViewById(R.id.llStoryContent)
        tvHeader = findViewById(R.id.tvStoryHeader)
        setupTabs()
        showChapterList()
    }

    private fun setupTabs() {
        val tabs = listOf("Глави", "Текуща", "Прогрес")
        val ll = findViewById<LinearLayout>(R.id.llStoryTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            Button(this).apply {
                text = tab; textSize = 12f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (tab == currentTab) Color.parseColor("#1A0A2E") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0); layoutParams = lp
                setOnClickListener {
                    currentTab = tab; setupTabs()
                    when (tab) {
                        "Глави" -> showChapterList()
                        "Текуща" -> if (currentChapter != null) showCurrentScene() else showChapterList()
                        "Прогрес" -> showProgress()
                    }
                }
            }.also { ll.addView(it) }
        }
    }

    // ── CHAPTER LIST ──
    private fun showChapterList() {
        llContent.removeAllViews()
        tvHeader.text = "📖 ИСТОРИЯ НА МИТОЛОГИИТЕ"

        val completed = StoryMode.ALL_CHAPTERS.count { it.isCompleted }
        val total = StoryMode.ALL_CHAPTERS.size
        addInfoBanner("📚 Прогрес: $completed/$total глави | ${engine.character.divinityTitle.title}")

        StoryMode.ALL_CHAPTERS.forEach { chapter ->
            val isAvailable = engine.character.level >= chapter.requiredLevel &&
                              engine.character.divinity >= chapter.requiredDivinity
            val bgColor = when {
                chapter.isCompleted -> "#001A00"
                isAvailable -> "#0A0A1A"
                else -> "#080808"
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor(bgColor))
                alpha = if (!isAvailable && !chapter.isCompleted) 0.4f else 1.0f
                setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 6, 0, 6); layoutParams = lp
            }

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply {
                text = if (chapter.isCompleted) "✅" else chapter.emoji
                textSize = 28f; setPadding(0, 0, 12, 0)
            }.also { row.addView(it) }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "Глава ${chapter.number}: ${chapter.title}"
                setTextColor(if (chapter.isCompleted) Color.parseColor("#00CC88") else Color.WHITE)
                textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = chapter.subtitle; setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "📚 ${chapter.mythology} | ⭐Ниво ${chapter.requiredLevel}${if (chapter.requiredDivinity > 0) " | ✨${chapter.requiredDivinity}" else ""}"
                setTextColor(Color.parseColor("#9B59B6")); textSize = 11f
            }.also { info.addView(it) }
            row.addView(info)
            card.addView(row)

            TextView(this).apply {
                text = "💬 ${chapter.lore}"; setTextColor(Color.DKGRAY); textSize = 11f; setPadding(0, 4, 0, 4)
            }.also { card.addView(it) }

            val rewardText = "🏆 💰${chapter.goldReward} ✨${chapter.divinityReward} ⭐${chapter.expReward}"
            TextView(this).apply {
                text = rewardText; setTextColor(Color.parseColor("#FFD700")); textSize = 11f
            }.also { card.addView(it) }

            if (!chapter.isCompleted) {
                Button(this).apply {
                    text = when {
                        !isAvailable -> "🔒 Ниво ${chapter.requiredLevel}${if (chapter.requiredDivinity > 0) " + ✨${chapter.requiredDivinity}" else ""}"
                        else -> "▶️ ${if (chapter.currentSceneIndex > 0) "ПРОДЪЛЖИ" else "НАЧАЛО"} — Глава ${chapter.number}"
                    }
                    setTextColor(Color.WHITE); isEnabled = isAvailable
                    backgroundTintList = android.content.res.ColorStateList.valueOf(
                        if (isAvailable) Color.parseColor("#1A0A2E") else Color.parseColor("#333333")
                    )
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(0, 6, 0, 0); layoutParams = lp
                    setOnClickListener {
                        currentChapter = chapter
                        currentSceneIndex = chapter.currentSceneIndex
                        currentTab = "Текуща"; setupTabs(); showCurrentScene()
                    }
                }.also { card.addView(it) }
            } else {
                Button(this).apply {
                    text = "🔄 Изиграй отново"
                    setTextColor(Color.WHITE)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#003300"))
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(0, 6, 0, 0); layoutParams = lp
                    setOnClickListener {
                        chapter.currentSceneIndex = 0
                        currentChapter = chapter; currentSceneIndex = 0
                        currentTab = "Текуща"; setupTabs(); showCurrentScene()
                    }
                }.also { card.addView(it) }
            }
            llContent.addView(card)
        }
    }

    // ── CURRENT SCENE ──
    private fun showCurrentScene() {
        val chapter = currentChapter ?: return
        val scenes = chapter.scenes
        if (currentSceneIndex >= scenes.size) { onChapterComplete(chapter); return }
        val scene = scenes[currentSceneIndex]

        llContent.removeAllViews()
        tvHeader.text = "${chapter.emoji} Глава ${chapter.number}: ${chapter.title}"

        // Background + scene title
        val titleCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0015"))
            setPadding(16, 16, 16, 16)
        }
        TextView(this).apply {
            text = scene.backgroundEmoji; textSize = 48f
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }.also { titleCard.addView(it) }
        TextView(this).apply {
            text = scene.title; setTextColor(Color.parseColor("#9B59B6"))
            textSize = 18f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER
        }.also { titleCard.addView(it) }
        TextView(this).apply {
            text = "Сцена ${currentSceneIndex + 1}/${scenes.size}"
            setTextColor(Color.GRAY); textSize = 11f; gravity = android.view.Gravity.CENTER
        }.also { titleCard.addView(it) }
        llContent.addView(titleCard)

        // Narrator
        val narratorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#110022"))
            setPadding(12, 8, 12, 8)
        }
        TextView(this).apply { text = scene.narratorEmoji; textSize = 24f; setPadding(0, 0, 10, 0) }.also { narratorRow.addView(it) }
        TextView(this).apply {
            text = scene.narrator; setTextColor(Color.parseColor("#FFD700"))
            textSize = 14f; isFakeBoldText = true
        }.also { narratorRow.addView(it) }
        llContent.addView(narratorRow)

        // Story text — typewriter effect via simple display
        val storyCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05000F"))
            setPadding(16, 16, 16, 16)
        }
        TextView(this).apply {
            text = scene.text; setTextColor(Color.WHITE)
            textSize = 14f; lineSpacingMultiplier = 1.5f
        }.also { storyCard.addView(it) }
        llContent.addView(storyCard)

        // Battle scene
        if (scene.isBattleScene) {
            val battleBtn = Button(this).apply {
                text = "⚔️ ВЛЕЗ В БИТКАТА!"
                setTextColor(Color.WHITE); textSize = 15f; isFakeBoldText = true
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0000"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dpToPx())
                lp.setMargins(8, 16, 8, 8); layoutParams = lp
                setOnClickListener {
                    Toast.makeText(this@StoryActivity, "⚔️ Битката започва! Върни се след победа.", Toast.LENGTH_LONG).show()
                    currentSceneIndex++
                    chapter.currentSceneIndex = currentSceneIndex
                    showCurrentScene()
                }
            }
            llContent.addView(battleBtn)
            return
        }

        // Choices
        if (scene.choices.isNotEmpty()) {
            val choiceTitle = TextView(this).apply {
                text = "💬 Избери:"; setTextColor(Color.parseColor("#9B59B6"))
                textSize = 13f; setPadding(12, 16, 12, 8)
            }
            llContent.addView(choiceTitle)

            scene.choices.forEach { choice ->
                Button(this).apply {
                    text = "${choice.emoji} ${choice.text}"
                    setTextColor(Color.WHITE); textSize = 12f
                    backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#1A0A2E"))
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(8, 4, 8, 4); layoutParams = lp
                    setOnClickListener { onChoiceSelected(choice, chapter, scene) }
                }.also { llContent.addView(it) }
            }
        } else {
            // Auto-continue button
            Button(this).apply {
                text = if (scene.isChapterEnd) "✅ Завърши главата" else "▶️ Продължи →"
                setTextColor(Color.WHITE); textSize = 14f
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (scene.isChapterEnd) Color.parseColor("#006600") else Color.parseColor("#1A0A2E")
                )
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 52.dpToPx())
                lp.setMargins(8, 16, 8, 8); layoutParams = lp
                setOnClickListener {
                    currentSceneIndex++
                    chapter.currentSceneIndex = currentSceneIndex
                    if (currentSceneIndex >= scenes.size) onChapterComplete(chapter)
                    else showCurrentScene()
                }
            }.also { llContent.addView(it) }
        }
    }

    private fun onChoiceSelected(choice: StoryChoice, chapter: StoryChapter, scene: StoryScene) {
        val c = engine.character
        if (choice.goldChange != 0) c.gold = maxOf(0, c.gold + choice.goldChange)
        if (choice.divinityChange != 0) {
            c.divinity += choice.divinityChange
            c.updateDivinityTitle()
        }

        AlertDialog.Builder(this)
            .setTitle("${choice.emoji} ${choice.text}")
            .setMessage(choice.consequence)
            .setPositiveButton("▶️ Продължи") { _, _ ->
                engine.saveGame()
                currentSceneIndex++
                chapter.currentSceneIndex = currentSceneIndex
                if (currentSceneIndex >= chapter.scenes.size) onChapterComplete(chapter)
                else showCurrentScene()
            }
            .show()
    }

    private fun onChapterComplete(chapter: StoryChapter) {
        StoryMode.completeChapter(chapter, engine.character)
        engine.saveGame()
        AlertDialog.Builder(this)
            .setTitle("✅ Глава ${chapter.number} завършена!")
            .setMessage(buildString {
                appendLine("\"${chapter.title}\" е завършена!")
                appendLine()
                appendLine("🏆 Награди:")
                appendLine("💰 +${chapter.goldReward} злато")
                appendLine("✨ +${chapter.divinityReward} дивинити")
                appendLine("⭐ +${chapter.expReward} опит")
                chapter.unlockTitle?.let { appendLine("👑 Титла: $it") }
                appendLine()
                StoryMode.getNextChapter(chapter.id)?.let {
                    appendLine("🔓 Отключена: Глава ${it.number}: ${it.title}")
                } ?: appendLine("🌌 Историята е завършена. Ти си ВСЕБОГ.")
            })
            .setCancelable(false)
            .setPositiveButton("🏆 Отлично!") { _, _ ->
                currentChapter = null; currentTab = "Глави"; setupTabs(); showChapterList()
            }
            .show()
    }

    // ── PROGRESS ──
    private fun showProgress() {
        llContent.removeAllViews()
        tvHeader.text = "📊 ИСТОРИЯ ПРОГРЕС"
        val completed = StoryMode.ALL_CHAPTERS.count { it.isCompleted }
        val total = StoryMode.ALL_CHAPTERS.size
        val pct = if (total > 0) completed * 100 / total else 0

        addInfoBanner("📖 $completed/$total глави | $pct% завършени")

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = total; progress = completed
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 20).apply { setMargins(8, 8, 8, 16) }
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#9B59B6"))
        }
        llContent.addView(pb)

        StoryMode.ALL_CHAPTERS.forEach { ch ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setPadding(8, 6, 8, 6)
                setBackgroundColor(if (ch.isCompleted) Color.parseColor("#001A00") else Color.parseColor("#080808"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            TextView(this).apply {
                text = if (ch.isCompleted) "✅" else ch.emoji
                textSize = 20f; setPadding(0, 0, 10, 0)
            }.also { row.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "Глава ${ch.number}: ${ch.title}"
                setTextColor(if (ch.isCompleted) Color.parseColor("#00CC88") else Color.GRAY)
                textSize = 13f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "${ch.mythology} | ${ch.scenes.size} сцени"
                setTextColor(Color.DKGRAY); textSize = 11f
            }.also { info.addView(it) }
            row.addView(info)
            llContent.addView(row)
        }

        if (completed == total) {
            val banner = TextView(this).apply {
                text = "🌌 ИСТОРИЯТА Е ЗАВЪРШЕНА!\nТИ СИ ВСЕБОГ!"
                setTextColor(Color.parseColor("#FFD700"))
                textSize = 18f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER
                setPadding(16, 24, 16, 24)
                setBackgroundColor(Color.parseColor("#1A0A2E"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 16, 0, 0); layoutParams = lp
            }
            llContent.addView(banner)
        }
    }

    private fun addInfoBanner(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.WHITE)
            textSize = 13f; gravity = android.view.Gravity.CENTER
            setPadding(12, 10, 12, 10); setBackgroundColor(Color.parseColor("#110022"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 8); layoutParams = lp
        }.also { llContent.addView(it) }
    }

    private fun Int.dpToPx() = (this * resources.displayMetrics.density).toInt()
}
