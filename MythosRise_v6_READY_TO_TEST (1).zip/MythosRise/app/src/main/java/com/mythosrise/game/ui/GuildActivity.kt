package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

class GuildActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentTab = "Гилдии"
    private var myGuild: Guild? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guild)
        engine = GameEngine(this)
        engine.loadGame()
        llContent = findViewById(R.id.llGuildContent)
        tvHeader = findViewById(R.id.tvGuildHeader)
        setupTabs()
        showGuildListTab()
    }

    private fun setupTabs() {
        val tabs = listOf("Гилдии", "Моята", "Война", "Класация")
        val ll = findViewById<LinearLayout>(R.id.llGuildTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            Button(this).apply {
                text = tab; textSize = 11f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (tab == currentTab) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0); layoutParams = lp
                setOnClickListener {
                    currentTab = tab; setupTabs()
                    when (tab) {
                        "Гилдии" -> showGuildListTab()
                        "Моята" -> showMyGuildTab()
                        "Война" -> showWarTab()
                        "Класация" -> showRankingTab()
                    }
                }
            }.also { ll.addView(it) }
        }
    }

    // ── GUILD LIST ──
    private fun showGuildListTab() {
        llContent.removeAllViews()
        tvHeader.text = "🏰 ГИЛДИИ — Намери своята!"

        Button(this).apply {
            text = "➕ СЪЗДАЙ НОВА ГИЛДИЯ"
            setTextColor(Color.WHITE); textSize = 13f
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0DAD"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 12); layoutParams = lp
            setOnClickListener { showCreateGuildDialog() }
        }.also { llContent.addView(it) }

        addSectionTitle("🌍 ВСИЧКИ ГИЛДИИ")

        GuildSystem.SAMPLE_GUILDS.forEach { guild ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#0A0A1A"))
                setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 5, 0, 5); layoutParams = lp
            }
            val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply { text = guild.emblem; textSize = 28f; setPadding(0, 0, 12, 0) }.also { row1.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "${guild.name} ${guild.tag}"
                setTextColor(Color.WHITE); textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "Ниво ${guild.level} | 👥${guild.memberCount}/${guild.maxMembers} | ⚔️${guild.warWins}В | ${guild.mythology}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = guild.description; setTextColor(Color.LTGRAY); textSize = 11f
            }.also { info.addView(it) }
            row1.addView(info)
            card.addView(row1)

            if (guild.announcement.isNotBlank()) {
                TextView(this).apply {
                    text = "📢 ${guild.announcement}"
                    setTextColor(Color.parseColor("#FFD700")); textSize = 11f; setPadding(0, 4, 0, 0)
                }.also { card.addView(it) }
            }

            // Online members
            val online = guild.members.count { it.isOnline }
            TextView(this).apply {
                text = "🟢 Онлайн: $online | Мин. ниво: ${guild.minLevel}"
                setTextColor(Color.parseColor("#00CC88")); textSize = 11f
            }.also { card.addView(it) }

            val canJoin = engine.character.level >= guild.minLevel && !guild.isFull
            Button(this).apply {
                text = when {
                    guild.isFull -> "🔒 Пълна"
                    !canJoin -> "🔒 Ниво ${guild.minLevel} нужно"
                    else -> "🏰 ПРИСЪЕДИНИ СЕ"
                }
                setTextColor(Color.WHITE); isEnabled = canJoin
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (canJoin) Color.parseColor("#2C5A2C") else Color.parseColor("#333333")
                )
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 6, 0, 0); layoutParams = lp
                setOnClickListener {
                    myGuild = guild
                    guild.members.add(GuildMember(
                        engine.character.name, engine.character.heroClass,
                        engine.character.level, engine.character.divinity,
                        GuildRank.RECRUIT, isOnline = true
                    ))
                    Toast.makeText(this@GuildActivity, "🏰 Добре дошъл в ${guild.name}!", Toast.LENGTH_LONG).show()
                    currentTab = "Моята"; setupTabs(); showMyGuildTab()
                }
            }.also { card.addView(it) }
            llContent.addView(card)
        }
    }

    // ── MY GUILD ──
    private fun showMyGuildTab() {
        llContent.removeAllViews()
        val guild = myGuild
        if (guild == null) {
            tvHeader.text = "🏰 МОЯТА ГИЛДИЯ"
            TextView(this).apply {
                text = "Не си в гилдия!\n\nПрисъедини се от таба 'Гилдии' или създай своя."
                setTextColor(Color.GRAY); textSize = 14f; gravity = android.view.Gravity.CENTER
                setPadding(16, 40, 16, 16)
            }.also { llContent.addView(it) }
            return
        }

        tvHeader.text = "${guild.emblem} ${guild.name} ${guild.tag}"

        addSectionTitle("📊 ИНФОРМАЦИЯ")
        addInfoRow("Ниво:", "${guild.level} (${guild.levelProgress}%)")
        addInfoRow("Членове:", "${guild.memberCount}/${guild.maxMembers}")
        addInfoRow("Войни:", "${guild.warWins}В / ${guild.warLosses}П")
        addInfoRow("Митология:", guild.mythology)
        if (guild.announcement.isNotBlank()) {
            TextView(this).apply {
                text = "📢 ${guild.announcement}"
                setTextColor(Color.parseColor("#FFD700")); textSize = 12f; setPadding(8, 8, 8, 8)
                setBackgroundColor(Color.parseColor("#1A1A00"))
            }.also { llContent.addView(it) }
        }

        addSectionTitle("👥 ЧЛЕНОВЕ (${guild.memberCount})")
        guild.members.forEach { member ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (member.isOnline) Color.parseColor("#0A1A0A") else Color.parseColor("#080808"))
                setPadding(10, 7, 10, 7)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 2, 0, 2); layoutParams = lp
            }
            val onlineEmoji = if (member.isOnline) "🟢" else "⚫"
            TextView(this).apply { text = "$onlineEmoji ${member.heroClass.emoji}"; textSize = 16f; setPadding(0, 0, 8, 0) }.also { row.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "${member.name} ${member.rank.emoji}"
                setTextColor(Color.WHITE); textSize = 13f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "Ниво ${member.level} | ✨${member.divinity} | ${member.rank.displayName}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            row.addView(info)
            TextView(this).apply {
                text = "🏆${member.weeklyContribution}"
                setTextColor(Color.parseColor("#FFD700")); textSize = 11f
            }.also { row.addView(it) }
            llContent.addView(row)
        }

        addSectionTitle("⚡ АКТИВНИ БАФОВЕ")
        val availBuffs = GuildSystem.getAvailableBuffs(guild)
        availBuffs.forEach { buff ->
            val buffRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 6, 8, 6)
                setBackgroundColor(Color.parseColor("#0A0A1A"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            val bInfo = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply { text = "${buff.emoji} ${buff.name}"; setTextColor(Color.WHITE); textSize = 13f }.also { bInfo.addView(it) }
            TextView(this).apply { text = buff.description; setTextColor(Color.GRAY); textSize = 11f }.also { bInfo.addView(it) }
            buffRow.addView(bInfo)
            Button(this).apply {
                text = "⚡ ${buff.guildExpCost}XP"
                textSize = 10f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C1A4A"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT); layoutParams = lp
                setOnClickListener {
                    if (GuildSystem.activateBuff(buff, guild)) {
                        Toast.makeText(this@GuildActivity, "${buff.emoji} ${buff.name} активиран!", Toast.LENGTH_SHORT).show()
                        showMyGuildTab()
                    } else Toast.makeText(this@GuildActivity, "Недостатъчно Guild XP!", Toast.LENGTH_SHORT).show()
                }
            }.also { buffRow.addView(it) }
            llContent.addView(buffRow)
        }

        addSectionTitle("📜 ГИЛДИЙНИ КУЕСТОВЕ")
        GuildSystem.GUILD_QUESTS.take(4).forEach { quest ->
            val qCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#0A0A1A"))
                setPadding(10, 8, 10, 8)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 4, 0, 4); layoutParams = lp
            }
            TextView(this).apply {
                text = "${quest.emoji} ${quest.title} [${quest.difficulty}]"
                setTextColor(Color.WHITE); textSize = 13f; isFakeBoldText = true
            }.also { qCard.addView(it) }
            TextView(this).apply { text = quest.description; setTextColor(Color.GRAY); textSize = 11f }.also { qCard.addView(it) }
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = quest.targetCount; progress = quest.currentCount
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12).apply { setMargins(0, 4, 0, 2) }
                progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0DAD"))
            }
            qCard.addView(pb)
            TextView(this).apply {
                text = "${quest.progress} | 💰${quest.goldReward} ✨${quest.divinityReward} +${quest.guildExpReward}XP"
                setTextColor(Color.parseColor("#FFD700")); textSize = 11f
            }.also { qCard.addView(it) }
            llContent.addView(qCard)
        }
    }

    // ── WAR TAB ──
    private fun showWarTab() {
        llContent.removeAllViews()
        tvHeader.text = "⚔️ ГИЛДИЙНА ВОЙНА"

        addSectionTitle("🔥 АКТИВНИ ВОЙНИ")
        val warCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1A0000"))
            setPadding(14, 12, 14, 12)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 6, 0, 6); layoutParams = lp
        }
        val g1 = GuildSystem.SAMPLE_GUILDS[0]
        val g2 = GuildSystem.SAMPLE_GUILDS[1]
        TextView(this).apply {
            text = "⚔️ ВОЙНА В ПРОГРЕС"
            setTextColor(Color.RED); textSize = 14f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER
        }.also { warCard.addView(it) }
        val vsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, 8, 0, 8) }
        val leftInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); gravity = android.view.Gravity.CENTER }
        TextView(this).apply { text = g1.emblem; textSize = 32f; gravity = android.view.Gravity.CENTER }.also { leftInfo.addView(it) }
        TextView(this).apply { text = g1.name; setTextColor(Color.WHITE); textSize = 13f; gravity = android.view.Gravity.CENTER }.also { leftInfo.addView(it) }
        TextView(this).apply { text = "1250 точки"; setTextColor(Color.parseColor("#00CC00")); textSize = 16f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER }.also { leftInfo.addView(it) }
        vsRow.addView(leftInfo)
        TextView(this).apply { text = "⚔️\nVS\n⚔️"; setTextColor(Color.RED); textSize = 16f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER; setPadding(16, 0, 16, 0) }.also { vsRow.addView(it) }
        val rightInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); gravity = android.view.Gravity.CENTER }
        TextView(this).apply { text = g2.emblem; textSize = 32f; gravity = android.view.Gravity.CENTER }.also { rightInfo.addView(it) }
        TextView(this).apply { text = g2.name; setTextColor(Color.WHITE); textSize = 13f; gravity = android.view.Gravity.CENTER }.also { rightInfo.addView(it) }
        TextView(this).apply { text = "980 точки"; setTextColor(Color.parseColor("#FF4444")); textSize = 16f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER }.also { rightInfo.addView(it) }
        vsRow.addView(rightInfo)
        warCard.addView(vsRow)
        TextView(this).apply {
            text = "⏱️ Оставащо: 14:32:00 | 💰 Залог: 20 000 злато"
            setTextColor(Color.parseColor("#FFD700")); textSize = 12f; gravity = android.view.Gravity.CENTER
        }.also { warCard.addView(it) }
        Button(this).apply {
            text = "⚔️ УЧАСТВАЙ В ВОЙНАТА (+50 точки за убийство)"
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#8B0000"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 8, 0, 0); layoutParams = lp
            setOnClickListener { Toast.makeText(this@GuildActivity, "⚔️ Война участие регистрирано! +50 точки за победа!", Toast.LENGTH_SHORT).show() }
        }.also { warCard.addView(it) }
        llContent.addView(warCard)

        addSectionTitle("📜 ВОЕНЕН ЛОГ")
        listOf(
            "🗡️ ΖευςSlayer99 уби DragonBlood (+50т)" to "#FF4444",
            "🛡️ TiamatFan защити DragonBlood (+30т)" to "#44FF44",
            "⚡ Медуза_Убиец използва Гръм Форма!" to "#FFFF00",
            "💀 WyvernKing е победен от АтинаФолоуър" to "#FF4444",
            "🌟 [OLY] активира Боен Дух баф!" to "#9B59B6",
            "🎯 [DRAG] постига Квест: 10 дракона убити" to "#00CC88"
        ).forEach { (log, color) ->
            TextView(this).apply {
                text = log; setTextColor(Color.parseColor(color))
                textSize = 12f; setPadding(8, 3, 8, 3)
                setBackgroundColor(Color.parseColor("#080808"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 2, 0, 2); layoutParams = lp
            }.also { llContent.addView(it) }
        }
    }

    // ── RANKING TAB ──
    private fun showRankingTab() {
        llContent.removeAllViews()
        tvHeader.text = "🏆 ГИЛДИЙНА КЛАСАЦИЯ"
        addSectionTitle("🏆 ТОП ГИЛДИИ")
        GuildSystem.getGuildRanking().forEach { (rank, guild) ->
            val rankEmoji = when (rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "#$rank" }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (rank <= 3) Color.parseColor("#1A1A00") else Color.parseColor("#080808"))
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            TextView(this).apply { text = "$rankEmoji"; textSize = 22f; setPadding(0, 0, 10, 0) }.also { row.addView(it) }
            TextView(this).apply { text = guild.emblem; textSize = 24f; setPadding(0, 0, 10, 0) }.also { row.addView(it) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            TextView(this).apply { text = "${guild.name} ${guild.tag}"; setTextColor(Color.WHITE); textSize = 13f; isFakeBoldText = true }.also { info.addView(it) }
            TextView(this).apply { text = "Ниво ${guild.level} | 👥${guild.memberCount} | ⚔️${guild.warWins}В"; setTextColor(Color.GRAY); textSize = 11f }.also { info.addView(it) }
            row.addView(info)
            TextView(this).apply {
                text = "%,d".format(GuildSystem.getGuildScore(guild))
                setTextColor(Color.parseColor("#FFD700")); textSize = 12f
            }.also { row.addView(it) }
            llContent.addView(row)
        }
    }

    private fun showCreateGuildDialog() {
        AlertDialog.Builder(this)
            .setTitle("➕ СЪЗДАЙ ГИЛДИЯ")
            .setMessage("Гилдията изисква 1000 злато за основаване.\n\nТи ще станеш Лидер и ще имаш пълен контрол.\n\nИмеш ${engine.character.gold} злато.")
            .setPositiveButton("СЪЗДАЙ!") { _, _ ->
                if (engine.character.gold >= 1000) {
                    engine.character.gold -= 1000
                    val newGuild = GuildSystem.createGuild("Нова Гилдия", "[NEW]", "🌟", "Моята гилдия!", engine.character)
                    GuildSystem.SAMPLE_GUILDS.add(newGuild)
                    myGuild = newGuild
                    engine.saveGame()
                    Toast.makeText(this, "🏰 Гилдия създадена!", Toast.LENGTH_SHORT).show()
                    currentTab = "Моята"; setupTabs(); showMyGuildTab()
                } else Toast.makeText(this, "Нямаш 1000 злато!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Назад", null).show()
    }

    private fun addSectionTitle(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#9B59B6"))
            textSize = 13f; isFakeBoldText = true; setPadding(4, 14, 4, 6)
        }.also { llContent.addView(it) }
    }

    private fun addInfoRow(label: String, value: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4, 3, 4, 3) }
        TextView(this).apply { text = label; setTextColor(Color.GRAY); textSize = 12f; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }.also { row.addView(it) }
        TextView(this).apply { text = value; setTextColor(Color.WHITE); textSize = 12f }.also { row.addView(it) }
        llContent.addView(row)
    }
}
