package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  COMPANION
// ─────────────────────────────────────────────

enum class CompanionType { MOUNT, BEAST, SPIRIT, DIVINE }

data class Companion(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val type: CompanionType,
    val mythology: String,
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val healthBonus: Int = 0,
    val manaBonus: Int = 0,
    val divinityGainBonus: Float = 0f,
    val specialAbility: String = "",
    val specialAbilityDesc: String = "",
    val requiredDivinity: Int = 0,
    val requiredLevel: Int = 1,
    val goldCost: Int = 0,
    var isOwned: Boolean = false,
    var isActive: Boolean = false,
    var bond: Int = 0,      // 0-100 bond level
    val lore: String = ""
)

// ─────────────────────────────────────────────
//  COMPANION DATABASE
// ─────────────────────────────────────────────

object CompanionDatabase {

    val ALL_COMPANIONS = listOf(

        // ── MOUNTS ──
        Companion("horse", "Верен Кон", "Верен спътник в битките.", "🐴",
            CompanionType.MOUNT, "Mortal", defenseBonus = 10, healthBonus = 50,
            specialAbility = "charge", specialAbilityDesc = "Конски заряд — двоен начален урон",
            goldCost = 500, lore = "Всеки войн има нужда от кон."),

        Companion("pegasus", "Пегас", "Крилатият кон от Гръцката митология.", "🦄",
            CompanionType.MOUNT, "Greek", attackBonus = 25, healthBonus = 150, manaBonus = 80,
            specialAbility = "sky_charge", specialAbilityDesc = "Небесен удар от въздуха",
            requiredDivinity = 200, goldCost = 5000,
            lore = "Роден от кръвта на Медуза. Носи гръмотевиците на Зевс."),

        Companion("sleipnir", "Слейпнир", "8-кракият кон на Один. Най-бързото същество.", "🐎",
            CompanionType.MOUNT, "Norse", attackBonus = 20, healthBonus = 200, divinityGainBonus = 0.1f,
            specialAbility = "world_run", specialAbilityDesc = "Бяга между световете — спасение от смърт",
            requiredDivinity = 800, goldCost = 15000,
            lore = "Слейпнир е дете на Локи. Носи Один в Хел и обратно."),

        // ── BEASTS ──
        Companion("wolf", "Гладуващ Вълк", "Диво куче на войната.", "🐺",
            CompanionType.BEAST, "Mortal", attackBonus = 20, defenseBonus = 5,
            specialAbility = "pack_hunt", specialAbilityDesc = "Нападение — 20% шанс за допълнителна захапка",
            goldCost = 1000, lore = "Бое се рамо до рамо с теб."),

        Companion("dragon_hatchling", "Дракон Малко", "Малък дракон. Ще порасне.", "🐉",
            CompanionType.BEAST, "Dragon", attackBonus = 35, defenseBonus = 20, healthBonus = 100,
            specialAbility = "mini_fire", specialAbilityDesc = "Малка огнена атака всеки ход",
            requiredDivinity = 300, goldCost = 8000,
            lore = "Дракончето те гледа с огромни очи. Ти си неговото стадо."),

        Companion("fenrir_pup", "Кученцето на Фенрир", "Малко вълче от вълка на Рагнарок.", "🐕",
            CompanionType.BEAST, "Norse", attackBonus = 45, defenseBonus = 15,
            specialAbility = "ragnarok_bite", specialAbilityDesc = "Дива захапка — критичен удар",
            requiredDivinity = 500, goldCost = 12000,
            lore = "Баща му ще погълне Один. То само иска да играе... засега."),

        Companion("simurgh", "Симург", "Митичната персийска птица с безкрайна мъдрост.", "🦅",
            CompanionType.BEAST, "Persian", attackBonus = 30, manaBonus = 200, divinityGainBonus = 0.15f,
            specialAbility = "wisdom_cry", specialAbilityDesc = "Дава +100% мана регенерация",
            requiredDivinity = 600, goldCost = 18000,
            lore = "Симург е стар колкото света. Знае всички тайни."),

        Companion("kirin", "Кирин", "Китайското митично животно — символ на правда.", "🦌",
            CompanionType.BEAST, "Chinese", defenseBonus = 50, healthBonus = 300, divinityGainBonus = 0.2f,
            specialAbility = "righteous_aura", specialAbilityDesc = "Аура на правдата — намалява щетата",
            requiredDivinity = 700, goldCost = 20000,
            lore = "Кирин се появява само пред праведните. Твоята поява го извиква."),

        // ── SPIRITS ──
        Companion("valkyrie_spirit", "Духът на Валкирия", "Духовна война-жена от Асгард.", "⚡",
            CompanionType.SPIRIT, "Norse", attackBonus = 40, manaBonus = 100,
            specialAbility = "battle_blessing", specialAbilityDesc = "Благославя всяка атака с гръм",
            requiredDivinity = 400, goldCost = 10000,
            lore = "Валкириите избират кои войни умират достойно."),

        Companion("anubis_jackal", "Чакалът на Анубис", "Духовен пазач на пречистото.", "🐺",
            CompanionType.SPIRIT, "Egyptian", defenseBonus = 40, divinityGainBonus = 0.2f,
            specialAbility = "soul_judge", specialAbilityDesc = "Претегля душата на врага — ако е зъл, удвоен урон",
            requiredDivinity = 600, goldCost = 15000,
            lore = "Служи само на Анубис. И на теб, ако сте се срещнали."),

        Companion("apsara", "Апсара", "Небесна дансьорка от Индия.", "💃",
            CompanionType.SPIRIT, "Indian", manaBonus = 250, healthBonus = 200, divinityGainBonus = 0.15f,
            specialAbility = "divine_dance", specialAbilityDesc = "Всяко умение -30% мана",
            requiredDivinity = 700, goldCost = 18000,
            lore = "Апсарите танцуват в небесните градини. Тя е слязла да те помогне."),

        // ── DIVINE ──
        Companion("phoenix", "Феникс", "Птицата на прераждането.", "🔥",
            CompanionType.DIVINE, "Universal", attackBonus = 60, healthBonus = 400, divinityGainBonus = 0.25f,
            specialAbility = "rebirth", specialAbilityDesc = "При смърт — прераждаш се веднъж с 50% HP",
            requiredDivinity = 2000, goldCost = 50000,
            lore = "Феникс умира и се ражда отново. Един ден и ти ще направиш същото."),

        Companion("god_fragment", "Фрагмент на Бог", "Откъснато парче от убит бог.", "🌌",
            CompanionType.DIVINE, "Divine", attackBonus = 80, defenseBonus = 80, healthBonus = 500,
            divinityGainBonus = 0.5f, manaBonus = 300,
            specialAbility = "god_echo", specialAbilityDesc = "Всяка атака носи ехо от убития бог",
            requiredDivinity = 5000, goldCost = 0,
            lore = "Когато убиеш бог, малка частица остава. Тя те следва."),

        Companion("chaos_fragment", "Фрагмент на Хаос", "Парче от самата Първичност.", "💜",
            CompanionType.DIVINE, "Divine", attackBonus = 150, defenseBonus = 100,
            healthBonus = 1000, manaBonus = 500, divinityGainBonus = 1.0f,
            specialAbility = "chaos_nova", specialAbilityDesc = "АПОКАЛИПТИЧЕН удар всеки 10 хода",
            requiredDivinity = 30000, goldCost = 0,
            lore = "Само Всебог може да контролира Хаоса.")
    )

    fun getAvailable(divinity: Int, level: Int): List<Companion> =
        ALL_COMPANIONS.filter { it.requiredDivinity <= divinity && it.requiredLevel <= level }

    fun getOwned(): List<Companion> = ALL_COMPANIONS.filter { it.isOwned }

    fun getActive(): Companion? = ALL_COMPANIONS.firstOrNull { it.isActive }

    fun applyCompanionBonuses(companion: Companion, character: Character) {
        character.attack += companion.attackBonus
        character.defense += companion.defenseBonus
        character.maxHealth += companion.healthBonus
        character.maxMana += companion.manaBonus
        character.health = minOf(character.health + companion.healthBonus, character.getTotalMaxHealth())
    }

    fun removeCompanionBonuses(companion: Companion, character: Character) {
        character.attack -= companion.attackBonus
        character.defense -= companion.defenseBonus
        character.maxHealth -= companion.healthBonus
        character.maxMana -= companion.manaBonus
    }
}
