package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine

data class QuizQuestion(
    val question: String,
    val answers: List<String>,
    val correctIndex: Int,
    val mythology: String,
    val difficulty: Int, // 1-3
    val goldReward: Int,
    val divinityReward: Int,
    val explanation: String
)

class MythologyQuizActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private var currentQuestion: QuizQuestion? = null
    private var questionIndex = 0
    private var score = 0
    private var totalGold = 0
    private var totalDivinity = 0
    private var streak = 0
    private var timer: CountDownTimer? = null
    private var timeLeft = 20
    private var selectedMythology = "Всички"

    private lateinit var tvQuestion: TextView
    private lateinit var tvScore: TextView
    private lateinit var tvMythology: TextView
    private lateinit var tvTimer: TextView
    private lateinit var pbTimer: ProgressBar
    private lateinit var llAnswers: LinearLayout
    private lateinit var tvStreak: TextView
    private lateinit var tvRewards: TextView

    val ALL_QUESTIONS = listOf(
        QuizQuestion("Кой е бащата на Зевс?", listOf("Посейдон", "Кронос", "Уран", "Хермес"), 1,
            "Greek", 1, 200, 10, "Кронос (Сатурн) е Титанът-баща на Зевс, Хера, Хадес, Посейдон, Деметра и Хестия."),
        QuizQuestion("С какво оръжие се бие Зевс?", listOf("Трезъбец", "Лък", "Мълния", "Меч"), 2,
            "Greek", 1, 200, 10, "Мълниите на Зевс са изковани от Циклопите специално за него."),
        QuizQuestion("Кой е пазачът на подземния свят в Гърция?", listOf("Харон", "Хадес", "Цербер", "Хермес"), 2,
            "Greek", 1, 200, 10, "Цербер е тригласото куче, пазещо входа на Хадес."),
        QuizQuestion("Колко глави има Хидрата?", listOf("7", "9", "12", "5"), 1,
            "Greek", 1, 200, 10, "Лернейската Хидра има 9 глави — отрежеш ли една, израстват две."),
        QuizQuestion("Кой е Маймунският Крал в китайската митология?", listOf("Хоу И", "Нейча", "Сун Ву Конг", "Гуан Ю"), 2,
            "Chinese", 1, 200, 10, "Сун Ву Конг е роден от магически камък и има 72 трансформации."),
        QuizQuestion("Какво оръжие носи Тор?", listOf("Гунгнир", "Мьолнир", "Дюрандал", "Экскалибур"), 1,
            "Norse", 1, 200, 10, "Мьолнир е легендарният чук на Тор, изкован от Дварфите."),
        QuizQuestion("Кой е Всебащата в скандинавската митология?", listOf("Тор", "Балдур", "Локи", "Один"), 3,
            "Norse", 1, 200, 10, "Один (Вотан) е върховен скандинавски бог, жертвал окото си за мъдрост."),
        QuizQuestion("Кой бог претегля сърцата на мъртвите в Египет?", listOf("Ра", "Хор", "Анубис", "Тот"), 2,
            "Egyptian", 1, 200, 10, "Анубис (с глава на чакал) претегля сърцето срещу перото на Маат."),
        QuizQuestion("Кой е слънчевият бог в Египет?", listOf("Осирис", "Ра", "Сет", "Хатхор"), 1,
            "Egyptian", 1, 200, 10, "Ра е слънцето само — пътува с лодка по небето всеки ден."),
        QuizQuestion("Как се казва световното дърво в скандинавската митология?", listOf("Игдрасил", "Бифрост", "Глейпнир", "Вигрид"), 0,
            "Norse", 1, 300, 15, "Игдрасил свързва 9-те свята и е центърът на скандинавската космология."),
        QuizQuestion("Кой убива Медуза?", listOf("Херакъл", "Ахил", "Персей", "Тезей"), 2,
            "Greek", 2, 400, 20, "Персей я убива с отражение в щит (подарен от Атина) — не гледал директно."),
        QuizQuestion("Какво се крие в опашката на Ямата-но-Орочи?", listOf("Скъпоценен камък", "Свещен текст", "Меч Кусанаги", "Магически огледало"), 2,
            "Japanese", 2, 400, 20, "Сусаноо намерил меча Кусанаги-но-цуруги в опашката и го подарил на Аматерасу."),
        QuizQuestion("Колко ръце има Шива?", listOf("2", "4", "6", "8"), 1,
            "Indian", 2, 400, 20, "Шива традиционно се изобразява с 4 ръце, всяка с символично значение."),
        QuizQuestion("Кой е вечният враг на Ра (слънцето)?", listOf("Сет", "Апеп", "Собек", "Нут"), 1,
            "Egyptian", 2, 400, 20, "Апеп (Апофис) е огромен змей, атакуващ лодката на Ра всяка нощ."),
        QuizQuestion("Колко крака има Слейпнир — конят на Один?", listOf("4", "6", "8", "12"), 2,
            "Norse", 2, 400, 20, "Слейпнир е 8-краки и е роден от Локи (трансформиран в кобила) и жребеца Свадилфари."),
        QuizQuestion("Кой е първообразното начало в гръцката митология?", listOf("Зевс", "Кронос", "Уран", "Хаос"), 3,
            "Greek", 2, 400, 20, "Хаос е първото съществуване — от него се е родило всичко останало."),
        QuizQuestion("Какво означава Рагнарок?", listOf("Война на Боговете", "Съдбата на Боговете", "Смъртта на Локи", "Падането на Асгард"), 1,
            "Norse", 3, 700, 35, "Ragnarök = 'ragna' (богове) + 'rök' (съдба/унищожение) = Съдбата/Унищожението на Боговете."),
        QuizQuestion("Коя е матерята на всички чудовища в Тиамат митологията?", listOf("Иштар", "Тиамат", "Нинти", "Еришкигал"), 1,
            "Babylonian", 3, 700, 35, "Тиамат (солената вода) е праматерята в Вавилонската митология — от тялото й е направен светът."),
        QuizQuestion("Кое животно придружава Один?", listOf("Вълк и Гарван", "Орел и Змия", "Мечка и Лиса", "Дракон и Ворона"), 0,
            "Norse", 3, 700, 35, "Один има 2 гарвана (Хугин и Мунин), 2 вълка (Гери и Фреки) и коня Слейпнир."),
        QuizQuestion("Колко пъти Ву Конг може да се трансформира?", listOf("36", "72", "108", "144"), 1,
            "Chinese", 3, 700, 35, "Ву Конг владее 72 трансформации — може да стане всякакво животно, растение или обект."),
        QuizQuestion("Кой е синът на Тиамат в Вавилонската митология?", listOf("Мардук", "Енки", "Ану", "Кингу"), 0,
            "Babylonian", 3, 700, 35, "Мардук побеждава Тиамат, разцепва я и прави небето и земята от тялото й.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mythology_quiz)
        engine = GameEngine(this)
        engine.loadGame()

        tvQuestion = findViewById(R.id.tvQuizQuestion)
        tvScore = findViewById(R.id.tvQuizScore)
        tvMythology = findViewById(R.id.tvQuizMythology)
        tvTimer = findViewById(R.id.tvQuizTimer)
        pbTimer = findViewById(R.id.pbQuizTimer)
        llAnswers = findViewById(R.id.llQuizAnswers)
        tvStreak = findViewById(R.id.tvQuizStreak)
        tvRewards = findViewById(R.id.tvQuizRewards)

        showMythologySelection()
    }

    private fun showMythologySelection() {
        val options = arrayOf("Всички", "Greek", "Norse", "Egyptian", "Japanese", "Chinese", "Indian", "Babylonian")
        AlertDialog.Builder(this)
            .setTitle("📚 МИТОЛОГИЯ КУИЗ")
            .setMessage("Избери митология за въпроси.\nВсеки верен отговор → злато и дивинити!\nСтрийк бонуси!")
            .setSingleChoiceItems(options, 0) { _, i -> selectedMythology = options[i] }
            .setPositiveButton("НАЧАЛО!") { _, _ ->
                questionIndex = 0; score = 0; totalGold = 0; totalDivinity = 0; streak = 0
                loadQuestion()
            }
            .setNegativeButton("Назад") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun loadQuestion() {
        timer?.cancel()
        val pool = if (selectedMythology == "Всички") ALL_QUESTIONS
                   else ALL_QUESTIONS.filter { it.mythology == selectedMythology }
        if (pool.isEmpty() || questionIndex >= minOf(10, pool.size)) { showResults(); return }

        val shuffled = pool.shuffled()
        currentQuestion = shuffled[questionIndex % shuffled.size]
        questionIndex++
        renderQuestion()
        startTimer()
    }

    private fun renderQuestion() {
        val q = currentQuestion ?: return
        val diffStr = when (q.difficulty) { 1 -> "🟢 Лесна"; 2 -> "🟡 Средна"; else -> "🔴 Трудна" }
        val streakEmoji = when { streak >= 5 -> "🔥🔥🔥"; streak >= 3 -> "🔥🔥"; streak >= 1 -> "🔥"; else -> "" }

        tvMythology.text = "${q.mythology} митология | $diffStr"
        tvQuestion.text = "❓ ${q.question}"
        tvScore.text = "✅ Верни: $score/$questionIndex | 💰+$totalGold | ✨+$totalDivinity"
        tvStreak.text = if (streak > 0) "$streakEmoji Стрийк: $streak! (+${streak * 50}% бонус)" else ""
        tvRewards.text = "🏆 За верен: 💰${q.goldReward * (1 + streak * 0.5f).toInt()} | ✨${q.divinityReward}"

        llAnswers.removeAllViews()
        q.answers.forEachIndexed { i, answer ->
            val letter = listOf("A", "B", "C", "D")[i]
            Button(this).apply {
                text = "$letter. $answer"; textSize = 13f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#1A1A3A"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dpToPx())
                lp.setMargins(0, 4, 0, 4); layoutParams = lp
                setOnClickListener { timer?.cancel(); checkAnswer(i) }
            }.also { llAnswers.addView(it) }
        }
    }

    private fun startTimer() {
        timeLeft = 20
        pbTimer.max = 20; pbTimer.progress = 20
        timer = object : CountDownTimer(20000, 1000) {
            override fun onTick(ms: Long) {
                timeLeft = (ms / 1000).toInt()
                tvTimer.text = "⏱️ $timeLeft"
                pbTimer.progress = timeLeft
                tvTimer.setTextColor(if (timeLeft <= 5) Color.RED else Color.WHITE)
            }
            override fun onFinish() { checkAnswer(-1) }
        }.start()
    }

    private fun checkAnswer(selected: Int) {
        val q = currentQuestion ?: return
        val isCorrect = selected == q.correctIndex
        disableButtons()

        if (isCorrect) {
            streak++
            val streakBonus = (1 + streak * 0.5f)
            val goldEarned = (q.goldReward * streakBonus).toInt()
            val divEarned = (q.divinityReward * streakBonus).toInt()
            totalGold += goldEarned; totalDivinity += divEarned; score++
            engine.character.gold += goldEarned
            engine.character.divinity += divEarned
            highlightAnswer(q.correctIndex, Color.parseColor("#006600"))
            Toast.makeText(this, "✅ Вярно! +$goldEarned💰 +$divEarned✨ ${if (streak > 1) "🔥Стрийк x$streak!" else ""}", Toast.LENGTH_SHORT).show()
        } else {
            streak = 0
            if (selected >= 0) highlightAnswer(selected, Color.parseColor("#660000"))
            highlightAnswer(q.correctIndex, Color.parseColor("#006600"))
            Toast.makeText(this, "❌ Грешно! Верен: ${q.answers[q.correctIndex]}", Toast.LENGTH_LONG).show()
        }

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            AlertDialog.Builder(this)
                .setTitle(if (isCorrect) "✅ Вярно!" else "❌ Грешно!")
                .setMessage("📖 ${q.explanation}")
                .setPositiveButton("Следващ →") { _, _ -> engine.saveGame(); loadQuestion() }
                .setCancelable(false).show()
        }, 800)
    }

    private fun disableButtons() {
        for (i in 0 until llAnswers.childCount) {
            (llAnswers.getChildAt(i) as? Button)?.isEnabled = false
        }
    }

    private fun highlightAnswer(index: Int, color: Int) {
        (llAnswers.getChildAt(index) as? Button)?.backgroundTintList =
            android.content.res.ColorStateList.valueOf(color)
    }

    private fun showResults() {
        engine.saveGame()
        AlertDialog.Builder(this)
            .setTitle("🏆 КУИ ЗАВЪРШЕН!")
            .setMessage(buildString {
                appendLine("Верни отговори: $score/$questionIndex")
                appendLine("💰 Злато: +$totalGold")
                appendLine("✨ Дивинити: +$totalDivinity")
                appendLine("🔥 Максимален стрийк: $streak")
                if (score == questionIndex) appendLine("\n🌟 ПЕРФЕКТЕН РЕЗУЛТАТ!")
                else if (score >= questionIndex * 0.8) appendLine("\n🏆 Отличен резултат!")
                else if (score >= questionIndex * 0.5) appendLine("\n👍 Добър резултат!")
                else appendLine("\n📚 Научи митологията! Опитай пак!")
            })
            .setPositiveButton("Пак!") { _, _ -> showMythologySelection() }
            .setNegativeButton("Изход") { _, _ -> finish() }
            .setCancelable(false).show()
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
}
