package com.mythosrise.game.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*
import com.mythosrise.game.models.World

class WorldMapActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var tvHeroInfo: TextView
    private lateinit var tvDivinityTitle: TextView
    private lateinit var tvWorldInfo: TextView
    private lateinit var tvDailyBadge: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_world_map)
        engine = GameEngine(this)
        engine.loadGame()

        tvHeroInfo = findViewById(R.id.tvWorldMapHeroInfo)
        tvDivinityTitle = findViewById(R.id.tvWorldMapDivinityTitle)
        tvWorldInfo = findViewById(R.id.tvWorldMapCurrentWorld)
        tvDailyBadge = findViewById(R.id.tvDailyBadge)

        updateHeroInfo()
        setupWorldButtons()
        setupNavigationButtons()
        checkDailyBadge()
    }

    private fun updateHeroInfo() {
        val c = engine.character
        tvHeroInfo.text = "${c.heroClass.emoji} ${c.name} | Ниво ${c.level} | ❤️${c.health}/${c.getTotalMaxHealth()} | 💙${c.mana}/${c.maxMana}"
        tvDivinityTitle.text = "${c.divinityTitle.emoji} ${c.divinityTitle.title} | ✨${c.divinity} | 💰${c.gold}"
        tvWorldInfo.text = "🌍 ${c.currentWorld.displayName}"
    }

    private fun checkDailyBadge() {
        val today = DailyChallengeManager.getTodaysChallenges(engine.character)
        val unclaimed = today.count { it.completed && !it.claimed }
        tvDailyBadge.text = if (unclaimed > 0) "🔴 $unclaimed" else ""
        tvDailyBadge.visibility = if (unclaimed > 0) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun setupWorldButtons() {
        val worldContainer = findViewById<LinearLayout>(R.id.llWorldButtons)
        worldContainer.removeAllViews()
        val c = engine.character

        val worlds = listOf(
            Triple(World.MORTAL_REALM, 1, "#4A3A2A"),
            Triple(World.GREEK_OLYMPUS, 5, "#2A3A4A"),
            Triple(World.TARTARUS, 8, "#2A1A3A"),
            Triple(World.INDIAN_REALM, 9, "#3A2A1A"),
            Triple(World.NORSE_ASGARD, 11, "#1A2A3A"),
            Triple(World.EGYPTIAN_REALM, 13, "#3A2A00"),
            Triple(World.DRAGON_REALM, 16, "#3A1A00"),
            Triple(World.TITAN_REALM, 20, "#2A1A1A"),
            Triple(World.JAPANESE_REALM, 24, "#2A0A2A"),
            Triple(World.CHINESE_REALM, 28, "#0A2A2A"),
            Triple(World.MASS_BATTLE_ARENA, 25, "#1A2A0A"),
        )

        worlds.forEach { (world, reqLevel, bgColor) ->
            val isUnlocked = c.level >= reqLevel
            val isCurrent = c.currentWorld == world
            val btn = Button(this).apply {
                text = buildString {
                    append(world.emoji ?: "🌍")
                    append(" ")
                    append(world.displayName)
                    if (!isUnlocked) append(" [Ниво $reqLevel]")
                    if (isCurrent) append(" ←")
                }
                textSize = 13sp
                setTextColor(if (isCurrent) Color.parseColor("#FFD700") else Color.WHITE)
                isEnabled = isUnlocked
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (isUnlocked) Color.parseColor(bgColor) else Color.parseColor("#111111")
                )
                alpha = if (isUnlocked) 1f else 0.4f
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 50.dpToPx())
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
                setOnClickListener {
                    engine.character.currentWorld = world
                    engine.saveGame()
                    startActivity(Intent(this@WorldMapActivity, GameActivity::class.java).apply {
                        putExtra("world", world.name)
                    })
                }
            }
            worldContainer.addView(btn)
        }
    }

    private fun setupNavigationButtons() {
        // Row 1: Combat features
        setBtn(R.id.btnMassBattle) { startActivity(Intent(this, MassBattleActivity::class.java)) }
        setBtn(R.id.btnBossRush) { startActivity(Intent(this, BossRushActivity::class.java)) }

        // Row 2: Character
        setBtn(R.id.btnShop) { startActivity(Intent(this, ShopActivity::class.java)) }
        setBtn(R.id.btnSkillTree) { startActivity(Intent(this, SkillTreeActivity::class.java)) }
        setBtn(R.id.btnAchievements) { startActivity(Intent(this, AchievementActivity::class.java)) }
        setBtn(R.id.btnSettings) { startActivity(Intent(this, SettingsActivity::class.java)) }

        // Row 3: New features
        setBtn(R.id.btnQuests) { startActivity(Intent(this, QuestActivity::class.java)) }
        setBtn(R.id.btnCrafting) { startActivity(Intent(this, CraftingActivity::class.java)) }
        setBtn(R.id.btnLoreBook) { startActivity(Intent(this, LoreBookActivity::class.java)) }

        // Row 4: Endgame
        setBtn(R.id.btnPrestige) { startActivity(Intent(this, PrestigeActivity::class.java)) }
        setBtn(R.id.btnTransformation) { startActivity(Intent(this, TransformationActivity::class.java)) }
        setBtn(R.id.btnCompanions) { startActivity(Intent(this, CompanionActivity::class.java)) }

        // Row 5: Daily
        setBtn(R.id.btnDailyChallenge) { startActivity(Intent(this, DailyChallengeActivity::class.java)) }
    }

    private fun setBtn(id: Int, action: () -> Unit) {
        try { findViewById<Button>(id)?.setOnClickListener { action() } } catch (_: Exception) {}
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
    private val Int.sp: Float get() = this.toFloat()

    override fun onResume() {
        super.onResume()
        engine.loadGame()
        updateHeroInfo()
        checkDailyBadge()
    }
}
