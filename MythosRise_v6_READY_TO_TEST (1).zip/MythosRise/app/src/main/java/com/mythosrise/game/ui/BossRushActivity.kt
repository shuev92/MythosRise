package com.mythosrise.game.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.*
import kotlin.math.max
import kotlin.random.Random

class BossRushActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private val handler = Handler(Looper.getMainLooper())

    private val bossList = mutableListOf<Enemy>()
    private var currentBossIndex = 0
    private var currentBoss: Enemy? = null
    private var rushActive = false
    private var totalGold = 0
    private var totalDivinity = 0
    private var totalExp = 0L
    private var bossesDefeated = 0
    private var isAnimating = false
    private var playerBonusAttack = 0
    private var playerBonusDefense = 0

    // UI
    private lateinit var tvTitle: TextView
    private lateinit var tvBossCounter: TextView
    private lateinit var tvBossName: TextView
    private lateinit var tvBossEmoji: TextView
    private lateinit var tvBossHp: TextView
    private lateinit var pbBossHp: ProgressBar
    private lateinit var tvPlayerHp: TextView
    private lateinit var pbPlayerHp: ProgressBar
    private lateinit var tvPlayerMana: TextView
    private lateinit var tvLog: TextView
    private lateinit var svLog: ScrollView
    private lateinit var tvRewards: TextView
    private lateinit var btnAttack: Button
    private lateinit var btnAbility: Button
    private lateinit var btnPotion: Button
    private lateinit var tvDifficultyMult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_boss_rush)
        engine = GameEngine(this)
        engine.loadGame()
        bindViews()
        buildBossList()
        showModeSelection()
    }

    private fun bindViews() {
        tvTitle = findViewById(R.id.tvBossRushTitle)
        tvBossCounter = findViewById(R.id.tvBossRushCounter)
        tvBossName = findViewById(R.id.tvBossRushName)
        tvBossEmoji = findViewById(R.id.tvBossRushEmoji)
        tvBossHp = findViewById(R.id.tvBossRushHp)
        pbBossHp = findViewById(R.id.pbBossRushHp)
        tvPlayerHp = findViewById(R.id.tvBossRushPlayerHp)
        pbPlayerHp = findViewById(R.id.pbBossRushPlayerHp)
        tvPlayerMana = findViewById(R.id.tvBossRushPlayerMana)
        tvLog = findViewById(R.id.tvBossRushLog)
        svLog = findViewById(R.id.svBossRushLog)
        tvRewards = findViewById(R.id.tvBossRushRewards)
        btnAttack = findViewById(R.id.btnBossRushAttack)
        btnAbility = findViewById(R.id.btnBossRushAbility)
        btnPotion = findViewById(R.id.btnBossRushPotion)
        tvDifficultyMult = findViewById(R.id.tvBossRushMult)

        btnAttack.setOnClickListener { if (!isAnimating) doAttack() }
        btnAbility.setOnClickListener { if (!isAnimating) showAbilities() }
        btnPotion.setOnClickListener { showPotions() }
    }

    // ─────────────────────────────────────────────
    //  BOSS LIST
    // ─────────────────────────────────────────────

    private fun buildBossList() {
        val allBosses = GameDatabase.ALL_ENEMIES.filter { it.isBoss }.sortedBy { it.level }
        bossList.addAll(allBosses)
    }

    private fun showModeSelection() {
        AlertDialog.Builder(this)
            .setTitle("⚔️ BOSS RUSH")
            .setMessage("""
                Избери режим:
                
                🟢 НОРМАЛЕН — Всички босове по ред. Пълно лечение след всеки.
                
                🟡 ГЕРОИЧЕН — +50% HP на боссовете. 50% лечение след всеки.
                
                🔴 ЛЕГЕНДАРЕН — +100% HP, +50% ATK. Без лечение. 
                
                🌌 ВСЕБОГ — x3 всичко. Само за Всебогове.
                
                ${bossList.size} босса те чакат!
            """.trimIndent())
            .setCancelable(false)
            .setPositiveButton("🟢 Нормален") { _, _ -> startRush(1.0f, 1.0f, 1.0f) }
            .setNeutralButton("🟡 Героичен") { _, _ -> startRush(1.5f, 1.0f, 0.5f) }
            .setNegativeButton("🔴 Легендарен") { _, _ -> startRush(2.0f, 1.5f, 0.0f) }
            .setOnCancelListener { finish() }
            .create().also { dialog ->
                dialog.show()
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.GREEN)
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Color.YELLOW)
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.RED)
            }
    }

    private var hpMult = 1.0f
    private var atkMult = 1.0f
    private var healFrac = 1.0f

    private fun startRush(hp: Float, atk: Float, heal: Float) {
        hpMult = hp
        atkMult = atk
        healFrac = heal
        rushActive = true
        currentBossIndex = 0
        loadNextBoss()
    }

    // ─────────────────────────────────────────────
    //  BOSS LOGIC
    // ─────────────────────────────────────────────

    private fun loadNextBoss() {
        if (currentBossIndex >= bossList.size) {
            showVictory()
            return
        }
        val baseBoss = bossList[currentBossIndex]
        val difficultyScale = 1.0f + currentBossIndex * 0.15f
        currentBoss = baseBoss.copy(
            maxHealth = (baseBoss.maxHealth * hpMult * difficultyScale).toInt(),
            currentHealth = (baseBoss.maxHealth * hpMult * difficultyScale).toInt(),
            attack = (baseBoss.attack * atkMult * difficultyScale).toInt()
        )

        val mult = String.format("%.1f", difficultyScale)
        tvDifficultyMult.text = "💪 Множител: x$mult"
        tvTitle.text = "⚔️ BOSS RUSH — Бос ${currentBossIndex + 1}/${bossList.size}"
        tvBossCounter.text = "🏆 Победени: $bossesDefeated | ✨ +$totalDivinity"

        tvBossEmoji.text = currentBoss!!.emoji
        tvBossName.text = currentBoss!!.name
        addLog("═══ БОС ${currentBossIndex + 1}: ${currentBoss!!.name} ═══")
        addLog(currentBoss!!.loreText ?: "")

        updateUI()

        // Boss entrance shake effect
        if (currentBoss!!.isBoss) {
            handler.postDelayed({
                AlertDialog.Builder(this)
                    .setTitle("${currentBoss!!.emoji} ${currentBoss!!.name}")
                    .setMessage(currentBoss!!.loreText ?: currentBoss!!.description)
                    .setPositiveButton("БОРИ СЕ!") { _, _ -> }
                    .show()
            }, 300)
        }
    }

    private fun doAttack() {
        val boss = currentBoss ?: return
        isAnimating = true
        setButtons(false)

        val crit = Random.nextFloat() < 0.15f + engine.character.critChanceBonus
        val dmg = max(1, (engine.character.getTotalAttack() + playerBonusAttack - boss.defense / 2) * if (crit) 2 else 1)
        boss.currentHealth -= dmg

        val msg = if (crit) "💥 КРИТ! ${engine.character.name} удари за $dmg!" else "⚔️ ${engine.character.name} удари за $dmg"
        addLog(msg)

        if (boss.currentHealth <= 0) {
            onBossDefeated(boss)
            return
        }

        handler.postDelayed({ bossCounterAttack() }, 500)
    }

    private fun doAbility(ability: Ability) {
        val boss = currentBoss ?: return
        if (engine.character.mana < ability.manaCost) {
            Toast.makeText(this, "❌ Недостатъчно мана!", Toast.LENGTH_SHORT).show()
            return
        }
        isAnimating = true
        setButtons(false)
        engine.character.mana -= ability.manaCost

        val dmg = max(1, (engine.character.getTotalAttack() + playerBonusAttack * ability.damageMultiplier).toInt() - boss.defense / 2)
        boss.currentHealth -= dmg

        if (ability.healPercent > 0) {
            val heal = (engine.character.getTotalMaxHealth() * ability.healPercent).toInt()
            engine.character.health = minOf(engine.character.health + heal, engine.character.getTotalMaxHealth())
            addLog("💚 ${ability.emoji} ${ability.name}: +$heal живот!")
        } else {
            addLog("✨ ${ability.emoji} ${ability.name}: $dmg урон!")
        }

        if (boss.currentHealth <= 0) {
            onBossDefeated(boss)
            return
        }
        handler.postDelayed({ bossCounterAttack() }, 500)
    }

    private fun bossCounterAttack() {
        val boss = currentBoss ?: return
        val bossAbility = boss.abilities.randomOrNull()
        val dmg = if (bossAbility != null && Random.nextFloat() < bossAbility.useChance) {
            addLog("⚡ ${boss.name} използва ${bossAbility.name}!")
            max(1, (boss.attack * bossAbility.damageMultiplier).toInt() - engine.character.getTotalDefense() / 2)
        } else {
            max(1, boss.attack - engine.character.getTotalDefense() / 2)
        }

        engine.character.health -= dmg
        addLog("💥 ${boss.emoji} ${boss.name} удари за $dmg!")

        updateUI()

        if (engine.character.health <= 0) {
            engine.character.health = 0
            updateUI()
            handler.postDelayed({ showDefeat() }, 500)
        } else {
            isAnimating = false
            setButtons(true)
        }
    }

    private fun onBossDefeated(boss: Enemy) {
        bossesDefeated++
        val goldEarned = boss.goldReward * 3
        val divEarned = boss.divinityReward * 2
        val expEarned = boss.expReward * 2L
        totalGold += goldEarned
        totalDivinity += divEarned
        totalExp += expEarned

        engine.character.gold += goldEarned
        engine.character.divinity += divEarned
        engine.character.gainExperience(expEarned)
        engine.character.enemiesDefeated++
        engine.character.updateDivinityTitle()

        // Power absorption
        engine.character.absorbPower(boss)
        playerBonusAttack += boss.attack / 15
        playerBonusDefense += boss.defense / 15

        addLog("💀 ${boss.name} е победен! +$goldEarned💰 +$divEarned✨")
        addLog("⬆️ Поглъщаш силата! +${boss.attack / 15} ATK, +${boss.defense / 15} DEF")

        updateRewards()

        // Item drop (guaranteed from bosses in rush)
        val drop = boss.possibleDrops.randomOrNull()
        if (drop != null) {
            GameDatabase.ALL_ITEMS[drop]?.let {
                engine.character.inventory.add(it.copy())
                addLog("🎁 Намерен: ${it.emoji} ${it.name}!")
            }
        }

        engine.saveGame()
        currentBossIndex++

        handler.postDelayed({
            val healAmount = if (healFrac > 0f) {
                val h = (engine.character.getTotalMaxHealth() * healFrac).toInt()
                engine.character.health = minOf(engine.character.health + h, engine.character.getTotalMaxHealth())
                h
            } else 0
            val manaRestore = engine.character.maxMana / 2
            engine.character.mana = minOf(engine.character.mana + manaRestore, engine.character.maxMana)

            AlertDialog.Builder(this)
                .setTitle("✅ Бос ${bossesDefeated} победен!")
                .setMessage(buildString {
                    appendLine("💀 ${boss.name} e мъртъв!\n")
                    appendLine("💰 +$goldEarned злато")
                    appendLine("✨ +$divEarned дивинити")
                    appendLine("⭐ +$expEarned опит")
                    if (healAmount > 0) appendLine("💚 +$healAmount живот")
                    appendLine("⚔️ +${boss.attack / 15} ATK (поглъщане)")
                    appendLine("\n${engine.character.divinityTitle.title}")
                    if (currentBossIndex < bossList.size)
                        append("\nСледващ: ${bossList[currentBossIndex].emoji} ${bossList[currentBossIndex].name}")
                    else append("\nПОСЛЕДНИЯТ БОС Е ПОБЕДЕН!")
                })
                .setCancelable(false)
                .setPositiveButton(if (currentBossIndex < bossList.size) "СЛЕДВАЩ БОС ⚔️" else "🏆 ЗАВЪРШИ!") { _, _ ->
                    isAnimating = false
                    setButtons(true)
                    loadNextBoss()
                }
                .setNegativeButton("Оттегли се") { _, _ ->
                    isAnimating = false
                    showVictory()
                }
                .show()
        }, 800)
    }

    private fun showDefeat() {
        AlertDialog.Builder(this)
            .setTitle("💀 Паднал в Boss Rush")
            .setMessage(buildString {
                appendLine("Стигна до бос $bossesDefeated от ${bossList.size}!")
                appendLine("\n💰 Злато: +$totalGold")
                appendLine("✨ Дивинити: +$totalDivinity")
                appendLine("⭐ Опит: +$totalExp")
            })
            .setCancelable(false)
            .setPositiveButton("Опитай пак") { _, _ ->
                startActivity(Intent(this, BossRushActivity::class.java))
                finish()
            }
            .setNegativeButton("Изход") { _, _ ->
                startActivity(Intent(this, WorldMapActivity::class.java))
                finish()
            }
            .show()
    }

    private fun showVictory() {
        val allDefeated = bossesDefeated >= bossList.size
        val bonusDivinity = if (allDefeated) 5000 else 0
        if (allDefeated) {
            engine.character.divinity += bonusDivinity
            engine.character.updateDivinityTitle()
            engine.saveGame()
        }

        AlertDialog.Builder(this)
            .setTitle(if (allDefeated) "🏆 BOSS RUSH ЗАВЪРШЕН!" else "✅ Добро представяне!")
            .setMessage(buildString {
                if (allDefeated) appendLine("ВСИЧКИ ${bossList.size} БОСА ПОБЕДЕНИ!\n")
                appendLine("👹 Боса победени: $bossesDefeated/${bossList.size}")
                appendLine("💰 Злато: +$totalGold")
                appendLine("✨ Дивинити: +$totalDivinity")
                appendLine("⭐ Опит: +$totalExp")
                appendLine("⚔️ Поглъщане бонус: +$playerBonusAttack ATK")
                if (allDefeated) {
                    appendLine("\n🎁 БОНУС: +$bonusDivinity Дивинити!")
                    appendLine("${engine.character.divinityTitle.title}")
                }
            })
            .setCancelable(false)
            .setPositiveButton("🗺️ Карта") { _, _ ->
                startActivity(Intent(this, WorldMapActivity::class.java))
                finish()
            }
            .show()
    }

    private fun showAbilities() {
        val abilities = engine.character.abilities.filter { it.manaCost <= engine.character.mana }
        if (abilities.isEmpty()) {
            Toast.makeText(this, "Нямаш мана за умения!", Toast.LENGTH_SHORT).show()
            return
        }
        val items = abilities.map { "${it.emoji} ${it.name} — 💙${it.manaCost}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("✨ Умения")
            .setItems(items) { _, i -> doAbility(abilities[i]) }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun showPotions() {
        val potions = engine.character.inventory.filter { it.type == ItemType.POTION }
        if (potions.isEmpty()) { Toast.makeText(this, "Нямаш еликсири!", Toast.LENGTH_SHORT).show(); return }
        val items = potions.map { "${it.emoji} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("🧪 Еликсири")
            .setItems(items) { _, i ->
                val msg = engine.usePotion(potions[i])
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                updateUI()
            }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun updateUI() {
        val c = engine.character
        val boss = currentBoss
        tvPlayerHp.text = "❤️ ${c.health}/${c.getTotalMaxHealth()}"
        pbPlayerHp.max = c.getTotalMaxHealth()
        pbPlayerHp.progress = c.health
        tvPlayerMana.text = "💙 ${c.mana}/${c.maxMana}"
        if (boss != null) {
            tvBossHp.text = "💀 ${boss.currentHealth}/${boss.maxHealth}"
            pbBossHp.max = boss.maxHealth
            pbBossHp.progress = boss.currentHealth
            tvBossEmoji.text = boss.emoji
            tvBossName.text = boss.name
        }
        tvBossCounter.text = "🏆 Победени: $bossesDefeated | ATK bonus: +$playerBonusAttack"
        updateRewards()
    }

    private fun updateRewards() {
        tvRewards.text = "💰 +$totalGold  ✨ +$totalDivinity  ⭐ +$totalExp"
    }

    private fun addLog(text: String) {
        if (text.isBlank()) return
        val current = tvLog.text.toString()
        val lines = (current + "\n" + text).lines().takeLast(12)
        tvLog.text = lines.joinToString("\n")
        svLog.post { svLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setButtons(enabled: Boolean) {
        btnAttack.isEnabled = enabled
        btnAbility.isEnabled = enabled
        btnPotion.isEnabled = enabled
    }
}
