package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  BATTLE PASS TIER
// ─────────────────────────────────────────────

data class BattlePassTier(
    val tier: Int,
    val requiredExp: Int,
    val freeReward: BattlePassReward,
    val premiumReward: BattlePassReward
)

data class BattlePassReward(
    val name: String,
    val emoji: String,
    val type: String,           // gold, divinity, item, skin, title, cosmetic, exp
    val amount: Int = 0,
    val specialId: String = "",
    val description: String = ""
)

// ─────────────────────────────────────────────
//  BATTLE PASS SEASON
// ─────────────────────────────────────────────

data class BattlePassSeason(
    val id: String,
    val name: String,
    val theme: String,
    val emoji: String,
    val description: String,
    val mythology: String,
    val durationDays: Int,
    val tiers: List<BattlePassTier>,
    val finalRewardFree: BattlePassReward,
    val finalRewardPremium: BattlePassReward,
    val exclusiveTitle: String,
    val exclusiveSkin: String,
    var currentTier: Int = 0,
    var currentExp: Int = 0,
    var isPremium: Boolean = false
)

// ─────────────────────────────────────────────
//  BATTLE PASS MANAGER
// ─────────────────────────────────────────────

object BattlePassManager {

    val SEASON_1 = BattlePassSeason(
        id = "bp_s1_olympus",
        name = "Сезон 1: Олимпийска Слава",
        theme = "Greek Mythology",
        emoji = "⚡",
        description = "Докажи се пред олимпийските богове! 50 нива награди!",
        mythology = "Greek",
        durationDays = 90,
        exclusiveTitle = "⚡ Олимпийски Шампион",
        exclusiveSkin = "Злато-Синя Гръцка Броня",
        finalRewardFree = BattlePassReward("Злато Кесия", "💰", "gold", 10000),
        finalRewardPremium = BattlePassReward("Мълниеносната Коронa", "⚡", "cosmetic",
            specialId = "zeus_crown", description = "Корона от самия Зевс. Уникална."),
        tiers = buildBattlePassTiers()
    )

    val SEASON_2 = BattlePassSeason(
        id = "bp_s2_ragnarok",
        name = "Сезон 2: Рагнарок",
        theme = "Norse Mythology",
        emoji = "🌋",
        description = "Рагнарок идва! Сражавай се за оцеляване и слава!",
        mythology = "Norse",
        durationDays = 90,
        exclusiveTitle = "🌋 Оцелял при Рагнарок",
        exclusiveSkin = "Скандинавска Руна Броня",
        finalRewardFree = BattlePassReward("Злато Кесия", "💰", "gold", 15000),
        finalRewardPremium = BattlePassReward("Мьолнир Реплика", "🔨", "cosmetic",
            specialId = "thor_hammer_skin", description = "Кожа за оръжие: Мьолнир на Тор."),
        tiers = buildRagnarokTiers()
    )

    private fun buildBattlePassTiers(): List<BattlePassTier> = (1..50).map { tier ->
        BattlePassTier(
            tier = tier,
            requiredExp = tier * 500,
            freeReward = when {
                tier % 10 == 0 -> BattlePassReward("Злато Сандък", "💰", "gold", tier * 200)
                tier % 5 == 0 -> BattlePassReward("Дивинити Кристал", "✨", "divinity", tier * 10)
                tier % 3 == 0 -> BattlePassReward("Малко Злато", "💰", "gold", tier * 100)
                else -> BattlePassReward("Опит Руна", "⭐", "exp", tier * 150)
            },
            premiumReward = when {
                tier == 1 -> BattlePassReward("Олимпийски Аватар", "🏛️", "cosmetic", description = "Ексклузивна рамка за аватар")
                tier == 5 -> BattlePassReward("Емоция: Мълния", "⚡", "cosmetic", description = "Специална анимация при победа")
                tier == 10 -> BattlePassReward("Щит на Атина", "🛡️", "item", specialId = "athena_shield")
                tier == 15 -> BattlePassReward("Гръцки Трейл", "✨", "cosmetic", description = "Ефект зад персонажа")
                tier == 20 -> BattlePassReward("Мълния Оръжие Кожа", "⚡", "cosmetic", specialId = "lightning_skin")
                tier == 25 -> BattlePassReward("Персей Броня Кожа", "🏛️", "cosmetic", description = "Изглед на Персей")
                tier == 30 -> BattlePassReward("Голямо Злато", "💰", "gold", 5000)
                tier == 35 -> BattlePassReward("Титанова Дивинити", "✨", "divinity", 500)
                tier == 40 -> BattlePassReward("Олимпийски Спътник", "🦅", "companion", specialId = "olympian_eagle")
                tier == 45 -> BattlePassReward("Зевсов Гръм Ефект", "⚡", "cosmetic", description = "Мълнии при критичен удар")
                tier == 50 -> BattlePassReward("Мълниеносната Корона", "👑", "cosmetic", specialId = "zeus_crown")
                tier % 10 == 0 -> BattlePassReward("Гръцко Злато", "💰", "gold", tier * 500)
                tier % 5 == 0 -> BattlePassReward("Олимпийска Дивинити", "✨", "divinity", tier * 25)
                else -> BattlePassReward("Гръцка Руна", "🏛️", "exp", tier * 300)
            }
        )
    }

    private fun buildRagnarokTiers(): List<BattlePassTier> = (1..50).map { tier ->
        BattlePassTier(
            tier = tier,
            requiredExp = tier * 600,
            freeReward = when {
                tier % 10 == 0 -> BattlePassReward("Скандинавски Злато", "💰", "gold", tier * 250)
                tier % 5 == 0 -> BattlePassReward("Руна Кристал", "✨", "divinity", tier * 12)
                else -> BattlePassReward("Валхала Опит", "⭐", "exp", tier * 200)
            },
            premiumReward = when {
                tier == 10 -> BattlePassReward("Руни на Один", "🔮", "item", specialId = "odin_runes")
                tier == 20 -> BattlePassReward("Тор Чук Кожа", "🔨", "cosmetic", specialId = "mjolnir_skin")
                tier == 30 -> BattlePassReward("Фенрир Спътник", "🐺", "companion", specialId = "fenrir_pup")
                tier == 40 -> BattlePassReward("Валкирия Броня Кожа", "⚔️", "cosmetic", description = "Изглед на Валкирия")
                tier == 50 -> BattlePassReward("Мьолнир Реплика", "🔨", "cosmetic", specialId = "thor_hammer_skin")
                tier % 5 == 0 -> BattlePassReward("Скандинавска Дивинити", "✨", "divinity", tier * 20)
                else -> BattlePassReward("Рагнарок Руна", "🌋", "exp", tier * 250)
            }
        )
    }

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun getCurrentSeason(): BattlePassSeason = SEASON_2

    fun addExp(season: BattlePassSeason, exp: Int): List<BattlePassTier> {
        val unlockedTiers = mutableListOf<BattlePassTier>()
        season.currentExp += exp
        while (season.currentTier < season.tiers.size) {
            val nextTier = season.tiers[season.currentTier]
            if (season.currentExp >= nextTier.requiredExp) {
                season.currentExp -= nextTier.requiredExp
                season.currentTier++
                unlockedTiers.add(nextTier)
            } else break
        }
        return unlockedTiers
    }

    fun claimFreeReward(tier: BattlePassTier, character: Character): String {
        return applyReward(tier.freeReward, character)
    }

    fun claimPremiumReward(tier: BattlePassTier, character: Character, isPremium: Boolean): String {
        if (!isPremium) return "🔒 Нужен Premium Battle Pass!"
        return applyReward(tier.premiumReward, character)
    }

    private fun applyReward(reward: BattlePassReward, character: Character): String {
        return when (reward.type) {
            "gold" -> { character.gold += reward.amount; "💰 +${reward.amount} злато!" }
            "divinity" -> { character.divinity += reward.amount; character.updateDivinityTitle(); "✨ +${reward.amount} дивинити!" }
            "exp" -> { character.gainExperience(reward.amount.toLong()); "⭐ +${reward.amount} опит!" }
            "item" -> "🎁 Получи: ${reward.emoji} ${reward.name}!"
            "cosmetic" -> "🎨 Ексклузивна кожа: ${reward.name}!"
            "companion" -> "🐾 Ексклузивен спътник: ${reward.name}!"
            else -> "🏆 ${reward.name} взет!"
        }
    }

    fun getSeasonProgress(season: BattlePassSeason): String = buildString {
        appendLine("${season.emoji} ${season.name}")
        appendLine("Ниво: ${season.currentTier}/50")
        appendLine("EXP: ${season.currentExp}/${if (season.currentTier < 50) season.tiers.getOrNull(season.currentTier)?.requiredExp ?: 0 else 0}")
        appendLine("Premium: ${if (season.isPremium) "✅ Активен" else "🔒 Не"}")
        appendLine("Дни оставащи: ${season.durationDays}")
        appendLine()
        appendLine("🎯 Ексклузивни ти очакват:")
        appendLine("  ${season.exclusiveTitle}")
        appendLine("  ${season.exclusiveSkin}")
    }

    fun getBattlePassSources(): List<String> = listOf(
        "⚔️ Убиване на врагове: +10 BP EXP",
        "👑 Убиване на бос: +100 BP EXP",
        "📅 Дневни предизвикателства: +200 BP EXP",
        "📜 Завършен куест: +150 BP EXP",
        "🏟️ Арена вълна: +50 BP EXP",
        "👑 Boss Rush завършен: +500 BP EXP",
        "🌍 Ново посетен свят: +300 BP EXP",
        "🔨 Занаятен предмет: +75 BP EXP",
        "📖 Завършена история глава: +400 BP EXP",
        "🏰 Гилдиен куест: +250 BP EXP"
    )
}

// ─────────────────────────────────────────────
//  BATTLE PASS SEASON TRACKER
// ─────────────────────────────────────────────

object BattlePassTracker {
    val BONUS_SOURCES = mapOf(
        "kill_normal" to 10,
        "kill_boss" to 100,
        "kill_god" to 300,
        "daily_challenge" to 200,
        "daily_complete_all" to 500,
        "quest_complete" to 150,
        "arena_wave" to 50,
        "boss_rush_complete" to 500,
        "world_explore_new" to 300,
        "craft_item" to 75,
        "story_chapter" to 400,
        "guild_quest" to 250,
        "pvp_win" to 100,
        "pvp_loss" to 25,
        "prestige" to 2000,
        "achievement" to 150,
        "pet_evolve" to 300,
        "rune_socket" to 100
    )

    val PREMIUM_EXCLUSIVE_CONTENT = mapOf(
        "Season 1" to listOf(
            "⚡ Мълниеносна Аура (ATK ефект)",
            "🏛️ Олимпийски Аватар Рамка",
            "🦅 Орелът на Зевс (Спътник кожа)",
            "👑 Корона на Зевс (Хедгиър кожа)",
            "⚡ Мълния Трейл (Движение ефект)",
            "🌟 Олимпийски Шампион Титла",
            "🎭 Гръцка Броня Кожа",
            "💫 Злато-Синя Аура"
        ),
        "Season 2" to listOf(
            "🔨 Мьолнир Кожа (Оръжие)",
            "🌋 Рагнарок Аватар Рамка",
            "🐺 Фенрир Бебе (Спътник)",
            "⚔️ Валкирия Броня Кожа",
            "🌨️ Снежна Буря Аура",
            "🌋 Оцелял при Рагнарок Титла",
            "🔮 Руна Трейл (Движение ефект)",
            "🏔️ Асгардска Броня Кожа"
        )
    )

    val DAILY_BONUS_CALENDAR = (1..30).map { day ->
        day to when {
            day % 7 == 0 -> "💎 Седмичен бонус: +500 BP EXP + 1000 злато"
            day % 5 == 0 -> "⭐ Специален ден: +300 BP EXP + Дивинити"
            day % 3 == 0 -> "✨ Бонус ден: +150 BP EXP"
            else -> "📅 Ден $day: +50 BP EXP"
        }
    }.toMap()

    fun calculateDaysToMaxTier(currentTier: Int, currentExp: Int, dailyExpEstimate: Int): Int {
        val season = BattlePassManager.getCurrentSeason()
        var totalNeeded = 0
        for (tier in currentTier until BattlePassManager.SEASON_1.tiers.size) {
            totalNeeded += season.tiers.getOrNull(tier)?.requiredExp ?: 0
        }
        totalNeeded -= currentExp
        return if (dailyExpEstimate > 0) (totalNeeded / dailyExpEstimate) + 1 else 999
    }

    fun getExpProgressText(season: com.mythosrise.game.engine.BattlePassSeason): String {
        val tierExp = season.tiers.getOrNull(season.currentTier)?.requiredExp ?: 0
        val pct = if (tierExp > 0) season.currentExp * 100 / tierExp else 100
        return "Ниво ${season.currentTier}/50 | $pct% до следващо"
    }

    fun getPremiumValueAnalysis(): String = buildString {
        appendLine("📊 PREMIUM СТОЙНОСТЕН АНАЛИЗ:")
        appendLine()
        appendLine("Цена: 1000 Дивинити")
        appendLine("Приблизителна стойност: 10000+ Дивинити")
        appendLine()
        appendLine("Какво получаваш:")
        appendLine("  • 50 Premium ексклузивни нива")
        appendLine("  • Минимум 5 козметики")
        appendLine("  • 1-2 Ексклузивни спътника")
        appendLine("  • Сезонна титла")
        appendLine("  • Сезонна броня кожа")
        appendLine("  • Злато: ~30-50K")
        appendLine("  • Дивинити: ~5-10K")
        appendLine()
        appendLine("Никога повече не се появяват!")
        appendLine("Само за тези 90 дни на сезона.")
    }
}

// ─────────────────────────────────────────────
//  BATTLE PASS FINAL STATS & WRAP-UP
// ─────────────────────────────────────────────

object BattlePassWrapUp {
    val SEASON_SUMMARY_MESSAGES = mapOf(
        0..9 to "🌱 Прохождане — следващия сезон е по-добър!",
        10..24 to "⭐ Добро начало — около 20% завършен",
        25..39 to "🌟 Добър прогрес — половината е пред теб!",
        40..49 to "💥 Отличен! Само малко до максимума!",
        50..50 to "🌌 МАКСИМУМ! Battle Pass завършен! ВСЕБОГ!"
    )

    fun getSeasonEndMessage(tier: Int): String {
        return SEASON_SUMMARY_MESSAGES.entries.firstOrNull { tier in it.key }?.value
            ?: "Сезонът приключи."
    }

    val PREMIUM_TESTIMONIALS = listOf(
        "\"Premium Battle Pass беше ОП. Хаос Осколок Кожата е уникална!\" — DragonSlayer_BG",
        "\"50 нива. 100 награди. 1000 Дивинити. Честна сделка.\" — ZeusKiller99",
        "\"Валкирия Броня Кожата е нещо, което не можеш да вземеш другаде!\" — NorseWarrior",
        "\"Battle Pass + Гилдия Бафове = x5 EXP. Математиката работи.\" — OdinEye"
    )

    fun getRandomTestimonial() = PREMIUM_TESTIMONIALS.random()

    val NEXT_SEASON_PREVIEW = "Сезон 3: Египетска Мъдрост — DOT ефекти, Фараон Козметики, Анубис Спътник!"
}
