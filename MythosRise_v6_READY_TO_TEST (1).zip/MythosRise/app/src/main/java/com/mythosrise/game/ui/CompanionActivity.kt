package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.CompanionDatabase
import com.mythosrise.game.engine.GameEngine

class CompanionActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llCompanions: LinearLayout
    private lateinit var tvHeader: TextView
    private var showOwned = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_companions)
        engine = GameEngine(this)
        engine.loadGame()
        llCompanions = findViewById(R.id.llCompanionList)
        tvHeader = findViewById(R.id.tvCompanionHeader)
        setupToggle()
        renderCompanions()
    }

    private fun setupToggle() {
        val ll = findViewById<LinearLayout>(R.id.llCompanionTabs)
        listOf("Всички" to false, "Мои" to true).forEach { (label, owned) ->
            Button(this).apply {
                text = label; textSize = 13f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (owned == showOwned) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(4, 0, 4, 0); layoutParams = lp
                setOnClickListener { showOwned = owned; setupToggle(); renderCompanions() }
            }.also { ll.addView(it) }
        }
    }

    private fun renderCompanions() {
        llCompanions.removeAllViews()
        val c = engine.character
        val owned = CompanionDatabase.getOwned()
        val active = CompanionDatabase.getActive()
        tvHeader.text = "🐾 ПРИДРУЖИТЕЛИ (${owned.size}/${CompanionDatabase.ALL_COMPANIONS.size} придобити)"

        active?.let {
            val banner = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.parseColor("#0A2A0A"))
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, 12); layoutParams = lp
            }
            TextView(this).apply {
                text = "${it.emoji} Активен: ${it.name}"
                setTextColor(Color.parseColor("#00FF88")); textSize = 14f; isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }.also { banner.addView(it) }
            TextView(this).apply { text = "⚔️+${it.attackBonus} 🛡️+${it.defenseBonus}"; setTextColor(Color.LTGRAY); textSize = 12f }.also { banner.addView(it) }
            llCompanions.addView(banner)
        }

        val list = if (showOwned) CompanionDatabase.ALL_COMPANIONS.filter { it.isOwned }
                   else CompanionDatabase.ALL_COMPANIONS

        list.forEach { comp ->
            val canBuy = !comp.isOwned && c.gold >= comp.goldCost &&
                         c.divinity >= comp.requiredDivinity && c.level >= comp.requiredLevel
            val typeColor = when (comp.type) {
                com.mythosrise.game.engine.CompanionType.MOUNT -> "#8B4513"
                com.mythosrise.game.engine.CompanionType.BEAST -> "#228B22"
                com.mythosrise.game.engine.CompanionType.SPIRIT -> "#4B0082"
                com.mythosrise.game.engine.CompanionType.DIVINE -> "#FFD700"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(when {
                    comp.isActive -> Color.parseColor("#0A2A0A")
                    comp.isOwned -> Color.parseColor("#0A1A0A")
                    else -> Color.parseColor("#080808")
                })
                alpha = if (!comp.isOwned && !canBuy) 0.45f else 1.0f
                setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 5, 0, 5); layoutParams = lp
            }

            val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply { text = comp.emoji; textSize = 30f; setPadding(0, 0, 10, 0) }.also { row1.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = comp.name
                setTextColor(Color.WHITE); textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "[${comp.type.name}] [${comp.mythology}]"
                setTextColor(Color.parseColor(typeColor)); textSize = 11f
            }.also { info.addView(it) }
            val statsText = buildString {
                if (comp.attackBonus != 0) append("⚔️+${comp.attackBonus} ")
                if (comp.defenseBonus != 0) append("🛡️+${comp.defenseBonus} ")
                if (comp.healthBonus != 0) append("❤️+${comp.healthBonus} ")
                if (comp.divinityGainBonus != 0f) append("✨+${(comp.divinityGainBonus*100).toInt()}% ")
            }
            if (statsText.isNotBlank()) {
                TextView(this).apply { text = statsText; setTextColor(Color.parseColor("#88FF88")); textSize = 11f }.also { info.addView(it) }
            }
            TextView(this).apply {
                text = "⚡ ${comp.specialAbilityDesc}"
                setTextColor(Color.parseColor("#FFAA44")); textSize = 11f
            }.also { info.addView(it) }
            row1.addView(info)
            if (comp.isActive) {
                TextView(this).apply { text = "✅"; textSize = 24f }.also { row1.addView(it) }
            }
            card.addView(row1)

            // Lore
            if (comp.lore.isNotBlank()) {
                TextView(this).apply {
                    text = "💬 ${comp.lore}"; setTextColor(Color.DKGRAY); textSize = 11f
                    setPadding(0, 4, 0, 4)
                }.also { card.addView(it) }
            }

            // Action buttons
            val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            when {
                comp.isActive -> {
                    Button(this).apply {
                        text = "✅ Активен — Премахни"
                        setTextColor(Color.WHITE)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#006600"))
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                        setOnClickListener {
                            comp.isActive = false
                            CompanionDatabase.removeCompanionBonuses(comp, engine.character)
                            engine.saveGame(); renderCompanions()
                            Toast.makeText(this@CompanionActivity, "${comp.emoji} Премахнат", Toast.LENGTH_SHORT).show()
                        }
                    }.also { btnRow.addView(it) }
                }
                comp.isOwned -> {
                    Button(this).apply {
                        text = "🐾 Активирай"
                        setTextColor(Color.WHITE)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C5A2C"))
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                        setOnClickListener {
                            CompanionDatabase.getActive()?.let { old ->
                                old.isActive = false
                                CompanionDatabase.removeCompanionBonuses(old, engine.character)
                            }
                            comp.isActive = true
                            CompanionDatabase.applyCompanionBonuses(comp, engine.character)
                            engine.saveGame(); renderCompanions()
                            Toast.makeText(this@CompanionActivity, "${comp.emoji} ${comp.name} активиран!", Toast.LENGTH_SHORT).show()
                        }
                    }.also { btnRow.addView(it) }
                }
                else -> {
                    val priceText = buildString {
                        if (comp.goldCost > 0) append("💰${comp.goldCost}")
                        if (comp.requiredDivinity > 0) append(" ✨${comp.requiredDivinity}")
                        if (comp.requiredLevel > 1) append(" ⭐Ниво ${comp.requiredLevel}")
                    }
                    Button(this).apply {
                        text = if (canBuy) "🐾 Придобий ($priceText)" else "🔒 $priceText"
                        setTextColor(Color.WHITE); isEnabled = canBuy
                        backgroundTintList = android.content.res.ColorStateList.valueOf(
                            if (canBuy) Color.parseColor("#4A2A00") else Color.parseColor("#333333")
                        )
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                        setOnClickListener {
                            engine.character.gold -= comp.goldCost
                            engine.character.divinity -= comp.requiredDivinity.coerceAtMost(0)
                            comp.isOwned = true; engine.saveGame(); renderCompanions()
                            AlertDialog.Builder(this@CompanionActivity)
                                .setTitle("🎉 Придружител придобит!")
                                .setMessage("${comp.emoji} ${comp.name} сега е твой!\n\n${comp.lore}")
                                .setPositiveButton("Активирай веднага!") { _, _ ->
                                    comp.isActive = true
                                    CompanionDatabase.applyCompanionBonuses(comp, engine.character)
                                    engine.saveGame(); renderCompanions()
                                }
                                .setNegativeButton("По-късно", null).show()
                        }
                    }.also { btnRow.addView(it) }
                }
            }
            card.addView(btnRow)
            llCompanions.addView(card)
        }
    }
}
