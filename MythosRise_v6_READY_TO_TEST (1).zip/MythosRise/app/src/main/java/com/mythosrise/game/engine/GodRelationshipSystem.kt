package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  GOD RELATIONSHIP SYSTEM
// ─────────────────────────────────────────────

enum class RelationshipLevel(val displayName: String, val emoji: String, val bonusPercent: Int) {
    ENEMY("Враг", "💀", -10),
    HOSTILE("Враждебен", "😠", -5),
    NEUTRAL("Неутрален", "😐", 0),
    FRIENDLY("Приятелски", "🤝", 10),
    ALLY("Съюзник", "🛡️", 20),
    DEVOTED("Посветен", "💫", 35),
    CHOSEN("Избраник", "⭐", 50)
}

data class GodRelationship(
    val godId: String,
    val godName: String,
    val godEmoji: String,
    val mythology: String,
    var relationshipPoints: Int = 0,
    var currentLevel: RelationshipLevel = RelationshipLevel.NEUTRAL,
    var giftsReceived: Int = 0,
    var timesDefeated: Int = 0,
    val blessings: List<GodBlessing> = emptyList(),
    val lore: String = ""
)

data class GodBlessing(
    val name: String,
    val emoji: String,
    val description: String,
    val requiredLevel: RelationshipLevel,
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val divinityBonus: Float = 0f,
    val goldBonus: Float = 0f,
    val specialEffect: String = ""
)

object GodRelationshipSystem {

    val ALL_GODS = listOf(
        GodRelationship(
            godId = "zeus", godName = "Зевс", godEmoji = "⚡", mythology = "Greek",
            blessings = listOf(
                GodBlessing("Мълниеносна Искра", "⚡", "+50 ATK", RelationshipLevel.FRIENDLY, attackBonus = 50),
                GodBlessing("Щитът на Олимп", "🛡️", "+100 DEF", RelationshipLevel.ALLY, defenseBonus = 100),
                GodBlessing("Царски Благослов", "👑", "+25% Дивинити", RelationshipLevel.DEVOTED, divinityBonus = 0.25f),
                GodBlessing("Олимпийски Покровител", "🌟", "+200 ATK, +20% всичко", RelationshipLevel.CHOSEN,
                    attackBonus = 200, divinityBonus = 0.20f, goldBonus = 0.20f,
                    specialEffect = "Мълния при всяка 5-та атака")
            ),
            lore = "Победи Зевс, но го пощади — и той ще те уважи. Поглъщането на силата му не означава унищожение."
        ),
        GodRelationship(
            godId = "odin", godName = "Един", godEmoji = "🦅", mythology = "Norse",
            blessings = listOf(
                GodBlessing("Гарванско Oko", "👁️", "+15% точност", RelationshipLevel.FRIENDLY,
                    specialEffect = "Никога не пропускаш"),
                GodBlessing("Рунна Мъдрост", "🔮", "+15% Дивинити", RelationshipLevel.ALLY, divinityBonus = 0.15f),
                GodBlessing("Валхала Духове", "⚔️", "+25% ATK", RelationshipLevel.DEVOTED, attackBonus = 150),
                GodBlessing("Всебащин Благослов", "🦅", "+50% всичко + Гарвани", RelationshipLevel.CHOSEN,
                    attackBonus = 300, defenseBonus = 200, divinityBonus = 0.50f,
                    specialEffect = "Хугин и Мунин разузнават враговете")
            ),
            lore = "Един уважава тези, търсещи мъдрост. Питай го за Рагнарок — и ще научиш повече от всяка книга."
        ),
        GodRelationship(
            godId = "ra", godName = "Ра", godEmoji = "☀️", mythology = "Egyptian",
            blessings = listOf(
                GodBlessing("Слънчева Топлина", "☀️", "+40 ATK огнен", RelationshipLevel.FRIENDLY,
                    specialEffect = "+40 огнен урон"),
                GodBlessing("Окото на Ра", "👁️", "+20% злато", RelationshipLevel.ALLY, goldBonus = 0.20f),
                GodBlessing("Слънчев Ореол", "✨", "+25 DEF + светлина", RelationshipLevel.DEVOTED,
                    defenseBonus = 200, specialEffect = "Имунитет към тъмнина атаки"),
                GodBlessing("Слънчев Избраник", "🌅", "+200 ATK, +100 DEF, +30% всичко", RelationshipLevel.CHOSEN,
                    attackBonus = 200, defenseBonus = 100, goldBonus = 0.30f,
                    specialEffect = "Изгаряш всички врагове при влизане в битка")
            ),
            lore = "Ра е безкраен цикъл. Уважи цикъла — и слънцето ще те пази."
        ),
        GodRelationship(
            godId = "shiva", godName = "Шива", godEmoji = "💫", mythology = "Indian",
            blessings = listOf(
                GodBlessing("Тандава Импулс", "💫", "+60 ATK", RelationshipLevel.FRIENDLY, attackBonus = 60),
                GodBlessing("Трето Oko", "🔮", "+25% крит шанс", RelationshipLevel.ALLY,
                    specialEffect = "+25% крит"),
                GodBlessing("Разрушително Благо", "🌋", "+35% ATK", RelationshipLevel.DEVOTED, attackBonus = 250),
                GodBlessing("Космически Танц", "🌌", "AOE на всички атаки", RelationshipLevel.CHOSEN,
                    attackBonus = 500, specialEffect = "Всяка атака удря всички врагове")
            ),
            lore = "Шива разрушава за да твори. Ако го уважаваш, разрушението ти ще е по-мощно."
        ),
        GodRelationship(
            godId = "amaterasu", godName = "Аматерасу", godEmoji = "🌅", mythology = "Japanese",
            blessings = listOf(
                GodBlessing("Слънчева Стрела", "🌅", "+45 ATK светлина", RelationshipLevel.FRIENDLY,
                    specialEffect = "+45 светлинен урон"),
                GodBlessing("Свещено Огледало", "🪞", "+20% DEF", RelationshipLevel.ALLY, defenseBonus = 150),
                GodBlessing("Осветляваща Аура", "✨", "+20% Дивинити", RelationshipLevel.DEVOTED, divinityBonus = 0.20f),
                GodBlessing("Богиня Избраник", "🌸", "+300 ATK, +200 DEF, имунитет", RelationshipLevel.CHOSEN,
                    attackBonus = 300, defenseBonus = 200,
                    specialEffect = "Имунитет към всички тъмнина и сянка атаки")
            ),
            lore = "Аматерасу е самото слънце. Уважи я и светлината ти ще бъде твоята броня."
        ),
        GodRelationship(
            godId = "anubis", godName = "Анубис", godEmoji = "🐺", mythology = "Egyptian",
            blessings = listOf(
                GodBlessing("Съдбата Забавена", "⚖️", "+20% HP", RelationshipLevel.FRIENDLY,
                    specialEffect = "+20% максимален живот"),
                GodBlessing("Пазач на Душата", "🐺", "+25% DEF", RelationshipLevel.ALLY, defenseBonus = 180),
                GodBlessing("Подземна Мощ", "💀", "+30% ATK срещу нежити", RelationshipLevel.DEVOTED,
                    specialEffect = "+30% урон срещу нежити"),
                GodBlessing("Съдник Благослов", "⚖️", "Враговете губят HP всеки ход", RelationshipLevel.CHOSEN,
                    attackBonus = 200, defenseBonus = 150,
                    specialEffect = "Всеки враг губи 5% HP на ход")
            ),
            lore = "Анубис е справедлив. Покажи честност и той ще те защити дори от смъртта."
        ),
        GodRelationship(
            godId = "thor", godName = "Тор", godEmoji = "🔨", mythology = "Norse",
            blessings = listOf(
                GodBlessing("Мьолнир Сила", "🔨", "+80 ATK физически", RelationshipLevel.FRIENDLY, attackBonus = 80),
                GodBlessing("Гръм Защита", "⚡", "+30% DEF", RelationshipLevel.ALLY, defenseBonus = 200),
                GodBlessing("Берсерк Дух", "😤", "+40% ATK в ярост", RelationshipLevel.DEVOTED,
                    specialEffect = "+40% ATK при под 50% HP"),
                GodBlessing("Асит Братство", "🏔️", "+400 ATK, имунитет мълния", RelationshipLevel.CHOSEN,
                    attackBonus = 400, specialEffect = "Имунитет към мълния + Мьолнир се връща")
            ),
            lore = "Тор цени смелостта и честната битка. Победи го честно — и ще те смята за брат."
        )
    )

    fun addRelationshipPoints(godId: String, points: Int) {
        val god = ALL_GODS.find { it.godId == godId } ?: return
        god.relationshipPoints += points
        god.currentLevel = when {
            god.relationshipPoints >= 1000 -> RelationshipLevel.CHOSEN
            god.relationshipPoints >= 600 -> RelationshipLevel.DEVOTED
            god.relationshipPoints >= 350 -> RelationshipLevel.ALLY
            god.relationshipPoints >= 150 -> RelationshipLevel.FRIENDLY
            god.relationshipPoints >= 0 -> RelationshipLevel.NEUTRAL
            god.relationshipPoints >= -100 -> RelationshipLevel.HOSTILE
            else -> RelationshipLevel.ENEMY
        }
    }

    fun getAvailableBlessings(godId: String): List<GodBlessing> {
        val god = ALL_GODS.find { it.godId == godId } ?: return emptyList()
        return god.blessings.filter { it.requiredLevel.ordinal <= god.currentLevel.ordinal }
    }

    fun onGodDefeated(godId: String) {
        addRelationshipPoints(godId, 50)
        ALL_GODS.find { it.godId == godId }?.timesDefeated = (ALL_GODS.find { it.godId == godId }?.timesDefeated ?: 0) + 1
    }

    fun onGodSpared(godId: String) {
        addRelationshipPoints(godId, 150)
    }

    fun onGodAbsorbed(godId: String) {
        addRelationshipPoints(godId, 75)
    }

    fun applyGodBlessings(character: Character) {
        ALL_GODS.forEach { god ->
            getAvailableBlessings(god.godId).forEach { blessing ->
                character.attack += blessing.attackBonus
                character.defense += blessing.defenseBonus
                character.divinity += (character.divinity * blessing.divinityBonus).toInt()
            }
        }
    }

    fun getRelationshipSummary(): String = buildString {
        appendLine("═══ ОТНОШЕНИЯ С БОГОВЕТЕ ═══")
        ALL_GODS.forEach { god ->
            appendLine("${god.godEmoji} ${god.godName} [${god.mythology}]")
            appendLine("  ${god.currentLevel.emoji} ${god.currentLevel.displayName} (${god.relationshipPoints} точки)")
            appendLine("  Победен: ${god.timesDefeated}x")
            val blessings = getAvailableBlessings(god.godId)
            if (blessings.isNotEmpty()) {
                appendLine("  Благословии: ${blessings.joinToString(", ") { it.name }}")
            }
        }
    }

    fun getGodTips(): List<String> = listOf(
        "💡 Пощади Зевс след битка → +150 Отношение с него!",
        "💡 Използвай Поглъщане → +75 Отношение!",
        "💡 CHOSEN ниво → получаваш ексклузивно благословие!",
        "💡 Зевс CHOSEN: Мълния при всяка 5-та атака!",
        "💡 Един CHOSEN: Гарвани разузнават врагове!",
        "💡 Шива CHOSEN: AOE на ВСИЧКИ атаки!",
        "💡 Постигни CHOSEN с всички богове за SECRET постижение!"
    )
}

// ─────────────────────────────────────────────
//  GOD DIALOGUE & INTERACTION SYSTEM
// ─────────────────────────────────────────────

object GodInteractionSystem {

    val GOD_DAILY_BLESSINGS = mapOf(
        "zeus" to mapOf(
            RelationshipLevel.FRIENDLY to "⚡ Зевс изпраща малка мълния. +10% ATK за деня.",
            RelationshipLevel.ALLY to "⚡ Олимпийски Вятър. +20% ATK и +5% Дивинити за деня.",
            RelationshipLevel.DEVOTED to "⚡ Зевсов Гръм. +35% ATK, +15% Дивинити, Мълния на 5-та атака.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА ЗЕВС. +50% всичко. Мълния при всяка атака. 1x/ден."
        ),
        "odin" to mapOf(
            RelationshipLevel.FRIENDLY to "🦅 Един изпраща гарван. Виждаш слабостите на следващия враг.",
            RelationshipLevel.ALLY to "🔮 Руни на Один. +15% Дивинити и +200 HP за деня.",
            RelationshipLevel.DEVOTED to "🦅 Валхала Покровителство. +30% ATK, никога не пропускаш.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА ЕДИН. Гарваните разузнават ВСИЧКИ врагове. +50% Дивинити."
        ),
        "ra" to mapOf(
            RelationshipLevel.FRIENDLY to "☀️ Слънчев Лъч. +10% злато от следващите 10 убийства.",
            RelationshipLevel.ALLY to "☀️ Слънчев Ореол. +20% злато, -20% получен огнен урон.",
            RelationshipLevel.DEVOTED to "☀️ Ра Покровителство. Изгаряща аура — врагове губят HP при приближаване.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА РА. Слънцето те следва. +50% злато. Имунитет огън."
        ),
        "thor" to mapOf(
            RelationshipLevel.FRIENDLY to "🔨 Тор изпраща малък Мьолнир. +80 ATK за следващата битка.",
            RelationshipLevel.ALLY to "⚡ Мьолнир Сила. +150 ATK, мълния при всяка 3-та атака.",
            RelationshipLevel.DEVOTED to "🔨 Берсерк Братство. При под 50% HP — ATK x2 автоматично.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА ТОР. Мьолнир се връща след всяко хвърляне. AOE."
        ),
        "shiva" to mapOf(
            RelationshipLevel.FRIENDLY to "💫 Тандава Импулс. +60 ATK за следващата битка.",
            RelationshipLevel.ALLY to "🔮 Третото Oko. Виждаш слабостите на ВСИЧКИ врагове в световете.",
            RelationshipLevel.DEVOTED to "💫 Шива Благослов. +25% крит, +35% ATK, Разрушителен Аура.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА ШИВА. Тандава Нритям! AOE на ВСИЧКИ атаки!"
        ),
        "amaterasu" to mapOf(
            RelationshipLevel.FRIENDLY to "🌅 Слънчева Стрела. +45 светлинен урон за деня.",
            RelationshipLevel.ALLY to "🌸 Аматерасу Защита. Имунитет към 1 тъмнина атака.",
            RelationshipLevel.DEVOTED to "🌅 Свещено Огледало. +30% DEF, блокираш Сянка атаки.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА АМАТЕРАСУ. Светлинна Аура. Имунитет Сянка/Тъмнина."
        ),
        "anubis" to mapOf(
            RelationshipLevel.FRIENDLY to "⚖️ Анубис Защита. +200 HP за деня.",
            RelationshipLevel.ALLY to "🐺 Подземна Сила. Врагове с проклятие получават -20% ATK.",
            RelationshipLevel.DEVOTED to "⚖️ Съдебен Справедливост. Смъртоносни удари имат 30% шанс да пропуснат.",
            RelationshipLevel.CHOSEN to "🌟 ИЗБРАНИК НА АНУБИС. Всеки враг губи 5% HP/ход. Ти — безсмъртен 30с."
        )
    )

    val GOD_GIFT_REACTIONS = mapOf(
        "zeus" to mapOf(
            "gold" to "Злато? Интересен жест за смъртен. Приемам.",
            "divinity" to "Дивинити?! Ти даваш сила на боговете? Необичайно.",
            "item" to "Полезен предмет. Кован от смъртен. Малко грубо но... приемам."
        ),
        "odin" to mapOf(
            "gold" to "Злато. Материален дар. Мъдростта цени нематериалното. Но... приемам.",
            "divinity" to "Дивинити. Ти разбираш силата. Гарваните одобряват.",
            "item" to "Древен предмет. Историята в него е интересна. Разказвай."
        ),
        "thor" to mapOf(
            "gold" to "ЗЛАТО! Харесвам те! Ще пием след битката!",
            "divinity" to "ДИВИНИТИ! Хей, дори аз не давам дивинити на хора!",
            "item" to "ХУБАВ ПРЕДМЕТ! Ковано добре! Хефест ли е? Питам го!"
        )
    )

    val RELATIONSHIP_MILESTONES = mapOf(
        150 to "🤝 Приятелство установено! Боговете те знаят.",
        350 to "🛡️ Съюз! Богът ти предлага активна помощ в битки.",
        600 to "💫 Посветен! Благословията стана постоянна.",
        1000 to "🌟 ИЗБРАНИК! Максималното ниво. Ексклузивни бонуси само за теб."
    )

    fun getDailyBlessing(godId: String, level: RelationshipLevel): String? {
        return GOD_DAILY_BLESSINGS[godId]?.get(level)
    }

    fun getGiftReaction(godId: String, giftType: String): String {
        return GOD_GIFT_REACTIONS[godId]?.get(giftType) ?: "Богът приема мълчаливо."
    }

    fun getMilestoneMessage(points: Int): String? {
        return RELATIONSHIP_MILESTONES.entries
            .filter { it.key <= points }
            .maxByOrNull { it.key }?.value
    }

    val CHOSEN_GOD_LEADERBOARD_TITLES = mapOf(
        "zeus" to "⚡ Олимпийски Избраник",
        "odin" to "🦅 Всебащин Избраник",
        "ra" to "☀️ Слънчев Избраник",
        "thor" to "🔨 Мьолниров Избраник",
        "shiva" to "💫 Тандава Избраник",
        "amaterasu" to "🌅 Слънчева Богиня Избраник",
        "anubis" to "⚖️ Съдебен Избраник"
    )

    val GOD_STORY_CONNECTIONS = mapOf(
        "zeus" to "Атина ти помогна да стигнеш до него. Хермес те пусна вътре. Зевс се изненада.",
        "odin" to "Хеймдал видя дивинитито ти. Тор те тества. Один наблюдаваше.",
        "ra" to "Анубис претегли душата ти. Ра слезе от Ладията. Срещата беше уредена.",
        "thor" to "Един нареди теста. Тор го прие с радост. Малко прекалено с радост.",
        "shiva" to "Три очи те видяха. Третото видя истината. Тандавата спря за момент.",
        "amaterasu" to "Сусаноо те срещна. Аматерасу излезе от пещерата. Заради теб. Малко.",
        "anubis" to "Душата ти беше претеглена. Лека. Анубис е изненадан. Рядко се случва."
    )

    fun getGodStoryConnection(godId: String): String =
        GOD_STORY_CONNECTIONS[godId] ?: "История неизвестна."

    fun getChosenTitle(godId: String): String =
        CHOSEN_GOD_LEADERBOARD_TITLES[godId] ?: "Избраник на Бога"
}
