package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.LoreBook

class LoreBookActivity : AppCompatActivity() {

    private lateinit var llLore: LinearLayout
    private var selectedMythology = "Всички"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lore_book)
        llLore = findViewById(R.id.llLoreList)
        setupMythologyButtons()
        renderLore()
    }

    private fun setupMythologyButtons() {
        val mythologies = listOf("Всички") + LoreBook.mythologies
        val hsv = findViewById<HorizontalScrollView>(R.id.hsvLoreMythologies)
        val ll = hsv.getChildAt(0) as LinearLayout
        ll.removeAllViews()
        mythologies.forEach { m ->
            val btn = Button(this).apply {
                text = mythologyEmoji(m) + " " + m; textSize = 12f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (m == selectedMythology) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(4, 0, 4, 0)
                layoutParams = lp
                setOnClickListener { selectedMythology = m; setupMythologyButtons(); renderLore() }
            }
            ll.addView(btn)
        }
    }

    private fun renderLore() {
        llLore.removeAllViews()
        val entries = if (selectedMythology == "Всички") LoreBook.ALL_ENTRIES
        else LoreBook.getByMythology(selectedMythology)

        entries.forEach { entry ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.parseColor("#0F0A1F"))
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 4, 0, 4)
                layoutParams = lp
                isClickable = true
                isFocusable = true
            }

            val emojiTv = TextView(this).apply {
                text = entry.emoji; textSize = 30f; setPadding(0, 0, 12, 0)
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val mythColor = when (entry.mythology) {
                "Greek" -> "#4488FF"
                "Egyptian" -> "#FFAA00"
                "Norse" -> "#88CCFF"
                "Japanese" -> "#FF6688"
                "Chinese" -> "#FF4444"
                "Dragon", "Babylonian" -> "#FF6600"
                "Universal" -> "#9B59B6"
                "Game" -> "#FFD700"
                else -> "#AAAAAA"
            }
            TextView(this).apply {
                text = entry.title
                setTextColor(Color.WHITE); textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "${entry.mythology} | ${entry.category}"
                setTextColor(Color.parseColor(mythColor)); textSize = 11f
            }.also { info.addView(it) }
            TextView(this).apply {
                text = entry.shortDesc
                setTextColor(Color.LTGRAY); textSize = 12f
            }.also { info.addView(it) }

            card.addView(emojiTv)
            card.addView(info)
            card.addView(TextView(this).apply { text = "›"; textSize = 22f; setTextColor(Color.GRAY) })

            card.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("${entry.emoji} ${entry.title}")
                    .setMessage(entry.fullText)
                    .setPositiveButton("Затвори", null)
                    .show()
            }
            llLore.addView(card)
        }
    }

    private fun mythologyEmoji(m: String) = when (m) {
        "Greek" -> "🏛️"; "Egyptian" -> "🏺"; "Norse" -> "⚡"
        "Japanese" -> "⛩️"; "Chinese" -> "🐲"; "Dragon" -> "🐉"
        "Universal" -> "🌍"; "Game" -> "🎮"; "Babylonian" -> "🌊"
        else -> "📖"
    }
}
