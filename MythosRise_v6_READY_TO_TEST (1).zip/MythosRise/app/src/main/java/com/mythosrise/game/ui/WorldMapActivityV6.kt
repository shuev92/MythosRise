package com.mythosrise.game.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

class WorldMapActivityV6 : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var scrollContent: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_world_map_v6)
        engine = GameEngine(this)
        engine.loadGame()
        scrollContent = findViewById(R.id.llWorldMapContent)
        buildHub()
    }

    override fun onResume() {
        super.onResume()
        engine.loadGame()
        scrollContent.removeAllViews()
        buildHub()
    }

    private fun buildHub() {
        val c = engine.character
        val season = SeasonalEventManager.getCurrentSeason()
        val weather = SeasonalEventManager.getCurrentWeather()
        val event = SeasonalEventManager.getActiveEvent()
        val bpSeason = BattlePassManager.getCurrentSeason()
        val pvpRank = PvpSystem.getPvpRank(c.pvpRating)
        val activePet = PetSystem.getActivePet()

        // ── HERO BANNER ──
        val heroBanner = buildSection("#0A0020")
        addHeroRow(heroBanner, c)
        addText(heroBanner, "${season.emoji} ${season.displayName} | ${weather.emoji} ${weather.displayName}", "#9B59B6", 11f)
        event?.let { addText(heroBanner, "🎉 СЪБИТИЕ: ${it.name}", "#FFD700", 12f) }
        activePet?.let { addText(heroBanner, "${it.emoji} Питомец: ${it.name} [${it.stage.displayName}]", "#00CC88", 11f) }
        scrollContent.addView(heroBanner)

        // ── QUICK STATS ──
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(6, 4, 6, 4)
        }
        listOf(
            "⚔️ ${c.getTotalAttack()}" to "#FF6666",
            "🛡️ ${c.getTotalDefense()}" to "#6666FF",
            "❤️ ${c.health}/${c.getTotalMaxHealth()}" to "#FF66FF",
            "✨ ${c.divinity}" to "#FFFF66"
        ).forEach { (text, color) ->
            TextView(this).apply {
                this.text = text; setTextColor(Color.parseColor(color))
                textSize = 11f; gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }.also { statsRow.addView(it) }
        }
        scrollContent.addView(statsRow)

        // ── STORY PROGRESS ──
        val storyCompleted = StoryMode.ALL_CHAPTERS.count { it.isCompleted }
        val storyTotal = StoryMode.ALL_CHAPTERS.size
        if (storyCompleted < storyTotal) {
            val nextChapter = StoryMode.ALL_CHAPTERS.firstOrNull { !it.isCompleted && it.isUnlocked }
            nextChapter?.let {
                val storyBanner = buildSection("#05000F")
                addText(storyBanner, "📖 ИСТОРИЯ: Глава ${it.number} — ${it.title}", "#9B59B6", 13f)
                addNavButton(storyBanner, "▶️ Продължи Историята", "#1A0A2E") {
                    startActivity(Intent(this, StoryActivity::class.java))
                }
                scrollContent.addView(storyBanner)
            }
        } else {
            val completedBanner = buildSection("#001A00")
            addText(completedBanner, "🌌 ИСТОРИЯТА ЗАВЪРШЕНА! ТИ СИ ВСЕБОГ!", "#FFD700", 14f)
            scrollContent.addView(completedBanner)
        }

        // ── WORLDS ──
        addSectionHeader("🌍 СВЕТОВЕ")
        val worldsGrid = buildSection("#080808")
        val worlds = listOf(
            Triple("🏰", "Смъртното Кралство", 1),
            Triple("⚡", "Олимп", 5),
            Triple("💀", "Тартар", 8),
            Triple("🕉️", "Индия", 9),
            Triple("🏔️", "Асгард", 11),
            Triple("☀️", "Египет", 13),
            Triple("🐉", "Дракон Царство", 16),
            Triple("⚡", "Царство на Титаните", 20),
            Triple("🌸", "Япония", 24),
            Triple("🏯", "Китай", 28),
            Triple("🏟️", "Арена", 25)
        )
        var row: LinearLayout? = null
        worlds.forEachIndexed { i, (emoji, name, reqLevel) ->
            if (i % 2 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 3, 0, 3) }
                }
                worldsGrid.addView(row)
            }
            val isUnlocked = c.level >= reqLevel
            val btn = Button(this).apply {
                text = "$emoji $name"
                textSize = 10f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (isUnlocked) Color.parseColor("#1A0A2E") else Color.parseColor("#1A1A1A")
                )
                alpha = if (isUnlocked) 1f else 0.5f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 0, 2, 0) }
                setOnClickListener {
                    if (isUnlocked) {
                        engine.character.currentWorld = name
                        engine.saveGame()
                        startActivity(Intent(this@WorldMapActivityV6, GameActivity::class.java))
                    } else {
                        Toast.makeText(this@WorldMapActivityV6, "🔒 Нужно Ниво $reqLevel!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            row?.addView(btn)
        }
        scrollContent.addView(worldsGrid)

        // ── COMBAT ──
        addSectionHeader("⚔️ БИТКИ")
        val combatSection = buildSection("#0A0000")
        addNavButton(combatSection, "⚔️ Масова Битка", "#3D0000") { startActivity(Intent(this, MassBattleActivity::class.java)) }
        addNavButton(combatSection, "👑 Boss Rush", "#2D0000") { startActivity(Intent(this, BossRushActivity::class.java)) }
        addNavButton(combatSection, "🏟️ Арена", "#1D0000") {
            engine.character.currentWorld = "Арена"; engine.saveGame()
            startActivity(Intent(this, GameActivity::class.java))
        }
        addNavButton(combatSection, "⚔️ PvP Арена — ${pvpRank.emoji} ${pvpRank.displayName}", "#2A0010") { startActivity(Intent(this, PvpActivity::class.java)) }
        scrollContent.addView(combatSection)

        // ── STORY & GUILD ──
        addSectionHeader("📖 ИСТОРИЯ & ГИЛДИИ")
        val storySection = buildSection("#050010")
        addNavButton(storySection, "📖 История ($storyCompleted/$storyTotal глави)", "#0A0020") { startActivity(Intent(this, StoryActivity::class.java)) }
        addNavButton(storySection, "🏰 Гилдии", "#0A0015") { startActivity(Intent(this, GuildActivity::class.java)) }
        addNavButton(storySection, "📚 Митология Куиз", "#050015") { startActivity(Intent(this, MythologyQuizActivity::class.java)) }
        scrollContent.addView(storySection)

        // ── CHARACTER ──
        addSectionHeader("👤 ПЕРСОНАЖ")
        val charSection = buildSection("#050010")
        addNavButton(charSection, "🏪 Магазин", "#001A00") { startActivity(Intent(this, ShopActivity::class.java)) }
        addNavButton(charSection, "🎒 Инвентар", "#001010") { startActivity(Intent(this, InventoryActivity::class.java)) }
        addNavButton(charSection, "🌳 Дърво на Умения", "#001010") { startActivity(Intent(this, SkillTreeActivity::class.java)) }
        addNavButton(charSection, "🤝 Спътници", "#00100A") { startActivity(Intent(this, CompanionActivity::class.java)) }
        scrollContent.addView(charSection)

        // ── ENDGAME & PETS ──
        addSectionHeader("✨ ЕНДГЕЙМ")
        val endgameSection = buildSection("#0A000A")
        addNavButton(endgameSection, "⭐ Престиж & Статистики", "#1A001A") { startActivity(Intent(this, PrestigeActivity::class.java)) }
        addNavButton(endgameSection, "✨ Трансформации", "#150015") { startActivity(Intent(this, TransformationActivity::class.java)) }
        addNavButton(endgameSection, "🐾 Питомци", "#0A0A15") {
            Toast.makeText(this, "🐾 Питомци идват скоро!", Toast.LENGTH_SHORT).show()
        }
        addNavButton(endgameSection, "💎 Руни", "#0A0010") {
            Toast.makeText(this, "💎 Руни идват скоро!", Toast.LENGTH_SHORT).show()
        }
        scrollContent.addView(endgameSection)

        // ── SEASONAL & BATTLE PASS ──
        addSectionHeader("🎉 СЕЗОННИ")
        val seasonSection = buildSection("#0A0A00")
        addNavButton(seasonSection, "📅 Дневни Предизвикателства", "#1A1A00") { startActivity(Intent(this, DailyChallengeActivity::class.java)) }
        addNavButton(seasonSection, "⭐ Battle Pass — Ниво ${bpSeason.currentTier}/50", "#1A0A00") { startActivity(Intent(this, BattlePassActivity::class.java)) }
        scrollContent.addView(seasonSection)

        // ── EXPLORE ──
        addSectionHeader("🔍 ИЗСЛЕДВАНЕ")
        val exploreSection = buildSection("#000A0A")
        addNavButton(exploreSection, "📜 Куестове", "#001A1A") { startActivity(Intent(this, QuestActivity::class.java)) }
        addNavButton(exploreSection, "🔨 Занаятчийство", "#001A15") { startActivity(Intent(this, CraftingActivity::class.java)) }
        addNavButton(exploreSection, "📚 Книга на Лор", "#001515") { startActivity(Intent(this, LoreBookActivity::class.java)) }
        addNavButton(exploreSection, "🏆 Постижения", "#001010") { startActivity(Intent(this, AchievementActivity::class.java)) }
        scrollContent.addView(exploreSection)

        // ── DIVINITY TITLE BANNER ──
        val titleBanner = buildSection("#050005")
        addText(titleBanner, c.divinityTitle.title, "#FFD700", 18f)
        addText(titleBanner, "🌍 ${c.currentWorld} | ⭐ Престиж: ${c.prestigeCount}x", "#9B59B6", 11f)
        val nextTitle = listOf(500, 2000, 5000, 10000, 25000, 50000).firstOrNull { it > c.divinity }
        nextTitle?.let { addText(titleBanner, "✨ До следваща титла: ${it - c.divinity} дивинити", "#666666", 11f) }
        scrollContent.addView(titleBanner)
    }

    private fun buildSection(bg: String = "#0A0A1A"): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor(bg))
        setPadding(8, 6, 8, 6)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 4, 0, 4); layoutParams = lp
    }

    private fun addSectionHeader(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#9B59B6"))
            textSize = 13f; isFakeBoldText = true; setPadding(8, 10, 8, 4)
        }.also { scrollContent.addView(it) }
    }

    private fun addHeroRow(parent: LinearLayout, c: com.mythosrise.game.models.Character) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 4) }
        TextView(this).apply { text = c.heroClass.emoji; textSize = 32f; setPadding(0, 0, 10, 0) }.also { row.addView(it) }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        TextView(this).apply { text = c.name; setTextColor(Color.WHITE); textSize = 16f; isFakeBoldText = true }.also { info.addView(it) }
        TextView(this).apply { text = "${c.heroClass.displayName} | Ниво ${c.level} | ${c.divinityTitle.title}"; setTextColor(Color.parseColor("#9B59B6")); textSize = 11f }.also { info.addView(it) }
        val expPct = if (c.expToNextLevel > 0) (c.experience * 100 / c.expToNextLevel).toInt() else 100
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = expPct
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 8).apply { setMargins(0, 2, 0, 0) }
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#9B59B6"))
        }
        info.addView(pb)
        row.addView(info)
        val goldInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.END }
        TextView(this).apply { text = "💰${c.gold}"; setTextColor(Color.parseColor("#FFD700")); textSize = 12f }.also { goldInfo.addView(it) }
        TextView(this).apply { text = "✨${c.divinity}"; setTextColor(Color.parseColor("#9B59B6")); textSize = 11f }.also { goldInfo.addView(it) }
        row.addView(goldInfo)
        parent.addView(row)
    }

    private fun addNavButton(parent: LinearLayout, text: String, bg: String, onClick: () -> Unit) {
        Button(this).apply {
            this.text = text; setTextColor(Color.WHITE); textSize = 12f
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(bg))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 46.dpToPx())
            lp.setMargins(0, 2, 0, 2); layoutParams = lp
            setOnClickListener { onClick() }
        }.also { parent.addView(it) }
    }

    private fun addText(parent: LinearLayout, text: String, color: String, size: Float) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.parseColor(color))
            textSize = size; setPadding(4, 2, 4, 2)
        }.also { parent.addView(it) }
    }

    private fun Int.dpToPx() = (this * resources.displayMetrics.density).toInt()
}
