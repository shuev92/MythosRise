package com.mythosrise.game.engine

import android.content.Context
import android.content.SharedPreferences
import com.mythosrise.game.models.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// ─────────────────────────────────────────────
//  COMBAT RESULT
// ─────────────────────────────────────────────

data class CombatResult(
    val playerDamage: Int = 0,
    val enemyDamage: Int = 0,
    val playerHealed: Int = 0,
    val isCritical: Boolean = false,
    val isEvaded: Boolean = false,
    val enemyDied: Boolean = false,
    val playerDied: Boolean = false,
    val abilityUsed: String? = null,
    val statusEffect: String? = null,
    val log: String = ""
)

// ─────────────────────────────────────────────
//  GAME STATE
// ─────────────────────────────────────────────

enum class GameState {
    MAIN_MENU, CHARACTER_CREATION, WORLD_MAP, BATTLE, DIALOGUE, INVENTORY, LEVEL_UP, GAME_OVER, VICTORY
}

// ─────────────────────────────────────────────
//  GAME ENGINE
// ─────────────────────────────────────────────

class GameEngine(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("mythos_save", Context.MODE_PRIVATE)

    var character: Character = Character()
    var currentEnemy: Enemy? = null
    var gameState: GameState = GameState.MAIN_MENU
    var battleLog: MutableList<String> = mutableListOf()
    var isPlayerTurn: Boolean = true
    var pendingDivinity: Int = 0

    companion object {
        private const val SAVE_KEY = "character_save"
        private const val HAS_SAVE_KEY = "has_save"
    }

    // ─────────────────────────────────────────────
    //  SAVE / LOAD
    // ─────────────────────────────────────────────

    fun saveGame() {
        prefs.edit()
            .putString(SAVE_KEY, character.toJson())
            .putBoolean(HAS_SAVE_KEY, true)
            .apply()
    }

    fun loadGame(): Boolean {
        if (!prefs.getBoolean(HAS_SAVE_KEY, false)) return false
        val json = prefs.getString(SAVE_KEY, null) ?: return false
        return try {
            character = Character.fromJson(json)
            true
        } catch (e: Exception) { false }
    }

    fun hasSave(): Boolean = prefs.getBoolean(HAS_SAVE_KEY, false)

    fun deleteSave() {
        prefs.edit().clear().apply()
    }

    // ─────────────────────────────────────────────
    //  CHARACTER CREATION
    // ─────────────────────────────────────────────

    fun createCharacter(name: String, gender: Gender, skin: SkinTone, heroClass: HeroClass): Character {
        character = Character(
            name = name.ifBlank { "Герой" },
            gender = gender,
            skinTone = skin,
            heroClass = heroClass,
            maxHealth = heroClass.baseHp,
            health = heroClass.baseHp,
            maxMana = heroClass.baseMana,
            mana = heroClass.baseMana,
            attack = heroClass.baseAtk,
            defense = heroClass.baseDef,
            abilities = GameDatabase.getStarterAbilities(heroClass).toMutableList(),
            gold = 100,
            inventory = mutableListOf(
                GameDatabase.ALL_ITEMS["health_potion"]!!,
                GameDatabase.ALL_ITEMS["health_potion"]!!,
                GameDatabase.ALL_ITEMS["mana_potion"]!!
            )
        )
        // Equip starter weapon based on class
        val starterWeapon = GameDatabase.ALL_ITEMS["iron_sword"]!!
        character.equippedWeapon = starterWeapon
        character.inventory.add(starterWeapon)
        val starterArmor = GameDatabase.ALL_ITEMS["leather_armor"]!!
        character.equippedArmor = starterArmor
        character.inventory.add(starterArmor)
        return character
    }

    // ─────────────────────────────────────────────
    //  BATTLE SYSTEM
    // ─────────────────────────────────────────────

    fun startBattle(enemy: Enemy) {
        currentEnemy = enemy.copy(currentHealth = enemy.maxHealth)
        isPlayerTurn = character.speed >= 1.0f || Random.nextBoolean()
        battleLog.clear()
        battleLog.add("⚔️ Битка с ${enemy.name}!")
        if (enemy.isBoss) battleLog.add("🔥 БОШОВ ВРАГ!")
        gameState = GameState.BATTLE
    }

    fun playerAttack(): CombatResult {
        val enemy = currentEnemy ?: return CombatResult()
        val baseAtk = character.getTotalAttack()
        val crit = Random.nextFloat() < 0.15f
        val critMult = if (crit) 1.8f else 1.0f
        val rawDmg = (baseAtk * critMult).toInt()
        val defended = max(1, rawDmg - enemy.defense / 2)
        enemy.currentHealth -= defended
        val enemyDied = enemy.currentHealth <= 0

        val log = buildString {
            append("${character.name} удари за $defended урон")
            if (crit) append(" 💥 КРИТ!")
            if (enemyDied) append(" — ${enemy.name} е победен!")
        }
        battleLog.add(log)

        if (enemyDied) {
            onEnemyDefeated(enemy)
        } else {
            isPlayerTurn = false
        }

        return CombatResult(
            playerDamage = defended,
            isCritical = crit,
            enemyDied = enemyDied,
            log = log
        )
    }

    fun playerUseAbility(ability: Ability): CombatResult {
        val enemy = currentEnemy ?: return CombatResult()
        if (character.mana < ability.manaCost) {
            return CombatResult(log = "❌ Недостатъчно мана!")
        }
        if (ability.currentCooldown > 0) {
            return CombatResult(log = "⏳ Умението е в cooldown!")
        }
        if (ability.requiredDivinity > character.divinity) {
            return CombatResult(log = "🚫 Нужна е повече дивинити!")
        }

        character.mana -= ability.manaCost
        ability.currentCooldown = ability.cooldownTurns

        var healed = 0
        var dmg = 0
        var stunned = false
        val log = StringBuilder()

        // Heal
        if (ability.healPercent > 0) {
            healed = (character.getTotalMaxHealth() * ability.healPercent).toInt()
            character.health = min(character.getTotalMaxHealth(), character.health + healed)
            log.append("💚 ${character.name} се излекува с $healed живот! ")
        }

        // Damage
        if (ability.damageMultiplier > 0) {
            val baseDmg = (character.getTotalAttack() * ability.damageMultiplier).toInt()
            dmg = max(1, baseDmg - enemy.defense / 3)
            enemy.currentHealth -= dmg
            log.append("✨ ${ability.name}: $dmg урон! ")
        }

        // Stun
        if (ability.stunChance > 0 && Random.nextFloat() < ability.stunChance) {
            stunned = true
            log.append("⚡ Врагът е зашеметен! ")
        }

        val enemyDied = enemy.currentHealth <= 0
        if (enemyDied) {
            log.append("${enemy.name} е победен!")
            onEnemyDefeated(enemy)
        } else {
            if (!stunned) isPlayerTurn = false
        }

        battleLog.add(log.toString())
        return CombatResult(
            playerDamage = dmg,
            playerHealed = healed,
            abilityUsed = ability.name,
            enemyDied = enemyDied,
            statusEffect = if (stunned) "stun" else null,
            log = log.toString()
        )
    }

    fun enemyAttack(): CombatResult {
        val enemy = currentEnemy ?: return CombatResult()
        val activeAbility = enemy.abilities.filter { Random.nextFloat() < it.chance }.randomOrNull()
        val baseDmg = if (activeAbility != null) {
            (enemy.attack * activeAbility.damageMultiplier).toInt()
        } else {
            enemy.attack
        }

        val evaded = character.equippedHelmet?.specialEffect?.contains("избягване") == true &&
                Random.nextFloat() < 0.3f

        val defended = if (evaded) 0 else max(1, baseDmg - character.getTotalDefense() / 2)
        character.health -= defended
        val playerDied = character.health <= 0

        val log = buildString {
            if (evaded) {
                append("💨 ${character.name} избягва удара!")
            } else {
                append("${enemy.name} удари за $defended урон")
                if (activeAbility != null) append(" с ${activeAbility.name}!")
                if (playerDied) append(" — ${character.name} е мъртъв!")
            }
        }
        battleLog.add(log)
        isPlayerTurn = true

        // Reduce cooldowns
        character.abilities.forEach { if (it.currentCooldown > 0) it.currentCooldown-- }

        if (playerDied) gameState = GameState.GAME_OVER

        return CombatResult(
            enemyDamage = defended,
            isEvaded = evaded,
            playerDied = playerDied,
            log = log
        )
    }

    fun usePotion(item: Item): String {
        if (!character.inventory.contains(item)) return "Нямаш такъв предмет!"
        return when (item.type) {
            ItemType.POTION -> {
                if (item.healthBonus > 0) {
                    val healed = min(item.healthBonus, character.getTotalMaxHealth() - character.health)
                    character.health += healed
                    character.inventory.remove(item)
                    "💚 Излекуван с $healed живот!"
                } else if (item.manaBonus > 0) {
                    val restored = min(item.manaBonus, character.maxMana - character.mana)
                    character.mana += restored
                    character.inventory.remove(item)
                    "💙 Възстановена мана: $restored!"
                } else "Предметът няма ефект."
            }
            else -> "Не можеш да използваш ${item.name} тук."
        }
    }

    // ─────────────────────────────────────────────
    //  POST-BATTLE
    // ─────────────────────────────────────────────

    private fun onEnemyDefeated(enemy: Enemy) {
        character.enemiesDefeated++
        if (enemy.mythology == "Titan") character.titansDefeated++
        if (enemy.isBoss && enemy.divinityReward > 100) character.godsDefeated++

        character.gainExperience(enemy.expReward.toLong())
        character.gold += enemy.goldReward
        character.absorbPower(enemy)
        pendingDivinity = enemy.divinityReward

        // Random drop
        val dropChance = if (enemy.isBoss) 0.8f else 0.25f
        if (enemy.possibleDrops.isNotEmpty() && Random.nextFloat() < dropChance) {
            val dropId = enemy.possibleDrops.random()
            GameDatabase.getItemById(dropId)?.let { item ->
                character.inventory.add(item)
                battleLog.add("🎁 Намерен предмет: ${item.emoji} ${item.name}!")
            }
        }

        battleLog.add("✨ Поглъщаш ${enemy.divinityReward} дивинити от ${enemy.name}!")
        battleLog.add("⭐ +${enemy.expReward} опит | 💰 +${enemy.goldReward} злато")

        if (character.divinityTitle == DivinityTitle.OMNIGOD) {
            gameState = GameState.VICTORY
        } else {
            gameState = GameState.WORLD_MAP
        }
        saveGame()
    }

    // ─────────────────────────────────────────────
    //  EQUIP / SHOP
    // ─────────────────────────────────────────────

    fun equipItem(item: Item): String {
        return when (item.type) {
            ItemType.WEAPON -> { character.equippedWeapon = item; "⚔️ Екипиран: ${item.name}" }
            ItemType.ARMOR -> { character.equippedArmor = item; "🛡️ Екипиран: ${item.name}" }
            ItemType.HELMET -> { character.equippedHelmet = item; "⛑️ Екипиран: ${item.name}" }
            ItemType.BOOTS -> { character.equippedBoots = item; "👢 Екипиран: ${item.name}" }
            ItemType.RING -> { character.equippedRing = item; "💍 Екипиран: ${item.name}" }
            ItemType.AMULET -> { character.equippedAmulet = item; "📿 Екипиран: ${item.name}" }
            else -> "Не можеш да екипираш ${item.name}"
        }
    }

    fun getNextEnemy(): Enemy {
        val worldEnemies = GameDatabase.getEnemiesForWorld(character.currentWorld)
        val suitable = worldEnemies.filter { !it.isBoss && it.level <= character.level + 3 }
        return if (suitable.isNotEmpty()) suitable.random()
        else GameDatabase.getRandomEnemyForLevel(character.level)
    }

    fun getWorldBoss(): Enemy? {
        return GameDatabase.getEnemiesForWorld(character.currentWorld)
            .firstOrNull { it.isBoss }
    }

    fun unlockNextWorld(): Boolean {
        val worlds = World.values()
        val currentIdx = worlds.indexOf(character.currentWorld)
        if (currentIdx < worlds.size - 1) {
            val next = worlds[currentIdx + 1]
            if (character.level >= next.unlockLevel) {
                character.currentWorld = next
                saveGame()
                return true
            }
        }
        return false
    }

    fun getCharacterSummary(): String = buildString {
        append("${character.gender.emoji} ${character.name}\n")
        append("${character.divinityTitle.title} | Ниво ${character.level}\n")
        append("❤️ ${character.health}/${character.getTotalMaxHealth()} | ")
        append("💙 ${character.mana}/${character.maxMana}\n")
        append("⚔️ ATK: ${character.getTotalAttack()} | 🛡️ DEF: ${character.getTotalDefense()}\n")
        append("✨ Дивинити: ${character.divinity}\n")
        append("💰 Злато: ${character.gold}\n")
        append("🌍 ${character.currentWorld.displayName}\n")
        append("👹 Победени: ${character.enemiesDefeated}")
    }
}
