package com.mythosrise.game.engine

import com.mythosrise.game.models.Ability
import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  COMBO STEP
// ─────────────────────────────────────────────

data class ComboStep(
    val abilityId: String,
    val abilityName: String,
    val emoji: String
)

// ─────────────────────────────────────────────
//  SPELL COMBO
// ─────────────────────────────────────────────

data class SpellCombo(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val steps: List<ComboStep>,
    val bonusDamageMultiplier: Float,
    val bonusEffect: String,
    val requiredDivinity: Int = 0,
    val mythology: String = "Universal",
    val rarity: String = "Rare",
    val lore: String = ""
)

// ─────────────────────────────────────────────
//  COMBO TRACKER
// ─────────────────────────────────────────────

object ComboSystem {

    val ALL_COMBOS = listOf(

        SpellCombo(
            id = "combo_thunder_blizzard",
            name = "Гръм Буря",
            emoji = "⛈️",
            description = "Мълния + Замразяване = Електро-Лед буря",
            steps = listOf(
                ComboStep("thunder_god", "Гръм на Боговете", "⚡"),
                ComboStep("blizzard", "Виелица", "❄️")
            ),
            bonusDamageMultiplier = 2.8f,
            bonusEffect = "Замразява врага за 2 хода + електрически изгаряния",
            mythology = "Greek/Norse",
            rarity = "Epic",
            lore = "Когато Зевс и Скади се срещнали, светкавицата замръзна."
        ),

        SpellCombo(
            id = "combo_dragon_inferno",
            name = "Инфернодракон",
            emoji = "🐉🔥",
            description = "Дракон Огън + Метеор = Апокалиптично изгаряне",
            steps = listOf(
                ComboStep("dragon_fire", "Дракон Огън", "🐉"),
                ComboStep("meteor", "Метеор", "☄️")
            ),
            bonusDamageMultiplier = 3.5f,
            bonusEffect = "Оставя горяща зона — +50 урон следващите 3 хода",
            mythology = "Universal",
            rarity = "Legendary",
            lore = "Огъня на дракон + небесна скала = пъкъл на земята."
        ),

        SpellCombo(
            id = "combo_divine_nova",
            name = "Божествена Нова",
            emoji = "✨💥",
            description = "Свята Аура + Дивинити Взрив = Ослепително унищожение",
            steps = listOf(
                ComboStep("divine_light", "Божествена Светлина", "✨"),
                ComboStep("divinity_burst", "Дивинити Взрив", "💫")
            ),
            bonusDamageMultiplier = 3.0f,
            bonusEffect = "Имунитет към следващите 2 атаки",
            requiredDivinity = 3000,
            mythology = "Universal",
            rarity = "Divine",
            lore = "Когато смъртен достигне достатъчно дивинити, светлината му сама убива."
        ),

        SpellCombo(
            id = "combo_chaos_void",
            name = "Хаотичен Войд",
            emoji = "🌀🌑",
            description = "Хаос Взрив + Сянка = Войд разкъсване",
            steps = listOf(
                ComboStep("chaos_strike", "Хаос Удар", "🌀"),
                ComboStep("shadow_void", "Войд Сянка", "🌑")
            ),
            bonusDamageMultiplier = 4.0f,
            bonusEffect = "Игнорира цялата защита на врага",
            requiredDivinity = 10000,
            mythology = "Chaos",
            rarity = "Divine",
            lore = "Хаосът и нищото са едно. Заедно — раздират реалността."
        ),

        SpellCombo(
            id = "combo_berserker_rage",
            name = "Берсерк Ярост",
            emoji = "😤⚔️",
            description = "Берсерк + Кален Удар = Неудържима ярост",
            steps = listOf(
                ComboStep("berserker_rage", "Берсерк Ярост", "😤"),
                ComboStep("power_strike", "Мощен Удар", "💪")
            ),
            bonusDamageMultiplier = 2.5f,
            bonusEffect = "Всяка атака следващите 3 хода е критична",
            mythology = "Norse",
            rarity = "Epic",
            lore = "Викинг берсерк в ярост не чувства болка. Само убива."
        ),

        SpellCombo(
            id = "combo_phoenix_rebirth",
            name = "Прераждане на Феникс",
            emoji = "🔥🔄",
            description = "Феникс Огън + Лечение = Прераждаш се от пепелта",
            steps = listOf(
                ComboStep("phoenix_flame", "Феникс Пламък", "🦅"),
                ComboStep("divine_heal", "Божествено Лечение", "💚")
            ),
            bonusDamageMultiplier = 1.5f,
            bonusEffect = "Лекуваш 50% живот + нанасяш огнен урон",
            mythology = "Universal",
            rarity = "Legendary",
            lore = "Феникс умира и живее. Ти можеш да направиш същото."
        ),

        SpellCombo(
            id = "combo_samurai_swift",
            name = "Светкавична Катана",
            emoji = "⚡🗡️",
            description = "Мечен Танц + Мълния = 5 мълниеносни удара",
            steps = listOf(
                ComboStep("sword_dance", "Мечен Танц", "🗡️"),
                ComboStep("lightning_speed", "Скорост на Мълнията", "⚡")
            ),
            bonusDamageMultiplier = 2.2f,
            bonusEffect = "5 бързи удара вместо 1",
            mythology = "Japanese",
            rarity = "Epic",
            lore = "Сусаноо научи самураите как да режат с бързина на гръм."
        ),

        SpellCombo(
            id = "combo_monkey_72",
            name = "72 Форми Атака",
            emoji = "🐒✨",
            description = "Маймунски Фуст + Трансформация = 72 удара",
            steps = listOf(
                ComboStep("monkey_fist", "Маймунски Юмрук", "🐒"),
                ComboStep("transformation", "Трансформация", "🔄")
            ),
            bonusDamageMultiplier = 3.2f,
            bonusEffect = "Ударите идват от всички посоки — не може да се блокира",
            mythology = "Chinese",
            rarity = "Legendary",
            lore = "72 трансформации на Ву Конг като 72 удара наведнъж."
        ),

        SpellCombo(
            id = "combo_pyramid_curse",
            name = "Проклятие на Пирамидата",
            emoji = "🏺💀",
            description = "Мумифициране + Анубис Присъда = вечно проклятие",
            steps = listOf(
                ComboStep("mummify", "Мумифициране", "🧟"),
                ComboStep("anubis_judgment", "Съдба на Анубис", "⚖️")
            ),
            bonusDamageMultiplier = 2.0f,
            bonusEffect = "Врагът губи 10% живот всеки ход за 5 хода",
            mythology = "Egyptian",
            rarity = "Epic",
            lore = "Анубис взима душата. Мумията пази тялото. Нищо не остава."
        ),

        SpellCombo(
            id = "combo_ragnarok_call",
            name = "Зов на Рагнарок",
            emoji = "🌋⚡",
            description = "Фенрир Вой + Гарм Атака = Апокалиптичен зов",
            steps = listOf(
                ComboStep("fenrir_howl", "Вой на Фенрир", "🐺"),
                ComboStep("ragnarok_strike", "Удар на Рагнарок", "🌋")
            ),
            bonusDamageMultiplier = 4.5f,
            bonusEffect = "Всички врагове в Арена режим получават удара",
            requiredDivinity = 5000,
            mythology = "Norse",
            rarity = "Divine",
            lore = "Рагнарок е неизбежен. Но можеш да го използваш като оръжие."
        ),

        SpellCombo(
            id = "combo_omnigod_absolute",
            name = "АБСОЛЮТНА МОЩ НА ВСЕБОГА",
            emoji = "🌌✨",
            description = "Само Всебог може да изпълни това комбо",
            steps = listOf(
                ComboStep("omnigod_aura", "Аура на Всебога", "🌌"),
                ComboStep("chaos_strike", "Хаос Удар", "🌀"),
                ComboStep("divine_light", "Божествена Светлина", "✨")
            ),
            bonusDamageMultiplier = 10.0f,
            bonusEffect = "МИГНОВЕНА СМЪРТ при врагове под 50% живот",
            requiredDivinity = 50000,
            mythology = "Universal",
            rarity = "Omnigod",
            lore = "В началото беше Хаосът. В края — ти. Абсолютното."
        )
    )

    // ─────────────────────────────────────────────
    //  COMBO DETECTION
    // ─────────────────────────────────────────────

    private val recentAbilities = mutableListOf<String>()
    private const val COMBO_WINDOW = 3 // last N abilities used

    fun recordAbilityUse(abilityId: String) {
        recentAbilities.add(abilityId)
        if (recentAbilities.size > COMBO_WINDOW * 2) recentAbilities.removeAt(0)
    }

    fun detectCombo(character: Character): SpellCombo? {
        val availableCombos = ALL_COMBOS.filter { c ->
            character.divinity >= c.requiredDivinity
        }
        return availableCombos.firstOrNull { combo ->
            val stepIds = combo.steps.map { it.abilityId }
            val windowSize = stepIds.size
            if (recentAbilities.size < windowSize) return@firstOrNull false
            val lastN = recentAbilities.takeLast(windowSize)
            lastN == stepIds
        }
    }

    fun clearRecent() { recentAbilities.clear() }

    fun calculateComboDamage(combo: SpellCombo, baseDamage: Int): Int {
        return (baseDamage * combo.bonusDamageMultiplier).toInt()
    }

    fun getAvailableCombos(character: Character): List<SpellCombo> {
        return ALL_COMBOS.filter { it.requiredDivinity <= character.divinity }
    }

    fun getComboHint(character: Character): String? {
        if (recentAbilities.isEmpty()) return null
        val last = recentAbilities.last()
        return getAvailableCombos(character).firstOrNull { combo ->
            combo.steps.firstOrNull()?.abilityId == last && combo.steps.size > 1
        }?.let { combo ->
            "💡 Следва: ${combo.steps[1].emoji} ${combo.steps[1].abilityName} → ${combo.name}!"
        }
    }
}

// ─────────────────────────────────────────────
//  COMBO GUIDE
// ─────────────────────────────────────────────

object ComboGuide {
    val TIPS = listOf(
        "💡 Гръм Буря: Гръм на Боговете → Виелица. Замразява + изгаря!",
        "💡 Инфернодракон: Дракон Огън → Метеор. Оставя горяща зона!",
        "💡 Берсерк Ярост: Берсерк → Мощен Удар. Следващите 3 удара са критични!",
        "💡 Светкавична Катана: Мечен Танц → Скорост на Мълнията. 5 удара вместо 1!",
        "💡 72 Форми: Маймунски Юмрук → Трансформация. Неблокируем атака!",
        "💡 Феникс Прераждане: Феникс Пламък → Лечение. Атакуваш и се лекуваш!",
        "💡 Хаотичен Войд: Хаос Удар → Войд Сянка. Игнорира цялата защита!",
        "💡 Проклятие Пирамида: Мумифициране → Съдба на Анубис. 5 хода проклятие!",
        "💡 Рагнарок Зов: Вой на Фенрир → Удар на Рагнарок. AOE за всички врагове!",
        "💡 Абсолютна Мощ: Аура → Хаос → Светлина. 10x урон + мигновена смърт!"
    )
    
    val MYTHOLOGY_COMBOS = mapOf(
        "Greek" to listOf("combo_divine_nova", "combo_thunder_blizzard"),
        "Norse" to listOf("combo_berserker_rage", "combo_ragnarok_call"),
        "Japanese" to listOf("combo_samurai_swift"),
        "Chinese" to listOf("combo_monkey_72"),
        "Egyptian" to listOf("combo_pyramid_curse"),
        "Universal" to listOf("combo_dragon_inferno", "combo_phoenix_rebirth", "combo_chaos_void", "combo_omnigod_absolute")
    )
    
    fun getRandomTip(): String = TIPS.random()
    
    fun getCombosForMythology(mythology: String): List<SpellCombo> {
        val ids = MYTHOLOGY_COMBOS[mythology] ?: emptyList()
        return ComboSystem.ALL_COMBOS.filter { it.id in ids }
    }
    
    fun getFullComboBook(): String = buildString {
        appendLine("═══ КНИГА НА КОМБАТА ═══")
        appendLine()
        ComboSystem.ALL_COMBOS.forEach { combo ->
            appendLine("${combo.emoji} ${combo.name} [${combo.rarity}]")
            appendLine("  ${combo.description}")
            appendLine("  Стъпки: ${combo.steps.joinToString(" → ") { "${it.emoji} ${it.abilityName}" }}")
            appendLine("  Бонус: x${combo.bonusDamageMultiplier} урон")
            appendLine("  Ефект: ${combo.bonusEffect}")
            if (combo.requiredDivinity > 0) appendLine("  Изисква: ✨${combo.requiredDivinity} Дивинити")
            appendLine()
        }
    }
}

// ─────────────────────────────────────────────
//  EXTENDED COMBO GUIDE
// ─────────────────────────────────────────────

object ComboMasterySystem {

    val COMBO_CHALLENGES = listOf(
        Triple("Начинаещ Комбо", "Изпълни Гръм Буря 5 пъти", 5000),
        Triple("Среден Комбо", "Изпълни 5 различни комба в 1 битка", 15000),
        Triple("Напреднал Комбо", "Изпълни Рагнарок Зов без Дивинити бонус", 25000),
        Triple("Майстор Комбо", "Изпълни всичките 11 комба в 1 сесия", 50000),
        Triple("ВСЕБОГ КОМБО", "Изпълни АБСОЛЮТНА МОЩ 3 пъти в 1 битка", 200000)
    )

    val COMBO_CLASS_AFFINITY = mapOf(
        "Воин ⚔️" to listOf("Берсерк Ярост (x2.5)", "Зов Рагнарок (x4.5)", "72 Форми (x3.2)"),
        "Маг 🔮" to listOf("Гръм Буря (x2.8)", "Инфернодракон (x3.5)", "Хаотичен Войд (x4.0)"),
        "Ловец 🏹" to listOf("Светкавична Катана (x2.2)", "Прераждане Феникс (x1.5)", "Проклятие Пирамида (x2.0)"),
        "Монах 🥋" to listOf("72 Форми (x3.2)", "Берсерк Ярост (x2.5)", "Божествена Нова (x3.0)")
    )

    val ELEMENT_COMBO_BONUSES = mapOf(
        "Fire+Ice" to "Парна Взривна Вълна: +50% AOE урон",
        "Lightning+Water" to "Електрошок: Враг е парализиран 2 хода",
        "Light+Dark" to "Равновесие: +100% крит за следващата атака",
        "Earth+Wind" to "Пясъчна Буря: Всички врагове ослепени 1 ход",
        "All5Elements" to "ПЕТЕЛЕМЕНТНО КОМБО: x3 на следващата атака + AOE"
    )

    val COMBO_WORLD_BONUSES = mapOf(
        "Олимп" to "⚡ Гръм Буря комбо +50% в Олимп",
        "Асгард" to "🌋 Зов Рагнарок комбо +75% в Асгард",
        "Египет" to "🏺 Проклятие Пирамида +100% продължителност в Египет",
        "Дракон Царство" to "🐉 Инфернодракон +80% огнен урон в Дракон Царство",
        "Китай" to "🐒 72 Форми +1 допълнителен удар в Китай"
    )

    val COMBO_TRAINING_MISSIONS = listOf(
        "🎯 Мисия 1: Изпълни Гръм Буря — Пожни Мълнийния Страх",
        "🎯 Мисия 2: Изпълни Инфернодракон — Огненото Сърце е твое",
        "🎯 Мисия 3: Изпълни Хаотичен Войд — Хаосът те признава",
        "🎯 Мисия 4: Изпълни Зов Рагнарок — Асгард пее за теб",
        "🎯 ФИНАЛ: Изпълни АБСОЛЮТНА МОЩ — Боговете се прекланят"
    )

    fun getClassBestCombos(heroClass: String): List<String> =
        COMBO_CLASS_AFFINITY[heroClass] ?: listOf("Всички комба достъпни!")

    fun getWorldComboBonus(worldName: String): String? = COMBO_WORLD_BONUSES[worldName]

    fun getElementComboBonus(element1: String, element2: String): String? {
        val key1 = "$element1+$element2"
        val key2 = "$element2+$element1"
        return ELEMENT_COMBO_BONUSES[key1] ?: ELEMENT_COMBO_BONUSES[key2]
    }

    val COMBO_MASTERY_TITLES = mapOf(
        0 to "Начинаещ в Комбото",
        3 to "Комбо Ученик",
        6 to "Комбо Практик",
        9 to "Комбо Майстор",
        11 to "💥 КОМБО БОГ — Всичките 11!"
    )

    fun getComboMasteryTitle(unlockedCombos: Int): String {
        return COMBO_MASTERY_TITLES.entries
            .filter { it.key <= unlockedCombos }
            .maxByOrNull { it.key }?.value ?: "Начинаещ в Комбото"
    }
}
