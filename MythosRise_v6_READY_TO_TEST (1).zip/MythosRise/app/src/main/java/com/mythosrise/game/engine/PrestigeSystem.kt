package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.DivinityTitle
import com.mythosrise.game.models.HeroClass

// ─────────────────────────────────────────────
//  PRESTIGE TIER
// ─────────────────────────────────────────────

enum class PrestigeTier(
    val displayName: String,
    val emoji: String,
    val color: String,
    val requiredPrestige: Int,
    val attackMultiplier: Float,
    val defenseMultiplier: Float,
    val divinityMultiplier: Float
) {
    NONE("Без Престиж", "⬜", "#AAAAAA", 0, 1.0f, 1.0f, 1.0f),
    BRONZE("Бронзов Герой", "🟤", "#CD7F32", 1, 1.15f, 1.15f, 1.1f),
    SILVER("Сребърен Воин", "⚪", "#C0C0C0", 3, 1.30f, 1.25f, 1.20f),
    GOLD("Златен Шампион", "🟡", "#FFD700", 5, 1.50f, 1.40f, 1.35f),
    PLATINUM("Платинен Легенд", "🔵", "#E5E4E2", 8, 1.75f, 1.60f, 1.50f),
    DIAMOND("Диамантен Бог", "💎", "#B9F2FF", 12, 2.00f, 1.80f, 1.75f),
    MYTHIC("Митичен Всебог", "🔴", "#FF0000", 18, 2.50f, 2.20f, 2.00f),
    DIVINE("Божествен Хаос", "🌌", "#FF00FF", 25, 3.00f, 2.60f, 2.50f)
}

// ─────────────────────────────────────────────
//  PRESTIGE UPGRADE
// ─────────────────────────────────────────────

data class PrestigeUpgrade(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val cost: Int,          // prestige points
    val maxLevel: Int,
    var currentLevel: Int = 0,
    val bonusPerLevel: String,
    val category: String
)

// ─────────────────────────────────────────────
//  PRESTIGE SYSTEM
// ─────────────────────────────────────────────

object PrestigeSystem {

    val PRESTIGE_UPGRADES = listOf(
        PrestigeUpgrade("pu_attack", "Наследствена Сила", "+10% базова атака на ниво", "⚔️",
            cost = 1, maxLevel = 10, bonusPerLevel = "+10% ATK", category = "Боен"),
        PrestigeUpgrade("pu_defense", "Древна Броня", "+8% базова защита на ниво", "🛡️",
            cost = 1, maxLevel = 10, bonusPerLevel = "+8% DEF", category = "Боен"),
        PrestigeUpgrade("pu_health", "Жизнена Сила", "+15% базов живот на ниво", "❤️",
            cost = 1, maxLevel = 8, bonusPerLevel = "+15% HP", category = "Боен"),
        PrestigeUpgrade("pu_mana", "Магична Кръв", "+20% базова мана на ниво", "💙",
            cost = 1, maxLevel = 8, bonusPerLevel = "+20% Мана", category = "Боен"),
        PrestigeUpgrade("pu_divinity_gain", "Богоубийца Наследство", "+15% всички дивинити на ниво", "✨",
            cost = 2, maxLevel = 10, bonusPerLevel = "+15% Дивинити приходи", category = "Дивинити"),
        PrestigeUpgrade("pu_gold_gain", "Бизнес Умения", "+20% злато от всичко на ниво", "💰",
            cost = 1, maxLevel = 10, bonusPerLevel = "+20% Злато приходи", category = "Икономика"),
        PrestigeUpgrade("pu_absorb", "Поглъщащ Ум", "+25% бонус от поглъщане на ниво", "🌀",
            cost = 2, maxLevel = 8, bonusPerLevel = "+25% поглъщане", category = "Специален"),
        PrestigeUpgrade("pu_crit", "Критична Съдба", "+5% шанс за критичен удар на ниво", "💥",
            cost = 2, maxLevel = 5, bonusPerLevel = "+5% крит шанс", category = "Боен"),
        PrestigeUpgrade("pu_start_level", "Бързо Пробуждане", "Започваш от ниво +5 на ниво", "⭐",
            cost = 3, maxLevel = 5, bonusPerLevel = "Старт ниво +5", category = "Специален"),
        PrestigeUpgrade("pu_item_drop", "Везна на Съдбата", "+10% шанс за drop на предмет на ниво", "🎁",
            cost = 2, maxLevel = 5, bonusPerLevel = "+10% предмет drop", category = "Специален"),
        PrestigeUpgrade("pu_boss_dmg", "Богоубиец", "+15% урон срещу босове на ниво", "👑",
            cost = 3, maxLevel = 8, bonusPerLevel = "+15% урон срещу босове", category = "Боен"),
        PrestigeUpgrade("pu_arena_bonus", "Арена Ветеран", "+20% всички награди в Арената на ниво", "🏟️",
            cost = 2, maxLevel = 5, bonusPerLevel = "+20% Арена награди", category = "Арена"),
        PrestigeUpgrade("pu_unlock_world", "Световен Изследовател", "Отключва следващия свят на -2 нива", "🌍",
            cost = 3, maxLevel = 3, bonusPerLevel = "-2 нива за свят отключване", category = "Специален"),
        PrestigeUpgrade("pu_chaos_form", "Форма на Хаоса", "При 100% мана → +50% атака временно", "🌌",
            cost = 5, maxLevel = 1, bonusPerLevel = "Активира Chaos Form", category = "Специален")
    )

    // ─────────────────────────────────────────────
    //  PRESTIGE LOGIC
    // ─────────────────────────────────────────────

    fun canPrestige(character: Character): Boolean {
        return character.level >= 50 && character.divinity >= 50000
    }

    fun getPrestigePoints(character: Character): Int {
        return character.prestigeCount * 3 + (character.divinity / 10000).coerceAtMost(10)
    }

    fun performPrestige(character: Character): String {
        if (!canPrestige(character)) return "Недостатъчно ниво или дивинити за Престиж!"

        val prestigeCount = character.prestigeCount + 1
        val prestigePoints = 3 + prestigeCount

        // Calculate permanent bonuses
        val tier = getPrestigeTier(prestigeCount)
        val attackMult = tier.attackMultiplier
        val defenseMult = tier.defenseMultiplier
        val divinityMult = tier.divinityMultiplier

        // Save prestige data
        val oldName = character.name
        val oldClass = character.heroClass
        val oldGender = character.gender
        val oldSkin = character.skinTone
        val oldPrestigeCount = prestigeCount
        val oldPrestigePoints = character.prestigePoints + prestigePoints
        val oldUpgrades = PRESTIGE_UPGRADES.map { it.copy() }
        val keptItems = character.inventory.filter { it.rarity.ordinal >= 5 }.take(3) // Keep top 3 mythic+

        // Reset character
        character.apply {
            level = 1 + getStartLevelBonus()
            experience = 0
            health = 100 + level * 10
            maxHealth = 100 + level * 10
            mana = 50 + level * 5
            maxMana = 50 + level * 5
            attack = 10 + level * 2
            defense = 5 + level
            gold = 500
            divinity = 0
            divinityTitle = DivinityTitle.MORTAL
            enemiesDefeated = 0
            godsDefeated = 0
            titansDefeated = 0
            absorbedPowers.clear()
            abilities.clear()
            inventory.clear()
            equippedWeapon = null
            equippedArmor = null
            equippedHelmet = null
            equippedBoots = null
            equippedRing = null
            equippedAmulet = null
            currentWorld = com.mythosrise.game.models.World.MORTAL_REALM

            // Keep prestige stuff
            name = oldName
            this.heroClass = oldClass
            gender = oldGender
            skinTone = oldSkin
            this.prestigeCount = oldPrestigeCount
            this.prestigePoints = oldPrestigePoints

            // Apply prestige multipliers
            this.attack = (attack * attackMult).toInt()
            this.defense = (defense * defenseMult).toInt()
        }

        // Restore kept items
        keptItems.forEach { character.inventory.add(it) }

        return buildString {
            appendLine("⭐ ПРЕСТИЖ $prestigeCount!")
            appendLine("Нов тир: ${tier.emoji} ${tier.displayName}")
            appendLine("Постоянен ATK: x${attackMult}")
            appendLine("Постоянна DEF: x${defenseMult}")
            appendLine("Постоянна Дивинити: x${divinityMult}")
            appendLine("+$prestigePoints точки Престиж!")
            appendLine("Запазени: ${keptItems.size} Митични+ предмети")
        }
    }

    fun getPrestigeTier(count: Int): PrestigeTier {
        return PrestigeTier.values().filter { it.requiredPrestige <= count }.maxByOrNull { it.requiredPrestige }
            ?: PrestigeTier.NONE
    }

    private fun getStartLevelBonus(): Int {
        val upgrade = PRESTIGE_UPGRADES.find { it.id == "pu_start_level" }
        return (upgrade?.currentLevel ?: 0) * 5
    }

    fun upgradePrestige(upgrade: PrestigeUpgrade, character: Character): Boolean {
        if (upgrade.currentLevel >= upgrade.maxLevel) return false
        val cost = upgrade.cost * (upgrade.currentLevel + 1)
        if (character.prestigePoints < cost) return false
        character.prestigePoints -= cost
        upgrade.currentLevel++
        applyUpgrade(upgrade, character)
        return true
    }

    private fun applyUpgrade(upgrade: PrestigeUpgrade, character: Character) {
        when (upgrade.id) {
            "pu_attack" -> character.attack = (character.attack * 1.1f).toInt()
            "pu_defense" -> character.defense = (character.defense * 1.08f).toInt()
            "pu_health" -> {
                val bonus = (character.maxHealth * 0.15f).toInt()
                character.maxHealth += bonus
                character.health += bonus
            }
            "pu_mana" -> {
                val bonus = (character.maxMana * 0.20f).toInt()
                character.maxMana += bonus
                character.mana += bonus
            }
            "pu_crit" -> character.critChanceBonus += 0.05f
        }
    }

    fun getPrestigeDescription(character: Character): String {
        val tier = getPrestigeTier(character.prestigeCount)
        return buildString {
            appendLine("${tier.emoji} ${tier.displayName}")
            appendLine("Престиж: ${character.prestigeCount} пъти")
            appendLine("Точки: ${character.prestigePoints}")
            appendLine("ATK множител: x${tier.attackMultiplier}")
            appendLine("DEF множител: x${tier.defenseMultiplier}")
            appendLine("Дивинити множител: x${tier.divinityMultiplier}")
        }
    }
}

// ─────────────────────────────────────────────
//  PRESTIGE LORE & MILESTONE MESSAGES
// ─────────────────────────────────────────────

object PrestigeLore {
    val PRESTIGE_MESSAGES = mapOf(
        1 to "⭐ Прероден! Бронзовият Герой се издига от пепелта по-силен.",
        2 to "⭐⭐ Втори Престиж! Паметта остава. Силата се удвоява.",
        3 to "🥈 Сребърен Воин! Три пъти роден. Три пъти по-силен.",
        5 to "🥇 Златен Шампион! Пет Престижа. Легенда в собствения ти свят.",
        8 to "🔵 Платинен! Осем Прераждания. Боговете те забелязват.",
        12 to "💎 Диамантен Бог! Дванадесет пъти роден. Непобедимост приближава.",
        18 to "🔴 МИТИЧЕН! Осемнадесет Престижа. Ти си митологията.",
        25 to "🌌 БОЖЕСТВЕН ХАОС! 25 Престижа! Ти надхвърли самите богове!"
    )
    
    val WHAT_YOU_KEEP = listOf(
        "✅ Топ 3 Митични+ предмети",
        "✅ Всички Престиж точки",
        "✅ Престиж Подобрения",
        "✅ Постиженията",
        "✅ Записите в Книгата на Митологиите",
        "✅ Погълнатите Сили (бонусите)",
        "✅ Историята на куестовете"
    )
    
    val WHAT_YOU_LOSE = listOf(
        "❌ Ниво (връща се на 1 + бонус)",
        "❌ Злато (50 стартово)",
        "❌ Повечето предмети",
        "❌ Умения в Дървото",
        "❌ Дивинити (връща се на 0)",
        "❌ Текущи куест прогреси"
    )
    
    fun getMessage(prestigeCount: Int): String {
        return PRESTIGE_MESSAGES.entries
            .filter { it.key <= prestigeCount }
            .maxByOrNull { it.key }?.value
            ?: "⭐ Прероден! По-силен от преди!"
    }
    
    fun getFullPrestigeGuide(): String = buildString {
        appendLine("═══ ПЪЛЕН РЪКОВОДСТВО ЗА ПРЕСТИЖ ═══")
        appendLine()
        appendLine("Изисквания: Ниво 50 + 50 000 Дивинити")
        appendLine()
        appendLine("✅ ЗАПАЗВАШ:")
        WHAT_YOU_KEEP.forEach { appendLine(it) }
        appendLine()
        appendLine("❌ ГУБИШ:")
        WHAT_YOU_LOSE.forEach { appendLine(it) }
        appendLine()
        appendLine("🏆 НИВА НА ПРЕСТИЖ:")
        PrestigeTier.values().filter { it != PrestigeTier.NONE }.forEach { tier ->
            appendLine("${tier.emoji} ${tier.displayName} (${tier.requiredPrestige}x)")
            appendLine("   ATK x${tier.attackMultiplier} | DEF x${tier.defenseMultiplier} | Дивинити x${tier.divinityMultiplier}")
        }
    }
}
