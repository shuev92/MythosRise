package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import java.util.Calendar

// ─────────────────────────────────────────────
//  DAILY CHALLENGE
// ─────────────────────────────────────────────

enum class ChallengeType {
    KILL_COUNT, KILL_BOSS, USE_ABILITY, EARN_GOLD, EARN_DIVINITY,
    SURVIVE_WAVES, CRAFT_ITEM, ABSORB_POWER, NO_POTION_BOSS, PERFECT_BATTLE
}

data class DailyChallenge(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val type: ChallengeType,
    val targetValue: Int,
    var currentValue: Int = 0,
    val goldReward: Int,
    val divinityReward: Int,
    val expReward: Long,
    val skillPointReward: Int = 0,
    var completed: Boolean = false,
    var claimed: Boolean = false,
    val difficulty: String = "Обикновена"
)

// ─────────────────────────────────────────────
//  SPECIAL EVENT
// ─────────────────────────────────────────────

data class SpecialEvent(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val bonusMultiplier: Float,
    val bonusType: String,
    val durationDays: Int,
    val lore: String
)

// ─────────────────────────────────────────────
//  DAILY CHALLENGE MANAGER
// ─────────────────────────────────────────────

object DailyChallengeManager {

    private val challengePool = listOf(
        // Kill challenges
        DailyChallenge("d_kill_5", "Пет Убийства", "Убий 5 врагове днес.", "⚔️",
            ChallengeType.KILL_COUNT, 5, goldReward = 500, divinityReward = 20, expReward = 300, difficulty = "Лесна"),
        DailyChallenge("d_kill_20", "Двадесет Убийства", "Убий 20 врагове.", "🗡️",
            ChallengeType.KILL_COUNT, 20, goldReward = 1500, divinityReward = 60, expReward = 900, difficulty = "Средна"),
        DailyChallenge("d_kill_50", "Жътвар", "Убий 50 врагове!", "💀",
            ChallengeType.KILL_COUNT, 50, goldReward = 4000, divinityReward = 150, expReward = 2500, difficulty = "Трудна"),
        DailyChallenge("d_kill_boss", "Убиец на Босове", "Победи 1 бос.", "👑",
            ChallengeType.KILL_BOSS, 1, goldReward = 2000, divinityReward = 100, expReward = 1500, difficulty = "Средна"),
        DailyChallenge("d_kill_3boss", "Три Боса", "Победи 3 боса.", "🏆",
            ChallengeType.KILL_BOSS, 3, goldReward = 6000, divinityReward = 300, expReward = 4000, difficulty = "Трудна"),

        // Ability challenges
        DailyChallenge("d_ability_5", "Магьосник", "Използвай умения 5 пъти.", "✨",
            ChallengeType.USE_ABILITY, 5, goldReward = 400, divinityReward = 15, expReward = 200, difficulty = "Лесна"),
        DailyChallenge("d_ability_20", "Майстор Магьосник", "Използвай умения 20 пъти.", "🔮",
            ChallengeType.USE_ABILITY, 20, goldReward = 1200, divinityReward = 50, expReward = 700, difficulty = "Средна"),

        // Gold challenges
        DailyChallenge("d_gold_1000", "Търговец", "Спечели 1000 злато.", "💰",
            ChallengeType.EARN_GOLD, 1000, goldReward = 500, divinityReward = 10, expReward = 150, difficulty = "Лесна"),
        DailyChallenge("d_gold_5000", "Богаташ", "Спечели 5000 злато.", "💎",
            ChallengeType.EARN_GOLD, 5000, goldReward = 2500, divinityReward = 50, expReward = 750, difficulty = "Средна"),

        // Divinity challenges
        DailyChallenge("d_div_200", "Полубог за Ден", "Спечели 200 дивинити.", "✨",
            ChallengeType.EARN_DIVINITY, 200, goldReward = 1000, divinityReward = 100, expReward = 500, difficulty = "Средна"),
        DailyChallenge("d_div_1000", "Бог за Ден", "Спечели 1000 дивинити.", "🌟",
            ChallengeType.EARN_DIVINITY, 1000, goldReward = 3000, divinityReward = 500, expReward = 2000, difficulty = "Трудна"),

        // Survive challenges
        DailyChallenge("d_waves_5", "Арена Оцелял", "Оцелей 5 вълни в Арената.", "🏟️",
            ChallengeType.SURVIVE_WAVES, 5, goldReward = 2000, divinityReward = 80, expReward = 1000, difficulty = "Средна"),
        DailyChallenge("d_waves_10", "Арена Легенда", "Оцелей 10 вълни!", "🏆",
            ChallengeType.SURVIVE_WAVES, 10, goldReward = 8000, divinityReward = 400, expReward = 5000, skillPointReward = 1, difficulty = "Трудна"),

        // Special challenges
        DailyChallenge("d_absorb_5", "Поглъщач", "Погълни 5 сили от врагове.", "🌀",
            ChallengeType.ABSORB_POWER, 5, goldReward = 1500, divinityReward = 75, expReward = 800, difficulty = "Средна"),
        DailyChallenge("d_no_potion", "Чист Победител", "Победи бос без да използваш еликсир.", "🛡️",
            ChallengeType.NO_POTION_BOSS, 1, goldReward = 3000, divinityReward = 150, expReward = 2000, skillPointReward = 1, difficulty = "Трудна"),
        DailyChallenge("d_perfect", "Съвършена Битка", "Победи враг без да получиш щета.", "⭐",
            ChallengeType.PERFECT_BATTLE, 1, goldReward = 2000, divinityReward = 100, expReward = 1200, difficulty = "Средна")
    )

    val specialEvents = listOf(
        SpecialEvent("event_double_divinity", "🌟 ДВОЙНА ДИВИНИТИ", "Всички дивинити x2 за 24ч!",
            "✨", 2.0f, "divinity", 1, "Боговете са добре настроени. Поглъщай повече!"),
        SpecialEvent("event_dragon_invasion", "🐉 ДРАКОН ИНВАЗИЯ", "Дракони нахлуват! +50% злато от дракони.",
            "🐉", 1.5f, "gold_dragon", 2, "Армия дракони! Помогни да ги спрем!"),
        SpecialEvent("event_god_war", "⚡ ВОЙНА НА БОГОВЕТЕ", "Боговете воюват! +100% опит от богове.",
            "⚡", 2.0f, "exp_god", 3, "Зевс срещу Один срещу Ра. Хаос навсякъде."),
        SpecialEvent("event_chaos_rift", "🌀 РАЗЛОМ НА ХАОСА", "Хаотична енергия x3 дивинити!",
            "🌀", 3.0f, "divinity", 1, "Хаосът напуска Пандора. Поглъщай!"),
        SpecialEvent("event_harvest", "💰 ЖЪТВА НА ЗЛАТО", "x2 злато от всички врагове за 48ч.",
            "💰", 2.0f, "gold", 2, "Фараонът отвори хазната. Вземи колкото можеш!"),
        SpecialEvent("event_boss_week", "👑 СЕДМИЦА НА БОСОВЕТЕ", "Босове дават x3 от всичко!",
            "👑", 3.0f, "all_boss", 7, "Всяка митология изпраща найсилните си шампиони."),
        SpecialEvent("event_skill_boost", "🌳 УМЕНИЕ ПРИЛИВ", "Всички умения -50% мана за 24ч.",
            "🔮", 0.5f, "mana_cost", 1, "Мистична енергия тече свободно из световете.")
    )

    // ─────────────────────────────────────────────
    //  DAILY GENERATION
    // ─────────────────────────────────────────────

    fun getTodaysChallenges(character: Character): List<DailyChallenge> {
        val cal = Calendar.getInstance()
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val seed = dayOfYear + character.level

        val rng = java.util.Random(seed.toLong())
        val easy = challengePool.filter { it.difficulty == "Лесна" }.shuffled(rng).take(1)
        val medium = challengePool.filter { it.difficulty == "Средна" }.shuffled(rng).take(2)
        val hard = challengePool.filter { it.difficulty == "Трудна" }.shuffled(rng).take(1)
        return (easy + medium + hard).map { it.copy() }
    }

    fun getTodaysEvent(): SpecialEvent? {
        val cal = Calendar.getInstance()
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        return if (dayOfYear % 3 == 0) specialEvents[dayOfYear % specialEvents.size] else null
    }

    fun updateProgress(challenges: MutableList<DailyChallenge>, type: ChallengeType, amount: Int = 1): List<DailyChallenge> {
        val newlyCompleted = mutableListOf<DailyChallenge>()
        challenges.filter { it.type == type && !it.completed }.forEach { ch ->
            ch.currentValue = minOf(ch.currentValue + amount, ch.targetValue)
            if (ch.currentValue >= ch.targetValue) {
                ch.completed = true
                newlyCompleted.add(ch)
            }
        }
        return newlyCompleted
    }

    fun claimReward(challenge: DailyChallenge, character: Character): String {
        if (!challenge.completed || challenge.claimed) return "Не можеш да вземеш тази награда."
        challenge.claimed = true
        character.gold += challenge.goldReward
        character.divinity += challenge.divinityReward
        character.gainExperience(challenge.expReward)
        character.updateDivinityTitle()
        return buildString {
            appendLine("✅ Взет: ${challenge.title}")
            if (challenge.goldReward > 0) appendLine("💰 +${challenge.goldReward} злато")
            if (challenge.divinityReward > 0) appendLine("✨ +${challenge.divinityReward} дивинити")
            if (challenge.expReward > 0) appendLine("⭐ +${challenge.expReward} опит")
            if (challenge.skillPointReward > 0) appendLine("🌟 +${challenge.skillPointReward} точки умения")
        }
    }

    fun getCompletionRate(challenges: List<DailyChallenge>): String {
        val done = challenges.count { it.completed }
        val total = challenges.size
        val pct = if (total > 0) (done * 100) / total else 0
        return "$done/$total ($pct%)"
    }
}

// ─────────────────────────────────────────────
//  DAILY CHALLENGE LORE & TIPS
// ─────────────────────────────────────────────

object ChallengeLore {
    val CHALLENGE_QUOTES = listOf(
        "\"Всеки ден е нов шанс да станеш бог.\" — Мистериозен Старец",
        "\"Боговете не почиват. Ти защо да почиваш?\" — Прометей",
        "\"Дневна дисциплина = вечна сила.\" — Спартански Воин",
        "\"Слабият пропуска дневните. Силният ги завършва и иска още.\" — Атина",
        "\"Всеки дракон убит днес = по-слаб дракон утре.\" — Дракон Ловецът",
        "\"Дивинитито се трупа капка по капка. Всеки ден.\" — Анубис",
        "\"Рагнарок не чака. Ти ще чакаш ли?\" — Один"
    )
    
    val SPECIAL_EVENT_LORE = mapOf(
        "event_double_divinity" to "Боговете са благосклонни. За 24 часа дивинитито тече двойно. Използвай момента.",
        "event_dragon_invasion" to "Армия дракони нахлува. Рядка възможност за редки материали и умения.",
        "event_god_war" to "Когато боговете воюват — смъртните печелят. Двоен опит от всички конфликти.",
        "event_chaos_rift" to "Хаосът напуска границите. Нестабилно е. Но нестабилното е мощно.",
        "event_harvest" to "Жетвата на боговете — моментът, когато всичко е наред. Злато навсякъде.",
        "event_boss_week" to "Всяка митология изпраща шампионите си. Вземи го като покана.",
        "event_skill_boost" to "Магическа енергия тече свободно. Умения без ограничения за 24 часа."
    )
    
    val COMPLETION_TIERS = mapOf(
        1 to ("Начало" to "Завърши 1 дневно предизвикателство."),
        7 to ("Постоянен" to "7 дни подред. Дисциплината е добродетел."),
        30 to ("Ветеран" to "30 дни подред! Ти си легенда на дисциплината."),
        100 to ("Безсмъртен" to "100 дни. Боговете те уважават."),
        365 to ("ГОДИШЕН БОГ" to "365 дни! Цяла година. Ти ставаш митология сам по себе си.")
    )
    
    fun getRandomQuote() = CHALLENGE_QUOTES.random()
    
    fun getEventLore(eventId: String) = SPECIAL_EVENT_LORE[eventId] ?: "Специално събитие. Редки ресурси чакат."
    
    fun getCompletionMessage(totalCompleted: Int): String {
        val tier = COMPLETION_TIERS.entries.filter { it.key <= totalCompleted }.maxByOrNull { it.key }
        return tier?.let { (_, nameDesc) -> "🏆 ${nameDesc.first}: ${nameDesc.second}" }
            ?: "Продължавай! Легендите се градят с всеки ден."
    }
    
    fun generateDailyMotivation(character: com.mythosrise.game.models.Character): String {
        val messages = listOf(
            "Днес е шанс да убиеш бог. Готов ли си, ${character.name}?",
            "Дивинитито чака. Само трябва да го вземеш.",
            "Вчера беше полубог. Днес — може да станеш бог.",
            "Прометей е верижен за вечността. Ти си свободен. Действай.",
            "Рагнарок може да дойде утре. Днес — стани по-силен.",
            "Хаосът в теб чака да се освободи.",
            "Всеки враг убит днес — сила поглъщана завинаги.",
            "Мьолнир чака герой. Кусанаги чака воин. Ти ли си?"
        )
        return messages.random()
    }
}
