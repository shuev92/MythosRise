package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*
import com.mythosrise.game.models.Character

class PrestigeActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentTab = "Престиж"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prestige)
        engine = GameEngine(this)
        engine.loadGame()
        llContent = findViewById(R.id.llPrestigeContent)
        tvHeader = findViewById(R.id.tvPrestigeHeader)
        setupTabs()
        showPrestigeTab()
    }

    private fun setupTabs() {
        val tabs = listOf("Престиж", "Статистики", "Класация", "Елементи")
        val ll = findViewById<LinearLayout>(R.id.llPrestigeTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            val btn = Button(this).apply {
                text = tab; textSize = 11f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (tab == currentTab) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0); layoutParams = lp
                setOnClickListener {
                    currentTab = tab; setupTabs()
                    when (tab) {
                        "Престиж" -> showPrestigeTab()
                        "Статистики" -> showStatsTab()
                        "Класация" -> showLeaderboardTab()
                        "Елементи" -> showElementsTab()
                    }
                }
            }
            ll.addView(btn)
        }
    }

    // ── PRESTIGE TAB ──
    private fun showPrestigeTab() {
        llContent.removeAllViews()
        val c = engine.character
        val canPrestige = PrestigeSystem.canPrestige(c)
        val tier = PrestigeSystem.getPrestigeTier(c.prestigeCount)

        tvHeader.text = "${tier.emoji} ${tier.displayName} | Престиж: ${c.prestigeCount}x"

        // Current status
        addSection("📊 СТАТУС НА ПРЕСТИЖ")
        addInfo(PrestigeSystem.getPrestigeDescription(c))

        // Prestige button
        val prestigeBtn = Button(this).apply {
            text = if (canPrestige) "⭐ НАПРАВИ ПРЕСТИЖ!" else "🔒 Нужни: Ниво 50 + 50 000 Дивинити\n(Имаш: Ниво ${c.level}, ✨${c.divinity})"
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (canPrestige) Color.parseColor("#FF8800") else Color.parseColor("#333333")
            )
            isEnabled = canPrestige
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 8, 0, 16); layoutParams = lp
            setOnClickListener {
                AlertDialog.Builder(this@PrestigeActivity)
                    .setTitle("⭐ ПРЕСТИЖ!")
                    .setMessage("Ще загубиш всичко освен Митичните+ предмети.\nЩе получиш постоянни бонуси.\n\nСигурен ли си?")
                    .setPositiveButton("ДА, ПРЕСТИЖ!") { _, _ ->
                        val msg = PrestigeSystem.performPrestige(c)
                        engine.saveGame()
                        AlertDialog.Builder(this@PrestigeActivity)
                            .setTitle("⭐ ПРЕСТИЖ ЗАВЪРШЕН!")
                            .setMessage(msg)
                            .setPositiveButton("Продължи!") { _, _ ->
                                setupTabs(); showPrestigeTab()
                            }.show()
                    }
                    .setNegativeButton("Не", null)
                    .show()
            }
        }
        llContent.addView(prestigeBtn)

        // Prestige upgrades
        addSection("⬆️ ПРЕСТИЖ ПОДОБРЕНИЯ (Точки: ${c.prestigePoints})")
        PrestigeSystem.PRESTIGE_UPGRADES.forEach { upg ->
            val cost = upg.cost * (upg.currentLevel + 1)
            val maxed = upg.currentLevel >= upg.maxLevel
            val canAfford = c.prestigePoints >= cost && !maxed

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (maxed) Color.parseColor("#001A00") else Color.parseColor("#0A0A1A"))
                setPadding(12, 8, 12, 8)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "${upg.emoji} ${upg.name} [${upg.currentLevel}/${upg.maxLevel}]"
                setTextColor(if (maxed) Color.parseColor("#FFD700") else Color.WHITE)
                textSize = 13f; isFakeBoldText = maxed
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "${upg.bonusPerLevel} | Цена: $cost точки"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            row.addView(info)

            if (!maxed) {
                Button(this).apply {
                    text = if (canAfford) "⬆️" else "🔒"
                    textSize = 13f; isEnabled = canAfford; setTextColor(Color.WHITE)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(
                        if (canAfford) Color.parseColor("#6A0DAD") else Color.parseColor("#333333")
                    )
                    val lp = LinearLayout.LayoutParams(80, LinearLayout.LayoutParams.WRAP_CONTENT); layoutParams = lp
                    setOnClickListener {
                        if (PrestigeSystem.upgradePrestige(upg, c)) {
                            engine.saveGame(); showPrestigeTab()
                            Toast.makeText(this@PrestigeActivity, "✅ ${upg.name} улучшен!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.also { row.addView(it) }
            } else {
                TextView(this).apply { text = "✅ MAX"; setTextColor(Color.parseColor("#FFD700")); textSize = 12f }.also { row.addView(it) }
            }
            llContent.addView(row)
        }
    }

    // ── STATS TAB ──
    private fun showStatsTab() {
        llContent.removeAllViews()
        tvHeader.text = "📊 СТАТИСТИКИ"
        val stats = loadStats()
        val c = engine.character

        addSection("⚔️ БОЙНИ СТАТИСТИКИ")
        addInfo("Общо битки: ${stats.totalBattles} | Победи: ${stats.battlesWon}")
        addInfo("Убити врагове: ${stats.totalEnemiesKilled}")
        addInfo("Убити богове: ${stats.totalGodsKilled} | Титани: ${stats.totalTitansKilled}")
        addInfo("Убити дракони: ${stats.totalDragonsKilled}")
        addInfo("Максимален удар: ${stats.highestSingleHit}")
        addInfo("Крит хитове: ${stats.totalCriticalHits}")
        addInfo("Перфектни битки: ${stats.perfectBattles}")

        addSection("💰 ИКОНОМИКА")
        addInfo("Спечелено злато: ${stats.totalGoldEarned}")
        addInfo("Занаятени предмети: ${stats.itemsCrafted}")

        addSection("✨ ДИВИНИТИ")
        addInfo("Общо спечелено: ${stats.totalDivinityEarned}")
        addInfo("Максимум достигнат: ${stats.highestDivinityReached}")
        addInfo("Погълнати сили: ${stats.totalPowersAbsorbed}")

        addSection("🏆 ПОСТИЖЕНИЯ")
        addInfo("Куестове: ${stats.questsCompleted}")
        addInfo("Постижения: ${stats.achievementsUnlocked}")
        addInfo("Дневни: ${stats.dailyChallengesCompleted}")
        addInfo("Boss Rush: ${stats.bossRushesCompleted}")
        addInfo("Макс. вълна Арена: ${stats.highestWaveReached}")

        addSection("🌟 ПОСТИЖЕНИЯ-ВЕХИ")
        val milestones = StatisticsManager.getMilestones(stats)
        if (milestones.isEmpty()) addInfo("Все още без вехи. Продължавай!")
        else milestones.forEach { addInfo(it) }

        addSection("🎯 РЕЗУЛТАТ")
        val score = StatisticsManager.calculateScore(c, stats)
        addInfo("Общ резултат: ${score.let { "%,d".format(it) }}")
    }

    // ── LEADERBOARD TAB ──
    private fun showLeaderboardTab() {
        llContent.removeAllViews()
        tvHeader.text = "🏆 КЛАСАЦИЯ"
        val stats = loadStats()
        val board = StatisticsManager.generateLocalLeaderboard(engine.character, stats)

        addSection("🏆 ТОП 10 ИГРАЧИ")
        board.take(10).forEach { entry ->
            val isPlayer = entry.name == engine.character.name
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(if (isPlayer) Color.parseColor("#1A0A2E") else Color.parseColor("#0A0A0A"))
                setPadding(12, 8, 12, 8)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            val rankEmoji = when (entry.rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "#${entry.rank}" }
            TextView(this).apply {
                text = rankEmoji; textSize = 20f; setPadding(0, 0, 10, 0)
            }.also { row.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = "${entry.heroClass.emoji} ${entry.name}${if (isPlayer) " (ТИ)" else ""}"
                setTextColor(if (isPlayer) Color.parseColor("#FFD700") else Color.WHITE)
                textSize = 14f; isFakeBoldText = isPlayer
            }.also { info.addView(it) }
            TextView(this).apply {
                text = "Ниво ${entry.level} | ✨${entry.divinity} | ${entry.divinityTitle}"
                setTextColor(Color.GRAY); textSize = 11f
            }.also { info.addView(it) }
            row.addView(info)
            TextView(this).apply {
                text = "%,d".format(entry.score); setTextColor(Color.parseColor("#FFD700")); textSize = 12f
            }.also { row.addView(it) }
            llContent.addView(row)
        }
    }

    // ── ELEMENTS TAB ──
    private fun showElementsTab() {
        llContent.removeAllViews()
        tvHeader.text = "⚗️ ЕЛЕМЕНТАРНА СИСТЕМА"
        addSection("🔥 СИЛНИ ВЗАИМОДЕЙСТВИЯ")
        addInfo("🔥 Огън → разтопява ❄️ Лед и 💨 Вятър")
        addInfo("❄️ Лед → охлажда 🔥 Огън и 🌍 Земя")
        addInfo("⚡ Мълния → удря 🌊 Вода и ❄️ Лед")
        addInfo("✨ Свят → пречиства 🌑 Сянка и 🌀 Хаос")
        addInfo("🌑 Сянка → поглъща ✨ Свят и 🌟 Дивин")
        addInfo("🌊 Вода → гаси 🔥 Огън и 🌍 Земя")
        addInfo("🌀 Хаос → разрушава 🌟 Дивин и ✨ Свят")
        addSection("🛡️ ИМУНИТЕТИ")
        addInfo("🌑 Сянка → имунна срещу 🐍 Отрова")
        addInfo("🌟 Дивин → имунен срещу 🐍 Отрова и 🔥 Огън")
        addInfo("🌀 Хаос → имунен срещу ❄️ Лед и 🌊 Вода")
        addSection("💡 СЪВЕТ")
        addInfo("Провери елемента на врага преди битка! Правилният елемент нанася 2x урон!")
        Element.values().forEach { elem ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 5, 8, 5)
            }
            TextView(this).apply {
                text = "${elem.emoji} ${elem.displayName}"
                setTextColor(Color.parseColor(elem.color))
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }.also { row.addView(it) }
            llContent.addView(row)
        }
    }

    // ── HELPERS ──
    private fun addSection(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#9B59B6"))
            textSize = 14f; isFakeBoldText = true; setPadding(4, 14, 4, 4)
        }.also { llContent.addView(it) }
    }

    private fun addInfo(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.LTGRAY)
            textSize = 12f; setPadding(12, 3, 4, 3)
        }.also { llContent.addView(it) }
    }

    private fun loadStats(): GameStatistics {
        val c = engine.character
        return GameStatistics(
            totalEnemiesKilled = c.enemiesDefeated,
            totalGodsKilled = c.godsDefeated,
            totalTitansKilled = c.titansDefeated,
            totalPowersAbsorbed = c.absorbedPowers.size,
            totalDivinityEarned = c.divinity.toLong(),
            highestDivinityReached = c.divinity,
            questsCompleted = c.enemiesDefeated / 10,
            achievementsUnlocked = AchievementManager.getUnlockedCount(),
            prestigeCount = c.prestigeCount
        )
    }
}
