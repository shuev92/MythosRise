package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.engine.TransformationSystem

class TransformationActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llForms: LinearLayout
    private lateinit var tvHeader: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transformation)
        engine = GameEngine(this)
        engine.loadGame()
        llForms = findViewById(R.id.llTransformationList)
        tvHeader = findViewById(R.id.tvTransformationHeader)
        renderForms()
    }

    private fun renderForms() {
        llForms.removeAllViews()
        val c = engine.character
        val available = TransformationSystem.getAvailableForms(c)
        val locked = TransformationSystem.getLockedForms(c)

        tvHeader.text = "✨ БОЖЕСТВЕНИ ФОРМИ (${available.size}/${TransformationSystem.ALL_FORMS.size} отключени)"

        if (available.isNotEmpty()) {
            addSectionHeader("✅ ОТКЛЮЧЕНИ ФОРМИ")
            available.forEach { form -> addFormCard(form, true) }
        }

        if (locked.isNotEmpty()) {
            addSectionHeader("🔒 ЗАКЛЮЧЕНИ ФОРМИ")
            locked.forEach { form -> addFormCard(form, false) }
        }
    }

    private fun addSectionHeader(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#FFD700"))
            textSize = 15f; isFakeBoldText = true; setPadding(4, 16, 4, 8)
        }.also { llForms.addView(it) }
    }

    private fun addFormCard(form: com.mythosrise.game.engine.DivineForm, isUnlocked: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (isUnlocked) Color.parseColor("#0A1020") else Color.parseColor("#080808"))
            setPadding(14, 12, 14, 12)
            alpha = if (isUnlocked) 1.0f else 0.45f
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 6, 0, 6); layoutParams = lp
        }

        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        TextView(this).apply { text = form.emoji; textSize = 32f; setPadding(0, 0, 12, 0) }.also { titleRow.addView(it) }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        TextView(this).apply {
            text = form.name
            setTextColor(Color.parseColor(form.auraColor)); textSize = 15f; isFakeBoldText = true
        }.also { info.addView(it) }
        TextView(this).apply {
            text = form.description; setTextColor(Color.LTGRAY); textSize = 12f
        }.also { info.addView(it) }
        titleRow.addView(info)
        card.addView(titleRow)

        // Stats grid
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 4)
        }
        listOf(
            "⚔️ x${form.attackMultiplier}",
            "🛡️ x${form.defenseMultiplier}",
            "❤️ +${(form.healthRegenPercent*100).toInt()}%/ход",
            "⏱️ ${form.durationSeconds}с"
        ).forEach { stat ->
            TextView(this).apply {
                text = stat; setTextColor(Color.parseColor("#88AAFF"))
                textSize = 11f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }.also { statsRow.addView(it) }
        }
        card.addView(statsRow)

        // Special effect
        TextView(this).apply {
            text = "⚡ ${form.specialEffect}"; setTextColor(Color.parseColor("#FFAA44")); textSize = 11f
        }.also { card.addView(it) }

        // Requirements
        val reqs = buildString {
            append("📋 ✨ ${form.requiredDivinity} Дивинити")
            form.requiredAbsorbedGod?.let { append(" + Погълнал: $it") }
        }
        TextView(this).apply {
            text = reqs; setTextColor(Color.GRAY); textSize = 10f
        }.also { card.addView(it) }

        if (isUnlocked) {
            Button(this).apply {
                text = "🔮 АКТИВИРАЙ: ${form.name}"
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#6A0DAD"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 8, 0, 0); layoutParams = lp
                setOnClickListener {
                    val result = TransformationSystem.activateForm(form, engine.character)
                    AlertDialog.Builder(this@TransformationActivity)
                        .setTitle("${form.emoji} ТРАНСФОРМАЦИЯ!")
                        .setMessage(buildString {
                            appendLine(result.message)
                            appendLine()
                            appendLine("⚔️ ATK бонус: +${result.attackBonus}")
                            appendLine("🛡️ DEF бонус: +${result.defenseBonus}")
                            appendLine("⏱️ Продължава: ${form.durationSeconds} секунди")
                            appendLine()
                            appendLine("⚡ ${form.specialEffect}")
                        })
                        .setPositiveButton("ПРЕРАЖДАМ СЕ!") { _, _ ->
                            engine.character.attack += result.attackBonus
                            engine.character.defense += result.defenseBonus
                            engine.saveGame()
                            Toast.makeText(this@TransformationActivity,
                                "${form.emoji} ${form.name} активирана!", Toast.LENGTH_LONG).show()
                        }
                        .show()
                }
            }.also { card.addView(it) }
        }
        llForms.addView(card)
    }
}
