package com.mythosrise.game.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine

class MainMenuActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        engine = GameEngine(this)

        val btnNewGame = findViewById<Button>(R.id.btnNewGame)
        val btnContinue = findViewById<Button>(R.id.btnContinue)
        val btnAbout = findViewById<Button>(R.id.btnAbout)

        // Show continue only if save exists
        btnContinue.visibility = if (engine.hasSave()) View.VISIBLE else View.GONE

        btnNewGame.setOnClickListener {
            if (engine.hasSave()) {
                AlertDialog.Builder(this)
                    .setTitle("Нова игра")
                    .setMessage("Имаш запазена игра. Сигурен ли си, че искаш да започнеш отначало?")
                    .setPositiveButton("Да") { _, _ ->
                        engine.deleteSave()
                        startActivity(Intent(this, CharacterCreationActivity::class.java))
                    }
                    .setNegativeButton("Не", null)
                    .show()
            } else {
                startActivity(Intent(this, CharacterCreationActivity::class.java))
            }
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
        }

        btnContinue.setOnClickListener {
            if (engine.loadGame()) {
                startActivity(Intent(this, WorldMapActivity::class.java))
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
            }
        }

        btnAbout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("🌌 За Mythos Rise")
                .setMessage("""
                    ⚔️ MYTHOS RISE ⚔️
                    
                    Епична RPG с митологии от целия свят.
                    
                    🏛️ Гръцки богове
                    🕉️ Индийски богове  
                    ⚡ Скандинавски богове
                    🌋 Титани
                    🌌 Първичния Хаос
                    
                    Поглъщай силите на враговете.
                    Стани ВСЕБОГ.
                    
                    Версия 1.0.0
                """.trimIndent())
                .setPositiveButton("Разбрах!", null)
                .show()
        }
    }
}
