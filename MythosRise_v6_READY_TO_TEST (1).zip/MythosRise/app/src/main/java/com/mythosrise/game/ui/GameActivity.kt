package com.mythosrise.game.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.BounceInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.*

class GameActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private var isBattleAnimating = false

    // UI Views
    private lateinit var tvEnemyName: TextView
    private lateinit var tvEnemyHp: TextView
    private lateinit var pbEnemyHp: ProgressBar
    private lateinit var tvEnemyEmoji: TextView
    private lateinit var tvEnemyDesc: TextView

    private lateinit var tvPlayerName: TextView
    private lateinit var tvPlayerHp: TextView
    private lateinit var pbPlayerHp: ProgressBar
    private lateinit var tvPlayerMana: TextView
    private lateinit var pbPlayerMana: ProgressBar
    private lateinit var tvPlayerEmoji: TextView
    private lateinit var tvDivinityTitle: TextView

    private lateinit var tvBattleLog: TextView
    private lateinit var svBattleLog: ScrollView

    private lateinit var btnAttack: Button
    private lateinit var btnAbilities: Button
    private lateinit var btnFlee: Button
    private lateinit var btnPotion: Button

    private lateinit var llDialogue: LinearLayout
    private lateinit var tvDialogueSpeaker: TextView
    private lateinit var tvDialogueText: TextView
    private lateinit var llChoices: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var currentDialogue: Dialogue? = null
    private var dialogueIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        engine = GameEngine(this)
        engine.loadGame()

        bindViews()

        val showIntro = intent.getBooleanExtra("show_intro", false)
        val enemyId = intent.getStringExtra("enemy_id")

        if (showIntro) {
            showDialogue("intro")
        } else if (enemyId != null) {
            val enemy = GameDatabase.ALL_ENEMIES.find { it.id == enemyId }
            if (enemy != null) {
                // Show pre-battle dialogue for bosses
                val dialogueId = when (enemy.id) {
                    "zeus" -> "zeus_pre_battle"
                    "shiva" -> "shiva_pre_battle"
                    "kronos" -> "kronos_pre_battle"
                    "primordial" -> "final_boss"
                    else -> null
                }
                if (dialogueId != null && enemy.isBoss) {
                    showDialogue(dialogueId, afterDialogue = { startBattleWithEnemy(enemy) })
                } else {
                    startBattleWithEnemy(enemy)
                }
            }
        }
    }

    private fun bindViews() {
        tvEnemyName = findViewById(R.id.tvEnemyName)
        tvEnemyHp = findViewById(R.id.tvEnemyHp)
        pbEnemyHp = findViewById(R.id.pbEnemyHp)
        tvEnemyEmoji = findViewById(R.id.tvEnemyEmoji)
        tvEnemyDesc = findViewById(R.id.tvEnemyDesc)

        tvPlayerName = findViewById(R.id.tvPlayerName)
        tvPlayerHp = findViewById(R.id.tvPlayerHp)
        pbPlayerHp = findViewById(R.id.pbPlayerHp)
        tvPlayerMana = findViewById(R.id.tvPlayerMana)
        pbPlayerMana = findViewById(R.id.pbPlayerMana)
        tvPlayerEmoji = findViewById(R.id.tvPlayerEmoji)
        tvDivinityTitle = findViewById(R.id.tvDivinityTitle)

        tvBattleLog = findViewById(R.id.tvBattleLog)
        svBattleLog = findViewById(R.id.svBattleLog)

        btnAttack = findViewById(R.id.btnAttack)
        btnAbilities = findViewById(R.id.btnAbilities)
        btnFlee = findViewById(R.id.btnFlee)
        btnPotion = findViewById(R.id.btnPotion)

        llDialogue = findViewById(R.id.llDialogue)
        tvDialogueSpeaker = findViewById(R.id.tvDialogueSpeaker)
        tvDialogueText = findViewById(R.id.tvDialogueText)
        llChoices = findViewById(R.id.llDialogueChoices)

        setupButtonListeners()
    }

    private fun setupButtonListeners() {
        btnAttack.setOnClickListener {
            if (!isBattleAnimating && engine.isPlayerTurn) {
                doPlayerAttack()
            }
        }

        btnAbilities.setOnClickListener {
            if (!isBattleAnimating && engine.isPlayerTurn) {
                showAbilitiesDialog()
            }
        }

        btnPotion.setOnClickListener {
            showPotionDialog()
        }

        btnFlee.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Бягство")
                .setMessage("Сигурен ли си, че искаш да бягаш от битката?")
                .setPositiveButton("Бягай!") { _, _ ->
                    engine.saveGame()
                    startActivity(Intent(this, WorldMapActivity::class.java))
                    finish()
                }
                .setNegativeButton("Продължи да се биеш", null)
                .show()
        }
    }

    // ─────────────────────────────────────────────
    //  DIALOGUE SYSTEM
    // ─────────────────────────────────────────────

    private var afterDialogueCallback: (() -> Unit)? = null

    private fun showDialogue(dialogueId: String, afterDialogue: (() -> Unit)? = null) {
        currentDialogue = GameDatabase.getDialogueById(dialogueId) ?: return
        dialogueIndex = 0
        afterDialogueCallback = afterDialogue
        llDialogue.visibility = View.VISIBLE
        setButtonsEnabled(false)
        showNextDialogueLine()
    }

    private fun showNextDialogueLine() {
        val dialogue = currentDialogue ?: return
        if (dialogueIndex >= dialogue.lines.size) {
            endDialogue()
            return
        }
        val line = dialogue.lines[dialogueIndex]
        val speakerName = if (line.speaker.contains("%s")) {
            line.speaker.replace("%s", engine.character.name)
        } else line.speaker

        tvDialogueSpeaker.text = "${line.emoji} $speakerName"
        tvDialogueText.text = line.text

        llChoices.removeAllViews()

        if (line.choices.isNotEmpty()) {
            // Show choices
            line.choices.forEach { choice ->
                val btn = Button(this).apply {
                    text = choice.text
                    setBackgroundColor(Color.parseColor("#4A1A6B"))
                    setTextColor(Color.WHITE)
                    setOnClickListener {
                        choice.effect?.let { applyDialogueEffect(it) }
                        dialogueIndex++
                        showNextDialogueLine()
                    }
                }
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.setMargins(0, 8, 0, 8)
                btn.layoutParams = lp
                llChoices.addView(btn)
            }
        } else {
            // Tap to continue
            llDialogue.setOnClickListener {
                dialogueIndex++
                showNextDialogueLine()
            }
        }
    }

    private fun applyDialogueEffect(effect: DialogueEffect) {
        effect.goldChange.takeIf { it != 0 }?.let { engine.character.gold += it }
        effect.expChange.takeIf { it != 0 }?.let { engine.character.gainExperience(it.toLong()) }
        effect.divinityChange.takeIf { it != 0 }?.let {
            engine.character.divinity += it
            engine.character.updateDivinityTitle()
        }
        effect.itemId?.let { id ->
            GameDatabase.getItemById(id)?.let { engine.character.inventory.add(it) }
        }
    }

    private fun endDialogue() {
        llDialogue.visibility = View.GONE
        llDialogue.setOnClickListener(null)
        currentDialogue = null
        afterDialogueCallback?.invoke()
        afterDialogueCallback = null
    }

    // ─────────────────────────────────────────────
    //  BATTLE
    // ─────────────────────────────────────────────

    private fun startBattleWithEnemy(enemy: Enemy) {
        engine.startBattle(enemy)
        updateAllUI()
        setButtonsEnabled(true)

        if (enemy.isBoss) {
            // Boss entrance animation
            val shake = ObjectAnimator.ofFloat(tvEnemyEmoji, "translationX", 0f, 30f, -30f, 20f, -20f, 0f)
            shake.duration = 800
            shake.start()
        }
    }

    private fun doPlayerAttack() {
        isBattleAnimating = true
        setButtonsEnabled(false)

        // Attack animation
        animatePlayerAttack {
            val result = engine.playerAttack()
            updateAllUI()

            if (result.enemyDied) {
                showVictoryForBattle()
            } else {
                // Enemy turn
                handler.postDelayed({
                    val enemyResult = engine.enemyAttack()
                    updateAllUI()
                    animateEnemyAttack {}
                    if (enemyResult.playerDied) {
                        showGameOver()
                    } else {
                        isBattleAnimating = false
                        setButtonsEnabled(true)
                    }
                }, 800)
            }
        }
    }

    private fun showAbilitiesDialog() {
        val abilities = engine.character.abilities
        if (abilities.isEmpty()) {
            Toast.makeText(this, "Нямаш умения!", Toast.LENGTH_SHORT).show()
            return
        }

        val items = abilities.map { ability ->
            val cdText = if (ability.currentCooldown > 0) " (CD: ${ability.currentCooldown})" else ""
            val divinityText = if (ability.requiredDivinity > 0) " [✨${ability.requiredDivinity}]" else ""
            "${ability.emoji} ${ability.name}$cdText$divinityText\n💙${ability.manaCost} мана | ${ability.description}"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("⚡ Умения")
            .setItems(items) { _, which ->
                val ability = abilities[which]
                isBattleAnimating = true
                setButtonsEnabled(false)

                val result = engine.playerUseAbility(ability)
                addToBattleLog(result.log)
                updateAllUI()

                if (result.log.contains("❌") || result.log.contains("⏳") || result.log.contains("🚫")) {
                    isBattleAnimating = false
                    setButtonsEnabled(true)
                    return@setItems
                }

                if (result.enemyDied) {
                    showVictoryForBattle()
                } else {
                    handler.postDelayed({
                        val enemyResult = engine.enemyAttack()
                        updateAllUI()
                        if (enemyResult.playerDied) showGameOver()
                        else {
                            isBattleAnimating = false
                            setButtonsEnabled(true)
                        }
                    }, 800)
                }
            }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun showPotionDialog() {
        val potions = engine.character.inventory.filter { it.type == ItemType.POTION }
        if (potions.isEmpty()) {
            Toast.makeText(this, "Нямаш еликсири!", Toast.LENGTH_SHORT).show()
            return
        }
        val items = potions.map { "${it.emoji} ${it.name}: ${it.description}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("🧪 Еликсири")
            .setItems(items) { _, which ->
                val msg = engine.usePotion(potions[which])
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                updateAllUI()
            }
            .setNegativeButton("Назад", null)
            .show()
    }

    // ─────────────────────────────────────────────
    //  UPDATE UI
    // ─────────────────────────────────────────────

    private fun updateAllUI() {
        updatePlayerUI()
        updateEnemyUI()
        updateBattleLog()
    }

    private fun updatePlayerUI() {
        val c = engine.character
        tvPlayerName.text = "${c.name} | Ниво ${c.level}"
        tvDivinityTitle.text = c.divinityTitle.title
        tvPlayerHp.text = "❤️ ${c.health}/${c.getTotalMaxHealth()}"
        pbPlayerHp.max = c.getTotalMaxHealth()
        pbPlayerHp.progress = c.health
        tvPlayerMana.text = "💙 ${c.mana}/${c.maxMana}"
        pbPlayerMana.max = c.maxMana
        pbPlayerMana.progress = c.mana
        tvPlayerEmoji.text = when (c.heroClass) {
            HeroClass.WARRIOR -> "🤺"
            HeroClass.MAGE -> "🧙"
            HeroClass.ARCHER -> "🏹"
            HeroClass.MONK -> "🥋"
        }
    }

    private fun updateEnemyUI() {
        val enemy = engine.currentEnemy ?: return
        tvEnemyName.text = "${enemy.mythology} | ${enemy.name}"
        tvEnemyHp.text = "❤️ ${enemy.currentHealth}/${enemy.maxHealth}"
        pbEnemyHp.max = enemy.maxHealth
        pbEnemyHp.progress = enemy.currentHealth
        tvEnemyEmoji.text = enemy.emoji
        tvEnemyDesc.text = if (enemy.isBoss) "⚠️ БОШОВ ВРАГ" else "Ниво ${enemy.level}"
    }

    private fun updateBattleLog() {
        tvBattleLog.text = engine.battleLog.takeLast(8).joinToString("\n")
        svBattleLog.post { svBattleLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun addToBattleLog(text: String) {
        engine.battleLog.add(text)
        updateBattleLog()
    }

    // ─────────────────────────────────────────────
    //  ANIMATIONS
    // ─────────────────────────────────────────────

    private fun animatePlayerAttack(onEnd: () -> Unit) {
        val anim = ObjectAnimator.ofFloat(tvPlayerEmoji, "translationX", 0f, 80f, 0f)
        anim.duration = 300
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) { onEnd() }
        })
        anim.start()
    }

    private fun animateEnemyAttack(onEnd: () -> Unit) {
        val anim = ObjectAnimator.ofFloat(tvEnemyEmoji, "translationX", 0f, -80f, 0f)
        anim.duration = 300
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) { onEnd() }
        })
        anim.start()
    }

    // ─────────────────────────────────────────────
    //  RESULTS
    // ─────────────────────────────────────────────

    private fun showVictoryForBattle() {
        val enemy = engine.currentEnemy!!
        val droppedItem = engine.character.inventory.lastOrNull()?.takeIf {
            engine.battleLog.any { log -> log.contains(it.name) }
        }

        val msg = buildString {
            append("⚔️ Победи ${enemy.name}!\n\n")
            append("✨ +${enemy.divinityReward} Дивинити\n")
            append("⭐ +${enemy.expReward} Опит\n")
            append("💰 +${enemy.goldReward} Злато\n")
            if (droppedItem != null) append("\n🎁 Намерен: ${droppedItem.emoji} ${droppedItem.name}!")
            append("\n\n🔮 Погълна силата на ${enemy.name}!")
            append("\nОбщо Дивинити: ${engine.character.divinity}")
            append("\n${engine.character.divinityTitle.title}")
        }

        AlertDialog.Builder(this)
            .setTitle("🏆 ПОБЕДА!")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("Продължи") { _, _ ->
                engine.saveGame()
                startActivity(Intent(this, WorldMapActivity::class.java))
                finish()
            }
            .show()
    }

    private fun showGameOver() {
        AlertDialog.Builder(this)
            .setTitle("💀 ЗАГИНАЛ")
            .setMessage("${engine.character.name} пада в битка...\n\nНо смъртта е само началото.\n\nПрогресът ти е запазен!")
            .setCancelable(false)
            .setPositiveButton("Опитай пак") { _, _ ->
                // Revive with half health
                engine.character.health = engine.character.getTotalMaxHealth() / 2
                engine.saveGame()
                startActivity(Intent(this, WorldMapActivity::class.java))
                finish()
            }
            .setNegativeButton("Главно меню") { _, _ ->
                startActivity(Intent(this, MainMenuActivity::class.java))
                finishAffinity()
            }
            .show()
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        btnAttack.isEnabled = enabled
        btnAbilities.isEnabled = enabled
        btnFlee.isEnabled = enabled
        btnPotion.isEnabled = enabled
    }
}
