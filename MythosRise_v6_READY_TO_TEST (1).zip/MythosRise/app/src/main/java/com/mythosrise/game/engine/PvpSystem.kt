package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.HeroClass
import kotlin.math.max
import kotlin.random.Random

// ─────────────────────────────────────────────
//  PVP RATING
// ─────────────────────────────────────────────

enum class PvpRank(val displayName: String, val emoji: String, val minRating: Int, val color: String) {
    BRONZE("Бронзов", "🥉", 0, "#CD7F32"),
    SILVER("Сребърен", "🥈", 1000, "#C0C0C0"),
    GOLD("Златен", "🥇", 1500, "#FFD700"),
    PLATINUM("Платинен", "💎", 2000, "#E5E4E2"),
    DIAMOND("Диамантен", "💠", 2500, "#B9F2FF"),
    MASTER("Майстор", "🔮", 3000, "#9B59B6"),
    GRANDMASTER("Грандмайстор", "👑", 3500, "#FF8800"),
    OMNIGOD_RANK("Всебог", "🌌", 4000, "#FF00FF")
}

// ─────────────────────────────────────────────
//  PVP OPPONENT
// ─────────────────────────────────────────────

data class PvpOpponent(
    val name: String,
    val heroClass: HeroClass,
    val level: Int,
    val divinity: Int,
    val rating: Int,
    val attack: Int,
    val defense: Int,
    val health: Int,
    val maxHealth: Int,
    val abilities: List<String>,
    val divinityTitle: String,
    val winRate: Float,
    val country: String = "🌍",
    val favoriteWorld: String = "Олимп",
    val pvpStyle: String = "Агресивен"
)

// ─────────────────────────────────────────────
//  PVP MATCH RESULT
// ─────────────────────────────────────────────

data class PvpMatchResult(
    val won: Boolean,
    val opponent: PvpOpponent,
    val playerDamageDealt: Int,
    val opponentDamageDealt: Int,
    val turnsPlayed: Int,
    val ratingChange: Int,
    val goldReward: Int,
    val divinityReward: Int,
    val mvpMoment: String,
    val matchLog: List<String>
)

// ─────────────────────────────────────────────
//  PVP SYSTEM
// ─────────────────────────────────────────────

object PvpSystem {

    val OPPONENTS_POOL = listOf(
        PvpOpponent("DragonSlayer_BG", HeroClass.WARRIOR, 45, 30000, 3800, 850, 400, 4500, 4500,
            listOf("Берсерк", "Дракон Огън"), "Легенда", 0.72f, "🇧🇬", "Дракон Царство", "Агресивен"),
        PvpOpponent("ZeusKiller99", HeroClass.MAGE, 42, 28000, 3500, 1200, 250, 3000, 3000,
            listOf("Гръм Буря", "Метеор"), "Митичен Герой", 0.68f, "🇷🇺", "Олимп", "Изблаговен"),
        PvpOpponent("NorseWarrior", HeroClass.WARRIOR, 38, 20000, 2800, 700, 550, 5000, 5000,
            listOf("Берсерк Ярост", "Железен Щит"), "Олимпиец", 0.61f, "🇸🇪", "Асгард", "Танк"),
        PvpOpponent("SunWukongFan", HeroClass.MONK, 40, 25000, 3200, 900, 350, 3500, 3500,
            listOf("72 Форми", "Железен Юмрук"), "Легенда", 0.65f, "🇨🇳", "Китай", "Комбо"),
        PvpOpponent("AmaterasuDev", HeroClass.ARCHER, 36, 18000, 2600, 750, 300, 3200, 3200,
            listOf("Светкавична Катана", "Отровна Стрела"), "Митичен Герой", 0.58f, "🇯🇵", "Япония", "Дистанционен"),
        PvpOpponent("RaFollower", HeroClass.MAGE, 44, 32000, 3900, 1100, 280, 2800, 2800,
            listOf("Слънчев Взрив", "Феникс Пламък"), "Легенда", 0.70f, "🇪🇬", "Египет", "Изблаговен"),
        PvpOpponent("TiamatServant", HeroClass.WARRIOR, 48, 40000, 3700, 950, 600, 6000, 6000,
            listOf("Дракон Форма", "Инфернодракон"), "Легенда", 0.74f, "🇩🇪", "Дракон Царство", "Агресивен"),
        PvpOpponent("OdinEye", HeroClass.MAGE, 50, 45000, 4200, 1400, 350, 3500, 3500,
            listOf("Гунгнир Хвърляне", "Рунна Магия"), "Всебог", 0.78f, "🇳🇴", "Асгард", "Стратег"),
        PvpOpponent("ChaosChild", HeroClass.WARRIOR, 50, 50000, 4500, 2000, 700, 8000, 8000,
            listOf("Хаотичен Войд", "Абсолютна Мощ"), "Всебог", 0.85f, "🌍", "Хаос", "Доминиращ"),
        PvpOpponent("BeginnerHero", HeroClass.WARRIOR, 10, 500, 800, 150, 80, 800, 800,
            listOf("Основна Атака"), "Смъртен", 0.40f, "🇧🇬", "Смъртно Кралство", "Начинаещ"),
        PvpOpponent("MidLevelMage", HeroClass.MAGE, 25, 5000, 1500, 450, 150, 1800, 1800,
            listOf("Огнена Топка", "Мълния"), "Олимпиец", 0.52f, "🇬🇷", "Олимп", "Магически"),
        PvpOpponent("BalancedFighter", HeroClass.MONK, 30, 8000, 2000, 500, 280, 2500, 2500,
            listOf("Медитация", "Железен Юмрук"), "Митичен Герой", 0.55f, "🇮🇳", "Индия", "Балансиран")
    )

    val PVP_ACHIEVEMENTS = listOf(
        "🏆 Първа PvP победа!",
        "🔥 5 победи подред!",
        "⚡ Победи Грандмайстор!",
        "🌌 Достигни Всебог PvP ранг!",
        "💀 100 PvP победи!",
        "🛡️ Победи без да получиш щета!",
        "⚔️ 3 победи за 5 минути!"
    )

    // ─────────────────────────────────────────────
    //  MATCHMAKING
    // ─────────────────────────────────────────────

    fun findOpponent(playerRating: Int, playerLevel: Int): PvpOpponent {
        val targetRating = playerRating + Random.nextInt(-300, 300)
        return OPPONENTS_POOL.minByOrNull { Math.abs(it.rating - targetRating) }
            ?: OPPONENTS_POOL.random()
    }

    fun findOpponentsByRating(playerRating: Int): List<PvpOpponent> {
        return OPPONENTS_POOL.sortedBy { Math.abs(it.rating - playerRating) }.take(5)
    }

    // ─────────────────────────────────────────────
    //  BATTLE SIMULATION
    // ─────────────────────────────────────────────

    fun simulatePvpBattle(player: Character, opponent: PvpOpponent): PvpMatchResult {
        var playerHp = player.getTotalMaxHealth()
        var opponentHp = opponent.maxHealth
        var turn = 0
        var totalPlayerDmg = 0
        var totalOppDmg = 0
        val log = mutableListOf<String>()

        log.add("⚔️ ${player.name} VS ${opponent.name}")
        log.add("━━━━━━━━━━━━━━━━━━")

        while (playerHp > 0 && opponentHp > 0 && turn < 30) {
            turn++

            // Player attacks
            val playerCrit = Random.nextFloat() < 0.15f + player.critChanceBonus
            val playerDmg = max(1, (player.getTotalAttack() - opponent.defense / 2) * if (playerCrit) 2 else 1)
            opponentHp -= playerDmg
            totalPlayerDmg += playerDmg
            log.add("${if (playerCrit) "💥 КРИТ!" else "⚔️"} ${player.name}: $playerDmg урон (${maxOf(0, opponentHp)}HP ост.)")

            if (opponentHp <= 0) break

            // Opponent attacks (with occasional ability use)
            val useAbility = Random.nextFloat() < 0.3f
            val oppAtkMult = if (useAbility) 1.5f else 1.0f
            val oppCrit = Random.nextFloat() < 0.12f
            val oppDmg = max(1, ((opponent.attack * oppAtkMult).toInt() - player.getTotalDefense() / 2) * if (oppCrit) 2 else 1)
            playerHp -= oppDmg
            totalOppDmg += oppDmg
            val abilityText = if (useAbility) " [${opponent.abilities.random()}]" else ""
            log.add("${if (oppCrit) "💥 КРИТ!" else "🗡️"} ${opponent.name}$abilityText: $oppDmg урон (${maxOf(0, playerHp)}HP ост.)")

            // Special moments
            if (turn == 3 && playerHp < player.getTotalMaxHealth() * 0.5f) {
                log.add("⚠️ ${player.name} е в опасност!")
            }
        }

        val won = opponentHp <= 0
        val ratingChange = calculateRatingChange(won, player, opponent)
        val goldReward = if (won) 500 + opponent.rating / 10 else 50
        val divReward = if (won) 50 + opponent.divinity / 1000 else 5

        val mvpMoment = when {
            log.count { it.contains("КРИТ") } >= 3 -> "💥 Крит Машина — 3+ критични удара!"
            totalPlayerDmg > opponent.maxHealth * 1.5 -> "💪 Доминиране — нанесе огромен урон!"
            won && turn <= 5 -> "⚡ Светкавична Победа — в 5 хода!"
            won && playerHp > player.getTotalMaxHealth() * 0.8 -> "🛡️ Чиста Победа — почти без щети!"
            else -> "⚔️ Упорита Битка — спечели трудно!"
        }

        log.add("━━━━━━━━━━━━━━━━━━")
        log.add(if (won) "🏆 ПОБЕДА!" else "💀 ПОРАЖЕНИЕ")
        log.add("Rating: ${if (ratingChange >= 0) "+$ratingChange" else "$ratingChange"}")

        return PvpMatchResult(
            won = won,
            opponent = opponent,
            playerDamageDealt = totalPlayerDmg,
            opponentDamageDealt = totalOppDmg,
            turnsPlayed = turn,
            ratingChange = ratingChange,
            goldReward = goldReward,
            divinityReward = divReward,
            mvpMoment = mvpMoment,
            matchLog = log
        )
    }

    private fun calculateRatingChange(won: Boolean, player: Character, opponent: PvpOpponent): Int {
        val ratingDiff = opponent.rating - player.pvpRating
        val base = if (won) 25 else -20
        val bonus = when {
            won && ratingDiff > 300 -> 15
            won && ratingDiff > 0 -> 10
            won && ratingDiff < -300 -> -5
            !won && ratingDiff < -300 -> -5
            !won && ratingDiff < 0 -> -10
            else -> 0
        }
        return base + bonus
    }

    fun getPvpRank(rating: Int): PvpRank {
        return PvpRank.values().filter { it.minRating <= rating }.maxByOrNull { it.minRating }
            ?: PvpRank.BRONZE
    }

    fun getSeasonLeaderboard(): List<Triple<Int, String, Int>> {
        return OPPONENTS_POOL
            .sortedByDescending { it.rating }
            .take(10)
            .mapIndexed { i, opp -> Triple(i + 1, "${opp.country} ${opp.name}", opp.rating) }
    }

    fun getPvpRewards(rank: PvpRank): String = when (rank) {
        PvpRank.BRONZE -> "💰 500 злато, ✨ 50 дивинити"
        PvpRank.SILVER -> "💰 1500 злато, ✨ 100 дивинити"
        PvpRank.GOLD -> "💰 3000 злато, ✨ 250 дивинити, 🎁 Злато кожа"
        PvpRank.PLATINUM -> "💰 5000 злато, ✨ 500 дивинити, 🎁 Платина рамка"
        PvpRank.DIAMOND -> "💰 10000 злато, ✨ 1000 дивинити, 🎁 Диамант аватар"
        PvpRank.MASTER -> "💰 20000 злато, ✨ 2000 дивинити, 🎁 Майстор сет кожа"
        PvpRank.GRANDMASTER -> "💰 50000 злато, ✨ 5000 дивинити, 🎁 Грандмайстор броня"
        PvpRank.OMNIGOD_RANK -> "💰 100000 злато, ✨ 25000 дивинити, 🌌 ВСЕБОГ PvP Корона"
    }
}

// Extension property for pvp rating
var Character.pvpRating: Int
    get() = (this.divinity / 100 + this.level * 20 + this.enemiesDefeated / 10).coerceAtMost(4500)
    set(value) {}

// ─────────────────────────────────────────────
//  PVP SEASON SYSTEM
// ─────────────────────────────────────────────

object PvpSeasonSystem {
    data class PvpSeason(
        val number: Int,
        val name: String,
        val mythology: String,
        val emoji: String,
        val description: String,
        val specialRules: String,
        val exclusiveReward: String,
        val durationDays: Int = 90
    )

    val SEASONS = listOf(
        PvpSeason(1, "Сезон 1: Гръцко Господство", "Greek", "⚡",
            "Гърците доминират. Гръцките класове +10% ATK.",
            "Специално правило: Зевс Форма дава +50% в PvP",
            "Корона на Олимп", 90),
        PvpSeason(2, "Сезон 2: Скандинавска Ярост", "Norse", "🔨",
            "Берсерк е мета. Norse умения +15% в PvP.",
            "Специално правило: Рагнарок Форма дава IMMUNITY 3 секунди",
            "Мьолнир Аватар Рамка", 90),
        PvpSeason(3, "Сезон 3: Египетска Мъдрост", "Egyptian", "🏺",
            "Тактиката победва силата. DOT ефекти +50%.",
            "Специално правило: Анубис Проклятие трае двойно",
            "Фараон Корона Ефект", 90),
        PvpSeason(4, "Сезон 4: ХАОС РЕЖИМ", "Chaos", "🌀",
            "Всичко е случайно. Произволни бонуси всеки ход.",
            "Специално правило: Всяка атака е случаен елемент",
            "🌌 Хаос Аватар — само за Сезон 4 играчи", 90)
    )

    val CURRENT_SEASON = SEASONS.last()

    val PVP_TIPS = listOf(
        "💡 Гледай отбраната на противника — не само атаката!",
        "💡 Трансформациите са мощни в PvP — активирай рано!",
        "💡 Комбо системата работи в PvP — подготви веригата!",
        "💡 Елементарните слабости важат и в PvP!",
        "💡 По-висок рейтинг = по-добри награди в края на сезона!",
        "💡 Guild Бафовете помагат дори в PvP!",
        "💡 Руните дават постоянен бонус — инвестирай в тях!",
        "💡 Питомецът се включва в PvP ако е активен!",
        "💡 God Relationship бонуси важат в PvP!",
        "💡 Не атакувай Грандмайстори преди Ниво 40!"
    )

    val RANKING_MILESTONES = mapOf(
        1000 to "Бронзов — начало на пътя",
        1500 to "Сребърен — ставаш сериозен",
        2000 to "Златен — над средното",
        2500 to "Платинен — елит",
        3000 to "Диамантен — много рядко",
        3500 to "Майстор — топ 5%",
        4000 to "Грандмайстор — топ 1%",
        4500 to "ВСЕБОГ — единственият"
    )

    fun getSeasonMotivation(currentRating: Int): String {
        val nextMilestone = RANKING_MILESTONES.keys.sorted().firstOrNull { it > currentRating }
        return if (nextMilestone != null) {
            "До ${RANKING_MILESTONES[nextMilestone]}: ${nextMilestone - currentRating} рейтинг"
        } else {
            "🌌 МАКСИМАЛЕН РАНГ! Ти си ВСЕБОГ PvP!"
        }
    }

    fun getSeasonRewardDescription(rank: PvpRank): String = buildString {
        appendLine("${rank.emoji} ${rank.displayName} Сезон Награди:")
        appendLine(PvpSystem.getPvpRewards(rank))
        appendLine()
        appendLine("⭐ Ексклузивна: ${CURRENT_SEASON.exclusiveReward}")
        appendLine("📅 Сезонът приключва след: ${CURRENT_SEASON.durationDays} дни")
    }
}

// ─────────────────────────────────────────────
//  PVP META ANALYSIS
// ─────────────────────────────────────────────

object PvpMeta {
    val TIER_LIST = mapOf(
        "S Tier" to listOf("Берсерк + Рагнарок Форма", "Маг + Гръм Комбо", "Монах + 72 Форми"),
        "A Tier" to listOf("Воин + Дракон Форма", "Ловец + Светкавична Катана", "Маг + Хаос Форма"),
        "B Tier" to listOf("Воин + Железен Щит", "Монах + Медитация", "Ловец + Отровна Стрела"),
        "C Tier" to listOf("Базов Воин без трансформация", "Базов Маг без комбо", "Базов Ловец")
    )

    val COUNTER_PICKS = mapOf(
        "Берсерк" to "Танк Монах с Медитация — изчаквай го",
        "Маг Комбо" to "Бърз Ловец — прекъсни комбото",
        "Дракон Форма" to "Лед умения — 2x урон",
        "Хаос Форма" to "Устойчив Воин — изчаквай края на формата",
        "72 Форми" to "AOE умения — хитовете са несъвместими"
    )

    fun getTierListText(): String = buildString {
        appendLine("PvP META — TIER LIST:")
        TIER_LIST.forEach { (tier, builds) ->
            appendLine("\n$tier:")
            builds.forEach { appendLine("  ✓ $it") }
        }
    }

    fun getCounterPick(enemyBuild: String): String =
        COUNTER_PICKS[enemyBuild] ?: "Анализирай противника и използвай елементарните слабости."
}
