package com.mythosrise.game.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.engine.SoundManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var soundManager: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        engine = GameEngine(this)
        engine.loadGame()
        soundManager = SoundManager(this)

        setupUI()
    }

    private fun setupUI() {
        val c = engine.character

        // ── Character Info ──
        findViewById<TextView>(R.id.tvSettingsHero).text = buildString {
            appendLine("${c.gender.emoji} ${c.name}")
            appendLine("${c.heroClass.emoji} ${c.heroClass.displayName} | Ниво ${c.level}")
            appendLine("${c.divinityTitle.title}")
            appendLine("✨ ${c.divinity} Дивинити")
            appendLine("💰 ${c.gold} Злато")
            appendLine("👹 ${c.enemiesDefeated} победени врагове")
            appendLine("⚡ ${c.godsDefeated} убити богове")
            appendLine("🌋 ${c.titansDefeated} убити Титани")
            append("🌍 ${c.currentWorld.displayName}")
        }

        // ── Music Toggle ──
        val swMusic = findViewById<Switch>(R.id.swMusic)
        swMusic.isChecked = soundManager.isMusicOn()
        swMusic.setOnCheckedChangeListener { _, checked ->
            soundManager.setMusicEnabled(checked)
        }

        // ── SFX Toggle ──
        val swSfx = findViewById<Switch>(R.id.swSfx)
        swSfx.isChecked = soundManager.isSfxOn()
        swSfx.setOnCheckedChangeListener { _, checked ->
            soundManager.setSfxEnabled(checked)
        }

        // ── Music Volume ──
        val sbMusic = findViewById<SeekBar>(R.id.sbMusicVolume)
        sbMusic.progress = (soundManager.getMusicVolume() * 100).toInt()
        sbMusic.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, user: Boolean) {
                soundManager.setMusicVolume(progress / 100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // ── SFX Volume ──
        val sbSfx = findViewById<SeekBar>(R.id.sbSfxVolume)
        sbSfx.progress = (soundManager.getSfxVolume() * 100).toInt()
        sbSfx.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, user: Boolean) {
                soundManager.setSfxVolume(progress / 100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // ── Reset Progress ──
        findViewById<Button>(R.id.btnResetProgress).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("⚠️ Нулирай прогрес")
                .setMessage("Всички данни ще бъдат изтрити!\nЦялата игра от начало.\n\nСигурен ли си?")
                .setPositiveButton("ДА, НУЛИРАЙ") { _, _ ->
                    engine.deleteSave()
                    Toast.makeText(this, "✅ Прогресът е нулиран.", Toast.LENGTH_LONG).show()
                    finish()
                }
                .setNegativeButton("НЕ", null)
                .show()
        }

        // ── Absorbed Powers ──
        findViewById<Button>(R.id.btnViewAbsorbed).setOnClickListener {
            val powers = engine.character.absorbedPowers
            if (powers.isEmpty()) {
                Toast.makeText(this, "Все още не си поглъщал сили.", Toast.LENGTH_SHORT).show()
            } else {
                val msg = powers.joinToString("\n") { "• $it" }
                AlertDialog.Builder(this)
                    .setTitle("🌀 Поглъщани Сили (${powers.size})")
                    .setMessage(msg)
                    .setPositiveButton("Затвори", null)
                    .show()
            }
        }

        // ── About ──
        findViewById<Button>(R.id.btnAboutSettings).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("ℹ️ MYTHOS RISE")
                .setMessage("""
                    ⚔️ Mythos Rise v2.0
                    
                    Епична митологична RPG за Android.
                    
                    🌍 12 Свята
                    🐉 8+ Вида дракони
                    ⚡ 50+ Врагове
                    🗡️ 50+ Предмети
                    🔮 30+ Умения
                    🏆 45 Постижения
                    🌳 Дърво на уменията
                    🐾 14 Придружители
                    ⚔️ Масови битки (10 вълни)
                    
                    От смъртен до ВСЕБОГ — ти решаваш.
                    
                    🌌 Поглъщай. Расти. Победи Хаоса.
                """.trimIndent())
                .setPositiveButton("🌌 ВЕЛИЧЕСТВЕНО!", null)
                .show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager.release()
    }
}
