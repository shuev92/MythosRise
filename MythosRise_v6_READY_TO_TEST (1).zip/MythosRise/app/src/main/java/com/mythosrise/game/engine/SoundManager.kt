package com.mythosrise.game.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build

// ─────────────────────────────────────────────
//  SOUND MANAGER
// ─────────────────────────────────────────────

class SoundManager(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var bgMusic: MediaPlayer? = null
    private var isMusicEnabled = true
    private var isSfxEnabled = true
    private var musicVolume = 0.6f
    private var sfxVolume = 0.8f

    private val soundIds = mutableMapOf<String, Int>()
    private val prefs = context.getSharedPreferences("sound_prefs", Context.MODE_PRIVATE)

    companion object {
        // Sound event constants
        const val SFX_ATTACK = "attack"
        const val SFX_CRITICAL = "critical"
        const val SFX_HEAL = "heal"
        const val SFX_ABILITY = "ability"
        const val SFX_ENEMY_DEATH = "enemy_death"
        const val SFX_PLAYER_HIT = "player_hit"
        const val SFX_LEVEL_UP = "level_up"
        const val SFX_DIVINITY_GAIN = "divinity_gain"
        const val SFX_BOSS_APPEAR = "boss_appear"
        const val SFX_VICTORY = "victory"
        const val SFX_DEFEAT = "defeat"
        const val SFX_ITEM_PICKUP = "item_pickup"
        const val SFX_ACHIEVEMENT = "achievement"
        const val SFX_MENU_CLICK = "menu_click"
        const val SFX_SKILL_UNLOCK = "skill_unlock"
        const val SFX_DRAGON_ROAR = "dragon_roar"
        const val SFX_THUNDER = "thunder"
        const val SFX_MAGIC = "magic"

        const val MUSIC_MAIN_MENU = "main_menu"
        const val MUSIC_BATTLE = "battle"
        const val MUSIC_BOSS = "boss"
        const val MUSIC_VICTORY = "victory"
        const val MUSIC_DIVINE = "divine"
        const val MUSIC_DRAGON = "dragon_realm"
    }

    // ─────────────────────────────────────────────
    //  INITIALIZATION
    // ─────────────────────────────────────────────

    init {
        loadPreferences()
        initSoundPool()
    }

    private fun loadPreferences() {
        isMusicEnabled = prefs.getBoolean("music_enabled", true)
        isSfxEnabled = prefs.getBoolean("sfx_enabled", true)
        musicVolume = prefs.getFloat("music_volume", 0.6f)
        sfxVolume = prefs.getFloat("sfx_volume", 0.8f)
    }

    private fun initSoundPool() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(attrs)
            .build()
        // NOTE: In a real app, you would load .ogg or .mp3 files from res/raw
        // Example: soundIds[SFX_ATTACK] = soundPool!!.load(context, R.raw.attack, 1)
    }

    // ─────────────────────────────────────────────
    //  PLAY SOUNDS
    // ─────────────────────────────────────────────

    fun playSound(soundName: String) {
        if (!isSfxEnabled) return
        soundIds[soundName]?.let { id ->
            soundPool?.play(id, sfxVolume, sfxVolume, 1, 0, 1f)
        }
    }

    fun playSoundForAbility(abilityName: String) {
        if (!isSfxEnabled) return
        val soundName = when {
            abilityName.contains("Огн") || abilityName.contains("Дракон") -> SFX_DRAGON_ROAR
            abilityName.contains("Мълни") || abilityName.contains("Гръм") -> SFX_THUNDER
            abilityName.contains("Магия") || abilityName.contains("Заклинание") -> SFX_MAGIC
            abilityName.contains("Лечебна") || abilityName.contains("Heal") -> SFX_HEAL
            abilityName.contains("АПОКАЛИПСИС") || abilityName.contains("Хаос") -> SFX_BOSS_APPEAR
            else -> SFX_ABILITY
        }
        playSound(soundName)
    }

    // ─────────────────────────────────────────────
    //  BACKGROUND MUSIC
    // ─────────────────────────────────────────────

    fun playMusic(musicName: String) {
        if (!isMusicEnabled) return
        stopMusic()
        // In real app: val resId = getMusicResId(musicName)
        // bgMusic = MediaPlayer.create(context, resId)
        // bgMusic?.isLooping = true
        // bgMusic?.setVolume(musicVolume, musicVolume)
        // bgMusic?.start()
    }

    fun playMusicForWorld(worldName: String) {
        val music = when {
            worldName.contains("Дракон") -> MUSIC_DRAGON
            worldName.contains("Пантеон") && worldName.contains("Бо") -> MUSIC_DIVINE
            else -> MUSIC_BATTLE
        }
        playMusic(music)
    }

    fun stopMusic() {
        bgMusic?.stop()
        bgMusic?.release()
        bgMusic = null
    }

    fun pauseMusic() { bgMusic?.pause() }
    fun resumeMusic() { if (isMusicEnabled) bgMusic?.start() }

    // ─────────────────────────────────────────────
    //  SETTINGS
    // ─────────────────────────────────────────────

    fun setMusicEnabled(enabled: Boolean) {
        isMusicEnabled = enabled
        prefs.edit().putBoolean("music_enabled", enabled).apply()
        if (!enabled) stopMusic()
    }

    fun setSfxEnabled(enabled: Boolean) {
        isSfxEnabled = enabled
        prefs.edit().putBoolean("sfx_enabled", enabled).apply()
    }

    fun setMusicVolume(volume: Float) {
        musicVolume = volume.coerceIn(0f, 1f)
        bgMusic?.setVolume(musicVolume, musicVolume)
        prefs.edit().putFloat("music_volume", musicVolume).apply()
    }

    fun setSfxVolume(volume: Float) {
        sfxVolume = volume.coerceIn(0f, 1f)
        prefs.edit().putFloat("sfx_volume", sfxVolume).apply()
    }

    fun isMusicOn() = isMusicEnabled
    fun isSfxOn() = isSfxEnabled
    fun getMusicVolume() = musicVolume
    fun getSfxVolume() = sfxVolume

    // ─────────────────────────────────────────────
    //  CLEANUP
    // ─────────────────────────────────────────────

    fun release() {
        stopMusic()
        soundPool?.release()
        soundPool = null
    }
}
