package com.mythosrise.game.engine

import com.mythosrise.game.models.*

// ─────────────────────────────────────────────
//  CRAFTING MATERIAL
// ─────────────────────────────────────────────

data class Material(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val rarity: Rarity,
    val stackable: Boolean = true,
    var quantity: Int = 0,
    val dropsFromEnemyIds: List<String> = emptyList(),
    val goldValue: Int = 100
)

// ─────────────────────────────────────────────
//  RECIPE
// ─────────────────────────────────────────────

data class CraftingRecipe(
    val id: String,
    val resultItemId: String,
    val resultName: String,
    val resultEmoji: String,
    val description: String,
    val ingredients: Map<String, Int>,   // materialId -> quantity
    val goldCost: Int = 0,
    val requiredLevel: Int = 1,
    val requiredDivinity: Int = 0,
    val category: String = "General"
)

// ─────────────────────────────────────────────
//  CRAFTING SYSTEM
// ─────────────────────────────────────────────

object CraftingSystem {

    // ── Materials ──

    val ALL_MATERIALS = listOf(
        Material("dragon_scale", "Дракон Люспа", "Люспа от легендарен дракон.", "🐉",
            Rarity.RARE, dropsFromEnemyIds = listOf("fire_dragon", "ice_dragon", "shadow_dragon", "wyvern"), goldValue = 500),
        Material("dragon_fang_mat", "Дракон Зъб", "Остър зъб от дракон.", "🦷",
            Rarity.EPIC, dropsFromEnemyIds = listOf("fire_dragon", "ice_dragon", "hydra"), goldValue = 800),
        Material("dragon_heart", "Дракон Сърце", "Горещото сърце на дракон.", "❤️‍🔥",
            Rarity.MYTHIC, dropsFromEnemyIds = listOf("fire_dragon", "tiamat"), goldValue = 3000),
        Material("god_essence", "Божествена Есенция", "Капка от силата на бог.", "✨",
            Rarity.LEGENDARY, dropsFromEnemyIds = listOf("zeus", "ra", "odin", "amaterasu_god"), goldValue = 5000),
        Material("titan_blood", "Кръв на Титан", "Древна кръв с несравнима сила.", "🌋",
            Rarity.DIVINE, dropsFromEnemyIds = listOf("kronos", "atlas"), goldValue = 10000),
        Material("chaos_shard", "Фрагмент Хаос", "Парче от самия Хаос.", "🌀",
            Rarity.DIVINE, dropsFromEnemyIds = listOf("primordial"), goldValue = 50000),
        Material("iron_ore", "Желязна Руда", "Обикновена руда за оръжия.", "⛏️",
            Rarity.COMMON, dropsFromEnemyIds = listOf("bandit", "orc", "dark_knight"), goldValue = 50),
        Material("steel_ingot", "Стоманен Слитък", "Преработено желязо.", "🔩",
            Rarity.UNCOMMON, dropsFromEnemyIds = listOf("dark_knight", "troll"), goldValue = 200),
        Material("mithril_ore", "Митрил Руда", "Фантастичен метал. Лек и здрав.", "💙",
            Rarity.RARE, dropsFromEnemyIds = listOf("frost_giant", "thor"), goldValue = 1000),
        Material("orichalcum", "Орихалк", "Митичният метал на Атлантида.", "🟡",
            Rarity.MYTHIC, dropsFromEnemyIds = listOf("kronos", "zeus"), goldValue = 5000),
        Material("phoenix_feather", "Пера на Феникс", "Пламтящо перо от феникс.", "🔥",
            Rarity.LEGENDARY, dropsFromEnemyIds = listOf("ares", "ra"), goldValue = 8000),
        Material("sacred_lotus", "Свещен Лотос", "Лотосът на Брахма.", "🪷",
            Rarity.EPIC, dropsFromEnemyIds = listOf("brahma", "shiva"), goldValue = 1500),
        Material("yggdrasil_bark", "Кора от Игдрасил", "От световното дърво.", "🌳",
            Rarity.LEGENDARY, dropsFromEnemyIds = listOf("odin", "nidhogg"), goldValue = 6000),
        Material("oni_horn", "Рог на Они", "Тъмен рог от японски демон.", "👹",
            Rarity.RARE, dropsFromEnemyIds = listOf("oni", "tengu"), goldValue = 600),
        Material("jade_stone", "Нефрит", "Свещен китайски камък.", "💚",
            Rarity.RARE, dropsFromEnemyIds = listOf("jiangshi", "dragon_king"), goldValue = 700),
        Material("hydra_venom", "Отрова на Хидрата", "Смъртоносна отрова.", "🐍",
            Rarity.EPIC, dropsFromEnemyIds = listOf("hydra", "nidhogg"), goldValue = 2000),
        Material("soul_crystal", "Кристал на Душата", "Кристализирана душа на враг.", "💎",
            Rarity.EPIC, dropsFromEnemyIds = listOf("any_boss"), goldValue = 3000),
        Material("stardust", "Звездна Прах", "От падаща звезда.", "⭐",
            Rarity.RARE, goldValue = 800),
        Material("moon_silver", "Лунно Сребро", "Сребро от пълнолуние.", "🌕",
            Rarity.UNCOMMON, goldValue = 300),
        Material("ancient_scroll", "Древен Свитък", "Съдържа изгубени знания.", "📜",
            Rarity.COMMON, dropsFromEnemyIds = listOf("mummy", "sphinx"), goldValue = 150)
    )

    // ── Recipes ──

    val ALL_RECIPES = listOf(

        // ── WEAPONS ──
        CraftingRecipe(
            id = "craft_dragon_sword",
            resultItemId = "fire_dragon_fang",
            resultName = "Занаятчийски Дракон Меч",
            resultEmoji = "🐉⚔️",
            description = "Меч от дракон зъб и огнено сърце. Изгаря при всеки удар.",
            ingredients = mapOf("dragon_fang_mat" to 3, "dragon_heart" to 1, "steel_ingot" to 5),
            goldCost = 2000, requiredLevel = 18, category = "Оръжия"
        ),
        CraftingRecipe(
            id = "craft_god_slayer",
            resultItemId = "zeus_lightning",
            resultName = "Богоубийствена Коса",
            resultEmoji = "⚡☠️",
            description = "Оръжие, създадено специално за убиване на богове.",
            ingredients = mapOf("god_essence" to 3, "orichalcum" to 2, "chaos_shard" to 1),
            goldCost = 10000, requiredLevel = 30, requiredDivinity = 5000, category = "Оръжия"
        ),
        CraftingRecipe(
            id = "craft_poison_blade",
            resultItemId = "nidhogg_venom",
            resultName = "Отровна Кама",
            resultEmoji = "🐍🗡️",
            description = "Камата, напоена с отрова на Хидрата.",
            ingredients = mapOf("hydra_venom" to 2, "iron_ore" to 10, "moon_silver" to 3),
            goldCost = 1500, requiredLevel = 20, category = "Оръжия"
        ),
        CraftingRecipe(
            id = "craft_jade_sword",
            resultItemId = "guan_yu_halberd",
            resultName = "Нефритен Меч",
            resultEmoji = "💚⚔️",
            description = "Китайски меч от нефрит. Символ на справедливостта.",
            ingredients = mapOf("jade_stone" to 5, "soul_crystal" to 2, "steel_ingot" to 8),
            goldCost = 3000, requiredLevel = 25, category = "Оръжия"
        ),

        // ── ARMOR ──
        CraftingRecipe(
            id = "craft_dragon_armor",
            resultItemId = "dragon_scale_armor",
            resultName = "Пълна Дракон Броня",
            resultEmoji = "🐉🛡️",
            description = "Броня от 20 дракон люспи. Почти непробиваема.",
            ingredients = mapOf("dragon_scale" to 20, "iron_ore" to 15, "steel_ingot" to 8),
            goldCost = 5000, requiredLevel = 20, category = "Броня"
        ),
        CraftingRecipe(
            id = "craft_mithril_armor",
            resultItemId = "valhalla_armor",
            resultName = "Митрил Броня",
            resultEmoji = "💙🛡️",
            description = "Лека но здрава броня от митрил.",
            ingredients = mapOf("mithril_ore" to 10, "moon_silver" to 5, "stardust" to 3),
            goldCost = 8000, requiredLevel = 28, category = "Броня"
        ),
        CraftingRecipe(
            id = "craft_chaos_armor",
            resultItemId = "tiamat_scale",
            resultName = "Хаос Броня",
            resultEmoji = "🌀🛡️",
            description = "Броня от хаотична енергия. Имунитет към магии.",
            ingredients = mapOf("chaos_shard" to 2, "titan_blood" to 3, "god_essence" to 2),
            goldCost = 30000, requiredLevel = 40, requiredDivinity = 10000, category = "Броня"
        ),

        // ── AMULETS & ACCESSORIES ──
        CraftingRecipe(
            id = "craft_phoenix_amulet",
            resultItemId = "yggdrasil_ring",
            resultName = "Амулет на Феникс",
            resultEmoji = "🔥💎",
            description = "Амулетът те прераждa при смърт.",
            ingredients = mapOf("phoenix_feather" to 2, "soul_crystal" to 3, "stardust" to 5),
            goldCost = 12000, requiredLevel = 28, category = "Аксесоари"
        ),
        CraftingRecipe(
            id = "craft_wisdom_crown",
            resultItemId = "pharaoh_crown",
            resultName = "Корона на Мъдростта",
            resultEmoji = "👑",
            description = "Корона от злато и дракон люспи. Увеличава дивинити.",
            ingredients = mapOf("dragon_scale" to 5, "god_essence" to 1, "orichalcum" to 3),
            goldCost = 6000, requiredLevel = 22, category = "Аксесоари"
        ),
        CraftingRecipe(
            id = "craft_titan_gauntlets",
            resultItemId = "atlas_gauntlets",
            resultName = "Ръкавици на Титан",
            resultEmoji = "💪🌋",
            description = "Ръкавиците на Атлас. Сила на 100 войника.",
            ingredients = mapOf("titan_blood" to 2, "orichalcum" to 4, "dragon_heart" to 1),
            goldCost = 15000, requiredLevel = 35, requiredDivinity = 3000, category = "Аксесоари"
        ),

        // ── POTIONS ──
        CraftingRecipe(
            id = "craft_divinity_potion",
            resultItemId = "mass_heal_scroll",
            resultName = "Еликсир на Дивинити",
            resultEmoji = "✨🧪",
            description = "+500 Дивинити незабавно.",
            ingredients = mapOf("god_essence" to 1, "sacred_lotus" to 2, "stardust" to 2),
            goldCost = 1000, requiredLevel = 15, category = "Еликсири"
        ),
        CraftingRecipe(
            id = "craft_berserker",
            resultItemId = "berserker_potion",
            resultName = "Берсерк Еликсир",
            resultEmoji = "😤🧪",
            description = "Тройна атака за 5 хода.",
            ingredients = mapOf("iron_ore" to 5, "dragon_scale" to 1, "hydra_venom" to 1),
            goldCost = 500, requiredLevel = 10, category = "Еликсири"
        ),

        // ── DIVINE ITEMS ──
        CraftingRecipe(
            id = "craft_omnigod_weapon",
            resultItemId = "kronos_scythe",
            resultName = "Оръжието на Всебога",
            resultEmoji = "🌌⚔️",
            description = "Последното оръжие. Само Всебог може да го направи.",
            ingredients = mapOf(
                "chaos_shard" to 5, "titan_blood" to 5,
                "god_essence" to 10, "dragon_heart" to 5,
                "orichalcum" to 10
            ),
            goldCost = 100000, requiredLevel = 45, requiredDivinity = 25000, category = "Божествени"
        )
    )

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun canCraft(recipe: CraftingRecipe, character: Character, materials: Map<String, Int>): Boolean {
        if (character.level < recipe.requiredLevel) return false
        if (character.divinity < recipe.requiredDivinity) return false
        if (character.gold < recipe.goldCost) return false
        return recipe.ingredients.all { (matId, needed) ->
            (materials[matId] ?: 0) >= needed
        }
    }

    fun craft(recipe: CraftingRecipe, character: Character, playerMaterials: MutableMap<String, Int>): Item? {
        if (!canCraft(recipe, character, playerMaterials)) return null

        // Deduct materials
        recipe.ingredients.forEach { (matId, needed) ->
            playerMaterials[matId] = (playerMaterials[matId] ?: 0) - needed
        }
        character.gold -= recipe.goldCost

        // Create result item
        val resultItem = GameDatabase.ALL_ITEMS[recipe.resultItemId]?.copy(
            name = recipe.resultName,
            emoji = recipe.resultEmoji
        )
        resultItem?.let { character.inventory.add(it) }
        return resultItem
    }

    fun getMaterialDropForEnemy(enemyId: String): Material? {
        val possible = ALL_MATERIALS.filter { mat ->
            mat.dropsFromEnemyIds.contains(enemyId) || mat.dropsFromEnemyIds.contains("any_boss")
        }
        return if (possible.isNotEmpty() && kotlin.random.Random.nextFloat() < 0.35f) {
            possible.random()
        } else null
    }

    fun getRecipesByCategory(category: String) = ALL_RECIPES.filter { it.category == category }
    val categories get() = ALL_RECIPES.map { it.category }.distinct()
}

// ─────────────────────────────────────────────
//  CRAFTING TIPS & EXTENDED MATERIAL LORE
// ─────────────────────────────────────────────

object CraftingLore {
    val MATERIAL_LORE = mapOf(
        "dragon_scale" to "Люспата на дракон е по-здрава от всеки известен метал. Дори митрилът не я надминава.",
        "dragon_fang_mat" to "Зъбът на дракон може да пробие всяка броня. Отровата в него продължава да действа и след смъртта.",
        "dragon_heart" to "Сърцето бие дори изваено. Вечен извор на огнена енергия — никога не изстива.",
        "god_essence" to "Капка дистилирана сила на бог. Хиляди години дивинити в микроскопично количество.",
        "titan_blood" to "По-тъмна от нощта. По-гореща от огъня. Кръвта на Титан предшества самото сътворение.",
        "chaos_shard" to "Парче от преди всичко. Нестабилно. Опасно. Но носителят му е непобедим.",
        "iron_ore" to "Обикновено желязо — но всяка легенда е започнала от обикновено.",
        "mithril_ore" to "Митрилът е измислен от Толкин, но в Mythos Rise е реален. Три пъти по-лек от желязо, десет пъти по-здрав.",
        "orichalcum" to "Атлантидският метал. Платон го споменава. Никой не го е намирал — до сега.",
        "phoenix_feather" to "Пламтящо перо. Изгаря и се ражда наново — безброй пъти.",
        "yggdrasil_bark" to "Кора от Световното Дърво. Свързва всичките 9 свята. Изключително мощна магически.",
        "soul_crystal" to "Кристализирала душа. Пита се: чия? Отговорът е тъжен.",
        "stardust" to "Прах от падаща звезда. Астрономите ще кажат — метеоритна прах. Митолозите знаят истината.",
        "hydra_venom" to "Убива за секунди. Херакъл го използвал на стрели — те убивали векове по-късно."
    )
    
    val CRAFTING_TIPS = listOf(
        "💡 Дракон материали падат само от Дракон Царство — отиди там специално!",
        "💡 Бог Есенция пада само от убити богове — всеки бог дава различен вид.",
        "💡 Орихалк е изключително рядък — Кронос и Зевс са единствените източници.",
        "💡 Занаяти Дракон Меч преди Дракон Царство — ще ти трябва!",
        "💡 Хаос Осколок е 5x по-рядък от всичко друго — пази го!",
        "💡 Комплекти дават гигантски бонуси — занаяти всичките 3 части!",
        "💡 Феникс Перо пада само от Арес и Ра — рядък но мощен материал.",
        "💡 Занаяти Divine предмети само след Престиж 3+ — иначе ги губиш!",
        "💡 Митрил Броня + Дракон Меч + Феникс Амулет = убийствена комбинация.",
        "💡 Берсерк Еликсир + Берсерк Форма = троен ATK за 5 хода!"
    )
    
    val LEGENDARY_CRAFT_REQUIREMENTS = listOf(
        Triple("Дракон Броня", "20 Люспи + 15 Желязо + 8 Стомана", "Ниво 20"),
        Triple("Митрил Броня", "10 Митрил + 5 Лунно Сребро + 3 Звездна Прах", "Ниво 28"),
        Triple("Богоубийствена Коса", "3 Бог Есенция + 2 Орихалк + 1 Хаос Осколок", "Ниво 30, ✨5000"),
        Triple("Хаос Броня", "2 Хаос Осколок + 3 Титан Кръв + 2 Бог Есенция", "Ниво 40, ✨10000"),
        Triple("Оръжие на Всебога", "5 Хаос + 5 Титан + 10 Бог + 5 Дракон Сърце + 10 Орихалк", "Ниво 45, ✨25000")
    )
    
    fun getRandomTip() = CRAFTING_TIPS.random()
    fun getMaterialLore(id: String) = MATERIAL_LORE[id] ?: "Митичен материал от легендарни източници."
    
    fun getCraftingGuide(): String = buildString {
        appendLine("═══ РЪКОВОДСТВО ЗА ЗАНАЯТИ ═══")
        appendLine()
        appendLine("РЕДКОСТ НА МАТЕРИАЛИ:")
        appendLine("⬜ Common: Желязо, Стомана — падат от всякакви врагове")
        appendLine("🟢 Uncommon: Лунно Сребро — от по-силни врагове")
        appendLine("🔵 Rare: Митрил, Нефрит, Хидра Отрова — рядко пада")
        appendLine("🟣 Epic: Феникс Перо, Душен Кристал — само от босове")
        appendLine("🟡 Legendary: Бог Есенция, Игдрасил Кора — само от богове")
        appendLine("🔴 Mythic: Орихалк, Дракон Сърце — от мощни босове")
        appendLine("⭐ Divine: Хаос Осколок, Титан Кръв — от крайни босове")
        appendLine()
        appendLine("ЛЕГЕНДАРНИ ЗАНАЯТИ:")
        LEGENDARY_CRAFT_REQUIREMENTS.forEach { (name, mats, req) ->
            appendLine("🔨 $name")
            appendLine("   Материали: $mats")
            appendLine("   Изисква: $req")
            appendLine()
        }
    }
}
