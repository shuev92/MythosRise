package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  DIVINE FORM
// ─────────────────────────────────────────────

data class DivineForm(
    val id: String,
    val name: String,
    val description: String,
    val emoji: String,
    val requiredDivinity: Int,
    val requiredAbsorbedGod: String?,       // Must have absorbed this god's power
    val durationSeconds: Int,
    val attackMultiplier: Float,
    val defenseMultiplier: Float,
    val healthRegenPercent: Float,
    val manaRegenPercent: Float,
    val specialEffect: String,
    val auraColor: String,
    val transformationText: String,
    var isUnlocked: Boolean = false,
    var cooldownSeconds: Int = 300
)

// ─────────────────────────────────────────────
//  TRANSFORMATION SYSTEM
// ─────────────────────────────────────────────

object TransformationSystem {

    val ALL_FORMS = listOf(

        DivineForm(
            id = "form_berserker",
            name = "Форма на Берсерка",
            description = "Древна ярост на викинг воина. Атаката се удвоява.",
            emoji = "😤",
            requiredDivinity = 500,
            requiredAbsorbedGod = null,
            durationSeconds = 30,
            attackMultiplier = 2.0f,
            defenseMultiplier = 0.7f,
            healthRegenPercent = 0.02f,
            manaRegenPercent = 0.0f,
            specialEffect = "Всяка атака има 30% шанс за двоен удар",
            auraColor = "#FF4400",
            transformationText = "🔥 Берсерк ярост завладява тялото ти!"
        ),

        DivineForm(
            id = "form_zeus",
            name = "Гръм Форма — Зевс",
            description = "Силата на олимпийския цар. Мълнии с всяка атака.",
            emoji = "⚡",
            requiredDivinity = 2000,
            requiredAbsorbedGod = "Зевс - Цар на Боговете",
            durationSeconds = 45,
            attackMultiplier = 2.5f,
            defenseMultiplier = 1.2f,
            healthRegenPercent = 0.01f,
            manaRegenPercent = 0.05f,
            specialEffect = "Всяка атака поразява с мълния за +50% бонус урон",
            auraColor = "#FFFF00",
            transformationText = "⚡ Силата на Зевс те завзема! Ти си Царят на Боговете!"
        ),

        DivineForm(
            id = "form_ra",
            name = "Слънчева Форма — Ра",
            description = "Станеш живото слънце. Изгаряш всичко наоколо.",
            emoji = "☀️",
            requiredDivinity = 2500,
            requiredAbsorbedGod = "Ра - Слънчевият Бог",
            durationSeconds = 40,
            attackMultiplier = 2.3f,
            defenseMultiplier = 1.5f,
            healthRegenPercent = 0.03f,
            manaRegenPercent = 0.03f,
            specialEffect = "Изгаряш врагове само с присъствието си — +20 урон всеки ход",
            auraColor = "#FF8800",
            transformationText = "☀️ Ти ставаш Слънцето! Светлина залива всичко!"
        ),

        DivineForm(
            id = "form_shiva",
            name = "Форма на Разрушителя — Шива",
            description = "Шива разрушава, за да твори. Атаките имат AOE ефект.",
            emoji = "💫",
            requiredDivinity = 3000,
            requiredAbsorbedGod = "Шива - Разрушителят",
            durationSeconds = 50,
            attackMultiplier = 2.8f,
            defenseMultiplier = 1.0f,
            healthRegenPercent = 0.0f,
            manaRegenPercent = 0.08f,
            specialEffect = "Всяка атака удря всички врагове в Арена режим",
            auraColor = "#9B59B6",
            transformationText = "💫 Танцът на Шива започва! Разрушение и прераждане!"
        ),

        DivineForm(
            id = "form_odin",
            name = "Форма на Всебащата — Один",
            description = "Мъдростта на Один. Знаеш слабото място на всеки враг.",
            emoji = "🦅",
            requiredDivinity = 4000,
            requiredAbsorbedGod = "Один - Всебащата",
            durationSeconds = 60,
            attackMultiplier = 2.2f,
            defenseMultiplier = 1.8f,
            healthRegenPercent = 0.02f,
            manaRegenPercent = 0.05f,
            specialEffect = "100% точност + вижда слабото място → +40% урон винаги",
            auraColor = "#4488FF",
            transformationText = "🦅 Мъдростта на Один те обвзема! Гарвани пеят!"
        ),

        DivineForm(
            id = "form_amaterasu",
            name = "Слънчева Богиня — Аматерасу",
            description = "Японската богиня на слънцето. Светлина побеждава мрака.",
            emoji = "🌅",
            requiredDivinity = 4500,
            requiredAbsorbedGod = "Аматерасу - Богинята на Слънцето",
            durationSeconds = 55,
            attackMultiplier = 2.6f,
            defenseMultiplier = 1.6f,
            healthRegenPercent = 0.04f,
            manaRegenPercent = 0.04f,
            specialEffect = "Имунитет към тъмнина атаки + всички атаки изгарят",
            auraColor = "#FFAAFF",
            transformationText = "🌅 Аматерасу влиза в тялото ти! Слънцето изгрява!"
        ),

        DivineForm(
            id = "form_wukong",
            name = "72 Трансформации — Ву Конг",
            description = "Маймунският крал може да стане всичко. Ти също.",
            emoji = "🐒",
            requiredDivinity = 5000,
            requiredAbsorbedGod = "Сун Ву Конг - Маймунският Крал",
            durationSeconds = 60,
            attackMultiplier = 3.0f,
            defenseMultiplier = 1.4f,
            healthRegenPercent = 0.02f,
            manaRegenPercent = 0.06f,
            specialEffect = "Случайно копираш способностите на врага всеки ход",
            auraColor = "#FF6600",
            transformationText = "🐒 72 трансформации активирани! Ти можеш да си всичко!"
        ),

        DivineForm(
            id = "form_dragon",
            name = "Форма на Дракона",
            description = "Ти ставаш дракон. Огненото дихание е унищожително.",
            emoji = "🐉",
            requiredDivinity = 6000,
            requiredAbsorbedGod = "Тиамат - Майката на Дракони",
            durationSeconds = 45,
            attackMultiplier = 3.2f,
            defenseMultiplier = 2.0f,
            healthRegenPercent = 0.01f,
            manaRegenPercent = 0.0f,
            specialEffect = "Огнено дихание — +200% урон на всяка трета атака",
            auraColor = "#FF2200",
            transformationText = "🐉 ДРАКОН ТРАНСФОРМАЦИЯ! Люспи покриват кожата ти!"
        ),

        DivineForm(
            id = "form_chaos",
            name = "ФОРМА НА ХАОСА",
            description = "Погълнал си Хаоса. Ти ставаш неговото оръдие.",
            emoji = "🌌",
            requiredDivinity = 25000,
            requiredAbsorbedGod = "Хаос - Първичността",
            durationSeconds = 120,
            attackMultiplier = 5.0f,
            defenseMultiplier = 3.0f,
            healthRegenPercent = 0.05f,
            manaRegenPercent = 0.10f,
            specialEffect = "АПОКАЛИПТИЧНА АУРА — всяка атака е критична + AOE",
            auraColor = "#FF00FF",
            transformationText = "🌌 ХАОСЪТ ТЕ ПОГЛЪЩА! ТИ СТАВАШ САМИЯ ХАОС!"
        ),

        DivineForm(
            id = "form_omnigod",
            name = "ФОРМА НА ВСЕБОГА",
            description = "Ти ставаш абсолютното съществуване. Непобедим.",
            emoji = "✨",
            requiredDivinity = 50000,
            requiredAbsorbedGod = null,
            durationSeconds = 180,
            attackMultiplier = 10.0f,
            defenseMultiplier = 5.0f,
            healthRegenPercent = 0.10f,
            manaRegenPercent = 0.20f,
            specialEffect = "АБСОЛЮТНА МОЩ — имунитет + критичен при всяка атака + регенерация",
            auraColor = "#FFFFFF",
            transformationText = "🌟 ТИ СТА ВСЕБОГ! АБСОЛЮТНАТА МОЩ Е ТВОЯ!"
        )
    )

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun getAvailableForms(character: Character): List<DivineForm> {
        return ALL_FORMS.filter { form ->
            character.divinity >= form.requiredDivinity &&
            (form.requiredAbsorbedGod == null || character.absorbedPowers.contains(form.requiredAbsorbedGod))
        }
    }

    fun getLockedForms(character: Character): List<DivineForm> {
        return ALL_FORMS.filter { form ->
            character.divinity < form.requiredDivinity ||
            (form.requiredAbsorbedGod != null && !character.absorbedPowers.contains(form.requiredAbsorbedGod))
        }
    }

    fun activateForm(form: DivineForm, character: Character): TransformationResult {
        return TransformationResult(
            form = form,
            attackBonus = (character.getTotalAttack() * (form.attackMultiplier - 1)).toInt(),
            defenseBonus = (character.getTotalDefense() * (form.defenseMultiplier - 1)).toInt(),
            message = form.transformationText
        )
    }

    fun getFormRequirementsText(form: DivineForm, character: Character): String {
        return buildString {
            appendLine("${form.emoji} ${form.name}")
            appendLine(form.description)
            appendLine()
            appendLine("📋 Изисквания:")
            val hasDiv = character.divinity >= form.requiredDivinity
            appendLine("${if (hasDiv) "✅" else "❌"} ✨ ${form.requiredDivinity} Дивинити (имаш: ${character.divinity})")
            form.requiredAbsorbedGod?.let { god ->
                val hasGod = character.absorbedPowers.contains(god)
                appendLine("${if (hasGod) "✅" else "❌"} Погълнал: $god")
            }
            appendLine()
            appendLine("💪 Бонуси:")
            appendLine("⚔️ ATK x${form.attackMultiplier}")
            appendLine("🛡️ DEF x${form.defenseMultiplier}")
            if (form.healthRegenPercent > 0) appendLine("❤️ Регенерация: ${(form.healthRegenPercent * 100).toInt()}%/ход")
            appendLine("⏱️ Продължителност: ${form.durationSeconds}с")
            appendLine()
            appendLine("✨ Специален ефект:")
            appendLine(form.specialEffect)
        }
    }
}

data class TransformationResult(
    val form: DivineForm,
    val attackBonus: Int,
    val defenseBonus: Int,
    val message: String
)

// ─────────────────────────────────────────────
//  TRANSFORMATION GUIDE
// ─────────────────────────────────────────────

object TransformationGuide {
    val FORM_TIPS = mapOf(
        "form_berserker" to "💡 Използвай при врагове с висок HP. Двойната атака компенсира ниската защита.",
        "form_zeus" to "💡 Мълниите при всяка атака са особено ефективни срещу водни врагове.",
        "form_ra" to "💡 Изгарянето +20 урон/ход — идеално за дълги битки с босове.",
        "form_shiva" to "💡 Арена режим: Shiva е ПЕРФЕКТНА — удря всички врагове наведнъж!",
        "form_odin" to "💡 100% точност + 40% бонус урон — най-балансираната форма за всяка ситуация.",
        "form_amaterasu" to "💡 Имунитет към тъмнина атаки — перфектна за Тартар и Сянка врагове.",
        "form_wukong" to "💡 Копиране на враг умения — непредвидима! Работи различно всяка битка.",
        "form_dragon" to "💡 Всяка трета атака = Огнено дихание. Планирай атаките си!",
        "form_chaos" to "💡 Всяка атака е критична + AOE. Само за Хаос нива.",
        "form_omnigod" to "💡 Финалната форма. Използвай само при финалните босове!"
    )
    
    val TRANSFORMATION_STORY = """
        Трансформациите не са просто сила.
        
        Те са спомени от боговете, които си победил.
        Всеки бог, чиято сила си поглъщал, остава в теб.
        
        Когато активираш Форма на Зевс — ти не имитираш Зевс.
        Ти СИ Зевс. За 45 секунди.
        
        Когато активираш Форма на Хаос — ти вече не си нищо.
        Ти си всичко, преди да стане всичко.
        
        Финалната форма — ВСЕБОГА — е не просто комбинация от силите.
        Тя е нещо ново. Нещо, за което никоя митология няма дума.
        
        Ти.
    """.trimIndent()
    
    fun getTip(formId: String) = FORM_TIPS[formId] ?: "💡 Всяка форма е уникална. Експериментирай!"
    
    fun getUnlockPath(): List<Pair<String, String>> = listOf(
        "✨ 500 Дивинити" to "Берсерк Форма",
        "✨ 2 000 + Зевс погълнат" to "Гръм Форма (Зевс)",
        "✨ 2 500 + Ра погълнат" to "Слънчева Форма (Ра)",
        "✨ 3 000 + Шива погълнат" to "Форма на Разрушителя",
        "✨ 4 000 + Один погълнат" to "Форма на Всебащата",
        "✨ 4 500 + Аматерасу погълната" to "Форма на Слънчевата Богиня",
        "✨ 5 000 + Ву Конг погълнат" to "72 Трансформации",
        "✨ 6 000 + Тиамат погълната" to "Форма на Дракона",
        "✨ 25 000 + Хаос погълнат" to "Форма на Хаоса",
        "✨ 50 000" to "🌌 ФОРМА НА ВСЕБОГА"
    )
}
