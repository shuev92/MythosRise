package com.mythosrise.game.engine

// ─────────────────────────────────────────────
//  ACHIEVEMENT EXPANSION V2
// ─────────────────────────────────────────────

object AchievementExpansionV2 {

    data class SecretAchievement(
        val id: String,
        val name: String,
        val emoji: String,
        val hint: String,
        val realCondition: String,
        val goldReward: Int,
        val divinityReward: Int,
        val unlockMessage: String,
        val rarity: String
    )

    val SECRET_ACHIEVEMENTS = listOf(
        SecretAchievement(
            "sa_pacifist_run", "Мирния Пат", "🕊️",
            "Победи бос без да атакуваш директно",
            "Победи всеки бос само с отблъскване",
            50000, 2000,
            "Невероятно! Победа без атака! Ти доказа, че защитата е нападение!",
            "Legendary"
        ),
        SecretAchievement(
            "sa_speed_run_zeus", "Мълниеносен", "⚡",
            "Ускори нещо с Зевс",
            "Победи Зевс в под 10 удара",
            30000, 1500,
            "Зевс не стигна до мълниите си! Ти беше по-бърз!",
            "Epic"
        ),
        SecretAchievement(
            "sa_all_gods_chosen", "Любимец на Боговете", "🌟",
            "Всички богове те уважават еднакво",
            "Постигни CHOSEN с всичките 7 главни богове",
            200000, 10000,
            "7 богове. 7 CHOSEN. Невъзможното е постигнато. Ти си наистина Всебог.",
            "Divine"
        ),
        SecretAchievement(
            "sa_broke_gambler", "Счупеният Авантюрист", "🎲",
            "Загуби злато по специален начин",
            "Похарчи 100 000 злато в магазина за 1 сесия",
            10000, 500,
            "100 000 злато за 1 сесия? Икономиката на Олимп те ненавижда.",
            "Rare"
        ),
        SecretAchievement(
            "sa_phoenix_five", "Пет Живота", "🔥",
            "Прераждай се неколкократно",
            "Умри и се прероди 5 пъти в битката (Феникс Форма)",
            25000, 1000,
            "5 прераждания! Ти не умираш — ти просто сменяш форматата!",
            "Epic"
        ),
        SecretAchievement(
            "sa_lore_master", "Майсторът на Лора", "📚",
            "Прочети много лор",
            "Разгледай всичките 25 Лор факта в Книгата на Лор",
            15000, 750,
            "25 факта! Ти знаеш повече за митологиите от повечето богове!",
            "Rare"
        ),
        SecretAchievement(
            "sa_combo_god", "Комбо Бог", "💥",
            "Изпълни нещо феноменално в комбо",
            "Изпълни всичките 11 Комба поне веднъж",
            40000, 2000,
            "11 комба! Зевс Гръм, Рагнарок, дори АБСОЛЮТНА МОЩ! Ти си Комбо Бог!",
            "Legendary"
        ),
        SecretAchievement(
            "sa_no_prestige", "Естественият Максимум", "🏆",
            "Постигни максимума без нещо",
            "Достигни 50 000 Дивинити без да правиш Престиж",
            100000, 5000,
            "50 000 Дивинити без Престиж! Ти го постигна по трудния начин. Хатт от боговете.",
            "Divine"
        ),
        SecretAchievement(
            "sa_quiz_perfect", "Митологичен Гений", "🧠",
            "Перфектно в Куиза",
            "Отговори на всичките 21 въпроса правилно без грешка",
            20000, 1000,
            "21/21! Знаеш митологиите по-добре от самите богове!",
            "Legendary"
        ),
        SecretAchievement(
            "sa_guild_supreme", "Гилдийна Легенда", "🏰",
            "Постигни нещо невероятно в Гилдия",
            "Бъди в Гилдия Ниво 10 с 10+ победи от Война",
            75000, 3000,
            "Гилдия Ниво 10, 10+ войни спечелени! Легендарна гилдия!",
            "Legendary"
        ),
        SecretAchievement(
            "sa_story_completed", "Знаещият Всичко", "🌌",
            "Завърши нещо голямо в Историята",
            "Завърши всичките 5 глави на История режима",
            50000, 2500,
            "5 глави! Олимп, Асгард, Египет, и накрая — Хаоса! Ти знаеш пълната история!",
            "Epic"
        ),
        SecretAchievement(
            "sa_omnigod_true", "ИСТИНСКИЯТ ВСЕБОГ", "🌌",
            "Постигни абсолютния максимум",
            "50 000 Дивинити + Ниво 50 + Престиж 8 + Всичките истории + CHOSEN с всички богове",
            1000000, 50000,
            "🌌 ИСТИНСКИЯТ ВСЕБОГ 🌌\nНяма думи. Постигна ВСИЧКО.\nМитологиите се поклащат.",
            "OMNIGOD"
        )
    )

    val MILESTONE_MESSAGES = mapOf(
        1 to "🎯 Първа стъпка в митологиите!",
        5 to "⭐ 5 постижения! Добре вървиш!",
        10 to "🌟 10 постижения! Сериозен играч!",
        20 to "💫 20 постижения! Половината пред теб!",
        30 to "🏆 30 постижения! Ветеран!",
        40 to "👑 40 постижения! Близо до върха!",
        45 to "⚡ 45 постижения! Само малко остава!",
        50 to "🌌 ВСЕ ПОСТИЖЕНИЯ! ВСЕБОГ НА ПОСТИЖЕНИЯ!",
        57 to "🌌 Включително Тайните! АБСОЛЮТЕН ПЕРФЕКЦИОНИСТ!"
    )

    val ACHIEVEMENT_TIPS = listOf(
        "💡 Тайните постижения имат ПОДСКАЗКИ — следвай ги!",
        "💡 Победи всички 7 бога за Любимец на Боговете!",
        "💡 Прочети целия Лор за Лор Майстор!",
        "💡 Перфектен Куиз = Митологичен Гений!",
        "💡 ИСТИНСКИЯТ ВСЕБОГ изисква ВСИЧКО. Буквално.",
        "💡 Тайните постижения носят по-голямо злато!",
        "💡 Divine и OMNIGOD постижения са само 2 — добра охота!"
    )

    fun checkSecretAchievements(
        character: com.mythosrise.game.models.Character,
        achievementTracker: Map<String, Int>
    ): List<SecretAchievement> {
        return SECRET_ACHIEVEMENTS.filter { ach ->
            when (ach.id) {
                "sa_lore_master" -> (achievementTracker["lore_read"] ?: 0) >= 25
                "sa_quiz_perfect" -> (achievementTracker["quiz_perfect"] ?: 0) >= 1
                "sa_story_completed" -> StoryMode.ALL_CHAPTERS.all { it.isCompleted }
                "sa_all_gods_chosen" -> GodRelationshipSystem.ALL_GODS.all {
                    it.currentLevel == RelationshipLevel.CHOSEN
                }
                "sa_omnigod_true" -> character.divinity >= 50000 &&
                        character.level >= 50 &&
                        character.prestigeCount >= 8 &&
                        StoryMode.ALL_CHAPTERS.all { it.isCompleted } &&
                        GodRelationshipSystem.ALL_GODS.all { it.currentLevel == RelationshipLevel.CHOSEN }
                else -> false
            }
        }
    }

    fun getAchievementRarityColor(rarity: String): String = when (rarity) {
        "Common" -> "#AAAAAA"
        "Uncommon" -> "#44AA44"
        "Rare" -> "#4444FF"
        "Epic" -> "#AA44AA"
        "Legendary" -> "#FF8800"
        "Divine" -> "#FF44FF"
        "OMNIGOD" -> "#FFD700"
        else -> "#FFFFFF"
    }
}

// ─────────────────────────────────────────────
//  WORLD ENCYCLOPEDIA EXTENDED
// ─────────────────────────────────────────────

object WorldEncyclopediaExtended {

    data class WorldDetail(
        val name: String,
        val emoji: String,
        val mythology: String,
        val description: String,
        val history: String,
        val dominantElement: String,
        val uniqueMechanic: String,
        val bossLore: String,
        val secretArea: String,
        val recommendedLevel: Int,
        val atmosphereDesc: String,
        val musicStyle: String
    )

    val WORLD_DETAILS = listOf(
        WorldDetail(
            name = "Смъртното Кралство",
            emoji = "🏰",
            mythology = "Universal",
            description = "Светът на смъртните. Тук всичко е започнало. Тук всичко е просто.",
            history = "Преди митологиите, имаше само смъртното кралство. Обикновено. Скучно. После дойдоха боговете — и нищо не беше просто.",
            dominantElement = "Земя",
            uniqueMechanic = "Без Дивинити бонуси — чист скил тест",
            bossLore = "Тъмният Владетел: Бивш крал, предаден от боговете. Търси реванш.",
            secretArea = "🔍 Тайна пещера с Праисторически Артефакти зад третия замък",
            recommendedLevel = 1,
            atmosphereDesc = "Земна, реална, с мирис на злато и кръв",
            musicStyle = "Средновековен Оркестър"
        ),
        WorldDetail(
            name = "Олимп",
            emoji = "⚡",
            mythology = "Greek",
            description = "Домът на гръцките богове. Злато, мрамор, и мълнии навсякъде.",
            history = "Зевс завоюва Олимп след победата над Кронос. Дотогава — Хаос. Сега — ред. Или нещо подобно на ред.",
            dominantElement = "Мълния",
            uniqueMechanic = "+20% Дивинити от гръцки врагове. Мълниеносни атаки на боса.",
            bossLore = "Зевс: Цар на боговете. Използва Мълния, Гръм, и Олимпийска Гордост като оръжия.",
            secretArea = "🔍 Тронната зала на Зевс: Достъпна след победа над него. Съдържа Мълниеносна Руна.",
            recommendedLevel = 5,
            atmosphereDesc = "Вечно синьо небе, облаци, бляскаво злато",
            musicStyle = "Гръцки Епичен Оркестър"
        ),
        WorldDetail(
            name = "Тартар",
            emoji = "💀",
            mythology = "Greek",
            description = "Гръцкото подземие. Мрачно, смъртоносно, и пълно с паднали титани.",
            history = "Зевс хвърли победените Титани тук. Те чакат. И планират. Хиляди години.",
            dominantElement = "Тъмнина",
            uniqueMechanic = "Смъртта дава +50% EXP. Риското се отплаща.",
            bossLore = "Кронос: Баща на Зевс. Погълнат от собствения си syn. Вилнее от гняв.",
            secretArea = "🔍 Стикс Мост: Преплуй реката на мъртвите за скрит Некро Предмет",
            recommendedLevel = 8,
            atmosphereDesc = "Пепелно сиво, огнени ями, ехо от забравени крясъци",
            musicStyle = "Тъмен Амбиент Оркестър"
        ),
        WorldDetail(
            name = "Асгард",
            emoji = "🏔️",
            mythology = "Norse",
            description = "Домът на скандинавските богове. Величествен, студен, и готов за Рагнарок.",
            history = "Един го построи от нищото. Дигна стените с помощта на великан — после не му плати. Типично.",
            dominantElement = "Лед + Мълния",
            uniqueMechanic = "Берсерк ефект: При под 30% HP — ATK x2",
            bossLore = "Один: Всебащата. Едното oko вижда всичко. Гунгнирът никога не пропуска.",
            secretArea = "🔍 Иггдрасил: Световното Дърво. Съдържа Руна на Съдбата.",
            recommendedLevel = 11,
            atmosphereDesc = "Вечна зима, северно сияние, звук от рога",
            musicStyle = "Скандинавски Метъл Оркестър"
        ),
        WorldDetail(
            name = "Египет",
            emoji = "☀️",
            mythology = "Egyptian",
            description = "Земята на фараоните и вечните богове. Пясък, злато, и загадки.",
            history = "Ра създаде Египет от Хаоса. Анубис организира смъртта. Хор пазеше. Сет предаде. Типична семейна драма.",
            dominantElement = "Слънце + Пясък",
            uniqueMechanic = "+25% злато от египетски врагове. Проклятия работят 2x по-дълго.",
            bossLore = "Ра: Слънчевият бог. Умира всяка вечер, ражда се всяка сутрин. Не разбира умора.",
            secretArea = "🔍 Мумифицираната Зала: Скрити Пирамиди с Ancient Egyptian Set предмети",
            recommendedLevel = 13,
            atmosphereDesc = "Изгаряща жега, пясъчни бури, блясък на злато",
            musicStyle = "Египетски Мистичен Оркестър"
        ),
        WorldDetail(
            name = "Дракон Царство",
            emoji = "🐉",
            mythology = "Dragon",
            description = "Светът, управляван от дракони. Не са приятелски настроени.",
            history = "Тиамат е майката на всички дракони. Тя е избрала тези земи преди боговете да съществуват.",
            dominantElement = "Огън + Дракон",
            uniqueMechanic = "Дракон Люспи: Рядък материал само тук. Занаят Tier-5 изисква.",
            bossLore = "Тиамат: Майката Дракон. 7 глави, 7 елемента. Един удар = половин HP.",
            secretArea = "🔍 Дракон Яйце Пещера: Намери и поглъщай яйце за Pet Хаос Осколок",
            recommendedLevel = 16,
            atmosphereDesc = "Пламтящо небе, разтопена лава, дракон крила в хоризонта",
            musicStyle = "Епичен Дракон Метъл"
        ),
        WorldDetail(
            name = "Царство на Титаните",
            emoji = "⚡",
            mythology = "Titan",
            description = "Преди боговете — Титаните. Техните руини са тук. Те не са само руини.",
            history = "Кронос управляваше преди Зевс. Загуби. Но Титаните не умряха — само бяха затворени.",
            dominantElement = "Земя + Огън",
            uniqueMechanic = "Titanfall: При убийство на Титан — земетресение уврежда всички врагове",
            bossLore = "Атлас: Носи небесата на раменете. Опита се да ги сложи при теб. Не успя.",
            secretArea = "🔍 Иапет Крепост: Руни Tier-6 скрити в основите",
            recommendedLevel = 20,
            atmosphereDesc = "Огромни руини, колоси от камък, ехо от древни войни",
            musicStyle = "Монументален Епичен Оркестър"
        ),
        WorldDetail(
            name = "Япония",
            emoji = "🌸",
            mythology = "Japanese",
            description = "Земята на сакурата и самураите. Красиво и смъртоносно.",
            history = "Аматерасу се скри в пещера — светът потъна в мрак. После танцьорки я примамиха навън. Ефективно.",
            dominantElement = "Светлина + Вятър",
            uniqueMechanic = "Бусидо: Смъртта в битка дава +500 Дивинити на следващата",
            bossLore = "Сусаноо: Бурният бог. Убил 8-главния змей Ямата но Орочи. Ще опита с теб.",
            secretArea = "🔍 Сакура Светилище: Молитва тук дава временен Аматерасу Благослов",
            recommendedLevel = 24,
            atmosphereDesc = "Сакура листа, тихи планини, звук от шамисен",
            musicStyle = "Японски Традиционен + Епик"
        ),
        WorldDetail(
            name = "Китай",
            emoji = "🏯",
            mythology = "Chinese",
            description = "Царство на дракони, легенди и Jade Emperor.",
            history = "Нефритеният Император управлява Небесния Двор. 100 000 богове под него. Бюрокрацията е реална дори в митологиите.",
            dominantElement = "Нефрит + Гръм",
            uniqueMechanic = "72 Форми: Специална атака прави 72 удара за ход",
            bossLore = "Sun Wukong: Маймунският Крал. 72 Форми, Магически Прът, Облак. Не се подценява.",
            secretArea = "🔍 Нефритен Дворец: Съдържа Нефритена Руна Tier-4",
            recommendedLevel = 28,
            atmosphereDesc = "Нефрит и злато, облачни дворци, дракони в небето",
            musicStyle = "Китайски Епичен Оркестър + Дракон"
        ),
        WorldDetail(
            name = "Индия",
            emoji = "🕉️",
            mythology = "Indian",
            description = "Светът на Шива, Вишну и Брахма. Разрушение, опазване, творение.",
            history = "Тримурти: Брахма твори, Вишну опазва, Шива разрушава. Циклично. Вечно. Ритмично.",
            dominantElement = "Огън + Дух",
            uniqueMechanic = "Карма: Всяко добро дело дава +10% за следващата битка",
            bossLore = "Шива: Богът на Разрушението. Тандава танцът разрушава и твори. Третото oko изгаря всичко.",
            secretArea = "🔍 Ганг Брегове: Пречистване ритуал дава +1000 HP за сесията",
            recommendedLevel = 9,
            atmosphereDesc = "Горещина, аромат на тамян, звук от ситар",
            musicStyle = "Индийски Класически + Епичен"
        ),
        WorldDetail(
            name = "Арена",
            emoji = "🏟️",
            mythology = "Universal",
            description = "Безкрайни вълни. Безкрайни врагове. Безкрайна слава.",
            history = "Построена от боговете за забавление. После смъртните започнаха да я използват по-сериозно. Боговете са впечатлени.",
            dominantElement = "Всички",
            uniqueMechanic = "Вълна Система: Всяка вълна е по-трудна. Най-добрите стигат вълна 50+",
            bossLore = "Арена Шампион: Единственият, победил 100 вълни. Пази рекорда с живот.",
            secretArea = "🔍 VIP Ложа: Достъпна след вълна 25. Съдържа легендарни зрители предмети.",
            recommendedLevel = 1,
            atmosphereDesc = "Рев на тълпата, звън на метал, адреналин",
            musicStyle = "Интензивен Боен Хардкор"
        )
    )

    fun getWorldByName(name: String) = WORLD_DETAILS.firstOrNull { it.name == name }

    fun getWorldsByMythology(mythology: String) = WORLD_DETAILS.filter { it.mythology == mythology }

    fun getAllSecretAreas(): List<Pair<String, String>> = WORLD_DETAILS.map { it.name to it.secretArea }

    fun getWorldRecommendations(level: Int): List<WorldDetail> =
        WORLD_DETAILS.filter { it.recommendedLevel <= level }
            .sortedByDescending { it.recommendedLevel }
            .take(3)

    fun getWorldAtmosphereText(worldName: String): String {
        val world = getWorldByName(worldName) ?: return "Неизвестен свят"
        return buildString {
            appendLine("${world.emoji} ${world.name}")
            appendLine("━━━━━━━━━━━━━━━━")
            appendLine("📖 ${world.description}")
            appendLine()
            appendLine("📜 История: ${world.history}")
            appendLine()
            appendLine("⚡ Елемент: ${world.dominantElement}")
            appendLine("🎮 Уникална механика: ${world.uniqueMechanic}")
            appendLine()
            appendLine("👑 Бос: ${world.bossLore}")
            appendLine()
            appendLine("${world.secretArea}")
            appendLine()
            appendLine("🎵 Музика: ${world.musicStyle}")
            appendLine("🌅 Атмосфера: ${world.atmosphereDesc}")
        }
    }
}

// ─────────────────────────────────────────────
//  ACHIEVEMENT STATISTICS TRACKER
// ─────────────────────────────────────────────

object AchievementStatisticsTracker {

    data class AchievementSession(
        val date: String,
        val achievementsUnlocked: Int,
        val secretsUnlocked: Int,
        val totalGoldEarned: Int,
        val totalDivinityEarned: Int,
        val bestCombo: String,
        val bossesKilled: Int,
        val worldsVisited: List<String>
    )

    val RARITY_POINT_VALUES = mapOf(
        "Common" to 1,
        "Uncommon" to 3,
        "Rare" to 7,
        "Epic" to 15,
        "Legendary" to 30,
        "Divine" to 75,
        "OMNIGOD" to 200
    )

    val ACHIEVEMENT_CATEGORIES = mapOf(
        "⚔️ Бойни" to listOf("Убий 1000 врагове", "Победи всички богове", "Използвай всички комба"),
        "✨ Дивинити" to listOf("1000 Дивинити", "10 000 Дивинити", "50 000 Дивинити — ВСЕБОГ"),
        "📖 История" to listOf("Завърши Глава 1", "Завърши всички 5 глави"),
        "🏰 Гилдия" to listOf("Влез в гилдия", "Спечели гилдийна война"),
        "⚔️ PvP" to listOf("Първа PvP победа", "Достигни Грандмайстор"),
        "🐾 Питомци" to listOf("Купи питомец", "Еволюирай до Митично"),
        "💎 Руни" to listOf("Екипирай руна", "Пълен Сет Бонус"),
        "🌌 Ендгейм" to listOf("Престиж 8", "Истинският Всебог")
    )

    fun calculateAchievementScore(unlockedIds: List<String>): Int {
        return AchievementExpansionV2.SECRET_ACHIEVEMENTS
            .filter { it.id in unlockedIds }
            .sumOf { RARITY_POINT_VALUES[it.rarity] ?: 0 }
    }

    fun getCompletionPercentage(unlocked: Int, total: Int = 57): Float =
        if (total == 0) 0f else (unlocked.toFloat() / total) * 100f

    fun getRankByScore(score: Int): String = when {
        score >= 500 -> "🌌 ВСЕБОГ КОЛЕКЦИОНЕР"
        score >= 300 -> "👑 Легендарен Ловец"
        score >= 150 -> "🌟 Митичен Колекционер"
        score >= 75 -> "💫 Епичен Ловец"
        score >= 30 -> "⭐ Редовен Колекционер"
        else -> "🎯 Начинаещ Ловец"
    }

    fun buildAchievementReport(unlocked: Int, score: Int): String = buildString {
        appendLine("🏆 ПОСТИЖЕНИЯ ДОКЛАД")
        appendLine("━━━━━━━━━━━━━━━━")
        appendLine("Отключени: $unlocked/57")
        appendLine("Процент: ${"%.1f".format(getCompletionPercentage(unlocked))}%")
        appendLine("Точки: $score")
        appendLine("Ранг: ${getRankByScore(score)}")
        appendLine()
        appendLine("Категории:")
        ACHIEVEMENT_CATEGORIES.forEach { (cat, items) ->
            appendLine("  $cat: ${items.size} постижения")
        }
        appendLine()
        appendLine("Тайни Постижения: ${AchievementExpansionV2.SECRET_ACHIEVEMENTS.size}")
        appendLine("OMNIGOD Постижения: 1 (Истинският Всебог)")
    }
}
