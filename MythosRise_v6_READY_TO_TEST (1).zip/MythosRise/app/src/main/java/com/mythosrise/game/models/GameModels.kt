package com.mythosrise.game.models

import com.google.gson.Gson

// ─────────────────────────────────────────────
//  ENUMS
// ─────────────────────────────────────────────

enum class Gender(val displayName: String, val emoji: String) {
    MALE("Мъж", "⚔️"),
    FEMALE("Жена", "🌸"),
    NONBINARY("Небинарен", "✨")
}

enum class SkinTone(val displayName: String, val colorHex: String) {
    FAIR("Светла кожа", "#FFDBC1"),
    OLIVE("Маслинена кожа", "#C68642"),
    BROWN("Тъмно кафява", "#8D5524"),
    DARK("Тъмна кожа", "#3B1F10"),
    GOLDEN("Златна кожа", "#D4A843")
}

enum class HeroClass(val displayName: String, val description: String, val emoji: String,
                     val baseHp: Int, val baseAtk: Int, val baseDef: Int, val baseMana: Int) {
    WARRIOR("Воин", "Майстор на меч и щит. Силен в близък бой.", "⚔️", 150, 15, 12, 50),
    MAGE("Маг", "Владее магията на древните. Мощни заклинания.", "🔮", 80, 25, 5, 150),
    ARCHER("Ловец", "Бърз и прецизен. Смъртоносен от разстояние.", "🏹", 110, 18, 8, 80),
    MONK("Монах", "Балансира тяло и дух. Контраатаки.", "🥋", 120, 12, 15, 100)
}

enum class DivinityTitle(val title: String, val minDivinity: Int, val color: String) {
    MORTAL("Смъртен", 0, "#FFFFFF"),
    CHAMPION("Шампион", 100, "#C0C0C0"),
    DEMIGOD("Полубог", 500, "#FFD700"),
    TITAN("Титан", 1500, "#FF6B00"),
    LESSER_GOD("Малък Бог", 4000, "#9B59B6"),
    MAJOR_GOD("Велик Бог", 10000, "#3498DB"),
    SUPREME_GOD("Върховен Бог", 25000, "#E74C3C"),
    OMNIGOD("ВСЕБОГ", 50000, "#FF00FF")
}

enum class World(val displayName: String, val description: String, val emoji: String, val unlockLevel: Int) {
    MORTAL_REALM("Смъртното Кралство", "Родното ти кралство. Начало на всичко.", "🏰", 1),
    GREEK_OLYMPUS("Гръцки Олимп", "Светът на олимпийските богове. Зевс те чака.", "🏛️", 5),
    TARTARUS("Тартар", "Подземното царство на Хадес. Абсолютна тъмнина.", "🌑", 10),
    EGYPTIAN_REALM("Египетски Пантеон", "Фараони, богове и вечни пустини. Ра те очаква.", "🏺", 13),
    DRAGON_REALM("Царството на Дракони", "Дракони от всички митологии. Огън и хаос.", "🐉", 16),
    INDIAN_REALM("Индийски Пантеон", "Свят на Вишну, Шива и Брахма.", "🕉️", 20),
    JAPANESE_REALM("Японски Пантеон", "Самураи, Они демони и богове на Япония.", "⛩️", 24),
    CHINESE_REALM("Китайски Пантеон", "Слънчевият маймун, Нефритеният Император и Дракон Кралете.", "🐲", 28),
    NORSE_ASGARD("Скандинавски Асгард", "Войни Викинги и богове на Асгард.", "⚡", 32),
    TITAN_REALM("Царството на Титаните", "Пред-олимпийски чудовища на безумна сила.", "🌋", 38),
    MASS_BATTLE_ARENA("Арената на Масовите Битки", "Стотици врагове. Само един оцелява.", "⚔️", 25),
    DIVINE_PANTHEON("Божественият Пантеон", "Последната битка. Стани Всебог.", "✨", 45)
}

enum class Rarity(val displayName: String, val color: String, val multiplier: Float) {
    COMMON("Обикновен", "#AAAAAA", 1.0f),
    UNCOMMON("Необичаен", "#00FF00", 1.3f),
    RARE("Рядък", "#4444FF", 1.7f),
    EPIC("Епичен", "#AA00FF", 2.3f),
    LEGENDARY("Легендарен", "#FF8800", 3.2f),
    MYTHIC("Митичен", "#FF0000", 5.0f),
    DIVINE("Божествен", "#FFD700", 8.0f)
}

// ─────────────────────────────────────────────
//  ABILITY
// ─────────────────────────────────────────────

data class Ability(
    val id: String,
    val name: String,
    val description: String,
    val manaCost: Int,
    val cooldownTurns: Int,
    val damageMultiplier: Float,
    val healPercent: Float = 0f,
    val stunChance: Float = 0f,
    val aoeRadius: Float = 0f,
    val emoji: String = "⚡",
    var currentCooldown: Int = 0,
    val requiredDivinity: Int = 0
)

// ─────────────────────────────────────────────
//  ITEM
// ─────────────────────────────────────────────

enum class ItemType { WEAPON, ARMOR, HELMET, BOOTS, RING, AMULET, POTION, SPECIAL }

data class Item(
    val id: String,
    val name: String,
    val description: String,
    val type: ItemType,
    val rarity: Rarity,
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val healthBonus: Int = 0,
    val manaBonus: Int = 0,
    val divinityBonus: Int = 0,
    val speedBonus: Float = 0f,
    val mythology: String = "Mortal",
    val emoji: String = "⚔️",
    val specialEffect: String = "",
    val value: Int = 0
)

// ─────────────────────────────────────────────
//  ENEMY
// ─────────────────────────────────────────────

data class Enemy(
    val id: String,
    val name: String,
    val description: String,
    val mythology: String,
    val world: World,
    val level: Int,
    val maxHealth: Int,
    var currentHealth: Int = maxHealth,
    val attack: Int,
    val defense: Int,
    val divinityReward: Int,
    val expReward: Int,
    val goldReward: Int,
    val abilities: List<EnemyAbility> = emptyList(),
    val possibleDrops: List<String> = emptyList(),
    val emoji: String = "👹",
    val isBoss: Boolean = false,
    val specialPower: String = "",
    val loreText: String = ""
)

data class EnemyAbility(
    val name: String,
    val damageMultiplier: Float,
    val chance: Float,
    val description: String
)

// ─────────────────────────────────────────────
//  DIALOGUE
// ─────────────────────────────────────────────

data class DialogueLine(
    val speaker: String,
    val text: String,
    val choices: List<DialogueChoice> = emptyList(),
    val emoji: String = ""
)

data class DialogueChoice(
    val text: String,
    val nextDialogueId: String? = null,
    val effect: DialogueEffect? = null
)

data class DialogueEffect(
    val goldChange: Int = 0,
    val expChange: Int = 0,
    val divinityChange: Int = 0,
    val itemId: String? = null,
    val abilityId: String? = null
)

data class Dialogue(
    val id: String,
    val lines: List<DialogueLine>,
    val triggeredBy: String = ""
)

// ─────────────────────────────────────────────
//  CHARACTER
// ─────────────────────────────────────────────

data class Character(
    var name: String = "Герой",
    var gender: Gender = Gender.MALE,
    var skinTone: SkinTone = SkinTone.FAIR,
    var heroClass: HeroClass = HeroClass.WARRIOR,
    var level: Int = 1,
    var experience: Long = 0L,
    var experienceToNext: Long = 100L,
    var health: Int = 150,
    var maxHealth: Int = 150,
    var mana: Int = 50,
    var maxMana: Int = 50,
    var attack: Int = 15,
    var defense: Int = 12,
    var speed: Float = 1.0f,
    var divinity: Int = 0,
    var divinityTitle: DivinityTitle = DivinityTitle.MORTAL,
    var gold: Int = 0,
    var inventory: MutableList<Item> = mutableListOf(),
    var equippedWeapon: Item? = null,
    var equippedArmor: Item? = null,
    var equippedHelmet: Item? = null,
    var equippedBoots: Item? = null,
    var equippedRing: Item? = null,
    var equippedAmulet: Item? = null,
    var abilities: MutableList<Ability> = mutableListOf(),
    var currentWorld: World = World.MORTAL_REALM,
    var enemiesDefeated: Int = 0,
    var titansDefeated: Int = 0,
    var godsDefeated: Int = 0,
    var absorbedPowers: MutableList<String> = mutableListOf()
) {
    fun getTotalAttack(): Int {
        val weaponBonus = equippedWeapon?.attackBonus ?: 0
        val ringBonus = equippedRing?.attackBonus ?: 0
        return attack + weaponBonus + ringBonus + (divinity / 100)
    }

    fun getTotalDefense(): Int {
        val armorBonus = equippedArmor?.defenseBonus ?: 0
        val helmetBonus = equippedHelmet?.defenseBonus ?: 0
        val bootsBonus = equippedBoots?.defenseBonus ?: 0
        return defense + armorBonus + helmetBonus + bootsBonus
    }

    fun getTotalMaxHealth(): Int {
        val amuletBonus = equippedAmulet?.healthBonus ?: 0
        return maxHealth + amuletBonus + (divinity / 50)
    }

    fun updateDivinityTitle() {
        divinityTitle = DivinityTitle.values().filter { it.minDivinity <= divinity }.maxByOrNull { it.minDivinity }
            ?: DivinityTitle.MORTAL
    }

    fun gainExperience(exp: Long) {
        experience += exp
        while (experience >= experienceToNext) {
            experience -= experienceToNext
            levelUp()
        }
    }

    private fun levelUp() {
        level++
        experienceToNext = (experienceToNext * 1.5).toLong()
        when (heroClass) {
            HeroClass.WARRIOR -> { maxHealth += 20; attack += 3; defense += 2 }
            HeroClass.MAGE -> { maxHealth += 8; attack += 6; maxMana += 15 }
            HeroClass.ARCHER -> { maxHealth += 12; attack += 4; speed += 0.05f }
            HeroClass.MONK -> { maxHealth += 15; attack += 2; defense += 4 }
        }
        health = getTotalMaxHealth()
        mana = maxMana
    }

    fun absorbPower(enemy: Enemy) {
        divinity += enemy.divinityReward
        attack += enemy.attack / 20
        defense += enemy.defense / 20
        maxHealth += enemy.maxHealth / 30
        absorbedPowers.add(enemy.name)
        updateDivinityTitle()
    }

    fun toJson(): String = Gson().toJson(this)

    companion object {
        fun fromJson(json: String): Character = Gson().fromJson(json, Character::class.java)
    }
}
