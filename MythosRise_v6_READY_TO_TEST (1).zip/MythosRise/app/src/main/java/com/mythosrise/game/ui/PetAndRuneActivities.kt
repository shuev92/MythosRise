package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

// ─────────────────────────────────────────────
//  PET ACTIVITY
// ─────────────────────────────────────────────
class PetActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var showOwned = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet)
        engine = GameEngine(this); engine.loadGame()
        llContent = findViewById(R.id.llPetContent)
        tvHeader = findViewById(R.id.tvPetHeader)
        setupTabs(); showAllPets()
    }

    private fun setupTabs() {
        val ll = findViewById<LinearLayout>(R.id.llPetTabs)
        ll.removeAllViews()
        listOf("Всички" to false, "Мои" to true).forEach { (label, owned) ->
            Button(this).apply {
                text = label; textSize = 12f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (showOwned == owned) Color.parseColor("#006622") else Color.parseColor("#2C2C2C"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2,0,2,0) }
                setOnClickListener { showOwned = owned; setupTabs(); showAllPets() }
            }.also { ll.addView(it) }
        }
    }

    private fun showAllPets() {
        llContent.removeAllViews()
        val pets = if (showOwned) PetSystem.getOwnedPets() else PetSystem.ALL_PETS
        tvHeader.text = if (showOwned) "🐾 МОИ ПИТОМЦИ" else "🐾 ВСИЧКИ ПИТОМЦИ"

        val activePet = PetSystem.getActivePet()
        activePet?.let {
            val banner = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#001A00")); setPadding(12, 10, 12, 10)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,10) }
            }
            addText(banner, "🟢 АКТИВЕН: ${it.emoji} ${it.name} — ${it.stage.emoji} ${it.stage.displayName}", "#00CC88", 13f)
            addText(banner, "Ниво: ${it.level} | EXP: ${it.experience}", "#FFFFFF", 11f)
            addText(banner, "✨ ${it.specialAbility}", "#9B59B6", 11f)
            llContent.addView(banner)
        }

        if (pets.isEmpty()) {
            addText(llContent, "Нямаш питомци! Купи от списъка.", "#888888", 14f); return
        }

        pets.forEach { pet ->
            val canAfford = when (pet.costType) {
                "gold" -> engine.character.gold >= pet.baseCost
                "divinity" -> engine.character.divinity >= pet.baseCost
                else -> false
            }
            val bgColor = when { pet.isActive -> "#001A00"; pet.isOwned -> "#0A0A1A"; else -> "#080808" }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor(bgColor))
                setPadding(12, 10, 12, 10)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,5,0,5) }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addTextV(row, pet.emoji, 36f, "#FFFFFF", 0, 0, 12, 0)
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            addText(info, "${pet.name} [${pet.rarity}]", "#FFFFFF", 14f)
            addText(info, "${pet.mythology} | ${if (pet.isOwned) "${pet.stage.emoji} Ниво ${pet.level}" else "🔒 Не е купен"}", "#9B59B6", 11f)
            addText(info, pet.description, "#888888", 11f)
            row.addView(info)
            card.addView(row)
            addText(card, "⚔️+${pet.attackBonus} 🛡️+${pet.defenseBonus} ❤️+${pet.healthBonus} 💰+${(pet.goldBonus*100).toInt()}%", "#FFD700", 11f)
            addText(card, "✨ ${pet.specialAbility}", "#9B59B6", 11f)
            if (pet.isOwned) {
                addText(card, "🌟 ${pet.evolutionBonus}", "#00CC88", 10f)
                val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                if (!pet.isActive) {
                    Button(this).apply {
                        text = "▶️ Активирай"; textSize = 11f; setTextColor(Color.WHITE)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#006622"))
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0,4,2,0) }
                        setOnClickListener { PetSystem.activatePet(pet.id); engine.saveGame(); showAllPets() }
                    }.also { btnRow.addView(it) }
                } else {
                    Button(this).apply {
                        text = "✅ АКТИВЕН"; textSize = 11f; setTextColor(Color.WHITE); isEnabled = false
                        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#003311"))
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0,4,0,0) }
                    }.also { btnRow.addView(it) }
                }
                card.addView(btnRow)
            } else {
                val costText = if (pet.costType == "gold") "💰 ${pet.baseCost}" else "✨ ${pet.baseCost}"
                Button(this).apply {
                    text = "🛒 Купи — $costText"; textSize = 11f; setTextColor(Color.WHITE); isEnabled = canAfford
                    backgroundTintList = android.content.res.ColorStateList.valueOf(if (canAfford) Color.parseColor("#1A5C2A") else Color.parseColor("#333333"))
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,6,0,0) }
                    setOnClickListener {
                        if (PetSystem.purchasePet(pet.id, engine.character)) {
                            engine.saveGame()
                            Toast.makeText(this@PetActivity, "🎉 ${pet.name} е твой!", Toast.LENGTH_SHORT).show()
                            showAllPets()
                        }
                    }
                }.also { card.addView(it) }
            }
            llContent.addView(card)
        }
    }

    private fun addText(parent: LinearLayout, text: String, color: String, size: Float) {
        TextView(this).apply { this.text = text; setTextColor(Color.parseColor(color)); textSize = size; setPadding(0, 2, 0, 2) }.also { parent.addView(it) }
    }
    private fun addTextV(parent: LinearLayout, text: String, size: Float, color: String, l: Int, t: Int, r: Int, b: Int) {
        TextView(this).apply { this.text = text; textSize = size; setTextColor(Color.parseColor(color)); setPadding(l, t, r, b) }.also { parent.addView(it) }
    }
}

// ─────────────────────────────────────────────
//  RUNE ACTIVITY
// ─────────────────────────────────────────────
class RuneActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentTab = "Руни"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rune)
        engine = GameEngine(this); engine.loadGame()
        llContent = findViewById(R.id.llRuneContent)
        tvHeader = findViewById(R.id.tvRuneHeader)
        setupTabs(); showRunesTab()
    }

    private fun setupTabs() {
        val tabs = listOf("Руни", "Екипирани", "Сетове", "Наръчник")
        val ll = findViewById<LinearLayout>(R.id.llRuneTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            Button(this).apply {
                text = tab; textSize = 10f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(if (tab == currentTab) Color.parseColor("#4A0080") else Color.parseColor("#2C2C2C"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2,0,2,0) }
                setOnClickListener { currentTab = tab; setupTabs(); when(tab) { "Руни" -> showRunesTab(); "Екипирани" -> showEquippedTab(); "Сетове" -> showSetsTab(); "Наръчник" -> showGuideTab() } }
            }.also { ll.addView(it) }
        }
    }

    private fun showRunesTab() {
        llContent.removeAllViews()
        tvHeader.text = "💎 РУНИ — ${RuneSystem.getEquippedRunes().size}/${RuneSystem.MAX_SOCKETS} слота"
        val c = engine.character
        val available = RuneSystem.getAvailableRunes(c.level, c.divinity)
        addSectionTitle("💎 НАЛИЧНИ РУНИ (${available.size})")
        available.forEach { rune ->
            val equipped = rune.isEquipped
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(if (equipped) Color.parseColor("#1A001A") else Color.parseColor("#0A0A1A"))
                setPadding(10, 8, 10, 8)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,4,0,4) }
            }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addTextV(header, rune.emoji, 22f, "#FFFFFF", 0, 0, 10, 0)
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            addText(info, "${rune.name} [Tier ${rune.tier}]", if (equipped) "#CC88FF" else "#FFFFFF", 13f)
            addText(info, "${rune.type.emoji} ${rune.type.displayName} | ${rune.mythology}", "#9B59B6", 11f)
            addText(info, rune.description, "#888888", 10f)
            header.addView(info)
            card.addView(header)
            val statParts = mutableListOf<String>()
            if (rune.attackBonus > 0) statParts.add("⚔️+${rune.attackBonus}")
            if (rune.defenseBonus > 0) statParts.add("🛡️+${rune.defenseBonus}")
            if (rune.healthBonus > 0) statParts.add("❤️+${rune.healthBonus}")
            if (rune.divinityBonus > 0) statParts.add("✨+${(rune.divinityBonus*100).toInt()}%")
            if (rune.goldBonus > 0) statParts.add("💰+${(rune.goldBonus*100).toInt()}%")
            if (rune.critBonus > 0) statParts.add("💥+${(rune.critBonus*100).toInt()}%")
            if (statParts.isNotEmpty()) addText(card, statParts.joinToString(" "), "#FFD700", 11f)
            if (rune.specialEffect.isNotBlank()) addText(card, "✨ ${rune.specialEffect}", "#00CC88", 11f)
            Button(this).apply {
                text = if (equipped) "❌ Извади от слот ${rune.equippedSlot}" else "💎 Добави в слот"
                textSize = 11f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(if (equipped) Color.parseColor("#330000") else Color.parseColor("#1A001A"))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,6,0,0) }
                setOnClickListener {
                    if (equipped) { RuneSystem.removeRune(rune.equippedSlot); Toast.makeText(this@RuneActivity, "Руна извадена.", Toast.LENGTH_SHORT).show() }
                    else {
                        val nextSlot = (0 until RuneSystem.MAX_SOCKETS).firstOrNull { slot -> RuneSystem.ALL_RUNES.none { it.equippedSlot == slot } }
                        if (nextSlot != null) { RuneSystem.socketRune(rune, nextSlot); Toast.makeText(this@RuneActivity, "💎 ${rune.name} → Слот $nextSlot", Toast.LENGTH_SHORT).show() }
                        else Toast.makeText(this@RuneActivity, "Всички слотове са пълни!", Toast.LENGTH_SHORT).show()
                    }
                    showRunesTab()
                }
            }.also { card.addView(it) }
            llContent.addView(card)
        }
    }

    private fun showEquippedTab() {
        llContent.removeAllViews(); tvHeader.text = "💎 ЕКИПИРАНИ РУНИ"
        val equipped = RuneSystem.getEquippedRunes()
        if (equipped.isEmpty()) { addText(llContent, "Нямаш екипирани руни!", "#888888", 14f); return }
        addSectionTitle("💎 СЛОТОВЕ (${equipped.size}/${RuneSystem.MAX_SOCKETS})")
        equipped.forEach { rune ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#1A001A")); setPadding(10, 8, 10, 8)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,3,0,3) }
            }
            addTextV(row, "Слот ${rune.equippedSlot}: ${rune.emoji}", 18f, "#FFFFFF", 0, 0, 10, 0)
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            addText(info, rune.name, "#CC88FF", 13f)
            addText(info, "Tier ${rune.tier} | ${rune.mythology}", "#888888", 11f)
            row.addView(info)
            llContent.addView(row)
        }
        val sets = RuneSystem.getActiveSetBonuses()
        if (sets.isNotEmpty()) {
            addSectionTitle("🏆 АКТИВНИ СЕТ БОНУСИ")
            sets.forEach { (set, count) ->
                addText(llContent, "${set.emoji} ${set.name} (${count} части):", "#FFD700", 13f)
                if (count >= 2) addText(llContent, "  ✅ 2 части: ${set.setBonus2}", "#00CC88", 11f)
                if (count >= 4) addText(llContent, "  ✅ 4 части: ${set.setBonus4}", "#00CC88", 11f)
                if (count >= 6) addText(llContent, "  ✅ 6 части: ${set.setBonus6}", "#00CC88", 11f)
            }
        }
    }

    private fun showSetsTab() {
        llContent.removeAllViews(); tvHeader.text = "🏆 РУН СЕТОВЕ"
        RuneSystem.RUNE_SETS.forEach { set ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0A0A1A")); setPadding(12, 10, 12, 10)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,5,0,5) }
            }
            addText(card, "${set.emoji} ${set.name} [${set.mythology}]", "#FFD700", 14f)
            addText(card, "Руни в сета: ${set.runeIds.size}", "#888888", 11f)
            addText(card, "2 части: ${set.setBonus2}", "#FFFFFF", 11f)
            addText(card, "4 части: ${set.setBonus4}", "#FFFFFF", 11f)
            addText(card, "6 части: ${set.setBonus6}", "#FF8800", 12f)
            llContent.addView(card)
        }
    }

    private fun showGuideTab() {
        llContent.removeAllViews(); tvHeader.text = "📚 РЪКОВОДСТВО ЗА РУНИ"
        val guide = RuneSystem.getRuneGuide()
        addText(llContent, guide, "#CCCCCC", 12f)
    }

    private fun addSectionTitle(title: String) {
        TextView(this).apply { text = title; setTextColor(Color.parseColor("#9B59B6")); textSize = 13f; isFakeBoldText = true; setPadding(4, 12, 4, 6) }.also { llContent.addView(it) }
    }
    private fun addText(parent: LinearLayout, text: String, color: String, size: Float) {
        TextView(this).apply { this.text = text; setTextColor(Color.parseColor(color)); textSize = size; setPadding(0, 2, 0, 2) }.also { parent.addView(it) }
    }
    private fun addTextV(parent: LinearLayout, text: String, size: Float, color: String, l: Int, t: Int, r: Int, b: Int) {
        TextView(this).apply { this.text = text; textSize = size; setTextColor(Color.parseColor(color)); setPadding(l, t, r, b) }.also { parent.addView(it) }
    }
}
