package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.AchievementManager
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.Character

class AchievementActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llAchievements: LinearLayout
    private lateinit var tvProgress: TextView
    private var filterCategory = "Всички"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)
        engine = GameEngine(this)
        engine.loadGame()

        llAchievements = findViewById(R.id.llAchievementList)
        tvProgress = findViewById(R.id.tvAchievementProgress)

        setupCategoryButtons()
        renderAchievements()
    }

    private fun setupCategoryButtons() {
        val categories = listOf("Всички", "Битка", "Дивинити", "Прогресия", "Изследване", "Предмети", "Легенди", "Арена", "Специални")
        val scrollH = findViewById<HorizontalScrollView>(R.id.hsvCategories)
        val ll = scrollH.getChildAt(0) as LinearLayout

        categories.forEach { cat ->
            val btn = Button(this).apply {
                text = cat; textSize = 12f
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (cat == filterCategory) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(4, 0, 4, 0)
                layoutParams = lp
                setOnClickListener {
                    filterCategory = cat
                    setupCategoryButtons()
                    renderAchievements()
                }
            }
            ll.addView(btn)
        }
    }

    private fun renderAchievements() {
        llAchievements.removeAllViews()

        val unlocked = AchievementManager.getUnlockedCount()
        val total = AchievementManager.getTotalCount()
        tvProgress.text = "🏆 $unlocked / $total Постижения отключени"

        val achievements = if (filterCategory == "Всички") AchievementManager.ALL_ACHIEVEMENTS
        else AchievementManager.getByCategory(filterCategory)

        // Unlocked first
        achievements.sortedByDescending { it.unlocked }.forEach { ach ->
            val view = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(
                    if (ach.unlocked) Color.parseColor("#1A2A0A") else Color.parseColor("#0A0A1A")
                )
                alpha = if (ach.unlocked) 1.0f else 0.5f
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 4, 0, 4)
                layoutParams = lp
            }

            // Emoji + lock
            val emojTv = TextView(this).apply {
                text = if (ach.unlocked) ach.emoji else "🔒"
                textSize = 28f; setPadding(0, 0, 12, 0)
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val rarityColor = when (ach.rarity) {
                com.mythosrise.game.engine.AchievementRarity.BRONZE -> "#CD7F32"
                com.mythosrise.game.engine.AchievementRarity.SILVER -> "#C0C0C0"
                com.mythosrise.game.engine.AchievementRarity.GOLD -> "#FFD700"
                com.mythosrise.game.engine.AchievementRarity.PLATINUM -> "#E5E4E2"
                com.mythosrise.game.engine.AchievementRarity.DIAMOND -> "#B9F2FF"
                com.mythosrise.game.engine.AchievementRarity.LEGENDARY -> "#FF6600"
            }

            TextView(this).apply {
                text = "${ach.title} — ${ach.rarity.label}"
                setTextColor(Color.parseColor(rarityColor)); textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }

            TextView(this).apply {
                text = if (ach.unlocked) ach.description else "???"
                setTextColor(Color.LTGRAY); textSize = 12f
            }.also { info.addView(it) }

            if (ach.progressTarget > 1) {
                val prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = ach.progressTarget
                    progress = ach.progress
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 16)
                    progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(rarityColor))
                }
                info.addView(prog)
                TextView(this).apply {
                    text = "${ach.progress} / ${ach.progressTarget}"
                    setTextColor(Color.GRAY); textSize = 10f
                }.also { info.addView(it) }
            }

            if (ach.divinityReward > 0 || ach.goldReward > 0) {
                TextView(this).apply {
                    val rewards = buildString {
                        if (ach.divinityReward > 0) append("✨+${ach.divinityReward} ")
                        if (ach.goldReward > 0) append("💰+${ach.goldReward}")
                    }
                    text = rewards
                    setTextColor(Color.parseColor("#FFD700")); textSize = 11f
                }.also { info.addView(it) }
            }

            val checkMark = TextView(this).apply {
                text = if (ach.unlocked) "✅" else ""
                textSize = 20f
            }

            view.addView(emojTv)
            view.addView(info)
            view.addView(checkMark)
            llAchievements.addView(view)
        }
    }
}
