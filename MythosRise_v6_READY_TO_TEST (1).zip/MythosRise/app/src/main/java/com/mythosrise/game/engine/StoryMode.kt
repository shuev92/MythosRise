package com.mythosrise.game.engine

import com.mythosrise.game.models.World

// ─────────────────────────────────────────────
//  STORY CHOICE
// ─────────────────────────────────────────────

data class StoryChoice(
    val id: String,
    val text: String,
    val emoji: String,
    val consequence: String,
    val goldChange: Int = 0,
    val divinityChange: Int = 0,
    val unlocksChapter: String? = null,
    val affectsRelationship: String? = null,
    val relationshipChange: Int = 0
)

// ─────────────────────────────────────────────
//  STORY SCENE
// ─────────────────────────────────────────────

data class StoryScene(
    val id: String,
    val title: String,
    val narrator: String,
    val narratorEmoji: String,
    val text: String,
    val backgroundEmoji: String,
    val choices: List<StoryChoice> = emptyList(),
    val isBattleScene: Boolean = false,
    val battleEnemyId: String? = null,
    val isChapterEnd: Boolean = false,
    val musicMood: String = "epic"
)

// ─────────────────────────────────────────────
//  STORY CHAPTER
// ─────────────────────────────────────────────

data class StoryChapter(
    val id: String,
    val number: Int,
    val title: String,
    val subtitle: String,
    val emoji: String,
    val mythology: String,
    val scenes: List<StoryScene>,
    val requiredLevel: Int,
    val requiredDivinity: Int = 0,
    val unlockCondition: String = "",
    var isUnlocked: Boolean = false,
    var isCompleted: Boolean = false,
    var currentSceneIndex: Int = 0,
    val goldReward: Int,
    val divinityReward: Int,
    val expReward: Long,
    val unlockTitle: String? = null,
    val lore: String = ""
)

// ─────────────────────────────────────────────
//  STORY MODE
// ─────────────────────────────────────────────

object StoryMode {

    val ALL_CHAPTERS = listOf(

        // ═══════════════════════════════════
        //  CHAPTER 1 — ПРОБУЖДАНЕ
        // ═══════════════════════════════════
        StoryChapter(
            id = "ch_01_awakening",
            number = 1,
            title = "Пробуждане",
            subtitle = "Всяка легенда има начало",
            emoji = "🌅",
            mythology = "Universal",
            requiredLevel = 1,
            isUnlocked = true,
            goldReward = 1000,
            divinityReward = 50,
            expReward = 500,
            unlockTitle = "Пробуденият",
            lore = "Ти не си обикновен смъртен. Никога не си бил.",
            scenes = listOf(
                StoryScene(
                    id = "s1_01", title = "Тъмнина",
                    narrator = "??", narratorEmoji = "🌑",
                    backgroundEmoji = "🌑",
                    text = """
Тъмнина.

Абсолютна, пълна, задушаваща тъмнина.

Нямаш спомени. Нямаш минало. Само едно тихо гласче:

"Събуди се. Светът има нужда от теб. Или може би... ти имаш нужда от него."

Усещаш ръцете си. Краката си. Тялото — реално и живо.

Отваряш очи за пръв път.
                    """.trimIndent(),
                    backgroundEmoji = "🌑",
                    choices = listOf(
                        StoryChoice("choice_curious", "Питам: Кой е тук?", "❓",
                            "Гласът смее. 'Добре. Любопитен. Ще ти трябва.'"),
                        StoryChoice("choice_ready", "Ставам и се приготвям за битка", "⚔️",
                            "Гласът одобрява. 'Инстинктите те предхождат разума. Добър знак.'"),
                        StoryChoice("choice_silent", "Мълча и наблюдавам", "👁️",
                            "Гласът мълчи дълго. 'Мъдро. Много мъдро за начинаещ.'")
                    )
                ),
                StoryScene(
                    id = "s1_02", title = "Старецът",
                    narrator = "Старецът Теос", narratorEmoji = "🧙",
                    backgroundEmoji = "🏰",
                    text = """
Пред теб стои стар мъж с бяла брада и очи като звезди.

"Аз се казвам Теос. Пазя тайната на Митологиите от 3000 години."

Той те разглежда внимателно, после кима.

"Да. Ти си той. Усещам го в дивинитито ти. Слабо засега — само искрица. Но искрица може да запали богове."

Протяга ти ръжда меч и стара броня.

"Вземи. Не защото са добри — а защото са твои. За сега."
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_accept", "Приемам с благодарност", "🤝",
                            "Теос се усмихва за пръв път от столетия.", goldChange = 0),
                        StoryChoice("choice_question", "Питам какво е 'дивинити'", "✨",
                            "'Силата на боговете — уловена в смъртно тяло. Рядко. Опасно. Невероятно.'",
                            divinityChange = 10),
                        StoryChoice("choice_demand_more", "Искам по-добро оръжие", "😤",
                            "Теос се смее. 'Амбиция! Ще намериш по-добро когато го заслужиш.'",
                            goldChange = 200)
                    )
                ),
                StoryScene(
                    id = "s1_03", title = "Първата Битка",
                    narrator = "Теос", narratorEmoji = "🧙",
                    backgroundEmoji = "🏰",
                    text = """
"Преди да тръгнеш — трябва да докажеш, че можеш да оцелееш."

Пред теб се появяват двама бандита. Ухилени. Убедени в победата.

"Убий ги. Или умри. Така работи светът."

Теос стъпва назад.

"Между другото — ако успееш, ще забележиш нещо интересно. Нещо вътрешно. Сила, поглъщаща победата."
                    """.trimIndent(),
                    isBattleScene = true,
                    battleEnemyId = "bandit"
                ),
                StoryScene(
                    id = "s1_04", title = "Поглъщането",
                    narrator = "Теос", narratorEmoji = "🧙",
                    backgroundEmoji = "🌅",
                    text = """
Бандитите са паднали.

И тогава усещаш нещо невиждано. Сила тече от победените към теб. Топла. Реална. Твоя.

Теос кима бавно.

"Виждаш ли? Ти не просто убиваш. Ти поглъщаш. Всяка победа те прави по-силен."

"Сега слушай внимателно. Светът е разделен на митологии. Всяка митология — богове, чудовища, сили. Ти ще ги победиш всичките."

"Или ще умреш, опитвайки. Но не мисля, че ще умреш."

Той се усмихва мистериозно.

"Отиди на Олимп. Зевс те очаква. Не знае за теб. Скоро ще знае."
                    """.trimIndent(),
                    isChapterEnd = true,
                    choices = listOf(
                        StoryChoice("choice_olympus", "Тръгвам към Олимп", "🏛️",
                            "Приключението започва.", divinityChange = 50, unlocksChapter = "ch_02_olympus"),
                        StoryChoice("choice_train_first", "Първо ще се тренирам повече", "⚔️",
                            "'Мъдро.' Теос дава допълнително злато.", goldChange = 500)
                    )
                )
            )
        ),

        // ═══════════════════════════════════
        //  CHAPTER 2 — ОЛИМП
        // ═══════════════════════════════════
        StoryChapter(
            id = "ch_02_olympus",
            number = 2,
            title = "Оlимпийска Арогантност",
            subtitle = "Боговете смеят. Засега.",
            emoji = "🏛️",
            mythology = "Greek",
            requiredLevel = 5,
            goldReward = 3000,
            divinityReward = 200,
            expReward = 2000,
            unlockTitle = "Олимпиец Претендент",
            lore = "Никой смъртен не е стъпвал на Олимп. До днес.",
            scenes = listOf(
                StoryScene(
                    id = "s2_01", title = "Портите на Олимп",
                    narrator = "Хермес", narratorEmoji = "🪶",
                    backgroundEmoji = "☁️",
                    text = """
Портите на Олимп са от чисто злато, 100 метра високи.

Хермес ти се усмихва с характерната ирония.

"О! Смъртен! Тук? На Олимп? Баща ми Зевс ще те смаже на пепел!"

Пауза.

"... освен ако не си толкова интересен, колкото изглеждаш. Усещам нещо особено в теб."

"Дивинити. Малко, но реално. Любопитно."

Хермес ти мигва.

"Влез. Но не казвай, че съм те пуснал."
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_bribe_hermes", "Давам на Хермес злато", "💰",
                            "Хермес го взима с усмивка. 'Умен смъртен!'", goldChange = -200, divinityChange = 20),
                        StoryChoice("choice_threaten", "Казвам му, че ще стана бог", "⚡",
                            "Хермес се смее. После спира. 'Чакай... говориш сериозно, нали?'"),
                        StoryChoice("choice_charm", "Карам се на Хермес с хумор", "😄",
                            "'Харесвам те!' казва Хермес. 'Не умирай бързо!'")
                    )
                ),
                StoryScene(
                    id = "s2_02", title = "Среща с Атина",
                    narrator = "Атина", narratorEmoji = "🦉",
                    backgroundEmoji = "🏛️",
                    text = """
Атина те спира в коридора.

Богинята на мъдростта те разглежда с изчисляващ поглед.

"Ти не би трябвало да си тук. Но ти си тук. Значи има причина."

"Видях бъдещето. Не всичко — само пресечната точка. И ти си там."

"Можеш да избереш: честна битка с баща ми — или хитрост. Аз предпочитам хитрост. Но ти избираш."
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_strategy", "Питам за стратегия срещу Зевс", "🧠",
                            "Атина ти дава ЩИТА НА АТИНА — +100 DEF.", divinityChange = 50),
                        StoryChoice("choice_direct", "Ще го победя директно", "⚔️",
                            "Атина кима. 'Смел. Вероятно глупав. Но смел.'", goldChange = 500),
                        StoryChoice("choice_alliance", "Предлагам съюз с Атина", "🤝",
                            "Атина мълчи. После: 'Интересно предложение. Ще видим.'", divinityChange = 100)
                    )
                ),
                StoryScene(
                    id = "s2_03", title = "Зевс",
                    narrator = "Зевс", narratorEmoji = "⚡",
                    backgroundEmoji = "⚡",
                    text = """
Тронната зала на Олимп е огромна.

Зевс седи на трона от облаци и злато, с мълния в ръката.

"СМЪРТЕН!"

Гласът му резонира. Стените трепват.

"Как СМЕЕШ да стъпиш тук?! Никой смъртен не е—"

Той спира. Изправя се. Разглежда те внимателно.

"...чакай. Усещам нещо. Дивинити. В СМЪРТЕН? Как е..."

Мълния удря земята пред теб.

"Независимо. Ти ще умреш тук. Олимп НЕ е за смъртни!"
                    """.trimIndent(),
                    isBattleScene = true,
                    battleEnemyId = "zeus"
                ),
                StoryScene(
                    id = "s2_04", title = "Падането на Зевс",
                    narrator = "Зевс", narratorEmoji = "⚡",
                    backgroundEmoji = "🏛️",
                    text = """
Зевс е паднал на колене.

Невъзможно. Несъществувало досега. А все пак — реално.

"Как... как е ВЪЗМОЖНО?!"

Усещаш го. Силата му тече към теб. Поглъщаш я.

"Не... не... моята сила..."

Другите богове гледат в шок. Хермес — с ухилена усмивка. Атина — без изненада.

Зевс вдига глава. За първи път в очите му — уважение.

"Ти... ти вече не си смъртен. Не изцяло."

"Как се казваш, победителю?"
                    """.trimIndent(),
                    isChapterEnd = true,
                    choices = listOf(
                        StoryChoice("choice_state_name", "Казвам името си", "🗣️",
                            "Зевс повтаря името ти. Олимп запомня.", divinityChange = 200, unlocksChapter = "ch_03_asgard"),
                        StoryChoice("choice_mercy", "Пощадявам Зевс", "🕊️",
                            "Зевс е изненадан. 'Милост? Любопитно.'",
                            divinityChange = 300, unlocksChapter = "ch_03_asgard"),
                        StoryChoice("choice_absorb_fully", "Поглъщам пълната сила на Зевс", "🌀",
                            "Дивинитито ти ИЗБУХВА. Боговете са в шок.",
                            divinityChange = 500, unlocksChapter = "ch_03_asgard")
                    )
                )
            )
        ),

        // ═══════════════════════════════════
        //  CHAPTER 3 — АСГАРД
        // ═══════════════════════════════════
        StoryChapter(
            id = "ch_03_asgard",
            number = 3,
            title = "Рагнарок Наближава",
            subtitle = "Скандинавските богове не молят. Те се бият.",
            emoji = "⚡",
            mythology = "Norse",
            requiredLevel = 11,
            requiredDivinity = 2000,
            goldReward = 8000,
            divinityReward = 500,
            expReward = 6000,
            unlockTitle = "Убиец на Асити",
            lore = "Рагнарок е предсказан. Но предсказанието не казва кой ще спечели.",
            scenes = listOf(
                StoryScene(
                    id = "s3_01", title = "Бифрост",
                    narrator = "Хеймдал", narratorEmoji = "🌈",
                    backgroundEmoji = "🌈",
                    text = """
Бифрост — мостът между световете — свети с всички цветове.

Хеймдал, пазачът, ти блокира пътя с копие.

"Стой! Ти не си Асит, не си Ванир, не си Альв. Кой си?"

Той ти се вглежда дълбоко. Очите му виждат всичко.

"...чакай. Дивинити. Много дивинити за смъртен. Ти си победил гърците?"

Копието се прибира.

"Един разпознава друг. Влез. Но знай: Один те очаква."
                    """.trimIndent()
                ),
                StoryScene(
                    id = "s3_02", title = "Един",
                    narrator = "Един", narratorEmoji = "🦅",
                    backgroundEmoji = "🌲",
                    text = """
Один седи до огъня в Валхала с двата си гарвана на раменете.

Хугин и Мунин те наблюдават с умни очи.

"Седни." Не заповед. Просто факт.

"Гарваните ми ти наблюдаваха. От момента, в който победи Зевс."

Той пие от рога с мед.

"Видях бъдещето. Рагнарок е неизбежен. Всички ние ще умрем."

Пауза.

"...освен ако не се намери някой, поглъщащ силата на всички богове. Някой, ставащ по-силен от самия Рагнарок."

Той те гледа право в очите с единственото си oko.

"Ти ли си?"
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_yes_odin", "Да. Аз съм.", "⚡",
                            "Один кима. 'Добре. Тогава трябва да победиш Тор пред мен.'",
                            divinityChange = 100),
                        StoryChoice("choice_not_yet", "Все още не — но ще бъда.", "🌱",
                            "Един се усмихва. 'Честен. Рядко.' Дава ти Руни.",
                            goldChange = 1000, divinityChange = 150),
                        StoryChoice("choice_ask_odin", "Питам Един за Рагнарок", "📖",
                            "Един разказва 20 минути. Получаваш уникален Лор запис.",
                            divinityChange = 200)
                    )
                ),
                StoryScene(
                    id = "s3_03", title = "Тор",
                    narrator = "Тор", narratorEmoji = "🔨",
                    backgroundEmoji = "⚡",
                    text = """
Тор е огромен. По-огромен от всичко, което си виждал.

Мьолнир се върти в ръката му.

"Така де! Баща ми иска да те тествам! ОТЛИЧНО!"

Смях като гръм.

"Не се притесни — ако оцелееш, ще те почерпя!"

"Ако не оцелееш... ами... Валхала е хубаво място!"

Той замахва с Мьолнир.

"ХАЙДЕ!"
                    """.trimIndent(),
                    isBattleScene = true,
                    battleEnemyId = "thor"
                ),
                StoryScene(
                    id = "s3_04", title = "Уважение на Асите",
                    narrator = "Тор", narratorEmoji = "🔨",
                    backgroundEmoji = "⚡",
                    text = """
Тор лежи на земята. Мьолнир е до него.

Но вместо гняв — смях.

"AHAHAHA! Победен! Мен! Тор! Невероятно!"

Той скача на крака и стиска ръката ти.

"Приятел! Ти си ПРИЯТЕЛ вече! Един, вижда ли?!"

Един кима от разстояние.

"Добре. Поглъщаш силата ни, нали?"

"Тогава чуй: Рагнарок идва след три месеца. Трябва да поглъщаш ВСИЧКО. Всеки бог. Всяко чудовище."

"Само тогава ще имаш сила да спреш края."

Или да го завършиш ти.
                    """.trimIndent(),
                    isChapterEnd = true,
                    choices = listOf(
                        StoryChoice("choice_accept_ragnarok", "Приемам предизвикателството", "⚡",
                            "Асгард ехти от одобрение!", divinityChange = 300, unlocksChapter = "ch_04_egypt"),
                        StoryChoice("choice_absorb_thor", "Поглъщам силата на Тор", "🌀",
                            "Силата на Мьолнир тече в теб!", divinityChange = 500, unlocksChapter = "ch_04_egypt")
                    )
                )
            )
        ),

        // ═══════════════════════════════════
        //  CHAPTER 4 — ЕГИПЕТ
        // ═══════════════════════════════════
        StoryChapter(
            id = "ch_04_egypt",
            number = 4,
            title = "Претеглянето на Душата",
            subtitle = "Анубис преценява всяка душа. Дори твоята.",
            emoji = "🏺",
            mythology = "Egyptian",
            requiredLevel = 13,
            requiredDivinity = 5000,
            goldReward = 12000,
            divinityReward = 800,
            expReward = 10000,
            unlockTitle = "Познаващият Дуат",
            lore = "В Египет смъртта не е край — тя е врата.",
            scenes = listOf(
                StoryScene(
                    id = "s4_01", title = "Пристигане в Дуат",
                    narrator = "Анубис", narratorEmoji = "🐺",
                    backgroundEmoji = "🏺",
                    text = """
Тъмно. Горещо. Пясък навсякъде.

Анубис — с тяло на мъж и глава на чакал — те гледа без израз.

"Живи не влизат в Дуат."

Пауза. Той се навежда и те разглежда внимателно.

"...и все пак ти не си изцяло жив, нали? Дивинитито ти е реално. Поглъщал си богове. Любопитно."

"Нека видим какво е в сърцето ти."

Извежда везните.

"Ако сърцето ти е по-леко от перото на Маат — преминаваш. Ако не..."

Амут — чудовището с три глави — облизва устни.
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_honest", "Честен съм пред Анубис", "⚖️",
                            "Везните се накланят леко. 'Честност. Рядко сред силните.'",
                            divinityChange = 100),
                        StoryChoice("choice_offer_gold", "Предлагам злато", "💰",
                            "Анубис смята злато. 'Математиката не е ценност. Но... ОК.'",
                            goldChange = -2000, divinityChange = 50),
                        StoryChoice("choice_fight_anubis", "Казвам, че ще го победя ако трябва", "⚔️",
                            "Анубис е изненадан. После — уважителен. 'Смел. Или глупав.'",
                            divinityChange = 200)
                    )
                ),
                StoryScene(
                    id = "s4_02", title = "Ра",
                    narrator = "Ра", narratorEmoji = "☀️",
                    backgroundEmoji = "☀️",
                    text = """
Слънчевата ладия на Ра прелита над Дуат.

Ра — стар бог с глава на сокол и слънчев диск — те вижда.

"СТОЙ! Кой е там долу?!"

Той слиза. За пръв път от хиляди години.

"Смъртен с дивинити? С погълнати сили на гърци И скандинавци?!"

Той ти се усмихва.

"Аз се раждам всяка сутрин и умирам всяка вечер. Но ти... ти не умираш, нали?"

"Или може да умреш. Но само ако аз реша."

Слънчевата му аура се засилва.

"Тествай ме."
                    """.trimIndent(),
                    isBattleScene = true,
                    battleEnemyId = "ra"
                ),
                StoryScene(
                    id = "s4_03", title = "Слънцето се поклаща",
                    narrator = "Анубис", narratorEmoji = "🐺",
                    backgroundEmoji = "🌅",
                    text = """
Ра е паднал. За пръв път от сътворението.

Нощта е дошла. И не се е сменила.

Анубис стои до теб в тъмнината.

"Знаеш ли какво е направил? Ра е слънцето. Без него... нощта е вечна."

Пауза.

"...или не. Защото ти погълна силата му. Ти ставаш новото слънце."

Нещо топло избухва в гърдите ти.

"Египетската митология е твоя. Иди. Следващото ниво чака."
                    """.trimIndent(),
                    isChapterEnd = true,
                    choices = listOf(
                        StoryChoice("choice_restore_sun", "Връщам силата на Ра — само частично", "☀️",
                            "Ра се ражда отново. По-слаб. Ти си по-силен.",
                            divinityChange = 400, unlocksChapter = "ch_05_chaos"),
                        StoryChoice("choice_keep_all", "Поглъщам всичко", "🌀",
                            "Дивинитито ти достига нова височина. Египет те помни.",
                            divinityChange = 800, unlocksChapter = "ch_05_chaos")
                    )
                )
            )
        ),

        // ═══════════════════════════════════
        //  CHAPTER 5 — ХАОСЪТ
        // ═══════════════════════════════════
        StoryChapter(
            id = "ch_05_chaos",
            number = 5,
            title = "Началото и Краят",
            subtitle = "Хаосът е бил преди всичко. Ти ли ще бъдеш след всичко?",
            emoji = "🌌",
            mythology = "Universal",
            requiredLevel = 40,
            requiredDivinity = 25000,
            goldReward = 50000,
            divinityReward = 5000,
            expReward = 50000,
            unlockTitle = "🌌 ВСЕБОГ",
            lore = "В началото беше Хаосът. В края — ти.",
            scenes = listOf(
                StoryScene(
                    id = "s5_01", title = "Гласът на Хаоса",
                    narrator = "Хаос", narratorEmoji = "🌀",
                    backgroundEmoji = "🌌",
                    text = """
Нищо.

Абсолютно нищо. Нито светлина, нито тъмнина. Просто... отсъствие.

После гласът.

Не звук. Просто... знание. Директно в ума.

"Ти дойде."

"Зевс. Один. Ра. Шива. Всичките. Поглъщал си ги един по един."

"Знаеш ли кой съм аз?"

"Аз съм преди тях. Преди всичко. Хаосът, от който се е родило всичко."

"Ако ме победиш... Ако поглъщаш мен..."

"Ти ставаш не просто бог. Ти ставаш ВСИЧКО."

"Готов ли си?"
                    """.trimIndent(),
                    choices = listOf(
                        StoryChoice("choice_ready_chaos", "Роден съм готов.", "🌌",
                            "Хаосът мълчи. После: 'Да. Вярно.' Битката започва.",
                            divinityChange = 1000),
                        StoryChoice("choice_fear_chaos", "Честно — страхувам се.", "😰",
                            "'Честността пред Хаоса. Рядко. Може би достатъчно рядко.'",
                            divinityChange = 500),
                        StoryChoice("choice_challenge_chaos", "Ела тогава. Покажи ми какво си.", "⚔️",
                            "Хаосът се смее. Светът трепери.", divinityChange = 2000)
                    )
                ),
                StoryScene(
                    id = "s5_02", title = "ФИНАЛНА БИТКА",
                    narrator = "Хаос", narratorEmoji = "🌌",
                    backgroundEmoji = "🌌",
                    text = """
Хаосът няма форма.

Но има присъствие. Усещаш го навсякъде — в теб, около теб, в самото пространство.

"Всеки бог, когото си победил, е бил тест."

"Аз не съм тест."

"Аз съм края на всички тестове."

"Или началото на нещо ново."

"ЗАПОЧВАМЕ."
                    """.trimIndent(),
                    isBattleScene = true,
                    battleEnemyId = "chaos"
                ),
                StoryScene(
                    id = "s5_03", title = "ВСЕБОГ",
                    narrator = "???", narratorEmoji = "🌟",
                    backgroundEmoji = "✨",
                    text = """
Хаосът е погълнат.

Ти вече не стоиш. Ти просто... съществуваш.

Навсякъде и никъде.

Всеки бог, когото си победил, говори едновременно:

"Зевс: Смъртен, станал бог."
"Один: Търсещ, намерил."  
"Ра: Слънцето, угаснало и ново изгряло."
"Шива: Разрушителят, станал Строителят."
"Хаос: Началото, станало Краят, станало Началото."

И после — тишина.

И в тишината — Теос. Старецът. Все така стар. Все така усмихнат.

"Казах ти, нали? Искрица може да запали богове."

"Добре дошъл. Всебогу."
                    """.trimIndent(),
                    isChapterEnd = true,
                    choices = listOf(
                        StoryChoice("choice_omnigod_accept", "Приемам новата си същност", "🌌",
                            "Дивинитито ти достига 50 000. ВСЕБОГ е постигнато!",
                            divinityChange = 10000, unlocksChapter = null),
                        StoryChoice("choice_share_power", "Връщам сила на всеки бог", "🕊️",
                            "Боговете получават нова сила. Ти ставаш техен съюзник — ВСЕБОГ.",
                            divinityChange = 8000),
                        StoryChoice("choice_new_world", "Създавам нов свят", "🌍",
                            "С силата на Хаоса — раждаш нов свят. Легендата продължава.",
                            divinityChange = 12000)
                    )
                )
            )
        )
    )

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun getUnlockedChapters(): List<StoryChapter> = ALL_CHAPTERS.filter { it.isUnlocked }

    fun getAvailableChapters(level: Int, divinity: Int): List<StoryChapter> =
        ALL_CHAPTERS.filter { it.requiredLevel <= level && it.requiredDivinity <= divinity }

    fun getNextChapter(currentId: String): StoryChapter? {
        val current = ALL_CHAPTERS.indexOfFirst { it.id == currentId }
        return if (current >= 0 && current + 1 < ALL_CHAPTERS.size) ALL_CHAPTERS[current + 1] else null
    }

    fun completeChapter(chapter: StoryChapter, character: com.mythosrise.game.models.Character) {
        chapter.isCompleted = true
        character.gold += chapter.goldReward
        character.divinity += chapter.divinityReward
        character.gainExperience(chapter.expReward)
        chapter.unlockTitle?.let { character.divinityTitle.title }
        character.updateDivinityTitle()
        getNextChapter(chapter.id)?.isUnlocked = true
    }

    fun getChapterProgress(): String {
        val completed = ALL_CHAPTERS.count { it.isCompleted }
        val total = ALL_CHAPTERS.size
        return "📖 История: $completed/$total глави"
    }
}

// ─────────────────────────────────────────────
//  STORY CHOICE CONSEQUENCES TRACKER
// ─────────────────────────────────────────────

object StoryChoiceTracker {
    val CHOICES_MADE = mutableMapOf<String, String>()

    val CONSEQUENCE_MESSAGES = mapOf(
        "choice_mercy_zeus" to "Зевс помни пощадата. +100 Отношение с Зевс.",
        "choice_absorb_fully_zeus" to "Поглъщаш всичко. +500 Дивинити. Зевс е ядосан.",
        "choice_accept_ragnarok" to "Асгард те приема. +200 Дивинити. Тор те смята за брат.",
        "choice_restore_sun" to "Ра е слаб но жив. +400 Дивинити. Египет те уважава.",
        "choice_keep_all" to "Поглъщаш всичко от Ра. +800 Дивинити. Египет те страхува.",
        "choice_omnigod_accept" to "ВСЕБОГ! +10000 Дивинити. Историята завършена.",
        "choice_share_power" to "Боговете са твои съюзници. +8000 Дивинити. Всички те уважават.",
        "choice_new_world" to "Нов свят! +12000 Дивинити. Ти ставаш Творец."
    )

    fun recordChoice(sceneId: String, choiceId: String) {
        CHOICES_MADE[sceneId] = choiceId
    }

    fun getChoiceSummary(): String = buildString {
        appendLine("═══ ТВОИТЕ ИЗБОРИ ═══")
        appendLine()
        if (CHOICES_MADE.isEmpty()) {
            appendLine("Все още не си правил избори в Историята.")
            return@buildString
        }
        CHOICES_MADE.forEach { (scene, choice) ->
            appendLine("📖 Сцена: $scene")
            appendLine("   Избор: $choice")
            CONSEQUENCE_MESSAGES[choice]?.let { appendLine("   ⚡ $it") }
            appendLine()
        }
    }

    fun getMajorChoices(): List<Pair<String, String>> = CHOICES_MADE
        .filter { CONSEQUENCE_MESSAGES.containsKey(it.value) }
        .map { it.key to it.value }
}

// ─────────────────────────────────────────────
//  STORY DIALOGUE SYSTEM
// ─────────────────────────────────────────────

object StoryDialogueSystem {
    val CHARACTER_VOICES = mapOf(
        "Теос" to listOf(
            "Каквото и да избереш — то е правилното за теб.",
            "Не се притеснявай. Аз съм гледал много герои. Ти си различен.",
            "Силата е в теб. Аз само я посочих.",
            "Всеки бог, когото победиш, те прави по-близо до НЕГО.",
            "Питаш ме за Хаоса? Дори аз не знам всичко."
        ),
        "Зевс" to listOf(
            "НИКОЙ не се изправя срещу Зевс и оцелява! Никой до теб.",
            "Мълниите ми не пропускат. Ти си изключение.",
            "Атина ми каза за теб. Трябваше да я слушам.",
            "Дивинити в смъртен? Последния път, когато видях това...",
            "Добре. Ако трябва да бъда победен — поне от достоен."
        ),
        "Един" to listOf(
            "Виждам хиляди бъдещета. В повечето умираш. Не в това.",
            "Жертвах окото си за мъдрост. Ти жертваш ли нещо?",
            "Рагнарок не е края. Той е преходът.",
            "Хугин и Мунин те харесват. Те са взискателни.",
            "Знаеш ли защо съм Един? Защото съм единственият, знаещ истината."
        ),
        "Хаос" to listOf(
            "Аз съм преди всичко. Ти ще бъдеш след всичко.",
            "Не мислиш в правилни категории. Добро, зло, силно, слабо — всичко е Хаос.",
            "Победи ме. Ако можеш. Ако искаш.",
            "Всеки ред е Хаос, чакащ да се освободи.",
            "В края на деня — ти и аз сме едно и също нещо."
        )
    )

    val NARRATOR_LINES = listOf(
        "Митологиите не са само истории. Те са спомени.",
        "Всеки бог е бил по-слаб веднъж. После е избрал да стане бог.",
        "Ти не следваш митовете. Ти ги пишеш.",
        "Хаосът е в началото. Ти ще бъдеш в края.",
        "Поглъщаш. Ставаш. Надминаваш. Такъв е пътят.",
        "11 свята. 20 босове. 1 Всебог. Ти.",
        "Преди теб нямаше такъв. След теб — може да има."
    )

    fun getRandomNarratorLine() = NARRATOR_LINES.random()
    fun getCharacterLine(character: String) = CHARACTER_VOICES[character]?.random() ?: "..."

    fun generateDramaticIntro(heroName: String, heroClass: String): String = buildString {
        appendLine("В началото беше тъмнината.")
        appendLine()
        appendLine("После — ти.")
        appendLine()
        appendLine("$heroName. $heroClass. Смъртен — засега.")
        appendLine()
        appendLine("Теос казва: '${getCharacterLine("Теос")}'")
        appendLine()
        appendLine("Митологиите чакат.")
        appendLine("Боговете не знаят за теб.")
        appendLine()
        appendLine("Скоро ще знаят.")
    }
}
