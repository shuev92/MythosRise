package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  RUNE TYPE
// ─────────────────────────────────────────────

enum class RuneType(val displayName: String, val emoji: String, val color: String) {
    ATTACK("Атака", "⚔️", "#FF4444"),
    DEFENSE("Защита", "🛡️", "#4444FF"),
    VITALITY("Живот", "❤️", "#FF44FF"),
    DIVINITY("Дивинити", "✨", "#FFFF44"),
    SPEED("Скорост", "⚡", "#44FFFF"),
    LUCK("Късмет", "🍀", "#44FF44"),
    WISDOM("Мъдрост", "📚", "#FF8844"),
    CHAOS("Хаос", "🌀", "#8844FF")
}

// ─────────────────────────────────────────────
//  RUNE
// ─────────────────────────────────────────────

data class Rune(
    val id: String,
    val name: String,
    val emoji: String,
    val type: RuneType,
    val tier: Int,           // 1-7
    val mythology: String,
    val description: String,
    val lore: String,
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val healthBonus: Int = 0,
    val divinityBonus: Float = 0f,
    val goldBonus: Float = 0f,
    val critBonus: Float = 0f,
    val speedBonus: Int = 0,
    val specialEffect: String = "",
    val socketSlots: Int = 1,     // how many slots this rune has
    var isEquipped: Boolean = false,
    var equippedSlot: Int = -1,
    val requiredLevel: Int = 1,
    val requiredDivinity: Int = 0
)

// ─────────────────────────────────────────────
//  RUNE SET
// ─────────────────────────────────────────────

data class RuneSet(
    val id: String,
    val name: String,
    val emoji: String,
    val runeIds: List<String>,
    val setBonus2: String,
    val setBonus4: String,
    val setBonus6: String,
    val mythology: String
)

// ─────────────────────────────────────────────
//  RUNE SYSTEM
// ─────────────────────────────────────────────

object RuneSystem {

    val ALL_RUNES = listOf(
        // ── TIER 1 ──
        Rune("rune_iron_atk", "Желязна Атака", "⚔️", RuneType.ATTACK, 1, "Universal",
            "+30 ATK. Базова руна.", "Изковани от обикновени майстори. Началото.", attackBonus = 30),
        Rune("rune_iron_def", "Желязна Защита", "🛡️", RuneType.DEFENSE, 1, "Universal",
            "+30 DEF. Базова руна.", "Желязото пази. Просто. Ефективно.", defenseBonus = 30),
        Rune("rune_iron_hp", "Желязен Живот", "❤️", RuneType.VITALITY, 1, "Universal",
            "+150 HP. Базова руна.", "Повече кръв. Повече живот. Повече шансове.", healthBonus = 150),

        // ── TIER 2 ──
        Rune("rune_greek_thunder", "Гръцки Гръм", "⚡", RuneType.ATTACK, 2, "Greek",
            "+60 ATK + 5% крит шанс.", "Парче мълния от Олимп.", attackBonus = 60, critBonus = 0.05f, requiredLevel = 5),
        Rune("rune_greek_wisdom", "Мъдрост на Атина", "📚", RuneType.WISDOM, 2, "Greek",
            "+10% злато.", "Мъдростта на Атина е безценна. Почти.", goldBonus = 0.10f, requiredLevel = 5),
        Rune("rune_norse_strength", "Скандинавска Сила", "💪", RuneType.ATTACK, 2, "Norse",
            "+70 ATK. Викингска мощ.", "Викинг руна, изковано при Рагнарок.", attackBonus = 70, requiredLevel = 5),
        Rune("rune_norse_ice", "Ледена Руна", "❄️", RuneType.DEFENSE, 2, "Norse",
            "+50 DEF + леден щит.", "Скандинавската зима в руна форма.", defenseBonus = 50, requiredLevel = 5,
            specialEffect = "Замразяване шанс +10%"),

        // ── TIER 3 ──
        Rune("rune_egypt_gold", "Египетско Злато", "🏺", RuneType.LUCK, 3, "Egyptian",
            "+20% злато от врагове.", "Ра благославя търговците.", goldBonus = 0.20f, requiredLevel = 10),
        Rune("rune_egypt_soul", "Египетска Душа", "💀", RuneType.DIVINITY, 3, "Egyptian",
            "+15% дивинити.", "Анубис дава от силата си.", divinityBonus = 0.15f, requiredLevel = 10),
        Rune("rune_dragon_fire", "Дракон Огън", "🔥", RuneType.ATTACK, 3, "Dragon",
            "+120 ATK + огнен урон.", "Парче от дракон сърце.", attackBonus = 120, requiredLevel = 15,
            specialEffect = "+30 огнен урон"),
        Rune("rune_dragon_scale", "Дракон Люспа", "🐉", RuneType.DEFENSE, 3, "Dragon",
            "+100 DEF + огнена устойчивост.", "Люспата пази. Вечно.", defenseBonus = 100, requiredLevel = 15,
            specialEffect = "-30% получен огнен урон"),

        // ── TIER 4 ──
        Rune("rune_japan_swift", "Японска Мълния", "🗡️", RuneType.SPEED, 4, "Japanese",
            "+30 скорост + 8% крит.", "Сусаноо е бил толкова бърз.", speedBonus = 30, critBonus = 0.08f, requiredLevel = 20),
        Rune("rune_japan_honor", "Самурайска Чест", "🏯", RuneType.DEFENSE, 4, "Japanese",
            "+150 DEF + +15% ATK при ниско HP.", "Честта дава сила в последния момент.", defenseBonus = 150, requiredLevel = 20,
            specialEffect = "+15% ATK под 30% HP"),
        Rune("rune_china_dragon", "Нефритен Дракон", "🐲", RuneType.VITALITY, 4, "Chinese",
            "+500 HP + регенерация.", "Дракон Кралете дарявал здраве.", healthBonus = 500, requiredLevel = 20,
            specialEffect = "Регенерира 1% HP всеки ход"),
        Rune("rune_india_karma", "Карма Руна", "☯️", RuneType.LUCK, 4, "Indian",
            "+15% всички бонуси.", "Добрата карма умножава всичко.", divinityBonus = 0.10f, goldBonus = 0.15f,
            attackBonus = 50, requiredLevel = 20, requiredDivinity = 2000),

        // ── TIER 5 ──
        Rune("rune_titan_power", "Титанова Сила", "⚡", RuneType.ATTACK, 5, "Titan",
            "+250 ATK. Преди олимпийците.", attackBonus = 250, requiredLevel = 30, requiredDivinity = 5000,
            lore = "Титаните предшестват боговете. Силата им е по-стара и по-сурова."),
        Rune("rune_titan_wall", "Титанова Стена", "🗿", RuneType.DEFENSE, 5, "Titan",
            "+300 DEF. Непробиваема.", defenseBonus = 300, requiredLevel = 30, requiredDivinity = 5000,
            lore = "Атлас носи небесата. Тази руна носи малко от тежестта."),
        Rune("rune_void_chaos", "Войд Хаос", "🌀", RuneType.CHAOS, 5, "Chaos",
            "+200 ATK + игнорираш 20% DEF.", attackBonus = 200, requiredLevel = 35, requiredDivinity = 10000,
            specialEffect = "Игнорираш 20% от защитата на врага",
            lore = "Хаосът игнорира всякакви правила. Включително защитата."),
        Rune("rune_divine_light", "Божествена Светлина", "✨", RuneType.DIVINITY, 5, "Universal",
            "+30% Дивинити + светлина ефект.", divinityBonus = 0.30f, requiredLevel = 35, requiredDivinity = 10000,
            specialEffect = "Светлинни атаки +100 урон",
            lore = "Дистилирана дивинити в руна форма. Рядка. Мощна."),

        // ── TIER 6 ──
        Rune("rune_omnigod_fragment", "Фрагмент на Всебога", "🌟", RuneType.CHAOS, 6, "Universal",
            "+500 ATK +300 DEF +20% всичко.", attackBonus = 500, defenseBonus = 300,
            divinityBonus = 0.20f, goldBonus = 0.20f, requiredLevel = 45, requiredDivinity = 25000,
            specialEffect = "Всеки 10-ти удар е x5 урон",
            lore = "Парче от самия Всебог. Не питай откъде.",
            socketSlots = 2),

        // ── TIER 7 — SUPREME ──
        Rune("rune_supreme_chaos", "ВЪРХОВНА ХАОС РУНА", "🌌", RuneType.CHAOS, 7, "Chaos",
            "АБСОЛЮТНА МОЩ. Само за ВСЕБОГ.", attackBonus = 1000, defenseBonus = 500,
            healthBonus = 2000, divinityBonus = 0.50f, goldBonus = 0.30f, critBonus = 0.25f,
            requiredLevel = 50, requiredDivinity = 50000,
            specialEffect = "Всяка атака е потенциален ИНСТАКИЛ при врагове под 20% HP",
            lore = "Най-мощната руна. Кована от самия Хаос. Съществува само едно копие.",
            socketSlots = 3)
    )

    val RUNE_SETS = listOf(
        RuneSet(
            id = "set_zeus", name = "Олимпийски Гром", emoji = "⚡",
            runeIds = listOf("rune_greek_thunder", "rune_greek_wisdom", "rune_iron_atk"),
            setBonus2 = "+100 ATK, +5% крит",
            setBonus4 = "+200 ATK, +10% злато, Гръм при крит",
            setBonus6 = "+500 ATK, +20% всичко, Зевсов Благослов",
            mythology = "Greek"
        ),
        RuneSet(
            id = "set_ragnarok", name = "Рагнарок", emoji = "🌋",
            runeIds = listOf("rune_norse_strength", "rune_norse_ice", "rune_titan_power"),
            setBonus2 = "+150 ATK, Ледено Оплетение",
            setBonus4 = "+300 ATK, +200 DEF, Берсерк Активиран",
            setBonus6 = "+700 ATK, РАГНАРОК РЕЖИМ: +100% ATK при под 30% HP",
            mythology = "Norse"
        ),
        RuneSet(
            id = "set_pharaoh", name = "Фараонска Власт", emoji = "🏺",
            runeIds = listOf("rune_egypt_gold", "rune_egypt_soul", "rune_india_karma"),
            setBonus2 = "+25% злато и дивинити",
            setBonus4 = "+50% злато, +30% дивинити, Анубис Защита",
            setBonus6 = "+100% злато, +50% дивинити, Ра Благослов",
            mythology = "Egyptian"
        ),
        RuneSet(
            id = "set_omnigod", name = "Пълен Всебог", emoji = "🌌",
            runeIds = listOf("rune_omnigod_fragment", "rune_supreme_chaos", "rune_void_chaos"),
            setBonus2 = "+800 ATK, +500 DEF",
            setBonus4 = "+1500 ATK, +1000 DEF, +50% всичко",
            setBonus6 = "АБСОЛЮТНА ВСЕБОГ МОЩ: x2 всичко + МИГНОВЕНА СМЪРТ при под 10% HP",
            mythology = "Universal"
        )
    )

    val SOCKETED_RUNES = mutableListOf<Rune>()
    val MAX_SOCKETS = 6

    fun getEquippedRunes(): List<Rune> = ALL_RUNES.filter { it.isEquipped }

    fun socketRune(rune: Rune, slot: Int): Boolean {
        if (slot >= MAX_SOCKETS) return false
        if (ALL_RUNES.any { it.equippedSlot == slot }) return false
        rune.isEquipped = true
        rune.equippedSlot = slot
        return true
    }

    fun removeRune(slot: Int) {
        ALL_RUNES.filter { it.equippedSlot == slot }.forEach {
            it.isEquipped = false; it.equippedSlot = -1
        }
    }

    fun getActiveSetBonuses(): List<Pair<RuneSet, Int>> {
        val equipped = getEquippedRunes().map { it.id }.toSet()
        return RUNE_SETS.mapNotNull { set ->
            val count = set.runeIds.count { it in equipped }
            if (count >= 2) set to count else null
        }
    }

    fun calculateRuneBonuses(character: Character) {
        val runes = getEquippedRunes()
        character.attack += runes.sumOf { it.attackBonus }
        character.defense += runes.sumOf { it.defenseBonus }
    }

    fun getRunesByTier(tier: Int): List<Rune> = ALL_RUNES.filter { it.tier == tier }

    fun getAvailableRunes(level: Int, divinity: Int): List<Rune> =
        ALL_RUNES.filter { it.requiredLevel <= level && it.requiredDivinity <= divinity }

    fun getRuneGuide(): String = buildString {
        appendLine("═══ НАРЪЧНИК НА РУНИТЕ ═══")
        appendLine()
        appendLine("СЛОТОВЕ: $MAX_SOCKETS налични")
        appendLine()
        (1..7).forEach { tier ->
            val runes = getRunesByTier(tier)
            if (runes.isNotEmpty()) {
                appendLine("── Tier $tier ──")
                runes.forEach { rune ->
                    appendLine("${rune.emoji} ${rune.name} [${rune.mythology}]")
                    appendLine("  ${rune.description}")
                    if (rune.specialEffect.isNotBlank()) appendLine("  ✨ ${rune.specialEffect}")
                    appendLine("  📋 Изисква: Ниво ${rune.requiredLevel}${if (rune.requiredDivinity > 0) " + ✨${rune.requiredDivinity}" else ""}")
                }
                appendLine()
            }
        }
        appendLine("── СЕТОВЕ ──")
        RUNE_SETS.forEach { set ->
            appendLine("${set.emoji} ${set.name}")
            appendLine("  2 части: ${set.setBonus2}")
            appendLine("  4 части: ${set.setBonus4}")
            appendLine("  6 части: ${set.setBonus6}")
        }
    }
}

// ─────────────────────────────────────────────
//  RUNE CRAFTING SYSTEM
// ─────────────────────────────────────────────

object RuneCraftingSystem {

    data class RuneRecipe(
        val resultRuneId: String,
        val ingredients: List<Pair<String, Int>>,
        val goldCost: Int,
        val divinityCost: Int,
        val successRate: Float,
        val description: String
    )

    val RUNE_RECIPES = listOf(
        RuneRecipe(
            resultRuneId = "rune_greek_thunder",
            ingredients = listOf("rune_iron_atk" to 2, "thunder_crystal" to 1),
            goldCost = 5000, divinityCost = 100, successRate = 0.90f,
            description = "2x Желязна Атака + Гръм Кристал = Гръцки Гръм"
        ),
        RuneRecipe(
            resultRuneId = "rune_egypt_soul",
            ingredients = listOf("rune_iron_def" to 2, "soul_essence" to 2),
            goldCost = 8000, divinityCost = 200, successRate = 0.80f,
            description = "2x Желязна Защита + 2x Душа Есенция = Египетска Душа"
        ),
        RuneRecipe(
            resultRuneId = "rune_dragon_fire",
            ingredients = listOf("rune_norse_strength" to 1, "dragon_scale" to 3),
            goldCost = 15000, divinityCost = 500, successRate = 0.70f,
            description = "Скандинавска Сила + 3x Дракон Люспа = Дракон Огън"
        ),
        RuneRecipe(
            resultRuneId = "rune_titan_power",
            ingredients = listOf("rune_dragon_fire" to 2, "titan_essence" to 1),
            goldCost = 30000, divinityCost = 2000, successRate = 0.60f,
            description = "2x Дракон Огън + Титанова Есенция = Титанова Сила"
        ),
        RuneRecipe(
            resultRuneId = "rune_void_chaos",
            ingredients = listOf("rune_titan_power" to 1, "chaos_fragment" to 3),
            goldCost = 50000, divinityCost = 5000, successRate = 0.50f,
            description = "Титанова Сила + 3x Хаос Фрагмент = Войд Хаос"
        ),
        RuneRecipe(
            resultRuneId = "rune_omnigod_fragment",
            ingredients = listOf("rune_void_chaos" to 1, "divine_light" to 5, "rune_divine_light" to 1),
            goldCost = 100000, divinityCost = 15000, successRate = 0.35f,
            description = "Войд Хаос + 5x Божествена Светлина + Руна = Фрагмент на Всебога"
        ),
        RuneRecipe(
            resultRuneId = "rune_supreme_chaos",
            ingredients = listOf("rune_omnigod_fragment" to 3, "chaos_core" to 1),
            goldCost = 500000, divinityCost = 49000, successRate = 0.15f,
            description = "3x Фрагмент на Всебога + Хаос Ядро = ВЪРХОВНА ХАОС РУНА (15% шанс!)"
        )
    )

    val CRAFTING_TIPS = listOf(
        "💡 Употреби Занаятчийски Благослов преди крафт за +20% успех!",
        "💡 Tier-7 Руна има само 15% успех — пази материалите!",
        "💡 При провал — материалите НЕ се губят. Опитай отново!",
        "💡 Успешен крафт дава +75 Battle Pass EXP!",
        "💡 Хаос Фрагменти се получават от Хаос Осколок питомец!",
        "💡 Titan Essence пада само от Царство на Титаните босове!",
        "💡 Divine Light се получава от Arena Вълна 25+!"
    )

    fun canCraft(recipe: RuneRecipe, character: com.mythosrise.game.models.Character): Boolean =
        character.gold >= recipe.goldCost && character.divinity >= recipe.divinityCost

    fun attemptCraft(recipe: RuneRecipe, character: com.mythosrise.game.models.Character): Boolean {
        if (!canCraft(recipe, character)) return false
        character.gold -= recipe.goldCost
        character.divinity -= recipe.divinityCost
        return Math.random() < recipe.successRate
    }

    fun getRecipeForRune(runeId: String): RuneRecipe? =
        RUNE_RECIPES.firstOrNull { it.resultRuneId == runeId }

    fun getAllCraftableRunes(character: com.mythosrise.game.models.Character): List<RuneRecipe> =
        RUNE_RECIPES.filter { recipe ->
            character.gold >= recipe.goldCost * 0.5f && character.divinity >= recipe.divinityCost * 0.5f
        }
}
