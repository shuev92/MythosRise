package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.*

class ShopActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var tvGold: TextView
    private lateinit var tvDivinity: TextView
    private lateinit var llShopItems: LinearLayout
    private lateinit var llSellItems: LinearLayout

    private var currentTab = 0 // 0=Buy, 1=Sell, 2=Upgrade, 3=Legendary

    // Shop stock rotates based on world and level
    private val shopStock = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
        engine = GameEngine(this)
        engine.loadGame()

        tvGold = findViewById(R.id.tvShopGold)
        tvDivinity = findViewById(R.id.tvShopDivinity)
        llShopItems = findViewById(R.id.llShopItems)
        llSellItems = findViewById(R.id.llSellItems)

        generateShopStock()
        setupTabs()
        showBuyTab()
        updateHeader()
    }

    private fun updateHeader() {
        tvGold.text = "💰 ${engine.character.gold} Злато"
        tvDivinity.text = "✨ ${engine.character.divinity} Дивинити"
    }

    // ─────────────────────────────────────────────
    //  STOCK GENERATION
    // ─────────────────────────────────────────────

    private fun generateShopStock() {
        shopStock.clear()
        val c = engine.character
        val allItems = GameDatabase.ALL_ITEMS.values.toList()

        // Always have potions
        shopStock.add(GameDatabase.ALL_ITEMS["health_potion"]!!)
        shopStock.add(GameDatabase.ALL_ITEMS["health_potion"]!!)
        shopStock.add(GameDatabase.ALL_ITEMS["mana_potion"]!!)
        shopStock.add(GameDatabase.ALL_ITEMS["berserker_potion"]!!)

        // Level-appropriate gear
        val levelItems = allItems.filter {
            it.type != ItemType.POTION &&
            it.value <= c.gold * 3 &&
            it.value > 0
        }.sortedBy { it.value }.take(15)
        shopStock.addAll(levelItems)

        // World-specific items
        val worldItems = allItems.filter { item ->
            item.mythology.lowercase().contains(
                when (c.currentWorld) {
                    World.GREEK_OLYMPUS, World.TARTARUS -> "greek"
                    World.EGYPTIAN_REALM -> "egyptian"
                    World.DRAGON_REALM -> "dragon"
                    World.JAPANESE_REALM -> "japanese"
                    World.CHINESE_REALM -> "chinese"
                    World.NORSE_ASGARD -> "norse"
                    World.TITAN_REALM -> "titan"
                    else -> "mortal"
                }
            )
        }.take(5)
        shopStock.addAll(worldItems)
    }

    // ─────────────────────────────────────────────
    //  TABS
    // ─────────────────────────────────────────────

    private fun setupTabs() {
        val tabs = listOf(
            findViewById<Button>(R.id.btnTabBuy),
            findViewById<Button>(R.id.btnTabSell),
            findViewById<Button>(R.id.btnTabUpgrade),
            findViewById<Button>(R.id.btnTabLegendary)
        )
        tabs[0].setOnClickListener { currentTab = 0; showBuyTab(); highlightTab(tabs, 0) }
        tabs[1].setOnClickListener { currentTab = 1; showSellTab(); highlightTab(tabs, 1) }
        tabs[2].setOnClickListener { currentTab = 2; showUpgradeTab(); highlightTab(tabs, 2) }
        tabs[3].setOnClickListener { currentTab = 3; showLegendaryTab(); highlightTab(tabs, 3) }
        highlightTab(tabs, 0)
    }

    private fun highlightTab(tabs: List<Button>, selected: Int) {
        tabs.forEachIndexed { i, btn ->
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (i == selected) Color.parseColor("#6A0DAD") else Color.parseColor("#2C2C2C")
            )
        }
    }

    // ─────────────────────────────────────────────
    //  BUY TAB
    // ─────────────────────────────────────────────

    private fun showBuyTab() {
        llShopItems.removeAllViews()
        val header = makeHeader("🛒 КУПИ ПРЕДМЕТИ")
        llShopItems.addView(header)

        shopStock.distinctBy { it.id }.forEach { item ->
            val canAfford = engine.character.gold >= item.value
            addShopItemView(item, canAfford, "💰 ${item.value} злато", "КУПИ") {
                if (engine.character.gold >= item.value) {
                    engine.character.gold -= item.value
                    engine.character.inventory.add(item.copy())
                    engine.saveGame()
                    updateHeader()
                    Toast.makeText(this, "✅ Купен: ${item.name}!", Toast.LENGTH_SHORT).show()
                    showBuyTab()
                } else {
                    Toast.makeText(this, "❌ Недостатъчно злато!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ─────────────────────────────────────────────
    //  SELL TAB
    // ─────────────────────────────────────────────

    private fun showSellTab() {
        llShopItems.removeAllViews()
        val header = makeHeader("💰 ПРОДАЙ ПРЕДМЕТИ (50% цена)")
        llShopItems.addView(header)

        engine.character.inventory.forEach { item ->
            val sellPrice = item.value / 2
            addShopItemView(item, true, "Продава се за: $sellPrice злато", "ПРОДАЙ") {
                AlertDialog.Builder(this)
                    .setTitle("Продай ${item.name}?")
                    .setMessage("Ще получиш $sellPrice злато.\nСигурен ли си?")
                    .setPositiveButton("Продай") { _, _ ->
                        engine.character.inventory.remove(item)
                        engine.character.gold += sellPrice
                        engine.saveGame()
                        updateHeader()
                        Toast.makeText(this, "💰 Продаден: ${item.name} за $sellPrice злато!", Toast.LENGTH_SHORT).show()
                        showSellTab()
                    }
                    .setNegativeButton("Назад", null)
                    .show()
            }
        }
    }

    // ─────────────────────────────────────────────
    //  UPGRADE TAB
    // ─────────────────────────────────────────────

    private fun showUpgradeTab() {
        llShopItems.removeAllViews()
        val header = makeHeader("⬆️ ПОДОБРИ ЕКИПИРОВКА")
        llShopItems.addView(header)

        val equipped = listOfNotNull(
            engine.character.equippedWeapon,
            engine.character.equippedArmor,
            engine.character.equippedHelmet,
            engine.character.equippedBoots,
            engine.character.equippedRing,
            engine.character.equippedAmulet
        )

        if (equipped.isEmpty()) {
            llShopItems.addView(makeInfo("Нямаш екипирани предмети."))
            return
        }

        equipped.forEach { item ->
            val upgradeCost = item.value / 3 + 500
            val canAfford = engine.character.gold >= upgradeCost
            addShopItemView(item, canAfford, "Подобри за $upgradeCost злато (+20% бонуси)", "ПОДОБРИ") {
                if (engine.character.gold >= upgradeCost) {
                    engine.character.gold -= upgradeCost
                    // Create upgraded version
                    val upgraded = item.copy(
                        name = "⬆️ ${item.name}",
                        attackBonus = (item.attackBonus * 1.2f).toInt(),
                        defenseBonus = (item.defenseBonus * 1.2f).toInt(),
                        healthBonus = (item.healthBonus * 1.2f).toInt(),
                        manaBonus = (item.manaBonus * 1.2f).toInt(),
                        value = (item.value * 1.5f).toInt()
                    )
                    when (item.type) {
                        ItemType.WEAPON -> engine.character.equippedWeapon = upgraded
                        ItemType.ARMOR -> engine.character.equippedArmor = upgraded
                        ItemType.HELMET -> engine.character.equippedHelmet = upgraded
                        ItemType.BOOTS -> engine.character.equippedBoots = upgraded
                        ItemType.RING -> engine.character.equippedRing = upgraded
                        ItemType.AMULET -> engine.character.equippedAmulet = upgraded
                        else -> {}
                    }
                    engine.saveGame()
                    updateHeader()
                    Toast.makeText(this, "⬆️ ${item.name} е подобрен!", Toast.LENGTH_SHORT).show()
                    showUpgradeTab()
                } else {
                    Toast.makeText(this, "❌ Недостатъчно злато! (${upgradeCost - engine.character.gold} злато липсват)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ─────────────────────────────────────────────
    //  LEGENDARY TAB
    // ─────────────────────────────────────────────

    private fun showLegendaryTab() {
        llShopItems.removeAllViews()
        val header = makeHeader("🌟 ЛЕГЕНДАРЕН МАГАЗИН (Дивинити)")
        llShopItems.addView(header)

        val legendaryItems = listOf(
            Triple(GameDatabase.ALL_ITEMS["zeus_lightning"]!!, 5000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["vishnu_chakra"]!!, 6000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["mjolnir"]!!, 4500, "✨"),
            Triple(GameDatabase.ALL_ITEMS["kusanagi"]!!, 5500, "✨"),
            Triple(GameDatabase.ALL_ITEMS["ruyi_jingu_bang"]!!, 7000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["kronos_scythe"]!!, 8000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["omnigod_crown"]!!, 50000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["tiamat_scale"]!!, 9000, "✨"),
            Triple(GameDatabase.ALL_ITEMS["dragon_pearl"]!!, 4000, "✨"),
        )

        legendaryItems.forEach { (item, divinityPrice, _) ->
            val canAfford = engine.character.divinity >= divinityPrice
            addShopItemView(item, canAfford, "✨ $divinityPrice Дивинити", "ПРИДОБИЙ") {
                if (engine.character.divinity >= divinityPrice) {
                    engine.character.divinity -= divinityPrice
                    engine.character.inventory.add(item.copy())
                    engine.saveGame()
                    updateHeader()
                    Toast.makeText(this, "🌟 Придобит: ${item.name}!", Toast.LENGTH_SHORT).show()
                } else {
                    val needed = divinityPrice - engine.character.divinity
                    Toast.makeText(this, "❌ Нужни са още $needed Дивинити!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ─────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────

    private fun addShopItemView(item: Item, canAfford: Boolean, priceText: String, btnLabel: String, onClick: () -> Unit) {
        val rarityColor = when (item.rarity) {
            Rarity.COMMON -> "#AAAAAA"
            Rarity.UNCOMMON -> "#00AA00"
            Rarity.RARE -> "#4444FF"
            Rarity.EPIC -> "#AA00FF"
            Rarity.LEGENDARY -> "#FF8800"
            Rarity.MYTHIC -> "#FF2200"
            Rarity.DIVINE -> "#FFD700"
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1A0A2E"))
            setPadding(12, 10, 12, 10)
            alpha = if (canAfford) 1.0f else 0.5f
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 4, 0, 4)
            layoutParams = lp
        }

        val emojiTv = TextView(this).apply {
            text = item.emoji; textSize = 24f; setPadding(0, 0, 10, 0)
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        TextView(this).apply {
            text = "${item.name} (${item.rarity.displayName})"
            setTextColor(Color.parseColor(rarityColor)); textSize = 14f
        }.also { info.addView(it) }

        val stats = buildString {
            if (item.attackBonus != 0) append("⚔️+${item.attackBonus} ")
            if (item.defenseBonus != 0) append("🛡️+${item.defenseBonus} ")
            if (item.healthBonus != 0) append("❤️+${item.healthBonus} ")
            if (item.divinityBonus != 0) append("✨+${item.divinityBonus} ")
        }
        TextView(this).apply {
            text = if (stats.isNotBlank()) stats else item.description.take(30)
            setTextColor(Color.LTGRAY); textSize = 11f
        }.also { info.addView(it) }

        TextView(this).apply {
            text = priceText
            setTextColor(if (canAfford) Color.parseColor("#FFD700") else Color.GRAY)
            textSize = 12f
        }.also { info.addView(it) }

        val btn = Button(this).apply {
            text = btnLabel; textSize = 11f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (canAfford) Color.parseColor("#6A0DAD") else Color.parseColor("#333333")
            )
            isEnabled = canAfford
            setOnClickListener { onClick() }
        }

        row.addView(emojiTv)
        row.addView(info)
        row.addView(btn)
        llShopItems.addView(row)
    }

    private fun makeHeader(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.parseColor("#FFD700"))
        textSize = 16f; isFakeBoldText = true
        setPadding(8, 16, 8, 8)
    }

    private fun makeInfo(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.GRAY); textSize = 14f; setPadding(8, 8, 8, 8)
    }
}
