package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.CraftingSystem
import com.mythosrise.game.engine.GameEngine

class CraftingActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llRecipes: LinearLayout
    private lateinit var llMaterials: LinearLayout
    private lateinit var tvGold: TextView
    private val playerMaterials = mutableMapOf<String, Int>()
    private var currentTab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crafting)
        engine = GameEngine(this)
        engine.loadGame()

        llRecipes = findViewById(R.id.llCraftingRecipes)
        llMaterials = findViewById(R.id.llCraftingMaterials)
        tvGold = findViewById(R.id.tvCraftingGold)

        // Load player materials from save (simplified - in real app save/load materials)
        loadPlayerMaterials()
        setupTabs()
        showRecipes("Всички")
        updateHeader()
    }

    private fun loadPlayerMaterials() {
        // Demo materials for testing - in production these would be saved
        CraftingSystem.ALL_MATERIALS.forEach { mat ->
            playerMaterials[mat.id] = (engine.character.level / 5).coerceAtLeast(0)
        }
    }

    private fun updateHeader() {
        tvGold.text = "💰 ${engine.character.gold} Злато | ✨ ${engine.character.divinity} Дивинити"
    }

    private fun setupTabs() {
        val categories = listOf("Всички") + CraftingSystem.categories
        val ll = findViewById<LinearLayout>(R.id.llCraftingTabs)
        ll.removeAllViews()
        categories.forEach { cat ->
            val btn = Button(this).apply {
                text = cat; textSize = 11f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C2C2C"))
                val lp = LinearLayout.LayoutParams(0, 44.dpToPx(), 1f)
                lp.setMargins(2, 0, 2, 0)
                layoutParams = lp
                setOnClickListener { showRecipes(cat) }
            }
            ll.addView(btn)
        }
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()

    private fun showRecipes(category: String) {
        llRecipes.removeAllViews()
        val recipes = if (category == "Всички") CraftingSystem.ALL_RECIPES
        else CraftingSystem.getRecipesByCategory(category)

        recipes.forEach { recipe ->
            val canCraft = CraftingSystem.canCraft(recipe, engine.character, playerMaterials)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(if (canCraft) Color.parseColor("#0A1A0A") else Color.parseColor("#0A0A1A"))
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 6, 0, 6)
                layoutParams = lp
                alpha = if (canCraft) 1.0f else 0.6f
            }

            // Title
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            TextView(this).apply { text = recipe.resultEmoji; textSize = 24f; setPadding(0,0,8,0) }.also { titleRow.addView(it) }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            TextView(this).apply {
                text = recipe.resultName
                setTextColor(if (canCraft) Color.parseColor("#FFD700") else Color.LTGRAY)
                textSize = 14f; isFakeBoldText = true
            }.also { info.addView(it) }
            TextView(this).apply {
                text = recipe.description; setTextColor(Color.GRAY); textSize = 12f
            }.also { info.addView(it) }
            titleRow.addView(info)
            card.addView(titleRow)

            // Ingredients
            TextView(this).apply {
                text = "📦 Материали:"; setTextColor(Color.parseColor("#AAAAFF")); textSize = 12f
                setPadding(0, 6, 0, 2)
            }.also { card.addView(it) }

            recipe.ingredients.forEach { (matId, needed) ->
                val mat = CraftingSystem.ALL_MATERIALS.find { it.id == matId }
                val have = playerMaterials[matId] ?: 0
                val hasEnough = have >= needed
                val ingRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 1, 0, 1) }
                TextView(this).apply {
                    text = "${if (hasEnough) "✅" else "❌"} ${mat?.emoji ?: "?"} ${mat?.name ?: matId}"
                    setTextColor(if (hasEnough) Color.parseColor("#88FF88") else Color.parseColor("#FF8888"))
                    textSize = 11f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }.also { ingRow.addView(it) }
                TextView(this).apply {
                    text = "$have/$needed"; textSize = 11f
                    setTextColor(if (hasEnough) Color.parseColor("#00CC00") else Color.parseColor("#CC0000"))
                }.also { ingRow.addView(it) }
                card.addView(ingRow)
            }

            // Cost and requirements
            val reqs = buildString {
                if (recipe.goldCost > 0) append("💰 ${recipe.goldCost} злато  ")
                if (recipe.requiredLevel > 1) append("⭐ Ниво ${recipe.requiredLevel}  ")
                if (recipe.requiredDivinity > 0) append("✨ ${recipe.requiredDivinity} Дивинити")
            }
            if (reqs.isNotBlank()) {
                TextView(this).apply {
                    text = reqs; setTextColor(Color.parseColor("#FFD700")); textSize = 11f
                    setPadding(0, 4, 0, 0)
                }.also { card.addView(it) }
            }

            // Craft button
            Button(this).apply {
                text = if (canCraft) "🔨 ЗАНАЯТИ!" else "🔒 Недостатъчно материали"
                setTextColor(Color.WHITE); isEnabled = canCraft
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (canCraft) Color.parseColor("#8B6914") else Color.parseColor("#333333")
                )
                setOnClickListener {
                    AlertDialog.Builder(this@CraftingActivity)
                        .setTitle("🔨 Занаяти: ${recipe.resultName}?")
                        .setMessage(recipe.description)
                        .setPositiveButton("ЗАНАЯТИ!") { _, _ ->
                            val result = CraftingSystem.craft(recipe, engine.character, playerMaterials)
                            if (result != null) {
                                engine.saveGame()
                                updateHeader()
                                showRecipes(category)
                                AlertDialog.Builder(this@CraftingActivity)
                                    .setTitle("✅ Занаятено!")
                                    .setMessage("${result.emoji} ${result.name}\n\n${result.description}\n\nПредметът е добавен в инвентара!")
                                    .setPositiveButton("🎉 Страхотно!", null)
                                    .show()
                            }
                        }
                        .setNegativeButton("Назад", null)
                        .show()
                }
            }.also { card.addView(it) }

            llRecipes.addView(card)
        }
    }
}
