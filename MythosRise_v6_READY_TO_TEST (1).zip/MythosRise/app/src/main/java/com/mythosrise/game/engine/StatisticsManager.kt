package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.HeroClass
import com.mythosrise.game.models.World

// ─────────────────────────────────────────────
//  STATISTICS TRACKER
// ─────────────────────────────────────────────

data class GameStatistics(
    // Combat
    var totalDamageDealt: Long = 0,
    var totalDamageTaken: Long = 0,
    var totalCriticalHits: Int = 0,
    var totalAbilitiesUsed: Int = 0,
    var totalPotionsUsed: Int = 0,
    var highestSingleHit: Int = 0,
    var highestCriticalHit: Int = 0,
    var longestKillStreak: Int = 0,
    var currentKillStreak: Int = 0,
    var totalBattles: Int = 0,
    var battlesWon: Int = 0,
    var battlesLost: Int = 0,
    var perfectBattles: Int = 0, // Won without taking damage

    // Enemies
    var totalEnemiesKilled: Int = 0,
    var totalBossesKilled: Int = 0,
    var totalGodsKilled: Int = 0,
    var totalTitansKilled: Int = 0,
    var totalDragonsKilled: Int = 0,
    var rareEnemiesKilled: Int = 0,
    var mostKilledEnemy: String = "",
    var mostKilledCount: Int = 0,
    val killCounts: MutableMap<String, Int> = mutableMapOf(),

    // Economy
    var totalGoldEarned: Long = 0,
    var totalGoldSpent: Long = 0,
    var totalItemsBought: Int = 0,
    var totalItemsSold: Int = 0,
    var itemsCrafted: Int = 0,
    var highestGoldBalance: Int = 0,

    // Divinity
    var totalDivinityEarned: Long = 0,
    var highestDivinityReached: Int = 0,
    var totalPowersAbsorbed: Int = 0,
    var uniquePowersAbsorbed: Int = 0,

    // Exploration
    var worldsVisited: Int = 0,
    var totalDistanceTraveled: Int = 0,
    var secretsFound: Int = 0,

    // Progression
    var totalLevelsGained: Int = 0,
    var totalExperienceGained: Long = 0,
    var skillPointsSpent: Int = 0,
    var prestigeCount: Int = 0,

    // Quests & Achievements
    var questsCompleted: Int = 0,
    var achievementsUnlocked: Int = 0,
    var dailyChallengesCompleted: Int = 0,

    // Time
    var totalPlayTimeMinutes: Long = 0,
    var sessionsPlayed: Int = 0,

    // Special
    var timesTransformed: Int = 0,
    var bossRushesCompleted: Int = 0,
    var massWavesCompleted: Int = 0,
    var highestWaveReached: Int = 0,
    var totalArenaKills: Int = 0
)

// ─────────────────────────────────────────────
//  LEADERBOARD ENTRY
// ─────────────────────────────────────────────

data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val heroClass: HeroClass,
    val level: Int,
    val divinity: Int,
    val divinityTitle: String,
    val enemiesDefeated: Int,
    val godsDefeated: Int,
    val prestigeCount: Int,
    val score: Long
)

// ─────────────────────────────────────────────
//  STATISTICS MANAGER
// ─────────────────────────────────────────────

object StatisticsManager {

    fun calculateScore(character: Character, stats: GameStatistics): Long {
        return (character.divinity * 10L) +
               (character.level * 500L) +
               (stats.totalEnemiesKilled * 10L) +
               (stats.totalGodsKilled * 5000L) +
               (stats.totalTitansKilled * 20000L) +
               (stats.totalBossesKilled * 1000L) +
               (stats.perfectBattles * 2000L) +
               (stats.highestSingleHit * 5L) +
               (character.prestigeCount * 100000L) +
               (stats.questsCompleted * 3000L) +
               (stats.achievementsUnlocked * 5000L) +
               (stats.bossRushesCompleted * 50000L)
    }

    fun generateLocalLeaderboard(character: Character, stats: GameStatistics): List<LeaderboardEntry> {
        val playerScore = calculateScore(character, stats)
        val player = LeaderboardEntry(
            rank = 1,
            name = character.name,
            heroClass = character.heroClass,
            level = character.level,
            divinity = character.divinity,
            divinityTitle = character.divinityTitle.title,
            enemiesDefeated = character.enemiesDefeated,
            godsDefeated = character.godsDefeated,
            prestigeCount = character.prestigeCount,
            score = playerScore
        )
        // Generate AI competitors based on player's progress
        val aiEntries = generateAICompetitors(character, playerScore)
        return (listOf(player) + aiEntries)
            .sortedByDescending { it.score }
            .mapIndexed { i, e -> e.copy(rank = i + 1) }
    }

    private fun generateAICompetitors(character: Character, playerScore: Long): List<LeaderboardEntry> {
        val names = listOf(
            "Κρόνος_Slayer" to HeroClass.WARRIOR,
            "Amaterasu_Dev" to HeroClass.MAGE,
            "DragonBorn42" to HeroClass.ARCHER,
            "MonkOfZen" to HeroClass.MONK,
            "GodsDefeater" to HeroClass.WARRIOR,
            "MythosLegend" to HeroClass.MAGE,
            "TitanHunter" to HeroClass.ARCHER,
            "NidhoggBane" to HeroClass.WARRIOR,
            "ShivaFollower" to HeroClass.MONK,
            "ZeusKiller99" to HeroClass.ARCHER
        )
        return names.mapIndexed { i, (name, cls) ->
            val scoreMult = when (i) {
                0 -> 1.8f; 1 -> 1.4f; 2 -> 1.1f; 3 -> 0.95f; 4 -> 0.8f
                5 -> 0.7f; 6 -> 0.55f; 7 -> 0.4f; 8 -> 0.25f; else -> 0.1f
            }
            val score = (playerScore * scoreMult).toLong().coerceAtLeast(100)
            val lvl = (character.level * scoreMult).toInt().coerceIn(1, 50)
            val div = (character.divinity * scoreMult).toInt().coerceAtLeast(0)
            val titles = listOf("Смъртен", "Полубог", "Олимпиец", "Легенда", "Всебог")
            LeaderboardEntry(
                rank = 0, name = name, heroClass = cls, level = lvl,
                divinity = div, divinityTitle = titles[i % titles.size],
                enemiesDefeated = (character.enemiesDefeated * scoreMult).toInt(),
                godsDefeated = (character.godsDefeated * scoreMult).toInt(),
                prestigeCount = (character.prestigeCount * scoreMult).toInt(),
                score = score
            )
        }
    }

    fun getStatsSummary(stats: GameStatistics, character: Character): String = buildString {
        appendLine("═══ СТАТИСТИКИ ═══")
        appendLine()
        appendLine("⚔️ БИТКИ")
        appendLine("  Общо битки: ${stats.totalBattles}")
        appendLine("  Победи: ${stats.battlesWon} | Загуби: ${stats.battlesLost}")
        appendLine("  Перфектни: ${stats.perfectBattles}")
        appendLine("  Максимален удар: ${stats.highestSingleHit}")
        appendLine("  Максимален крит: ${stats.highestCriticalHit}")
        appendLine("  Пореден рекорд убийства: ${stats.longestKillStreak}")
        appendLine()
        appendLine("👹 ВРАГОВЕ")
        appendLine("  Убити общо: ${stats.totalEnemiesKilled}")
        appendLine("  Убити босове: ${stats.totalBossesKilled}")
        appendLine("  Убити богове: ${stats.totalGodsKilled}")
        appendLine("  Убити титани: ${stats.totalTitansKilled}")
        appendLine("  Убити дракони: ${stats.totalDragonsKilled}")
        appendLine()
        appendLine("💰 ИКОНОМИКА")
        appendLine("  Спечелено злато: ${stats.totalGoldEarned}")
        appendLine("  Похарчено злато: ${stats.totalGoldSpent}")
        appendLine("  Занаятени предмети: ${stats.itemsCrafted}")
        appendLine()
        appendLine("✨ ДИВИНИТИ")
        appendLine("  Спечелена дивинити: ${stats.totalDivinityEarned}")
        appendLine("  Максимум: ${stats.highestDivinityReached}")
        appendLine("  Погълнати сили: ${stats.totalPowersAbsorbed}")
        appendLine()
        appendLine("🏆 ПОСТИЖЕНИЯ")
        appendLine("  Куестове: ${stats.questsCompleted}")
        appendLine("  Постижения: ${stats.achievementsUnlocked}")
        appendLine("  Дневни: ${stats.dailyChallengesCompleted}")
        appendLine("  Престиж: ${stats.prestigeCount} пъти")
        appendLine()
        appendLine("⏱️ ИГРОВО ВРЕМЕ")
        val hours = stats.totalPlayTimeMinutes / 60
        val mins = stats.totalPlayTimeMinutes % 60
        appendLine("  Общо: ${hours}ч ${mins}мин")
        append("  Сесии: ${stats.sessionsPlayed}")
    }

    fun getMilestones(stats: GameStatistics): List<String> {
        val milestones = mutableListOf<String>()
        if (stats.totalEnemiesKilled >= 1000) milestones.add("💀 1000 врагове убити")
        if (stats.totalGodsKilled >= 10) milestones.add("⚡ 10 богове убити")
        if (stats.totalDamageDealt >= 1_000_000) milestones.add("💥 1 милион урон нанесен")
        if (stats.perfectBattles >= 50) milestones.add("🛡️ 50 перфектни битки")
        if (stats.highestSingleHit >= 10000) milestones.add("💪 10 000 единичен удар")
        if (stats.bossRushesCompleted >= 5) milestones.add("🏆 5 Boss Rush завършени")
        if (stats.highestWaveReached >= 10) milestones.add("🏟️ Вълна 10 в Арената")
        if (stats.totalPlayTimeMinutes >= 600) milestones.add("⏱️ 10 часа игрово време")
        if (stats.itemsCrafted >= 20) milestones.add("🔨 20 занаятени предмета")
        if (stats.questsCompleted >= 10) milestones.add("📜 10 куеста завършени")
        return milestones
    }
}

// ─────────────────────────────────────────────
//  EXTENDED STATISTICS ANALYSIS
// ─────────────────────────────────────────────

object StatisticsAnalyzer {
    data class PlayStyle(
        val name: String, val emoji: String, val description: String
    )
    
    val PLAY_STYLES = listOf(
        PlayStyle("Берсерк Воин", "😤", "Атакуваш директно. Защитата не те интересува. Или умираш, или побеждаваш."),
        PlayStyle("Стратег", "🧠", "Планираш умело. Използваш елементарните слабости. Перфектни битки."),
        PlayStyle("Богоубиец", "⚡", "Ловиш само боса. Нормалните врагове не са достойни."),
        PlayStyle("Поглъщач", "🌀", "Поглъщаш всичко. Силата расте с всяка победа."),
        PlayStyle("Търговец", "💰", "Злато над всичко. Купуваш победата."),
        PlayStyle("Изследовател", "🌍", "Посещаваш всеки свят. Четеш всяко лоре. Знаеш всичко."),
        PlayStyle("Перфекционист", "🛡️", "Без щети. Само перфектни победи. Чест над злато."),
        PlayStyle("Всебог", "🌌", "Дивинитито е всичко. Трансформации. Престиж. Абсолютната мощ.")
    )
    
    fun detectPlayStyle(stats: GameStatistics): PlayStyle {
        return when {
            stats.perfectBattles > stats.totalBattles * 0.5 -> PLAY_STYLES[6] // Perfectionist
            stats.totalGodsKilled > stats.totalEnemiesKilled * 0.3 -> PLAY_STYLES[2] // God Slayer
            stats.totalPowersAbsorbed > 50 -> PLAY_STYLES[3] // Absorber
            stats.totalGoldEarned > 100000 -> PLAY_STYLES[4] // Merchant
            stats.worldsVisited >= 10 -> PLAY_STYLES[5] // Explorer
            stats.totalDivinityEarned > 10000 -> PLAY_STYLES[7] // Omnigod
            stats.highestSingleHit > 5000 -> PLAY_STYLES[0] // Berserker
            else -> PLAY_STYLES[1] // Strategist
        }
    }
    
    fun getPersonalizedTips(stats: GameStatistics): List<String> {
        val tips = mutableListOf<String>()
        if (stats.perfectBattles < 10) tips.add("💡 Пробвай да победиш враг без да получиш щета за 'Перфектна Битка' постижение!")
        if (stats.totalPowersAbsorbed < 20) tips.add("💡 Поглъщай повече! Всяка погълната сила те прави постоянно по-силен.")
        if (stats.bossRushesCompleted == 0) tips.add("💡 Опитай Boss Rush! Поглъщаш всички босове наведнъж — гигантски бонуси!")
        if (stats.dailyChallengesCompleted < 5) tips.add("💡 Дневните предизвикателства дават безплатни ресурси всеки ден!")
        if (stats.totalGodsKilled < 5) tips.add("💡 Убий 5 бога за 'Богоубиец' постижение и огромна дивинити!")
        if (stats.itemsCrafted == 0) tips.add("💡 Занаятчийството прави по-добри предмети от магазина за висок tier!")
        if (stats.prestigeCount == 0 && stats.totalEnemiesKilled > 500) tips.add("💡 Готов ли си за Престиж? Постоянни бонуси те чакат при Ниво 50!")
        return tips.take(3)
    }
    
    fun formatNumber(n: Long): String = when {
        n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
        n >= 1_000 -> "%.1fK".format(n / 1_000.0)
        else -> n.toString()
    }
    
    fun getKillRank(kills: Int): String = when {
        kills >= 10000 -> "🌌 Легендарен Убиец"
        kills >= 5000 -> "💀 Велик Убиец"
        kills >= 1000 -> "⚔️ Ветеран"
        kills >= 500 -> "🗡️ Воин"
        kills >= 100 -> "🔰 Начинаещ"
        else -> "👶 Новак"
    }
    
    fun getDivinityRank(divinity: Int): String = when {
        divinity >= 50000 -> "🌌 ВСЕБОГ"
        divinity >= 25000 -> "🌟 Древен Бог"
        divinity >= 10000 -> "👑 Легенда"
        divinity >= 5000 -> "🔱 Митичен Герой"
        divinity >= 2000 -> "🏛️ Олимпиец"
        divinity >= 500 -> "⚡ Полубог"
        else -> "🧍 Смъртен"
    }
}
