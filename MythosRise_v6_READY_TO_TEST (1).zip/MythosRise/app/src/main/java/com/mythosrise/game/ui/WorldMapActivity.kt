package com.mythosrise.game.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameDatabase
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.World

class WorldMapActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_world_map)
        engine = GameEngine(this)
        engine.loadGame()

        setupUI()
    }

    override fun onResume() {
        super.onResume()
        engine.loadGame()
        setupUI()
    }

    private fun setupUI() {
        val c = engine.character

        // Header stats
        findViewById<TextView>(R.id.tvMapHeroName).text =
            "${c.gender.emoji} ${c.name} | ${c.divinityTitle.title}"
        findViewById<TextView>(R.id.tvMapStats).text =
            "❤️ ${c.health}/${c.getTotalMaxHealth()}  ⚔️${c.getTotalAttack()}  🛡️${c.getTotalDefense()}  ✨${c.divinity}"
        findViewById<TextView>(R.id.tvMapLevel).text = "Ниво ${c.level}"
        findViewById<TextView>(R.id.tvCurrentWorld).text =
            "${c.currentWorld.emoji} ${c.currentWorld.displayName}"

        // Battle buttons
        findViewById<Button>(R.id.btnFight).setOnClickListener {
            val enemy = engine.getNextEnemy()
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra("enemy_id", enemy.id)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnFightBoss).apply {
            val boss = engine.getWorldBoss()
            isEnabled = boss != null
            text = if (boss != null) "⚔️ Бош: ${boss.emoji} ${boss.name}" else "🔒 Бош (победен)"
            setOnClickListener {
                boss?.let {
                    val intent = Intent(this@WorldMapActivity, GameActivity::class.java)
                    intent.putExtra("enemy_id", it.id)
                    intent.putExtra("is_boss", true)
                    startActivity(intent)
                }
            }
        }

        findViewById<Button>(R.id.btnInventory).setOnClickListener {
            startActivity(Intent(this, InventoryActivity::class.java))
        }

        // Mass Battle Arena
        val massBattleBtn = findViewById<Button>(R.id.btnMassBattle)
        val arenaUnlocked = engine.character.level >= World.MASS_BATTLE_ARENA.unlockLevel
        massBattleBtn.isEnabled = arenaUnlocked
        massBattleBtn.alpha = if (arenaUnlocked) 1.0f else 0.4f
        massBattleBtn.text = if (arenaUnlocked) "⚔️ МАСОВА БИТКА — Арена" else "🔒 МАСОВА БИТКА (Ниво ${World.MASS_BATTLE_ARENA.unlockLevel})"
        massBattleBtn.setOnClickListener {
            startActivity(Intent(this, MassBattleActivity::class.java))
        }

        findViewById<Button>(R.id.btnShop).setOnClickListener {
            startActivity(Intent(this, ShopActivity::class.java))
        }
        findViewById<Button>(R.id.btnSkillTree).setOnClickListener {
            startActivity(Intent(this, SkillTreeActivity::class.java))
        }
        findViewById<Button>(R.id.btnAchievements).setOnClickListener {
            startActivity(Intent(this, AchievementActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnQuests).setOnClickListener {
            startActivity(Intent(this, QuestActivity::class.java))
        }
        findViewById<Button>(R.id.btnCrafting).setOnClickListener {
            startActivity(Intent(this, CraftingActivity::class.java))
        }
        findViewById<Button>(R.id.btnLoreBook).setOnClickListener {
            startActivity(Intent(this, LoreBookActivity::class.java))
        }

        // World selector
        setupWorldList()
    }

    private fun setupWorldList() {
        val container = findViewById<LinearLayout>(R.id.llWorldList)
        container.removeAllViews()

        World.values().forEach { world ->
            val btn = Button(this).apply {
                val unlocked = engine.character.level >= world.unlockLevel
                val isCurrent = world == engine.character.currentWorld
                text = "${world.emoji} ${world.displayName}" +
                        if (!unlocked) " (Ниво ${world.unlockLevel})" else ""
                alpha = when {
                    isCurrent -> 1.0f
                    unlocked -> 0.8f
                    else -> 0.3f
                }
                isEnabled = unlocked
                setBackgroundColor(if (isCurrent) Color.parseColor("#4A1A6B") else Color.parseColor("#2A0A3B"))
                setTextColor(Color.WHITE)
                setPadding(24, 16, 24, 16)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.setMargins(0, 8, 0, 8)
                layoutParams = lp

                setOnClickListener {
                    if (unlocked) {
                        engine.character.currentWorld = world
                        engine.saveGame()
                        setupUI()
                    }
                }
            }
            container.addView(btn)
        }
    }
}
