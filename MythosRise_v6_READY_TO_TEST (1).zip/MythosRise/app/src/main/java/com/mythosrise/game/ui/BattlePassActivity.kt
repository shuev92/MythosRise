package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.*

class BattlePassActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llContent: LinearLayout
    private lateinit var tvHeader: TextView
    private var currentTab = "Нива"
    private val season = BattlePassManager.getCurrentSeason()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_battle_pass)
        engine = GameEngine(this)
        engine.loadGame()
        llContent = findViewById(R.id.llBattlePassContent)
        tvHeader = findViewById(R.id.tvBattlePassHeader)
        setupTabs()
        showTiersTab()
    }

    private fun setupTabs() {
        val tabs = listOf("Нива", "Награди", "Сезон", "Как да спечеля")
        val ll = findViewById<LinearLayout>(R.id.llBattlePassTabs)
        ll.removeAllViews()
        tabs.forEach { tab ->
            Button(this).apply {
                text = tab; textSize = 10f; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (tab == currentTab) Color.parseColor("#FF8800") else Color.parseColor("#2C2C2C")
                )
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(2, 0, 2, 0); layoutParams = lp
                setOnClickListener {
                    currentTab = tab; setupTabs()
                    when (tab) {
                        "Нива" -> showTiersTab()
                        "Награди" -> showRewardsTab()
                        "Сезон" -> showSeasonTab()
                        "Как да спечеля" -> showEarnTab()
                    }
                }
            }.also { ll.addView(it) }
        }
    }

    private fun showTiersTab() {
        llContent.removeAllViews()
        tvHeader.text = "${season.emoji} ${season.name}"

        // Season progress banner
        val banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1A0A00"))
            setPadding(14, 12, 14, 12)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 10); layoutParams = lp
        }
        val progressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        TextView(this).apply {
            text = "Ниво ${season.currentTier}/50"
            setTextColor(Color.parseColor("#FFD700")); textSize = 16f; isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }.also { progressRow.addView(it) }
        TextView(this).apply {
            text = if (season.isPremium) "✅ PREMIUM" else "🔒 Безплатен"
            setTextColor(if (season.isPremium) Color.parseColor("#FFD700") else Color.GRAY)
            textSize = 13f
        }.also { progressRow.addView(it) }
        banner.addView(progressRow)

        val tierExp = season.tiers.getOrNull(season.currentTier)?.requiredExp ?: 0
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = tierExp.coerceAtLeast(1); progress = season.currentExp
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 14).apply { setMargins(0, 6, 0, 2) }
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#FF8800"))
        }
        banner.addView(pb)
        TextView(this).apply {
            text = "${season.currentExp}/$tierExp EXP до следващо ниво"
            setTextColor(Color.GRAY); textSize = 11f
        }.also { banner.addView(it) }

        if (!season.isPremium) {
            Button(this).apply {
                text = "⭐ КУПИ PREMIUM BATTLE PASS — 1000 Дивинити"
                setTextColor(Color.WHITE); textSize = 12f
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#FF8800"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 8, 0, 0); layoutParams = lp
                setOnClickListener {
                    if (engine.character.divinity >= 1000) {
                        engine.character.divinity -= 1000
                        season.isPremium = true
                        engine.saveGame()
                        Toast.makeText(this@BattlePassActivity, "✅ Premium Battle Pass активиран!", Toast.LENGTH_LONG).show()
                        showTiersTab()
                    } else {
                        Toast.makeText(this@BattlePassActivity, "Нямаш достатъчно Дивинити!", Toast.LENGTH_SHORT).show()
                    }
                }
            }.also { banner.addView(it) }
        }
        llContent.addView(banner)

        // Tier list
        season.tiers.take(20).forEach { tier ->
            val isUnlocked = tier.tier <= season.currentTier
            val isCurrent = tier.tier == season.currentTier + 1
            val bgColor = when { isUnlocked -> "#0A1A0A"; isCurrent -> "#1A1A00"; else -> "#080808" }

            val tierRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.parseColor(bgColor))
                setPadding(10, 8, 10, 8)
                alpha = if (!isUnlocked && !isCurrent) 0.5f else 1.0f
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 2, 0, 2); layoutParams = lp
            }

            // Tier number
            TextView(this).apply {
                text = if (isUnlocked) "✅" else "${tier.tier}"
                setTextColor(if (isUnlocked) Color.parseColor("#00CC88") else Color.GRAY)
                textSize = 13f; setPadding(0, 0, 10, 0)
                layoutParams = LinearLayout.LayoutParams(40.dpToPx(), LinearLayout.LayoutParams.WRAP_CONTENT)
            }.also { tierRow.addView(it) }

            // Free reward
            val freeCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setBackgroundColor(Color.parseColor("#050505"))
                setPadding(8, 4, 8, 4)
            }
            TextView(this).apply { text = "🆓 БЕЗПЛАТНО"; setTextColor(Color.GRAY); textSize = 9f }.also { freeCol.addView(it) }
            TextView(this).apply {
                text = "${tier.freeReward.emoji} ${tier.freeReward.name}"
                setTextColor(Color.WHITE); textSize = 11f
            }.also { freeCol.addView(it) }
            if (tier.freeReward.amount > 0) {
                TextView(this).apply { text = "+${tier.freeReward.amount}"; setTextColor(Color.parseColor("#FFD700")); textSize = 10f }.also { freeCol.addView(it) }
            }
            tierRow.addView(freeCol)

            // Divider
            View(this).apply {
                setBackgroundColor(Color.parseColor("#333333"))
                layoutParams = LinearLayout.LayoutParams(2, LinearLayout.LayoutParams.MATCH_PARENT).apply { setMargins(4, 0, 4, 0) }
            }.also { tierRow.addView(it) }

            // Premium reward
            val premCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setBackgroundColor(if (season.isPremium) Color.parseColor("#1A0A00") else Color.parseColor("#050505"))
                setPadding(8, 4, 8, 4)
            }
            TextView(this).apply {
                text = "⭐ PREMIUM"
                setTextColor(if (season.isPremium) Color.parseColor("#FF8800") else Color.parseColor("#555555"))
                textSize = 9f
            }.also { premCol.addView(it) }
            TextView(this).apply {
                text = "${tier.premiumReward.emoji} ${tier.premiumReward.name}"
                setTextColor(if (season.isPremium) Color.WHITE else Color.GRAY)
                textSize = 11f
            }.also { premCol.addView(it) }
            if (tier.premiumReward.amount > 0) {
                TextView(this).apply {
                    text = "+${tier.premiumReward.amount}"
                    setTextColor(if (season.isPremium) Color.parseColor("#FFD700") else Color.GRAY); textSize = 10f
                }.also { premCol.addView(it) }
            }
            tierRow.addView(premCol)

            // Claim button
            if (isUnlocked) {
                Button(this).apply {
                    text = "🎁"; textSize = 12f; setTextColor(Color.WHITE)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#006600"))
                    val lp = LinearLayout.LayoutParams(52.dpToPx(), LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(4, 0, 0, 0); layoutParams = lp
                    setOnClickListener {
                        val msg = BattlePassManager.claimFreeReward(tier, engine.character)
                        if (season.isPremium) BattlePassManager.claimPremiumReward(tier, engine.character, true)
                        engine.saveGame()
                        Toast.makeText(this@BattlePassActivity, msg, Toast.LENGTH_SHORT).show()
                    }
                }.also { tierRow.addView(it) }
            }
            llContent.addView(tierRow)
        }

        // Show more button
        Button(this).apply {
            text = "▼ Виж нива 21-50"
            setTextColor(Color.WHITE); textSize = 12f
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C2C2C"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 8, 0, 0); layoutParams = lp
            setOnClickListener { showAllTiers() }
        }.also { llContent.addView(it) }
    }

    private fun showAllTiers() {
        AlertDialog.Builder(this)
            .setTitle("${season.emoji} Нива 21-50")
            .setMessage(buildString {
                season.tiers.drop(20).forEach { tier ->
                    val unlocked = if (tier.tier <= season.currentTier) "✅" else "🔒"
                    appendLine("$unlocked Ниво ${tier.tier}:")
                    appendLine("  🆓 ${tier.freeReward.emoji} ${tier.freeReward.name}")
                    appendLine("  ⭐ ${tier.premiumReward.emoji} ${tier.premiumReward.name}")
                }
            })
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showRewardsTab() {
        llContent.removeAllViews()
        tvHeader.text = "🎁 ЕКСКЛУЗИВНИ НАГРАДИ"

        addSectionTitle("🌟 ФИНАЛНИ НАГРАДИ (Ниво 50)")
        addRewardCard("🆓 Безплатно финално", season.finalRewardFree)
        addRewardCard("⭐ Premium финално", season.finalRewardPremium)

        addSectionTitle("👑 ЕКСКЛУЗИВНИ КОЗМЕТИКИ")
        listOf(
            Triple("⭐ Ниво 1", season.tiers[0].premiumReward.emoji, season.tiers[0].premiumReward.name),
            Triple("⭐ Ниво 10", season.tiers[9].premiumReward.emoji, season.tiers[9].premiumReward.name),
            Triple("⭐ Ниво 20", season.tiers[19].premiumReward.emoji, season.tiers[19].premiumReward.name),
            Triple("⭐ Ниво 30", season.tiers[29].premiumReward.emoji, season.tiers[29].premiumReward.name),
            Triple("⭐ Ниво 40", season.tiers[39].premiumReward.emoji, season.tiers[39].premiumReward.name),
            Triple("⭐ Ниво 50", season.tiers[49].premiumReward.emoji, season.tiers[49].premiumReward.name)
        ).forEach { (label, emoji, name) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 6, 8, 6); setBackgroundColor(Color.parseColor("#0A0A1A"))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 3, 0, 3); layoutParams = lp
            }
            TextView(this).apply { text = emoji; textSize = 22f; setPadding(0, 0, 10, 0) }.also { row.addView(it) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 13f }.also { info.addView(it) }
            TextView(this).apply { text = label; setTextColor(Color.parseColor("#FF8800")); textSize = 11f }.also { info.addView(it) }
            row.addView(info)
            llContent.addView(row)
        }

        addSectionTitle("🏅 СЕЗОННА ТИТЛА")
        addInfoText("👑 \"${season.exclusiveTitle}\"")
        addInfoText("Получи при достигане на Ниво 50 Premium!")

        addSectionTitle("👘 СЕЗОННА КОЖА")
        addInfoText("🎭 ${season.exclusiveSkin}")
        addInfoText("Ексклузивна за ${season.name}. Никога повече!")
    }

    private fun addRewardCard(label: String, reward: BattlePassReward) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0A0A1A"))
            setPadding(12, 10, 12, 10)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 4, 0, 4); layoutParams = lp
        }
        TextView(this).apply { text = reward.emoji; textSize = 28f; setPadding(0, 0, 12, 0) }.also { card.addView(it) }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        TextView(this).apply { text = "$label: ${reward.name}"; setTextColor(Color.parseColor("#FFD700")); textSize = 13f; isFakeBoldText = true }.also { info.addView(it) }
        if (reward.description.isNotBlank()) TextView(this).apply { text = reward.description; setTextColor(Color.GRAY); textSize = 11f }.also { info.addView(it) }
        card.addView(info)
        llContent.addView(card)
    }

    private fun showSeasonTab() {
        llContent.removeAllViews()
        tvHeader.text = "📅 СЕЗОН ИНФОРМАЦИЯ"
        addInfoBanner("${season.emoji} ${season.name}")
        addSectionTitle("📖 ОПИСАНИЕ")
        addInfoText(season.description)
        addSectionTitle("📊 СЕЗОН СТАТИСТИКИ")
        addInfoText("🌍 Тема: ${season.theme}")
        addInfoText("📚 Митология: ${season.mythology}")
        addInfoText("⏱️ Продължителност: ${season.durationDays} дни")
        addInfoText("📊 Нива: 50")
        addInfoText("🎁 Общо награди: ${season.tiers.size * 2 + 2}")
        addSectionTitle("🏆 ЕКСКЛУЗИВНО")
        addInfoText("👑 ${season.exclusiveTitle}")
        addInfoText("🎭 ${season.exclusiveSkin}")
        addSectionTitle("💰 PREMIUM СТОЙНОСТ")
        addInfoText("Цена: 1000 Дивинити")
        addInfoText("Стойност: 50+ ексклузивни награди")
        addInfoText("Включва: Козметики, Спътници, Злато, Дивинити")
        addInfoText("Ексклузивни ефекти: само тук!")
        addSectionTitle("📈 ТВОЙ ПРОГРЕС")
        addInfoText(BattlePassManager.getSeasonProgress(season))
    }

    private fun showEarnTab() {
        llContent.removeAllViews()
        tvHeader.text = "💡 КАК ДА СПЕЧЕЛИШ EXP"
        addInfoBanner("Всяко действие носи Battle Pass EXP!")
        addSectionTitle("⚡ ИЗТОЧНИЦИ НА EXP")
        BattlePassManager.getBattlePassSources().forEach { addInfoText(it) }
        addSectionTitle("💡 СЪВЕТИ")
        addInfoText("🎯 Дневните предизвикателства дават +200 EXP всеки ден!")
        addInfoText("👑 Boss Rush е най-бързият начин за голямо EXP!")
        addInfoText("📖 Завърши историята — +400 EXP на глава!")
        addInfoText("🏰 Гилдийните куестове дават +250 EXP!")
        addInfoText("⚔️ PvP победи носят бонус EXP!")
        addSectionTitle("🧮 ИЗЧИСЛЕНИЕ")
        addInfoText("За 50 нива са нужни ~150 000 EXP")
        addInfoText("С дневни предизвикателства: ~45 дни")
        addInfoText("С всички активности: ~25-30 дни")
        addInfoText("Сезонът е ${season.durationDays} дни — достатъчно!")
    }

    private fun addSectionTitle(title: String) {
        TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#FF8800"))
            textSize = 13f; isFakeBoldText = true; setPadding(4, 14, 4, 6)
        }.also { llContent.addView(it) }
    }

    private fun addInfoText(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(8, 3, 8, 3)
        }.also { llContent.addView(it) }
    }

    private fun addInfoBanner(text: String) {
        TextView(this).apply {
            this.text = text; setTextColor(Color.WHITE)
            textSize = 14f; isFakeBoldText = true; gravity = android.view.Gravity.CENTER
            setPadding(12, 10, 12, 10); setBackgroundColor(Color.parseColor("#1A0A00"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 8); layoutParams = lp
        }.also { llContent.addView(it) }
    }

    private fun Int.dpToPx() = (this * resources.displayMetrics.density).toInt()
}
