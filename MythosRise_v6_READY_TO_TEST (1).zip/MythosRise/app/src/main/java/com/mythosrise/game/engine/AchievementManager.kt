package com.mythosrise.game.engine

import com.mythosrise.game.models.Character
import com.mythosrise.game.models.DivinityTitle
import com.mythosrise.game.models.HeroClass
import com.mythosrise.game.models.World

// ─────────────────────────────────────────────
//  ACHIEVEMENT RARITY
// ─────────────────────────────────────────────

enum class AchievementRarity(val label: String, val color: String) {
    BRONZE("Бронзово", "#CD7F32"),
    SILVER("Сребърно", "#C0C0C0"),
    GOLD("Златно", "#FFD700"),
    PLATINUM("Платинено", "#E5E4E2"),
    DIAMOND("Диамантено", "#B9F2FF"),
    LEGENDARY("Легендарно", "#FF6600")
}

// ─────────────────────────────────────────────
//  ACHIEVEMENT
// ─────────────────────────────────────────────

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val rarity: AchievementRarity,
    val divinityReward: Int = 0,
    val goldReward: Int = 0,
    var unlocked: Boolean = false,
    var progress: Int = 0,
    val progressTarget: Int = 1,
    val category: String = "General"
)

// ─────────────────────────────────────────────
//  ACHIEVEMENT MANAGER
// ─────────────────────────────────────────────

object AchievementManager {

    val ALL_ACHIEVEMENTS = listOf(

        // ── FIRST STEPS ──
        Achievement("first_kill", "Първата Кръв", "Убий своя първи враг.", "⚔️",
            AchievementRarity.BRONZE, divinityReward = 5, goldReward = 50, category = "Битка"),
        Achievement("first_boss", "Убиецът на Босове", "Победи своя първи бос.", "👑",
            AchievementRarity.SILVER, divinityReward = 20, goldReward = 200, category = "Битка"),
        Achievement("first_god", "Богоубиец", "Победи своя първи бог.", "⚡",
            AchievementRarity.GOLD, divinityReward = 100, goldReward = 1000, category = "Битка"),
        Achievement("first_titan", "Убиец на Титани", "Победи своя първи Титан.", "🌋",
            AchievementRarity.PLATINUM, divinityReward = 300, goldReward = 5000, category = "Битка"),

        // ── KILL COUNTS ──
        Achievement("kills_10", "Малък Воин", "Убий 10 врагове.", "🗡️",
            AchievementRarity.BRONZE, divinityReward = 10, goldReward = 100, progressTarget = 10, category = "Битка"),
        Achievement("kills_50", "Ветеран", "Убий 50 врагове.", "⚔️",
            AchievementRarity.SILVER, divinityReward = 30, goldReward = 300, progressTarget = 50, category = "Битка"),
        Achievement("kills_100", "Войн", "Убий 100 врагове.", "🏹",
            AchievementRarity.GOLD, divinityReward = 100, goldReward = 1000, progressTarget = 100, category = "Битка"),
        Achievement("kills_500", "Жътвар на Смърт", "Убий 500 врагове.", "💀",
            AchievementRarity.PLATINUM, divinityReward = 500, goldReward = 5000, progressTarget = 500, category = "Битка"),
        Achievement("kills_1000", "Господар на Войната", "Убий 1000 врагове.", "🌋",
            AchievementRarity.DIAMOND, divinityReward = 1000, goldReward = 10000, progressTarget = 1000, category = "Битка"),
        Achievement("kills_gods_5", "Пет Убити Богове", "Победи 5 богове.", "⚡",
            AchievementRarity.GOLD, divinityReward = 200, goldReward = 2000, progressTarget = 5, category = "Битка"),
        Achievement("kills_titans_3", "Три Убити Титана", "Победи 3 Титана.", "🌋",
            AchievementRarity.PLATINUM, divinityReward = 500, goldReward = 5000, progressTarget = 3, category = "Битка"),

        // ── DIVINITY ──
        Achievement("divinity_100", "Шампион", "Достигни 100 Дивинити.", "✨",
            AchievementRarity.BRONZE, divinityReward = 10, goldReward = 100, category = "Дивинити"),
        Achievement("divinity_500", "Полубог", "Достигни 500 Дивинити.", "🌟",
            AchievementRarity.SILVER, divinityReward = 50, goldReward = 500, category = "Дивинити"),
        Achievement("divinity_1500", "Титан", "Достигни 1500 Дивинити.", "🌋",
            AchievementRarity.GOLD, divinityReward = 150, goldReward = 1500, category = "Дивинити"),
        Achievement("divinity_10000", "Велик Бог", "Достигни 10 000 Дивинити.", "👑",
            AchievementRarity.PLATINUM, divinityReward = 1000, goldReward = 15000, category = "Дивинити"),
        Achievement("divinity_50000", "ВСЕБОГ", "Достигни 50 000 Дивинити.", "🌌",
            AchievementRarity.LEGENDARY, divinityReward = 5000, goldReward = 99999, category = "Дивинити"),

        // ── LEVELS ──
        Achievement("level_10", "Ниво 10", "Достигни ниво 10.", "⭐",
            AchievementRarity.BRONZE, divinityReward = 15, goldReward = 200, category = "Прогресия"),
        Achievement("level_25", "Ниво 25", "Достигни ниво 25.", "🌟",
            AchievementRarity.SILVER, divinityReward = 50, goldReward = 800, category = "Прогресия"),
        Achievement("level_40", "Ниво 40", "Достигни ниво 40.", "💫",
            AchievementRarity.GOLD, divinityReward = 150, goldReward = 3000, category = "Прогресия"),
        Achievement("level_max", "Максимално Ниво", "Достигни ниво 50.", "👑",
            AchievementRarity.PLATINUM, divinityReward = 500, goldReward = 10000, category = "Прогресия"),

        // ── WORLDS ──
        Achievement("world_greek", "Гръцки Конквистадор", "Посети Гръцкия Олимп.", "🏛️",
            AchievementRarity.BRONZE, divinityReward = 10, goldReward = 100, category = "Изследване"),
        Achievement("world_egypt", "Египетски Изследовател", "Посети Египетския пантеон.", "🏺",
            AchievementRarity.BRONZE, divinityReward = 10, goldReward = 100, category = "Изследване"),
        Achievement("world_dragon", "Дракон Ловец", "Влез в Царството на дракони.", "🐉",
            AchievementRarity.SILVER, divinityReward = 30, goldReward = 500, category = "Изследване"),
        Achievement("world_japan", "Самурай Дух", "Посети Японския пантеон.", "⛩️",
            AchievementRarity.SILVER, divinityReward = 30, goldReward = 500, category = "Изследване"),
        Achievement("world_china", "Небесен Пилигрим", "Посети Китайския пантеон.", "🐲",
            AchievementRarity.SILVER, divinityReward = 30, goldReward = 500, category = "Изследване"),
        Achievement("world_norse", "Викинг Завоевател", "Посети Скандинавски Асгард.", "⚡",
            AchievementRarity.GOLD, divinityReward = 80, goldReward = 1500, category = "Изследване"),
        Achievement("world_titan", "Влез в Царството на Титаните", "Открий Царството на Титаните.", "🌋",
            AchievementRarity.PLATINUM, divinityReward = 200, goldReward = 5000, category = "Изследване"),
        Achievement("all_worlds", "Пътешественик на Световете", "Посети всички светове.", "🌍",
            AchievementRarity.LEGENDARY, divinityReward = 1000, goldReward = 20000, category = "Изследване"),

        // ── ITEMS ──
        Achievement("first_mythic", "Митичен Предмет", "Намери своя първи Митичен предмет.", "🔴",
            AchievementRarity.GOLD, divinityReward = 100, goldReward = 2000, category = "Предмети"),
        Achievement("first_divine", "Божествен Предмет", "Намери своя първи Божествен предмет.", "✨",
            AchievementRarity.LEGENDARY, divinityReward = 500, goldReward = 10000, category = "Предмети"),
        Achievement("full_set", "Пълна Екипировка", "Екипирай всички 6 слота.", "🛡️",
            AchievementRarity.SILVER, divinityReward = 50, goldReward = 500, category = "Предмети"),
        Achievement("inventory_full", "Колекционер", "Имай 20+ предмета в инвентара.", "🎒",
            AchievementRarity.BRONZE, progressTarget = 20, goldReward = 200, category = "Предмети"),

        // ── SPECIFIC BOSSES ──
        Achievement("kill_zeus", "Цареубиец", "Победи Зевс — Царя на боговете.", "⚡",
            AchievementRarity.PLATINUM, divinityReward = 500, goldReward = 5000, category = "Легенди"),
        Achievement("kill_shiva", "Разрушителят е Разрушен", "Победи Шива.", "🔱",
            AchievementRarity.PLATINUM, divinityReward = 600, goldReward = 6000, category = "Легенди"),
        Achievement("kill_odin", "Победи Всебащата", "Победи Один.", "🦅",
            AchievementRarity.DIAMOND, divinityReward = 800, goldReward = 8000, category = "Легенди"),
        Achievement("kill_wukong", "Победи Маймуната", "Победи Сун Ву Конг.", "🐒",
            AchievementRarity.DIAMOND, divinityReward = 900, goldReward = 9000, category = "Легенди"),
        Achievement("kill_tiamat", "Майката е Убита", "Победи Тиамат — Майката на дракони.", "🌊",
            AchievementRarity.DIAMOND, divinityReward = 700, goldReward = 7000, category = "Легенди"),
        Achievement("kill_chaos", "ВСЕБОГ", "Победи Хаос и стани Всебог!", "🌌",
            AchievementRarity.LEGENDARY, divinityReward = 10000, goldReward = 99999, category = "Легенди"),

        // ── MASS BATTLE ──
        Achievement("mass_wave_5", "Арена Ветеран", "Оцелей до вълна 5 в Арената.", "🏟️",
            AchievementRarity.SILVER, divinityReward = 80, goldReward = 800, category = "Арена"),
        Achievement("mass_wave_10", "Арена Шампион", "Оцелей до вълна 10 в Арената.", "🏆",
            AchievementRarity.GOLD, divinityReward = 300, goldReward = 3000, category = "Арена"),
        Achievement("mass_kill_100", "Масов Убиец", "Убий 100 врага в Арената.", "💥",
            AchievementRarity.GOLD, divinityReward = 200, goldReward = 2000, progressTarget = 100, category = "Арена"),

        // ── SPECIAL / SECRET ──
        Achievement("no_damage_boss", "Непоколебим", "Победи бос без да получиш щета.", "🛡️",
            AchievementRarity.DIAMOND, divinityReward = 400, goldReward = 5000, category = "Специални"),
        Achievement("absorb_100", "Поглъщач", "Погълни силите на 100 врагове.", "🌀",
            AchievementRarity.GOLD, divinityReward = 200, goldReward = 2000, progressTarget = 100, category = "Специални"),
        Achievement("gold_10000", "Богаташ", "Спечели 10 000 злато общо.", "💰",
            AchievementRarity.SILVER, divinityReward = 50, goldReward = 0, progressTarget = 10000, category = "Специални"),
        Achievement("use_ability_50", "Мистик", "Използвай умения 50 пъти.", "⚡",
            AchievementRarity.BRONZE, divinityReward = 20, goldReward = 200, progressTarget = 50, category = "Специални")
    )

    // ─────────────────────────────────────────────
    //  CHECK ACHIEVEMENTS
    // ─────────────────────────────────────────────

    fun checkAchievements(character: Character, event: AchievementEvent): List<Achievement> {
        val newlyUnlocked = mutableListOf<Achievement>()

        ALL_ACHIEVEMENTS.filter { !it.unlocked }.forEach { ach ->
            val shouldUnlock = when (ach.id) {
                "first_kill" -> character.enemiesDefeated >= 1
                "first_boss" -> event == AchievementEvent.BOSS_KILLED
                "first_god" -> character.godsDefeated >= 1
                "first_titan" -> character.titansDefeated >= 1
                "kills_10" -> { ach.progress = character.enemiesDefeated; character.enemiesDefeated >= 10 }
                "kills_50" -> { ach.progress = character.enemiesDefeated; character.enemiesDefeated >= 50 }
                "kills_100" -> { ach.progress = character.enemiesDefeated; character.enemiesDefeated >= 100 }
                "kills_500" -> { ach.progress = character.enemiesDefeated; character.enemiesDefeated >= 500 }
                "kills_1000" -> { ach.progress = character.enemiesDefeated; character.enemiesDefeated >= 1000 }
                "kills_gods_5" -> { ach.progress = character.godsDefeated; character.godsDefeated >= 5 }
                "kills_titans_3" -> { ach.progress = character.titansDefeated; character.titansDefeated >= 3 }
                "divinity_100" -> character.divinity >= 100
                "divinity_500" -> character.divinity >= 500
                "divinity_1500" -> character.divinity >= 1500
                "divinity_10000" -> character.divinity >= 10000
                "divinity_50000" -> character.divinity >= 50000
                "level_10" -> character.level >= 10
                "level_25" -> character.level >= 25
                "level_40" -> character.level >= 40
                "level_max" -> character.level >= 50
                "world_greek" -> character.currentWorld.ordinal >= 1
                "world_egypt" -> character.absorbedPowers.any { it.contains("Egyptian") || it.contains("Ра") || it.contains("Хор") }
                "world_dragon" -> character.absorbedPowers.any { it.contains("Dragon") || it.contains("Дракон") || it.contains("Хидра") }
                "world_japan" -> character.absorbedPowers.any { it.contains("Japanese") || it.contains("Oni") || it.contains("Аматерасу") }
                "world_china" -> character.absorbedPowers.any { it.contains("Chinese") || it.contains("Ву Конг") }
                "world_norse" -> character.currentWorld.ordinal >= 8
                "world_titan" -> character.currentWorld.ordinal >= 9
                "all_worlds" -> character.level >= 45
                "first_mythic" -> character.inventory.any { it.rarity.ordinal >= 5 }
                "first_divine" -> character.inventory.any { it.rarity.ordinal >= 6 }
                "full_set" -> character.equippedWeapon != null && character.equippedArmor != null &&
                        character.equippedHelmet != null && character.equippedBoots != null &&
                        character.equippedRing != null && character.equippedAmulet != null
                "inventory_full" -> { ach.progress = character.inventory.size; character.inventory.size >= 20 }
                "kill_zeus" -> character.absorbedPowers.contains("Зевс - Цар на Боговете")
                "kill_shiva" -> character.absorbedPowers.contains("Шива - Разрушителят")
                "kill_odin" -> character.absorbedPowers.contains("Один - Всебащата")
                "kill_wukong" -> character.absorbedPowers.contains("Сун Ву Конг - Маймунският Крал")
                "kill_tiamat" -> character.absorbedPowers.contains("Тиамат - Майката на Дракони")
                "kill_chaos" -> character.absorbedPowers.contains("Хаос - Първичността")
                "absorb_100" -> { ach.progress = character.absorbedPowers.size; character.absorbedPowers.size >= 100 }
                "gold_10000" -> { ach.progress = character.gold; character.gold >= 10000 }
                else -> false
            }

            if (shouldUnlock) {
                ach.unlocked = true
                ach.progress = ach.progressTarget
                // Apply rewards
                character.divinity += ach.divinityReward
                character.gold += ach.goldReward
                character.updateDivinityTitle()
                newlyUnlocked.add(ach)
            }
        }
        return newlyUnlocked
    }

    fun getUnlockedCount(): Int = ALL_ACHIEVEMENTS.count { it.unlocked }
    fun getTotalCount(): Int = ALL_ACHIEVEMENTS.size
    fun getByCategory(category: String) = ALL_ACHIEVEMENTS.filter { it.category == category }
    fun getUnlocked() = ALL_ACHIEVEMENTS.filter { it.unlocked }
    fun getLocked() = ALL_ACHIEVEMENTS.filter { !it.unlocked }
}

enum class AchievementEvent {
    ENEMY_KILLED, BOSS_KILLED, GOD_KILLED, TITAN_KILLED, LEVEL_UP,
    ITEM_FOUND, WORLD_ENTERED, ABILITY_USED, GOLD_EARNED, MASS_WAVE_COMPLETE
}

// ─────────────────────────────────────────────
//  ACHIEVEMENT MILESTONE MESSAGES
// ─────────────────────────────────────────────

object AchievementMessages {
    val UNLOCK_MESSAGES = mapOf(
        "first_kill" to "⚔️ Първото убийство. Хиляди следват.",
        "first_boss" to "👑 Бос паднал! Силата им е твоя.",
        "first_god" to "⚡ БОГ УБИТ! Олимп трепери!",
        "kill_1000" to "💀 1000 врагове. Ти си смъртта им.",
        "divinity_100" to "✨ Дивинитито тече. Ставаш нещо повече.",
        "divinity_50000" to "🌌 ВСЕБОГ! Абсолютното е достигнато!",
        "level_50" to "⭐ Максимум ниво! Престижът чака.",
        "explore_all" to "🌍 Всичките 12 свята посетени. Пътешественик на митологиите!",
        "first_mythic" to "💎 Митичен предмет! Легендите са реални.",
        "kill_zeus" to "⚡ ЗЕВС МЪРТЪВ! Ти управляваш небесата!",
        "boss_rush_complete" to "🏆 Boss Rush завършен! Всички паднаха пред теб!",
        "prestige_1" to "⭐ Първи Престиж! Прераждането е по-силно от смъртта.",
        "no_damage_boss" to "🛡️ Перфектна победа! Недосегаем!",
        "quiz_perfect" to "📚 Перфектен Куиз! Митологията е твоя!"
    )
    
    fun getMessage(achievementId: String): String {
        return UNLOCK_MESSAGES[achievementId] ?: "🏆 Постижение отключено!"
    }
    
    fun getUnlockedCount(): Int {
        return ALL_ACHIEVEMENTS.count { it.isUnlocked }
    }
    
    fun getTotalCount(): Int = ALL_ACHIEVEMENTS.size
    
    fun getUnlockRate(): Float {
        val total = getTotalCount()
        return if (total == 0) 0f else getUnlockedCount().toFloat() / total
    }
}
