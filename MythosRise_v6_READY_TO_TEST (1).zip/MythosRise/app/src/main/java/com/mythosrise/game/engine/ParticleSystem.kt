package com.mythosrise.game.engine

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

// ─────────────────────────────────────────────
//  PARTICLE TYPES
// ─────────────────────────────────────────────

enum class ParticleType {
    FIRE, ICE, LIGHTNING, HOLY, SHADOW, BLOOD, GOLD, DIVINE,
    SMOKE, EXPLOSION, HEAL, POISON, DRAGON_FIRE, CHAOS
}

// ─────────────────────────────────────────────
//  SINGLE PARTICLE
// ─────────────────────────────────────────────

data class Particle(
    var x: Float, var y: Float,
    var vx: Float, var vy: Float,
    var life: Float,          // 0..1
    var maxLife: Float,
    var size: Float,
    var color: Int,
    var type: ParticleType,
    var rotation: Float = 0f,
    var rotSpeed: Float = 0f,
    var gravity: Float = 0f,
    var alpha: Int = 255,
    var glow: Boolean = false
)

// ─────────────────────────────────────────────
//  PARTICLE SYSTEM
// ─────────────────────────────────────────────

class ParticleSystem {

    private val particles = mutableListOf<Particle>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }

    // ── Emit presets ──

    fun emitFire(cx: Float, cy: Float, count: Int = 30) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 8f + 2f
            particles += Particle(
                x = cx + Random.nextFloat() * 30 - 15,
                y = cy + Random.nextFloat() * 20 - 10,
                vx = cos(angle) * speed * 0.4f,
                vy = -(Random.nextFloat() * speed + 3f),
                life = 1f, maxLife = 0.6f + Random.nextFloat() * 0.8f,
                size = Random.nextFloat() * 14f + 4f,
                color = lerpColor(Color.YELLOW, Color.RED, Random.nextFloat()),
                type = ParticleType.FIRE, gravity = 0.1f, glow = true
            )
        }
    }

    fun emitIce(cx: Float, cy: Float, count: Int = 25) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 6f + 1f
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.5f + Random.nextFloat() * 0.6f,
                size = Random.nextFloat() * 10f + 3f,
                color = lerpColor(Color.WHITE, Color.CYAN, Random.nextFloat()),
                type = ParticleType.ICE, rotSpeed = Random.nextFloat() * 5f - 2.5f, glow = true
            )
        }
    }

    fun emitLightning(cx: Float, cy: Float, count: Int = 20) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 12f + 4f
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.3f + Random.nextFloat() * 0.4f,
                size = Random.nextFloat() * 6f + 2f,
                color = lerpColor(Color.WHITE, Color.YELLOW, Random.nextFloat()),
                type = ParticleType.LIGHTNING, glow = true
            )
        }
    }

    fun emitHoly(cx: Float, cy: Float, count: Int = 35) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val r = Random.nextFloat() * 80f
            particles += Particle(
                x = cx + cos(angle) * r, y = cy + sin(angle) * r,
                vx = cos(angle) * 1.5f, vy = -(Random.nextFloat() * 4f + 1f),
                life = 1f, maxLife = 0.8f + Random.nextFloat(),
                size = Random.nextFloat() * 8f + 2f,
                color = lerpColor(Color.WHITE, Color.YELLOW, Random.nextFloat()),
                type = ParticleType.HOLY, glow = true
            )
        }
    }

    fun emitShadow(cx: Float, cy: Float, count: Int = 30) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 5f + 1f
            particles += Particle(
                x = cx + Random.nextFloat() * 40 - 20,
                y = cy + Random.nextFloat() * 40 - 20,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.4f + Random.nextFloat() * 0.8f,
                size = Random.nextFloat() * 16f + 6f,
                color = lerpColor(Color.BLACK, Color.parseColor("#6600CC"), Random.nextFloat()),
                type = ParticleType.SHADOW, glow = true
            )
        }
    }

    fun emitBlood(cx: Float, cy: Float, count: Int = 20) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 9f + 2f
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed - 3f,
                life = 1f, maxLife = 0.5f + Random.nextFloat() * 0.5f,
                size = Random.nextFloat() * 8f + 2f,
                color = lerpColor(Color.RED, Color.parseColor("#880000"), Random.nextFloat()),
                type = ParticleType.BLOOD, gravity = 0.4f
            )
        }
    }

    fun emitHeal(cx: Float, cy: Float, count: Int = 25) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val r = Random.nextFloat() * 50f
            particles += Particle(
                x = cx + cos(angle) * r, y = cy + sin(angle) * r,
                vx = 0f, vy = -(Random.nextFloat() * 3f + 1f),
                life = 1f, maxLife = 0.7f + Random.nextFloat() * 0.8f,
                size = Random.nextFloat() * 10f + 4f,
                color = lerpColor(Color.GREEN, Color.parseColor("#00FF88"), Random.nextFloat()),
                type = ParticleType.HEAL, glow = true
            )
        }
    }

    fun emitGold(cx: Float, cy: Float, count: Int = 20) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 6f + 2f
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed - 4f,
                life = 1f, maxLife = 0.6f + Random.nextFloat() * 0.8f,
                size = Random.nextFloat() * 10f + 4f,
                color = lerpColor(Color.YELLOW, Color.parseColor("#FFD700"), Random.nextFloat()),
                type = ParticleType.GOLD, rotSpeed = Random.nextFloat() * 8f - 4f, gravity = 0.3f, glow = true
            )
        }
    }

    fun emitDivine(cx: Float, cy: Float, count: Int = 50) {
        repeat(count) {
            val angle = (it.toFloat() / count) * PI.toFloat() * 2
            val r = 20f + Random.nextFloat() * 100f
            particles += Particle(
                x = cx + cos(angle) * r, y = cy + sin(angle) * r,
                vx = cos(angle + PI.toFloat() / 2) * 2f,
                vy = sin(angle + PI.toFloat() / 2) * 2f - 1f,
                life = 1f, maxLife = 1f + Random.nextFloat(),
                size = Random.nextFloat() * 12f + 4f,
                color = lerpColor(Color.parseColor("#FFD700"), Color.WHITE, Random.nextFloat()),
                type = ParticleType.DIVINE, glow = true
            )
        }
    }

    fun emitExplosion(cx: Float, cy: Float, count: Int = 60) {
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 15f + 5f
            val colors = listOf(Color.YELLOW, Color.RED, Color.parseColor("#FF6600"), Color.WHITE)
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.4f + Random.nextFloat() * 0.6f,
                size = Random.nextFloat() * 18f + 6f,
                color = colors.random(),
                type = ParticleType.EXPLOSION, gravity = 0.3f, glow = true
            )
        }
    }

    fun emitDragonFire(cx: Float, cy: Float, count: Int = 45) {
        repeat(count) {
            val angle = -PI.toFloat() / 2 + (Random.nextFloat() - 0.5f) * 1.2f
            val speed = Random.nextFloat() * 14f + 6f
            particles += Particle(
                x = cx, y = cy,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.4f + Random.nextFloat() * 0.5f,
                size = Random.nextFloat() * 20f + 8f,
                color = lerpColor(Color.parseColor("#FF4400"), Color.parseColor("#FFAA00"), Random.nextFloat()),
                type = ParticleType.DRAGON_FIRE, gravity = -0.05f, glow = true
            )
        }
    }

    fun emitChaos(cx: Float, cy: Float, count: Int = 60) {
        val chaosColors = listOf(Color.MAGENTA, Color.CYAN, Color.parseColor("#FF00FF"),
            Color.parseColor("#00FFFF"), Color.BLACK, Color.WHITE)
        repeat(count) {
            val angle = Random.nextFloat() * PI.toFloat() * 2
            val speed = Random.nextFloat() * 18f + 5f
            particles += Particle(
                x = cx + (Random.nextFloat() - 0.5f) * 100f,
                y = cy + (Random.nextFloat() - 0.5f) * 100f,
                vx = cos(angle) * speed, vy = sin(angle) * speed,
                life = 1f, maxLife = 0.5f + Random.nextFloat() * 1f,
                size = Random.nextFloat() * 22f + 6f,
                color = chaosColors.random(),
                type = ParticleType.CHAOS, rotSpeed = Random.nextFloat() * 10f - 5f, glow = true
            )
        }
    }

    // ── Emit based on ability type ──

    fun emitForAbility(name: String, cx: Float, cy: Float) {
        when {
            name.contains("Огн") || name.contains("Дракон Огън") || name.contains("Dragon") -> emitDragonFire(cx, cy)
            name.contains("Лед") || name.contains("Студ") -> emitIce(cx, cy)
            name.contains("Мълни") || name.contains("Гръм") || name.contains("Thunder") -> emitLightning(cx, cy)
            name.contains("Свят") || name.contains("Хор") || name.contains("Ра") -> emitHoly(cx, cy)
            name.contains("Сянка") || name.contains("Тъмни") || name.contains("Хадес") -> emitShadow(cx, cy)
            name.contains("Лечебна") || name.contains("Heal") || name.contains("Прераждане") -> emitHeal(cx, cy)
            name.contains("Хаос") || name.contains("АПОКАЛИПСИС") || name.contains("Отмяна") -> emitChaos(cx, cy)
            name.contains("Взрив") || name.contains("Метеор") || name.contains("Взривяване") -> emitExplosion(cx, cy)
            name.contains("Злато") || name.contains("Злат") -> emitGold(cx, cy)
            name.contains("Бог") || name.contains("Всебог") || name.contains("Дивин") -> emitDivine(cx, cy)
            else -> emitBlood(cx, cy)
        }
    }

    // ── Update ──

    fun update(dt: Float) {
        val iter = particles.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.x += p.vx * dt * 60f
            p.y += p.vy * dt * 60f
            p.vy += p.gravity * dt * 60f
            p.vx *= 0.97f
            p.vy *= 0.97f
            p.life -= dt / p.maxLife
            p.rotation += p.rotSpeed * dt * 60f
            p.alpha = (p.life * 255).coerceIn(0f, 255f).toInt()
            if (p.life <= 0f) iter.remove()
        }
    }

    // ── Draw ──

    fun draw(canvas: Canvas) {
        particles.forEach { p ->
            val a = p.alpha
            if (a <= 0) return@forEach

            if (p.glow) {
                glowPaint.color = p.color
                glowPaint.alpha = (a * 0.4f).toInt()
                canvas.save()
                canvas.translate(p.x, p.y)
                canvas.rotate(p.rotation)
                canvas.drawCircle(0f, 0f, p.size * 2f, glowPaint)
                canvas.restore()
            }

            paint.color = p.color
            paint.alpha = a
            paint.style = Paint.Style.FILL

            canvas.save()
            canvas.translate(p.x, p.y)
            canvas.rotate(p.rotation)

            when (p.type) {
                ParticleType.FIRE, ParticleType.DRAGON_FIRE -> {
                    // Teardrop shape for fire
                    val path = Path().apply {
                        moveTo(0f, -p.size)
                        quadTo(p.size * 0.8f, 0f, 0f, p.size * 0.6f)
                        quadTo(-p.size * 0.8f, 0f, 0f, -p.size)
                    }
                    canvas.drawPath(path, paint)
                }
                ParticleType.ICE, ParticleType.LIGHTNING -> {
                    // Star/diamond shape
                    val path = Path().apply {
                        moveTo(0f, -p.size)
                        lineTo(p.size * 0.3f, -p.size * 0.3f)
                        lineTo(p.size, 0f)
                        lineTo(p.size * 0.3f, p.size * 0.3f)
                        lineTo(0f, p.size)
                        lineTo(-p.size * 0.3f, p.size * 0.3f)
                        lineTo(-p.size, 0f)
                        lineTo(-p.size * 0.3f, -p.size * 0.3f)
                        close()
                    }
                    canvas.drawPath(path, paint)
                }
                ParticleType.GOLD -> {
                    // Coin shape
                    canvas.drawOval(-p.size, -p.size * 0.6f, p.size, p.size * 0.6f, paint)
                }
                ParticleType.CHAOS -> {
                    // Irregular polygon
                    val path = Path()
                    val sides = 5 + Random.nextInt(3)
                    for (i in 0 until sides) {
                        val a = (i.toFloat() / sides) * PI.toFloat() * 2
                        val r = p.size * (0.7f + Random.nextFloat() * 0.3f)
                        if (i == 0) path.moveTo(cos(a) * r, sin(a) * r)
                        else path.lineTo(cos(a) * r, sin(a) * r)
                    }
                    path.close()
                    canvas.drawPath(path, paint)
                }
                else -> canvas.drawCircle(0f, 0f, p.size, paint)
            }
            canvas.restore()
        }
    }

    fun clear() = particles.clear()
    fun count() = particles.size

    private fun lerpColor(c1: Int, c2: Int, t: Float): Int {
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * t).toInt()
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * t).toInt()
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * t).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    }
}
