package com.mythosrise.game.engine

import com.mythosrise.game.models.Character

// ─────────────────────────────────────────────
//  PET EVOLUTION STAGE
// ─────────────────────────────────────────────

enum class PetStage(val displayName: String, val emoji: String, val level: Int) {
    EGG("Яйце", "🥚", 0),
    BABY("Бебе", "🐣", 1),
    YOUNG("Младо", "🐥", 10),
    ADULT("Зряло", "⭐", 25),
    LEGENDARY("Легендарно", "🌟", 50),
    MYTHIC("Митично", "💎", 100)
}

// ─────────────────────────────────────────────
//  PET
// ─────────────────────────────────────────────

data class Pet(
    val id: String,
    val name: String,
    val emoji: String,
    val mythology: String,
    val description: String,
    val lore: String,
    var stage: PetStage = PetStage.EGG,
    var experience: Int = 0,
    var level: Int = 1,
    var isActive: Boolean = false,
    var isOwned: Boolean = false,
    val baseCost: Int,
    val costType: String = "gold",     // gold, divinity, special
    val attackBonus: Int,
    val defenseBonus: Int,
    val healthBonus: Int,
    val divinityBonus: Float,
    val goldBonus: Float,
    val specialAbility: String,
    val evolutionBonus: String,
    val rarity: String = "Common"
)

// ─────────────────────────────────────────────
//  PET SYSTEM
// ─────────────────────────────────────────────

object PetSystem {

    val ALL_PETS = listOf(
        Pet(
            id = "pet_baby_dragon",
            name = "Дракончето Игни",
            emoji = "🐲",
            mythology = "Universal",
            description = "Малко драконче, намерено в изоставено яйце. Мрънка огън при гъделичкане.",
            lore = "Всеки велик дракон е бил малко драконче. Игни ще е велик. Може би.",
            baseCost = 2000,
            attackBonus = 50, defenseBonus = 20, healthBonus = 100,
            divinityBonus = 0.05f, goldBonus = 0.05f,
            specialAbility = "Огнено Дихание: +50 огнен урон на 3-та атака",
            evolutionBonus = "При Митично: Дракон Игни → +500 ATK + Огнен Шлейф",
            rarity = "Uncommon"
        ),
        Pet(
            id = "pet_fennec_anubis",
            name = "Анубис Фенек",
            emoji = "🦊",
            mythology = "Egyptian",
            description = "Малко лисиче с черни уши — мини версия на Анубис. Преценява душите на мухите.",
            lore = "Анубис понякога изпраща малки Фенеки да наблюдават смъртните. Ти спечели твоя.",
            baseCost = 3000,
            attackBonus = 20, defenseBonus = 60, healthBonus = 200,
            divinityBonus = 0.08f, goldBonus = 0.03f,
            specialAbility = "Претегляне: Врагове с нисък морал получават -20% ATK",
            evolutionBonus = "При Митично: Анубис Страж → Имунитет на смъртния удар 1x на битка",
            rarity = "Rare"
        ),
        Pet(
            id = "pet_mini_thor",
            name = "Мини Тор",
            emoji = "⚡",
            mythology = "Norse",
            description = "Малко чуче, което по невероятен начин носи мини Мьолнир. Ръмжи на облаците.",
            lore = "Тор се засмя толкова силно, когато видя миниатюрния Мьолнир, че гърмя 3 дни.",
            baseCost = 4000,
            attackBonus = 100, defenseBonus = 30, healthBonus = 150,
            divinityBonus = 0.06f, goldBonus = 0.04f,
            specialAbility = "Мини Мьолнир: +100 мълния урон 1x на ход",
            evolutionBonus = "При Митично: Тор Куче → ATK +300, всяка атака е мълния",
            rarity = "Rare"
        ),
        Pet(
            id = "pet_jade_rabbit",
            name = "Нефритеният Заек",
            emoji = "🐇",
            mythology = "Chinese",
            description = "Заекът, живеещ на луната. Смила магически еликсири в нефритено хаванче.",
            lore = "Нефритеният Заек е помощник на Чан Ъ — богинята на луната. Твоят е изгубен. Или изпратен.",
            baseCost = 5000,
            attackBonus = 10, defenseBonus = 40, healthBonus = 300,
            divinityBonus = 0.10f, goldBonus = 0.08f,
            specialAbility = "Лунен Еликсир: Възстановява 5% HP всеки ход",
            evolutionBonus = "При Митично: Лунен Заек → +500 HP, еликсирите лекуват 10%/ход",
            rarity = "Epic"
        ),
        Pet(
            id = "pet_owl_athena",
            name = "Совата на Атина",
            emoji = "🦉",
            mythology = "Greek",
            description = "Мъдра сова с очи като звезди. Вижда слабостите на врага.",
            lore = "Атина изпрати своята любима сова Никтоя. Причините са неясни. Резултатът — полезен.",
            baseCost = 4500,
            attackBonus = 30, defenseBonus = 50, healthBonus = 100,
            divinityBonus = 0.07f, goldBonus = 0.10f,
            specialAbility = "Мъдрост: +10% злато от всички победи",
            evolutionBonus = "При Митично: Атинова Сова → Виждаш слабостта на всеки враг",
            rarity = "Epic"
        ),
        Pet(
            id = "pet_cerberus_pup",
            name = "Кученце Цербер",
            emoji = "🐕",
            mythology = "Greek",
            description = "ТРИ малки главички, едно тяло. Облизват всичките три посоки едновременно.",
            lore = "Хадес случайно пусна едно от Цербер кученцата. Теос го намери. Сега е твое.",
            baseCost = 6000,
            attackBonus = 80, defenseBonus = 80, healthBonus = 250,
            divinityBonus = 0.09f, goldBonus = 0.06f,
            specialAbility = "Тройна Хапка: Атакува 3 пъти вместо 1 на 5-та ход",
            evolutionBonus = "При Митично: Цербер → Пазач на Врата: Блокира 1 атака напълно",
            rarity = "Legendary"
        ),
        Pet(
            id = "pet_phoenix_chick",
            name = "Феникс Пиле",
            emoji = "🐦",
            mythology = "Universal",
            description = "Малко пиле от пепел. Буквално — намерено в пепелта след голям пожар.",
            lore = "Феникс се ражда от пепелта. Това малкото го направи буквално. Носи огъня в перата си.",
            baseCost = 8000, costType = "divinity",
            attackBonus = 60, defenseBonus = 60, healthBonus = 400,
            divinityBonus = 0.12f, goldBonus = 0.07f,
            specialAbility = "Прераждане: 1x на битка се реанимираш при 0 HP с 30% живот",
            evolutionBonus = "При Митично: Феникс → Прераждаш се 3x на битка",
            rarity = "Legendary"
        ),
        Pet(
            id = "pet_chaos_fragment",
            name = "Хаос Осколок",
            emoji = "🌀",
            mythology = "Chaos",
            description = "Не е животно. Не е предмет. Просто... Хаос. Следва те. Обича те? Може би.",
            lore = "След победата над Хаоса, малко парче от него остана. Изглежда не иска да тръгне.",
            baseCost = 50000, costType = "divinity",
            attackBonus = 500, defenseBonus = 300, healthBonus = 1000,
            divinityBonus = 0.25f, goldBonus = 0.15f,
            specialAbility = "Хаотична Аура: Случаен бонус всеки ход (x2 ATK / x2 DEF / +1000 HP)",
            evolutionBonus = "При Митично: ХАОС СТРАЖЪТ → Всичко x1.5",
            rarity = "Divine"
        )
    )

    // ─────────────────────────────────────────────
    //  LOGIC
    // ─────────────────────────────────────────────

    fun getActivePet(): Pet? = ALL_PETS.firstOrNull { it.isActive && it.isOwned }

    fun getOwnedPets(): List<Pet> = ALL_PETS.filter { it.isOwned }

    fun purchasePet(petId: String, character: Character): Boolean {
        val pet = ALL_PETS.find { it.id == petId } ?: return false
        if (pet.isOwned) return false
        return when (pet.costType) {
            "gold" -> if (character.gold >= pet.baseCost) {
                character.gold -= pet.baseCost; pet.isOwned = true; true
            } else false
            "divinity" -> if (character.divinity >= pet.baseCost) {
                character.divinity -= pet.baseCost; pet.isOwned = true; true
            } else false
            else -> false
        }
    }

    fun activatePet(petId: String) {
        ALL_PETS.forEach { it.isActive = false }
        ALL_PETS.find { it.id == petId }?.isActive = true
    }

    fun addPetExperience(pet: Pet, exp: Int) {
        pet.experience += exp
        val newLevel = pet.experience / 1000
        if (newLevel > pet.level) {
            pet.level = newLevel
            pet.stage = when {
                newLevel >= 100 -> PetStage.MYTHIC
                newLevel >= 50 -> PetStage.LEGENDARY
                newLevel >= 25 -> PetStage.ADULT
                newLevel >= 10 -> PetStage.YOUNG
                newLevel >= 1 -> PetStage.BABY
                else -> PetStage.EGG
            }
        }
    }

    fun getPetBonuses(pet: Pet): Map<String, Float> {
        val stageMultiplier = when (pet.stage) {
            PetStage.EGG -> 0.0f
            PetStage.BABY -> 0.5f
            PetStage.YOUNG -> 0.75f
            PetStage.ADULT -> 1.0f
            PetStage.LEGENDARY -> 1.5f
            PetStage.MYTHIC -> 2.0f
        }
        return mapOf(
            "attack" to pet.attackBonus * stageMultiplier,
            "defense" to pet.defenseBonus * stageMultiplier,
            "health" to pet.healthBonus * stageMultiplier,
            "divinity" to pet.divinityBonus * stageMultiplier,
            "gold" to pet.goldBonus * stageMultiplier
        )
    }

    fun getPetGuide(): String = buildString {
        appendLine("═══ НАРЪЧНИК НА ПИТОМЦИТЕ ═══")
        appendLine()
        appendLine("ЕВОЛЮЦИОННИ ЕТАПИ:")
        PetStage.values().forEach { stage ->
            appendLine("${stage.emoji} ${stage.displayName} (Ниво ${stage.level}+)")
        }
        appendLine()
        appendLine("ПИТОМЦИ ПО РЯДКОСТ:")
        val grouped = ALL_PETS.groupBy { it.rarity }
        listOf("Common", "Uncommon", "Rare", "Epic", "Legendary", "Divine").forEach { rarity ->
            grouped[rarity]?.let { pets ->
                appendLine("\n$rarity:")
                pets.forEach { pet ->
                    appendLine("  ${pet.emoji} ${pet.name} [${pet.mythology}]")
                    appendLine("  ⚔️+${pet.attackBonus} 🛡️+${pet.defenseBonus} ❤️+${pet.healthBonus}")
                    appendLine("  ✨ ${pet.specialAbility}")
                }
            }
        }
    }
}

// ─────────────────────────────────────────────
//  PET EVOLUTION EVENTS
// ─────────────────────────────────────────────

object PetEvolutionEvents {

    val EVOLUTION_MESSAGES = mapOf(
        PetStage.BABY to mapOf(
            "pet_baby_dragon" to "🐲 Игни отвори очи за пръв път! Плюе малки огнени искри!",
            "pet_fennec_anubis" to "🦊 Анубис Фенекът разпери ушите си и претегли душата на мухата!",
            "pet_mini_thor" to "⚡ Мини Тор вдигна Мьолнира! Едва. Но го вдигна!",
            "pet_jade_rabbit" to "🐇 Нефритеният Заек смели първия еликсир! Вкуси добре!",
            "pet_owl_athena" to "🦉 Совата отвори Мъдрото oko! Сега разбира стратегията на врага!",
            "pet_cerberus_pup" to "🐕 Цербер Кученцето показа три опашки! Три пъти по-сладко!",
            "pet_phoenix_chick" to "🐦 Феникс Пилето пламна за пръв път! После се роди отново от пепелта!",
            "pet_chaos_fragment" to "🌀 Хаос Осколокът пулсира! Нещо вътре в него... избира форма!"
        ),
        PetStage.LEGENDARY to mapOf(
            "pet_baby_dragon" to "🐉 ДРАКОН ИГНИ ПРОБУДЕН! Пълен дракон! Огнен Шлейф активиран!",
            "pet_chaos_fragment" to "🌌 ХАОС СТРАЖЪТ ПРОБУДЕН! Всичко около теб трепери!"
        ),
        PetStage.MYTHIC to mapOf(
            "pet_baby_dragon" to "🌌 МИТИЧЕН ДРАКОН ИГНИ! Огън от самия Хаос! +500 ATK!",
            "pet_phoenix_chick" to "🌌 МИТИЧЕН ФЕНИКС! Прераждаш се 3x в битка!",
            "pet_chaos_fragment" to "🌌 АБСОЛЮТЕН ХАОС! Всичко x1.5 + Хаотична Аура!"
        )
    )

    val PET_BOND_DIALOGUES = mapOf(
        "pet_baby_dragon" to listOf(
            "Игни: *ВРРР* (Аз те пазя. Ти ме храниш. Честна сделка.)",
            "Игни: *Плюе малко огън* Извини. Все още тренирам.",
            "Игни: Един ден ще съм толкова голям като Тиамат. Ти ще ми помогнеш?"
        ),
        "pet_cerberus_pup" to listOf(
            "Цербер: ТРИ гласа, ТРИ обичания, ТРИ лапи! Четири? Не, три.",
            "Цербер: Пазим теб! Всичките три глави са съгласни. Рядко.",
            "Цербер: Хадес ни търси. Не му казвай, нали?"
        ),
        "pet_chaos_fragment" to listOf(
            "Хаос: Ти и аз сме едно и също нещо. Само различни форми.",
            "Хаос: Понякога се питам — аз следвам ли теб, или ти мен?",
            "Хаос: Вселената е Хаос. Ти си Хаос. Аз съм Хаос. Уютно."
        )
    )

    val PET_HUNGER_SYSTEM = mapOf(
        "Наситен" to Pair(1.0f, "Питомецът е щастлив и напълно бонус"),
        "Гладен" to Pair(0.75f, "Питомецът е малко тъжен. Дай му нещо."),
        "Много Гладен" to Pair(0.50f, "Питомецът едва помага. Нахрани го!"),
        "Умиращ" to Pair(0.25f, "СПЕШНО! Питомецът губи бонусите!")
    )

    val PET_FOOD_ITEMS = listOf(
        Triple("Дракон Месо", "🥩", "pet_baby_dragon"),
        Triple("Небесен Мед", "🍯", "pet_jade_rabbit"),
        Triple("Мълния Кристал", "⚡", "pet_mini_thor"),
        Triple("Душа Есенция", "💀", "pet_fennec_anubis"),
        Triple("Мъдрост Свитък", "📜", "pet_owl_athena"),
        Triple("Феникс Пепел", "🔥", "pet_phoenix_chick"),
        Triple("Хаос Фрагмент", "🌀", "pet_chaos_fragment"),
        Triple("Подземно Злато", "💰", "pet_cerberus_pup")
    )

    fun getEvolutionMessage(pet: Pet): String? =
        EVOLUTION_MESSAGES[pet.stage]?.get(pet.id)

    fun getPetBondDialogue(petId: String): String {
        val lines = PET_BOND_DIALOGUES[petId] ?: listOf("*мълчание*")
        return lines.random()
    }

    fun getFavoriteFood(petId: String): Triple<String, String, String>? =
        PET_FOOD_ITEMS.firstOrNull { it.third == petId }
}
