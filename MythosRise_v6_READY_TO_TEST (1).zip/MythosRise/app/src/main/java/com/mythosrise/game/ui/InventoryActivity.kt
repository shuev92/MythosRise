package com.mythosrise.game.ui

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.mythosrise.game.R
import com.mythosrise.game.engine.GameEngine
import com.mythosrise.game.models.Item
import com.mythosrise.game.models.ItemType
import com.mythosrise.game.models.Rarity

class InventoryActivity : AppCompatActivity() {

    private lateinit var engine: GameEngine
    private lateinit var llInventory: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)
        engine = GameEngine(this)
        engine.loadGame()

        llInventory = findViewById(R.id.llInventoryList)
        setupEquippedSection()
        setupInventoryList()
        setupStats()
    }

    private fun setupStats() {
        val c = engine.character
        findViewById<TextView>(R.id.tvInvStats).text = """
            ${c.gender.emoji} ${c.name} — ${c.divinityTitle.title}
            Ниво ${c.level} | ✨ ${c.divinity} Дивинити
            ❤️ ${c.health}/${c.getTotalMaxHealth()}  💙 ${c.mana}/${c.maxMana}
            ⚔️ ATK: ${c.getTotalAttack()}  🛡️ DEF: ${c.getTotalDefense()}
            💰 Злато: ${c.gold}
            👹 Победени: ${c.enemiesDefeated} | Богове: ${c.godsDefeated}
        """.trimIndent()
    }

    private fun setupEquippedSection() {
        val c = engine.character
        val equippedText = buildString {
            appendLine("🗡️ Оръжие: ${c.equippedWeapon?.let { "${it.emoji} ${it.name}" } ?: "—"}")
            appendLine("🛡️ Броня: ${c.equippedArmor?.let { "${it.emoji} ${it.name}" } ?: "—"}")
            appendLine("⛑️ Шлем: ${c.equippedHelmet?.let { "${it.emoji} ${it.name}" } ?: "—"}")
            appendLine("👢 Обувки: ${c.equippedBoots?.let { "${it.emoji} ${it.name}" } ?: "—"}")
            appendLine("💍 Пръстен: ${c.equippedRing?.let { "${it.emoji} ${it.name}" } ?: "—"}")
            append("📿 Амулет: ${c.equippedAmulet?.let { "${it.emoji} ${it.name}" } ?: "—"}")
        }
        findViewById<TextView>(R.id.tvEquipped).text = equippedText
    }

    private fun setupInventoryList() {
        llInventory.removeAllViews()
        val inventory = engine.character.inventory

        if (inventory.isEmpty()) {
            val tv = TextView(this).apply {
                text = "Инвентарът е празен"
                setTextColor(Color.GRAY)
                setPadding(16, 16, 16, 16)
            }
            llInventory.addView(tv)
            return
        }

        inventory.groupBy { it.type }.forEach { (type, items) ->
            // Section header
            val header = TextView(this).apply {
                text = when (type) {
                    ItemType.WEAPON -> "⚔️ Оръжия"
                    ItemType.ARMOR -> "🛡️ Броня"
                    ItemType.HELMET -> "⛑️ Шлемове"
                    ItemType.BOOTS -> "👢 Обувки"
                    ItemType.RING -> "💍 Пръстени"
                    ItemType.AMULET -> "📿 Амулети"
                    ItemType.POTION -> "🧪 Еликсири"
                    ItemType.SPECIAL -> "✨ Специални"
                }
                setTextColor(Color.parseColor("#FFD700"))
                textSize = 16f
                setPadding(8, 16, 8, 8)
            }
            llInventory.addView(header)

            items.forEach { item ->
                addItemView(item)
            }
        }
    }

    private fun addItemView(item: Item) {
        val rarityColor = when (item.rarity) {
            Rarity.COMMON -> "#AAAAAA"
            Rarity.UNCOMMON -> "#00AA00"
            Rarity.RARE -> "#4444FF"
            Rarity.EPIC -> "#AA00FF"
            Rarity.LEGENDARY -> "#FF8800"
            Rarity.MYTHIC -> "#FF2200"
            Rarity.DIVINE -> "#FFD700"
        }

        val itemView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1A0A2E"))
            setPadding(16, 12, 16, 12)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 4, 0, 4)
            layoutParams = lp

            setOnClickListener { showItemDetails(item) }
        }

        val emoji = TextView(this).apply {
            text = item.emoji
            textSize = 24f
            setPadding(0, 0, 16, 0)
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val nameView = TextView(this).apply {
            text = item.name
            setTextColor(Color.parseColor(rarityColor))
            textSize = 15f
        }

        val statsText = buildString {
            if (item.attackBonus != 0) append("⚔️+${item.attackBonus} ")
            if (item.defenseBonus != 0) append("🛡️+${item.defenseBonus} ")
            if (item.healthBonus != 0) append("❤️+${item.healthBonus} ")
            if (item.manaBonus != 0) append("💙+${item.manaBonus} ")
            if (item.divinityBonus != 0) append("✨+${item.divinityBonus} ")
        }

        val statsView = TextView(this).apply {
            text = if (statsText.isNotBlank()) statsText else item.description
            setTextColor(Color.LTGRAY)
            textSize = 12f
        }

        info.addView(nameView)
        info.addView(statsView)
        itemView.addView(emoji)
        itemView.addView(info)

        // Rarity indicator
        val rarityView = TextView(this).apply {
            text = item.rarity.displayName
            setTextColor(Color.parseColor(rarityColor))
            textSize = 10f
        }
        itemView.addView(rarityView)

        llInventory.addView(itemView)
    }

    private fun showItemDetails(item: Item) {
        val msg = buildString {
            appendLine("${item.emoji} ${item.name}")
            appendLine("${item.rarity.displayName} | ${item.mythology}")
            appendLine()
            appendLine(item.description)
            appendLine()
            if (item.attackBonus != 0) appendLine("⚔️ Атака: +${item.attackBonus}")
            if (item.defenseBonus != 0) appendLine("🛡️ Защита: +${item.defenseBonus}")
            if (item.healthBonus != 0) appendLine("❤️ Живот: +${item.healthBonus}")
            if (item.manaBonus != 0) appendLine("💙 Мана: +${item.manaBonus}")
            if (item.divinityBonus != 0) appendLine("✨ Дивинити: +${item.divinityBonus}")
            if (item.speedBonus != 0f) appendLine("⚡ Скорост: +${item.speedBonus}")
            if (item.specialEffect.isNotBlank()) appendLine("\n🔮 Ефект: ${item.specialEffect}")
            appendLine("\n💰 Стойност: ${item.value} злато")
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("Информация за предмет")
            .setMessage(msg)
            .setNegativeButton("Затвори", null)

        if (item.type != ItemType.POTION && item.type != ItemType.SPECIAL) {
            builder.setPositiveButton("Екипирай") { _, _ ->
                val result = engine.equipItem(item)
                Toast.makeText(this, result, Toast.LENGTH_SHORT).show()
                engine.saveGame()
                setupEquippedSection()
                setupStats()
            }
        }

        builder.show()
    }
}
