package com.mythosrise.game.engine

import java.util.Calendar

// ─────────────────────────────────────────────
//  SEASON
// ─────────────────────────────────────────────

enum class GameSeason(
    val displayName: String,
    val emoji: String,
    val description: String,
    val goldBonus: Float,
    val expBonus: Float,
    val divinityBonus: Float,
    val specialEffect: String
) {
    SPRING("Пролет", "🌸", "Природата се събужда. Боговете са добре настроени.",
        1.0f, 1.2f, 1.1f, "Лечебните умения лекуват 20% повече"),
    SUMMER("Лято", "☀️", "Горещото лято засилва огнените атаки.",
        1.2f, 1.0f, 1.0f, "Огнените умения нанасят 25% повече урон"),
    AUTUMN("Есен", "🍂", "Времето на жетвата. Злато отвсякъде.",
        1.5f, 1.1f, 1.0f, "Злато от всички врагове +50%"),
    WINTER("Зима", "❄️", "Ледената зима дава ледена сила.",
        1.0f, 1.0f, 1.2f, "Ледените умения замразяват врагове по-дълго"),
    FIMBULWINTER("ФИМБУЛВИНТЕР", "🌨️❄️🌨️", "Скандинавската апокалиптична зима! Рагнарок идва!",
        0.8f, 1.5f, 2.0f, "Всички Norse умения x3, Дивинити x2 — Рагнарок се приближава!"),
    HARVEST_OF_GODS("Жетва на Боговете", "⚡🏺☀️", "Всички митологии са активни едновременно!",
        1.3f, 1.3f, 1.5f, "Боговете от всички митологии дават x2 дивинити при убиване"),
    CHAOS_RIFT("Разлом на Хаоса", "🌀", "Хаосът напуска контейнера! Реалността се разкъсва!",
        1.0f, 1.0f, 3.0f, "Хаотична енергия — всеки убит враг дава случаен бонус")
}

// ─────────────────────────────────────────────
//  WEATHER
// ─────────────────────────────────────────────

enum class GameWeather(
    val displayName: String,
    val emoji: String,
    val effect: String,
    val attackMod: Float,
    val defenseMod: Float,
    val visibilityMod: Float
) {
    CLEAR("Ясно", "☀️", "Нормални условия.", 1.0f, 1.0f, 1.0f),
    RAIN("Дъжд", "🌧️", "Дъждът гаси огън. -20% огнена атака.", 0.9f, 1.0f, 0.8f),
    STORM("Буря", "⛈️", "Мълниите усилват Мълния умения +30%.", 1.3f, 0.8f, 0.6f),
    FOG("Мъгла", "🌫️", "Мъглата намалява точността -15%.", 0.85f, 1.1f, 0.4f),
    SNOWFALL("Снеговалеж", "🌨️", "Снегът усилва Лед умения +25%.", 1.25f, 0.9f, 0.7f),
    HEATWAVE("Жегa", "🌡️", "Огненият ад. Огнена атака +40%.", 1.4f, 0.85f, 1.0f),
    DIVINE_AURORA("Божествена Аврора", "🌌", "Аврора усилва Дивинити с 50%.", 1.0f, 1.0f, 1.0f),
    BLOOD_MOON("Кървава Луна", "🌕", "Боговете гледат. Дивинити x2. Опасност x2.", 1.5f, 0.7f, 0.9f),
    ECLIPSE("Слънчево Затъмнение", "🌑", "Апеп е близо! Сянката побеждава Светлината.", 1.2f, 0.9f, 0.5f)
}

// ─────────────────────────────────────────────
//  SEASONAL EVENTS
// ─────────────────────────────────────────────

data class SeasonalEvent(
    val id: String,
    val name: String,
    val emoji: String,
    val description: String,
    val month: Int,           // 1-12, 0 = any
    val bonuses: Map<String, Float>,
    val specialEnemies: List<String>,
    val specialDrops: List<String>,
    val lore: String,
    val durationDays: Int
)

object SeasonalEventManager {

    val ALL_EVENTS = listOf(
        SeasonalEvent(
            id = "event_olympian_games",
            name = "Олимпийски Игри",
            emoji = "🏛️🏆",
            description = "Боговете провеждат Олимпийски игри! Участвай и спечели!",
            month = 8,
            bonuses = mapOf("gold" to 2.0f, "exp" to 1.5f),
            specialEnemies = listOf("Olympic Champion", "Hermes Runner"),
            specialDrops = listOf("Golden Laurel", "Olympic Shield"),
            lore = "Всеки 4 години боговете спират войните за Игрите. Дори ти можеш да участваш.",
            durationDays = 14
        ),
        SeasonalEvent(
            id = "event_ragnarok_warning",
            name = "Предупреждение за Рагнарок",
            emoji = "🌋⚡",
            description = "Фенрир вие. Нидхог гризе. Рагнарок идва! Norse врагове са навсякъде.",
            month = 11,
            bonuses = mapOf("divinity" to 2.5f, "norse_drop" to 3.0f),
            specialEnemies = listOf("Pre-Ragnarok Warrior", "Frost Giant Berserker"),
            specialDrops = listOf("Bifrost Fragment", "Yggdrasil Seed"),
            lore = "Фимбулвинтерът е 3 години зима преди Рагнарок. Ние сме в края на третата.",
            durationDays = 7
        ),
        SeasonalEvent(
            id = "event_dragon_festival",
            name = "Фестивал на Дракони",
            emoji = "🐉🎉",
            description = "Китайски Нова Година! Дракони навсякъде! +200% Дракон Drops!",
            month = 2,
            bonuses = mapOf("dragon_drop" to 3.0f, "gold" to 1.5f),
            specialEnemies = listOf("Festival Dragon", "Jade Dragon"),
            specialDrops = listOf("Dragon Pearl", "Festival Lantern", "Lucky Red Envelope"),
            lore = "В Китай Дракон Кралете слизат на земята за Нова Година. Имат дарове — и зъби.",
            durationDays = 15
        ),
        SeasonalEvent(
            id = "event_halloween_underworld",
            name = "Нощ на Подземния Свят",
            emoji = "🎃💀",
            description = "Портите между световете са отворени! Мъртви, демони и богове на смъртта!",
            month = 10,
            bonuses = mapOf("shadow_dmg" to 2.0f, "exp" to 2.0f),
            specialEnemies = listOf("Undead God", "Risen Titan", "Ghost Pharaoh"),
            specialDrops = listOf("Soul Crystal", "Death God Mask", "Underworld Key"),
            lore = "Раз в годината Хадес, Анубис и Яма се събират. Нощта е тяхна.",
            durationDays = 7
        ),
        SeasonalEvent(
            id = "event_summer_solstice",
            name = "Лятно Слънцестоене",
            emoji = "☀️🔥",
            description = "Ра, Аматерасу и Аполон дават максимална светлина! Огнени умения x3!",
            month = 6,
            bonuses = mapOf("fire_dmg" to 3.0f, "holy_dmg" to 2.0f, "divinity" to 1.5f),
            specialEnemies = listOf("Solar Champion", "Ra's Guardian"),
            specialDrops = listOf("Sunstone", "Ra's Eye", "Solar Armor"),
            lore = "Най-дългият ден. Боговете на слънцето са в пълна сила.",
            durationDays = 3
        )
    )

    fun getCurrentSeason(): GameSeason {
        val month = Calendar.getInstance().get(Calendar.MONTH) + 1
        return when (month) {
            3, 4, 5 -> GameSeason.SPRING
            6, 7, 8 -> GameSeason.SUMMER
            9, 10, 11 -> GameSeason.AUTUMN
            else -> GameSeason.WINTER
        }
    }

    fun getCurrentWeather(): GameWeather {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val seed = (day * 24 + hour) % GameWeather.values().size
        val weights = listOf(
            GameWeather.CLEAR to 30,
            GameWeather.RAIN to 20,
            GameWeather.STORM to 10,
            GameWeather.FOG to 10,
            GameWeather.SNOWFALL to 8,
            GameWeather.HEATWAVE to 8,
            GameWeather.DIVINE_AURORA to 5,
            GameWeather.BLOOD_MOON to 5,
            GameWeather.ECLIPSE to 4
        )
        var total = 0
        val rng = java.util.Random(seed.toLong())
        val roll = rng.nextInt(100)
        for ((weather, weight) in weights) {
            total += weight
            if (roll < total) return weather
        }
        return GameWeather.CLEAR
    }

    fun getActiveEvent(): SeasonalEvent? {
        val month = Calendar.getInstance().get(Calendar.MONTH) + 1
        return ALL_EVENTS.firstOrNull { it.month == month || it.month == 0 }
    }

    fun getSeasonDescription(): String {
        val season = getCurrentSeason()
        val weather = getCurrentWeather()
        val event = getActiveEvent()
        return buildString {
            appendLine("${season.emoji} ${season.displayName}")
            appendLine(season.description)
            appendLine("⚡ ${season.specialEffect}")
            appendLine()
            appendLine("${weather.emoji} Времето: ${weather.displayName}")
            appendLine(weather.effect)
            event?.let {
                appendLine()
                appendLine("🎉 СЪБИТИЕ: ${it.name}")
                appendLine(it.description)
            }
        }
    }

    fun applySeasonBonuses(baseAmount: Int, type: String): Int {
        val season = getCurrentSeason()
        val weather = getCurrentWeather()
        var mult = 1.0f
        when (type) {
            "gold" -> mult = season.goldBonus
            "exp" -> mult = season.expBonus
            "divinity" -> {
                mult = season.divinityBonus
                if (weather == GameWeather.DIVINE_AURORA) mult *= 1.5f
                if (weather == GameWeather.BLOOD_MOON) mult *= 2.0f
            }
            "fire_dmg" -> if (weather == GameWeather.HEATWAVE) mult = 1.4f
            "ice_dmg" -> if (weather == GameWeather.SNOWFALL) mult = 1.25f
            "lightning_dmg" -> if (weather == GameWeather.STORM) mult = 1.3f
        }
        return (baseAmount * mult).toInt()
    }
}

// ─────────────────────────────────────────────
//  SEASONAL REWARDS
// ─────────────────────────────────────────────

object SeasonalRewards {
    data class SeasonReward(
        val name: String, val emoji: String, val description: String,
        val goldBonus: Int, val divinityBonus: Int, val season: GameSeason
    )

    val ALL_SEASONAL_REWARDS = listOf(
        SeasonReward("Пролетен Амулет", "🌸", "Лечебните умения +20%. Природата цъфти.",
            500, 100, GameSeason.SPRING),
        SeasonReward("Слънчев Кристал", "☀️", "Огнени умения +25%. Лятна жега.",
            800, 150, GameSeason.SUMMER),
        SeasonReward("Есенна Жетва", "🍂", "Злато от всичко +50%. Времето на реколтата.",
            2000, 200, GameSeason.AUTUMN),
        SeasonReward("Зимна Руна", "❄️", "Ледени умения +25%. Скандинавска зима.",
            600, 200, GameSeason.WINTER),
        SeasonReward("Фимбулвинтер Пергамент", "🌨️", "Norse умения x3! Апокалипсис идва!",
            1000, 1000, GameSeason.FIMBULWINTER),
        SeasonReward("Жетва на Боговете Медал", "⚡", "Всички богове дават x2 дивинити.",
            1500, 750, GameSeason.HARVEST_OF_GODS),
        SeasonReward("Хаосен Осколок", "🌀", "Хаотична енергия. Случаен бонус на всеки ход.",
            500, 2000, GameSeason.CHAOS_RIFT)
    )

    fun getCurrentSeasonReward(): SeasonReward? {
        val season = SeasonalEventManager.getCurrentSeason()
        return ALL_SEASONAL_REWARDS.firstOrNull { it.season == season }
    }

    fun getWeatherBonusDescription(): String {
        val weather = SeasonalEventManager.getCurrentWeather()
        return buildString {
            appendLine("${weather.emoji} ${weather.displayName}")
            appendLine(weather.effect)
            appendLine("⚔️ ATK мод: x${weather.attackMod}")
            appendLine("🛡️ DEF мод: x${weather.defenseMod}")
        }
    }
}

// ─────────────────────────────────────────────
//  SEASONAL BOSS EVENTS
// ─────────────────────────────────────────────

object SeasonalBossEvents {

    data class SeasonalBoss(
        val id: String,
        val name: String,
        val emoji: String,
        val description: String,
        val season: String,
        val health: Int,
        val attack: Int,
        val defense: Int,
        val goldReward: Int,
        val divinityReward: Int,
        val uniqueReward: String,
        val availableDays: Int,
        val respawnDays: Int,
        val preDialogue: String,
        val defeatDialogue: String,
        val lore: String
    )

    val ALL_SEASONAL_BOSSES = listOf(
        SeasonalBoss(
            id = "sb_winter_fenrir", name = "Зимният Фенрир", emoji = "🐺",
            description = "Фенрир отключен преди Рагнарок. Вие сте виновни. Малко.",
            season = "Fimbulwinter", health = 50000, attack = 1200, defense = 400,
            goldReward = 30000, divinityReward = 2000, uniqueReward = "Фенрир Кожа за Оръжие",
            availableDays = 7, respawnDays = 30,
            preDialogue = "Свободен! Рагнарок идва! Един не може да ме спре!",
            defeatDialogue = "Веригите... отново... Но не за дълго...",
            lore = "Фенрир е вързан от Гладр — нишката от Нежни. Яде Един при Рагнарок. Или опитва."
        ),
        SeasonalBoss(
            id = "sb_summer_kronos", name = "Лятното Слънце Кронос", emoji = "🌞",
            description = "При Лятното Слънцестоене силата на Кронос е максимална.",
            season = "Summer", health = 45000, attack = 1000, defense = 500,
            goldReward = 25000, divinityReward = 1500, uniqueReward = "Кронос Хронометър (забавя врагове)",
            availableDays = 3, respawnDays = 365,
            preDialogue = "Слънцестоенето е моята сила. Времето се подчинява.",
            defeatDialogue = "Времето... не е на моя страна... за сега...",
            lore = "Кронос е бог на Времето (различен от Кронос-Титана). Или са едно и също. Гръцката митология е сложна."
        ),
        SeasonalBoss(
            id = "sb_harvest_osiris", name = "Жетвеният Озирис", emoji = "🌾",
            description = "Озирис се появява при Жетвата — бог на смъртта и прераждането.",
            season = "HarvestOfGods", health = 55000, attack = 900, defense = 600,
            goldReward = 35000, divinityReward = 2500, uniqueReward = "Озирис Корона (+20% всички магии)",
            availableDays = 14, respawnDays = 90,
            preDialogue = "Смъртта и прераждането са цикъл. Ти ще бъдеш частта от цикъла.",
            defeatDialogue = "Ще се прероди... Така е. Винаги е така.",
            lore = "Озирис е убит от Сет. Съживен от Изида. Стана бог на Подземния свят. Имплементира справедлив съд."
        ),
        SeasonalBoss(
            id = "sb_chaos_rift_avatar", name = "Хаос Аватар", emoji = "🌀",
            description = "Хаос Рифтът отвори портал. Аватарът на самия Хаос е тук.",
            season = "ChaosRift", health = 100000, attack = 2000, defense = 1000,
            goldReward = 100000, divinityReward = 10000, uniqueReward = "🌌 ХАОС АВАТАР КОЖА — ексклузивна",
            availableDays = 3, respawnDays = 180,
            preDialogue = "Победи ме при Хаос Рифта? Амбициозно. Невероятно. Почти невъзможно.",
            defeatDialogue = "Хаосът не умира... само сменя форма... Ти знаеш това вече...",
            lore = "Хаос Аватарът е проекция на истинския Хаос. По-слаб от оригинала. Само леко."
        ),
        SeasonalBoss(
            id = "sb_spring_persephone", name = "Пролетната Персефона", emoji = "🌸",
            description = "Персефона се завръща от Хадес. Носи пролетта. И сила.",
            season = "Spring", health = 35000, attack = 700, defense = 350,
            goldReward = 20000, divinityReward = 1000, uniqueReward = "Пролетни Цветя (Aura ефект)",
            availableDays = 21, respawnDays = 365,
            preDialogue = "Върнах се! И не съм щастлива, че ме прекъсваш.",
            defeatDialogue = "Хадес ще чуе за това... Гарантирам...",
            lore = "Персефона е дъщеря на Деметра. Половин годишно е с Хадес. Деметра тъгува — зима е. Тя се завръща — пролет."
        )
    )

    val SEASONAL_BOSS_TIPS = listOf(
        "💡 Сезонните Босове се появяват само в конкретни сезони!",
        "💡 Зимният Фенрир дава уникална кожа — само 7 дни!",
        "💡 Хаос Аватарът е САМО на 3 дни на 180 дни!",
        "💡 Използвай Guild Баф преди Сезонен Бос за +20% ATK!",
        "💡 Сезонните Босове дават Battle Pass EXP x3!",
        "💡 Пощади Сезонния Бос? Получаваш +200 Отношение с бога!"
    )

    fun getCurrentSeasonalBoss(currentSeason: String): SeasonalBoss? =
        ALL_SEASONAL_BOSSES.firstOrNull { it.season == currentSeason }

    fun getUpcomingBosses(): List<Pair<String, SeasonalBoss>> {
        val seasons = listOf("Spring", "Summer", "Autumn", "Winter", "Fimbulwinter", "HarvestOfGods", "ChaosRift")
        return seasons.mapNotNull { season ->
            ALL_SEASONAL_BOSSES.firstOrNull { it.season == season }?.let { season to it }
        }
    }

    fun getBossLoreText(bossId: String): String {
        val boss = ALL_SEASONAL_BOSSES.firstOrNull { it.id == bossId } ?: return "Неизвестен бос."
        return buildString {
            appendLine("${boss.emoji} ${boss.name}")
            appendLine("━━━━━━━━━━━━━━━━")
            appendLine("📖 ${boss.lore}")
            appendLine()
            appendLine("⚔️ ATK: ${boss.attack} | 🛡️ DEF: ${boss.defense} | ❤️ HP: ${boss.health}")
            appendLine("💰 Злато: ${boss.goldReward} | ✨ Дивинити: ${boss.divinityReward}")
            appendLine("🎁 Уникална награда: ${boss.uniqueReward}")
            appendLine("📅 Достъпен: ${boss.availableDays} дни | Респ: ${boss.respawnDays} дни")
            appendLine()
            appendLine("💬 \"${boss.preDialogue}\"")
        }
    }
}

// ─────────────────────────────────────────────
//  WEATHER EFFECTS EXPANDED
// ─────────────────────────────────────────────

object WeatherEffectsExpanded {

    val WEATHER_ENEMY_BEHAVIOR = mapOf(
        "Storm" to "Враговете са озверени! +20% ATK за всички. Мълниите атакуват случайно.",
        "BloodMoon" to "Нежити и демони са ТРОЙНО по-силни! Всички останали +50% ATK.",
        "Eclipse" to "Видимостта е нулева. Критичните удари вероятно пропускат.",
        "DivinAurora" to "Боговете наблюдават. Всеки убит враг дава +10 Дивинити екстра.",
        "Fog" to "Засади! Врагове се появяват от нищото. Нямаш предупреждение.",
        "Heatwave" to "Огнените врагове са имунни. Ледените врагове са слаби x3.",
        "Snowfall" to "Скоростта на движение -20% за всички. Ледените атаки x2.",
        "Rain" to "Мълниите x1.5. Огънят -30%. Плъзга при тичане.",
        "Clear" to "Идеали условия. Нормален геймплей. Рядко в митологиите."
    )

    val WEATHER_LOOT_MODIFIERS = mapOf(
        "BloodMoon" to 3.0f,
        "DivinAurora" to 2.0f,
        "Storm" to 1.5f,
        "Eclipse" to 1.3f,
        "Clear" to 1.0f,
        "Fog" to 0.8f,
        "Rain" to 1.2f,
        "Snowfall" to 1.1f,
        "Heatwave" to 1.4f
    )

    fun getWeatherLootMultiplier(weather: String): Float =
        WEATHER_LOOT_MODIFIERS[weather] ?: 1.0f

    fun getWeatherEnemyInfo(weather: String): String =
        WEATHER_ENEMY_BEHAVIOR[weather] ?: "Нормални условия."

    val WEATHER_SPECIAL_SPAWNS = mapOf(
        "BloodMoon" to listOf("Кръвен Вампир", "Кървящ Демон", "Лунен Лъже-бог"),
        "DivinAurora" to listOf("Аурален Страж", "Дивинити Призрак", "Небесен Пазач"),
        "Storm" to listOf("Гръмов Елементал", "Мълния Дух", "Буреносен Дракон"),
        "Eclipse" to listOf("Сянка Асасин", "Тъмен Маг", "Слепият Оракул")
    )

    fun getSpecialSpawns(weather: String): List<String> =
        WEATHER_SPECIAL_SPAWNS[weather] ?: emptyList()

    fun buildWeatherReport(season: String, weather: String, event: String?): String = buildString {
        appendLine("🌍 ТЕКУЩО ВРЕМЕТО")
        appendLine("━━━━━━━━━━━━━")
        appendLine("📅 Сезон: $season")
        appendLine("🌤️ Времето: $weather")
        event?.let { appendLine("🎉 Събитие: $it") }
        appendLine()
        appendLine("⚠️ Ефекти: ${getWeatherEnemyInfo(weather)}")
        appendLine("💰 Лут Множител: x${getWeatherLootMultiplier(weather)}")
        val spawns = getSpecialSpawns(weather)
        if (spawns.isNotEmpty()) {
            appendLine()
            appendLine("👹 Специални Врагове:")
            spawns.forEach { appendLine("  • $it") }
        }
    }
}
